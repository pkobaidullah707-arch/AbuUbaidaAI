package com.abuubaida.ai.video

import android.content.Context
import android.net.Uri
import com.abuubaida.ai.data.ai.GeminiAssistantRepository
import com.abuubaida.ai.data.model.VideoProject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Pluggable Video Generation API Provider interface (e.g., Veo / Vertex AI / external video backend).
 * When a video generation provider is connected, exportMp4() saves the rendered MP4 file.
 */
interface VideoGenerationProvider {
    val providerNameBn: String
    val isConnected: Boolean
    suspend fun generateMp4(prompt: String, outputFile: File): Result<Uri>
}

class UnconnectedVideoProvider : VideoGenerationProvider {
    override val providerNameBn: String = "ভিডিও জেনারেশন প্রোভাইডার সংযুক্ত নয়"
    override val isConnected: Boolean = false

    override suspend fun generateMp4(prompt: String, outputFile: File): Result<Uri> {
        return Result.failure(
            IllegalStateException(
                "MP4 ভিডিও তৈরি করতে একটি বাহ্যিক ভিডিও-জেনারেশন API প্রোভাইডার (যেমন Veo / Vertex AI ব্যাকএন্ড) সংযুক্ত করা প্রয়োজন। " +
                    "বর্তমানে আপনার বাংলা চিত্রনাট্য, SEO এবং থাম্বনেইল প্রম্পট ব্যবহারের জন্য সম্পূর্ণ প্রস্তুত।"
            )
        )
    }
}

class VideoStudioRepository(
    private val context: Context,
    private val geminiRepo: GeminiAssistantRepository,
    private val videoProvider: VideoGenerationProvider = LocalMp4VideoProvider(context)
) {
    suspend fun createProjectFromTopic(topic: String): Result<VideoProject> {
        val cleanTopic = topic.trim().ifBlank { "সফল জীবনের ৫টি গুরুত্বপূর্ণ উপদেশ" }
        val aiRes = geminiRepo.generateVideoPackage(cleanTopic)
        return aiRes.fold(
            onSuccess = { project -> Result.success(project) },
            onFailure = {
                Result.success(buildOfflineYouTubeContentPackage(cleanTopic))
            }
        )
    }

    private fun buildOfflineYouTubeContentPackage(topic: String): VideoProject {
        val cleanTitle = "$topic — সম্পূর্ণ বাংলা গাইড ও বিস্তারিত আলোচনা | আবু উবাইদা AI"
        val script = buildString {
            appendLine("[০:০০ - ০:১৫ | সূচনা ও হুক]")
            appendLine("আসসালামু আলাইকুম! আজকের ভিডিওর বিষয় হলো \"$topic\"।")
            appendLine("শেষ পর্যন্ত দেখলে আপনি এই বিষয়ের সবচেয়ে গুরুত্বপূর্ণ তথ্য ও বাস্তব উপকারিতা পরিষ্কারভাবে জানতে পারবেন।")
            appendLine()
            appendLine("[০:১৫ - ১:০০ | মূল আলোচনা - ধাপ ১]")
            appendLine("\"$topic\" সম্পর্কে প্রথম ও সবচেয়ে জরুরি কথা হলো সঠিক নিয়ত ও স্পষ্ট ধারণা রাখা।")
            appendLine("আমরা দৈনন্দিন জীবনে বিষয়টি সহজভাবে প্রয়োগ করলে দ্রুত ভালো ফল পেতে পারি।")
            appendLine()
            appendLine("[১:০০ - ১:৪৫ | মূল আলোচনা - ধাপ ২]")
            appendLine("দ্বিতীয়ত, নিয়মিত অনুশীলন এবং নির্ভরযোগ্য উৎস থেকে শেখা আমাদের জ্ঞান ও দক্ষতা অনেক বাড়িয়ে দেয়।")
            appendLine("ভিডিওতে দেখানো প্রতিটি পয়েন্ট নোট করে রাখুন এবং বাস্তব জীবনে কাজে লাগান।")
            appendLine()
            appendLine("[১:৪৫ - ২:১৫ | সমাপ্তি ও কল-টু-অ্যাকশন]")
            appendLine("আজকের \"$topic\" নিয়ে আলোচনাটি ভালো লাগলে ভিডিওতে একটি লাইক দিন, প্রিয়জনদের সাথে শেয়ার করুন এবং চ্যানেলটি সাবস্ক্রাইব করে পাশে থাকুন। জাযাকাল্লাহু খাইরান!")
        }
        val description = buildString {
            appendLine("এই ভিডিওতে \"$topic\" বিষয়ে সহজ ও প্রাঞ্জল বাংলায় বিস্তারিত আলোচনা করা হয়েছে।")
            appendLine()
            appendLine("ভিডিওর অংশসমূহ:")
            appendLine("00:00 সূচনা ও মূল ধারণা")
            appendLine("00:15 প্রথম গুরুত্বপূর্ণ দিক")
            appendLine("01:00 দ্বিতীয় বাস্তব প্রয়োগ")
            appendLine("01:45 উপসংহার ও পরবর্তী ভিডিও")
            appendLine()
            appendLine("#বাংলাভিডিও #YouTubeBangladesh #AbuUbaidaAI #শিক্ষণীয়")
        }
        val tags = listOf(
            topic,
            "$topic বাংলা",
            "আবু উবাইদা AI",
            "বাংলা ইউটিউব ভিডিও",
            "Bangla Content",
            "ইসলামিক ও শিক্ষণীয়",
            "Bangladesh YouTube"
        )
        val thumbPrompts = listOf(
            "YouTube thumbnail in 16:9, bold deep navy blue and radiant gold gradient, dramatic studio lighting, clean focal subject representing '$topic', crisp high contrast 4K graphic design",
            "Minimalist premium creator YouTube thumbnail with glowing electric blue and imperial gold accents, space for large Bengali headline text about '$topic', ultra sharp 4K"
        )
        return VideoProject(
            topic = topic,
            script = script,
            seoTitle = cleanTitle,
            seoDescription = description,
            seoTags = tags,
            thumbnailPrompts = thumbPrompts,
            providerStatusBn = "সম্পূর্ণ বাংলা স্ক্রিপ্ট, SEO ও থাম্বনেইল প্রম্পট প্রস্তুত (অফলাইন স্টুডিও মোড)।"
        )
    }

    fun isMp4ProviderConnected(): Boolean = videoProvider.isConnected

    fun getProviderStatusMessageBn(): String = videoProvider.providerNameBn

    suspend fun exportMp4IfConnected(project: VideoProject): Result<Uri> = withContext(Dispatchers.IO) {
        if (!videoProvider.isConnected) {
            return@withContext videoProvider.generateMp4(project.topic, File(context.cacheDir, "placeholder.mp4"))
        }
        val outDir = File(context.filesDir, "abu_ubaida_videos").apply { mkdirs() }
        val file = File(outDir, "AbuUbaida_${System.currentTimeMillis()}.mp4")
        if (videoProvider is LocalMp4VideoProvider) {
            videoProvider.renderProjectSlidesMp4(project, file)
        } else {
            videoProvider.generateMp4(
                prompt = project.thumbnailPrompts.firstOrNull() ?: project.topic,
                outputFile = file
            )
        }
    }

    suspend fun exportScriptTextPackage(project: VideoProject): Result<File> = withContext(Dispatchers.IO) {
        return@withContext try {
            val outDir = File(context.filesDir, "abu_ubaida_scripts").apply { mkdirs() }
            val safeName = "script_${System.currentTimeMillis()}.txt"
            val file = File(outDir, safeName)
            val content = buildString {
                appendLine("=== আবু উবাইদা AI ভিডিও স্টুডিও প্যাকেজ ===")
                appendLine("বিষয়: ${project.topic}")
                appendLine()
                appendLine("SEO শিরোনাম: ${project.seoTitle}")
                appendLine("SEO বর্ণনা: ${project.seoDescription}")
                appendLine("ট্যাগসমূহ: ${project.seoTags.joinToString(", ")}")
                appendLine()
                appendLine("--- চিত্রনাট্য (Script) ---")
                appendLine(project.script)
                appendLine()
                appendLine("--- থাম্বনেইল ইমেজ প্রম্পট ---")
                project.thumbnailPrompts.forEachIndexed { idx, p ->
                    appendLine("${idx + 1}. $p")
                }
            }
            file.writeText(content)
            Result.success(file)
        } catch (e: Exception) {
            Result.failure(IllegalStateException("স্ক্রিপ্ট সংরক্ষণ করা যায়নি: ${e.localizedMessage}"))
        }
    }
}
