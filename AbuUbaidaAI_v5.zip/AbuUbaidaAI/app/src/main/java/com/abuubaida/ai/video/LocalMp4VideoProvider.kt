package com.abuubaida.ai.video

import android.content.ContentValues
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.abuubaida.ai.data.model.VideoProject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream

/**
 * ডিভাইসের ভেতরেই অফলাইনে বাংলা টাইটেল ও দৃশ্য কার্ডসহ MP4 ভিডিও তৈরি করে
 * এবং গ্যালারি / YouTube স্টুডিওতে আপলোডের জন্য সেভ করে।
 */
class LocalMp4VideoProvider(private val context: Context) : VideoGenerationProvider {

    override val providerNameBn: String = "অফলাইন অন-ডিভাইস MP4 ভিডিও স্টুডিও (সক্রিয়)"
    override val isConnected: Boolean = true

    override suspend fun generateMp4(prompt: String, outputFile: File): Result<Uri> {
        return renderProjectSlidesMp4(
            VideoProject(
                topic = prompt,
                seoTitle = prompt,
                script = prompt
            ),
            outputFile
        )
    }

    suspend fun renderProjectSlidesMp4(
        project: VideoProject,
        internalOutputFile: File
    ): Result<Uri> = withContext(Dispatchers.IO) {
        val slides = buildSlidesFromProject(project)
        val width = 1280
        val height = 720
        val fps = 10
        val framesPerSlide = 25 // 2.5 seconds per slide

        var codec: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var surface: android.view.Surface? = null
        var muxerStarted = false

        try {
            internalOutputFile.parentFile?.mkdirs()
            if (internalOutputFile.exists()) internalOutputFile.delete()

            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, 2_000_000)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }

            codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            surface = codec.createInputSurface()
            codec.start()

            muxer = MediaMuxer(internalOutputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val bufferInfo = MediaCodec.BufferInfo()
            var trackIndex = -1
            var writtenFrames = 0L
            val frameDurationUs = 1_000_000L / fps

            fun drainEncoder(endOfStream: Boolean) {
                if (endOfStream) {
                    codec.signalEndOfInputStream()
                }
                while (true) {
                    val outIndex = codec.dequeueOutputBuffer(bufferInfo, 10_000L)
                    when {
                        outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                            if (!endOfStream) break
                        }
                        outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            if (!muxerStarted) {
                                trackIndex = muxer.addTrack(codec.outputFormat)
                                muxer.start()
                                muxerStarted = true
                            }
                        }
                        outIndex >= 0 -> {
                            val encoded = codec.getOutputBuffer(outIndex)
                            if (encoded != null) {
                                if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                                    bufferInfo.size = 0
                                }
                                if (bufferInfo.size > 0 && muxerStarted) {
                                    encoded.position(bufferInfo.offset)
                                    encoded.limit(bufferInfo.offset + bufferInfo.size)
                                    bufferInfo.presentationTimeUs = writtenFrames * frameDurationUs
                                    writtenFrames++
                                    muxer.writeSampleData(trackIndex, encoded, bufferInfo)
                                }
                            }
                            codec.releaseOutputBuffer(outIndex, false)
                            if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                                break
                            }
                        }
                    }
                }
            }

            slides.forEachIndexed { slideIdx, slide ->
                for (frame in 0 until framesPerSlide) {
                    val canvas: Canvas = surface.lockCanvas(null)
                    try {
                        val progress = (frame + 1).toFloat() / framesPerSlide.toFloat()
                        drawSlide(canvas, width, height, slide.first, slide.second, slideIdx + 1, slides.size, progress)
                    } finally {
                        surface.unlockCanvasAndPost(canvas)
                    }
                    drainEncoder(false)
                }
            }
            drainEncoder(true)

            val savedUri = publishToMediaStoreOrFileUri(internalOutputFile)
            Result.success(savedUri)
        } catch (e: Exception) {
            Result.failure(IllegalStateException("MP4 ভিডিও রেন্ডার করা যায়নি: ${e.localizedMessage ?: "অজানা ত্রুটি"}"))
        } finally {
            try {
                surface?.release()
            } catch (_: Exception) {
            }
            try {
                codec?.stop()
                codec?.release()
            } catch (_: Exception) {
            }
            try {
                if (muxerStarted) muxer?.stop()
                muxer?.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun publishToMediaStoreOrFileUri(internalFile: File): Uri {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, internalFile.name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/AbuUbaidaAI")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(internalFile).use { input ->
                            input.copyTo(out)
                        }
                    }
                    val doneValues = ContentValues().apply {
                        put(MediaStore.Video.Media.IS_PENDING, 0)
                    }
                    resolver.update(uri, doneValues, null, null)
                    return uri
                }
            } catch (_: Exception) {
            }
        }
        return Uri.fromFile(internalFile)
    }

    private fun buildSlidesFromProject(project: VideoProject): List<Pair<String, String>> {
        val slides = mutableListOf<Pair<String, String>>()
        val title = project.seoTitle.ifBlank { project.topic }.ifBlank { "আবু উবাইদা AI ভিডিও" }
        slides.add("আবু উবাইদা AI · YouTube স্টুডিও" to title)

        val scriptLines = project.script
            .lines()
            .map { it.trim() }
            .filter { it.length >= 8 }

        val chunkSize = 3
        val chunks = scriptLines.chunked(chunkSize).take(4)
        chunks.forEachIndexed { idx, group ->
            slides.add("দৃশ্য ${idx + 1}" to group.joinToString("\n"))
        }

        if (slides.size < 3) {
            slides.add("মূল বার্তা" to (project.seoDescription.ifBlank { project.topic }))
        }
        slides.add("ধন্যবাদ ও সাবস্ক্রাইব করুন" to "ভিডিওটি ভালো লাগলে লাইক, শেয়ার ও চ্যানেলটি সাবস্ক্রাইব করুন।")
        return slides
    }

    private fun drawSlide(
        canvas: Canvas,
        width: Int,
        height: Int,
        header: String,
        body: String,
        slideNum: Int,
        totalSlides: Int,
        progress: Float
    ) {
        val bgPaint = Paint().apply {
            shader = LinearGradient(
                0f, 0f, width.toFloat(), height.toFloat(),
                intArrayOf(Color.parseColor("#060B18"), Color.parseColor("#0B1633"), Color.parseColor("#121E3D")),
                null,
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Outer gold border card
        val cardRect = RectF(64f, 64f, width - 64f, height - 64f)
        val cardFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(190, 18, 30, 61)
        }
        val cardStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 4f
            color = Color.parseColor("#D4AF37")
        }
        canvas.drawRoundRect(cardRect, 28f, 28f, cardFill)
        canvas.drawRoundRect(cardRect, 28f, 28f, cardStroke)

        // Header badge text
        val headerPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FCD34D")
            textSize = 34f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText(header, 110f, 145f, headerPaint)

        // Slide counter
        val counterPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#38BDF8")
            textSize = 26f
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText("$slideNum / $totalSlides", width - 110f, 142f, counterPaint)

        // Divider
        val linePaint = Paint().apply {
            color = Color.parseColor("#2563EB")
            strokeWidth = 3f
        }
        canvas.drawLine(110f, 172f, width - 110f, 172f, linePaint)

        // Body text with StaticLayout (supports Bengali multiline wrapping)
        val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F8FAFC")
            textSize = 40f
        }
        val textWidth = (width - 220).coerceAtLeast(300)
        val layout = StaticLayout.Builder
            .obtain(body, 0, body.length, bodyPaint, textWidth)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(14f, 1.0f)
            .setMaxLines(7)
            .build()

        canvas.save()
        canvas.translate(110f, 225f)
        layout.draw(canvas)
        canvas.restore()

        // Progress bar at bottom
        val barLeft = 110f
        val barRight = width - 110f
        val barTop = height - 104f
        val barBottom = height - 92f
        val barBg = Paint().apply { color = Color.parseColor("#1E325C") }
        val barFg = Paint().apply { color = Color.parseColor("#D4AF37") }
        canvas.drawRoundRect(RectF(barLeft, barTop, barRight, barBottom), 6f, 6f, barBg)
        canvas.drawRoundRect(
            RectF(barLeft, barTop, barLeft + (barRight - barLeft) * progress, barBottom),
            6f,
            6f,
            barFg
        )
    }
}
