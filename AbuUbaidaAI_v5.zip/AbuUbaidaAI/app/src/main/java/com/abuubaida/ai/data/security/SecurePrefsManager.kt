package com.abuubaida.ai.data.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.abuubaida.ai.data.model.AssistantSettings
import com.abuubaida.ai.data.model.ChatMessage
import org.json.JSONArray
import org.json.JSONObject

class SecurePrefsManager(context: Context) {

    private val prefs: SharedPreferences = createEncryptedPrefs(context)

    private fun createEncryptedPrefs(context: Context): SharedPreferences {
        return try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                "abu_ubaida_secure_prefs",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (_: Exception) {
            context.getSharedPreferences("abu_ubaida_fallback_prefs", Context.MODE_PRIVATE)
        }
    }

    fun loadSettings(): AssistantSettings {
        return AssistantSettings(
            wakePhrase = prefs.getString(KEY_WAKE_PHRASE, DEFAULT_WAKE_PHRASE) ?: DEFAULT_WAKE_PHRASE,
            ttsEnabled = prefs.getBoolean(KEY_TTS_ENABLED, true),
            continuousVoiceMode = prefs.getBoolean(KEY_CONTINUOUS_VOICE, false),
            backgroundServiceEnabled = prefs.getBoolean(KEY_BG_SERVICE_ENABLED, false),
            proxyEndpointUrl = prefs.getString(KEY_PROXY_URL, "") ?: "",
            speechLanguageTag = prefs.getString(KEY_SPEECH_LANG, "bn-BD") ?: "bn-BD"
        )
    }

    fun saveSettings(settings: AssistantSettings) {
        prefs.edit()
            .putString(KEY_WAKE_PHRASE, settings.wakePhrase.ifBlank { DEFAULT_WAKE_PHRASE })
            .putBoolean(KEY_TTS_ENABLED, settings.ttsEnabled)
            .putBoolean(KEY_CONTINUOUS_VOICE, settings.continuousVoiceMode)
            .putBoolean(KEY_BG_SERVICE_ENABLED, settings.backgroundServiceEnabled)
            .putString(KEY_PROXY_URL, settings.proxyEndpointUrl.trim())
            .putString(KEY_SPEECH_LANG, settings.speechLanguageTag.ifBlank { "bn-BD" })
            .apply()
    }

    fun saveOAuthAccessToken(token: String?) {
        if (token.isNullOrBlank()) {
            prefs.edit().remove(KEY_YT_ACCESS_TOKEN).apply()
        } else {
            prefs.edit().putString(KEY_YT_ACCESS_TOKEN, token).apply()
        }
    }

    fun getOAuthAccessToken(): String? = prefs.getString(KEY_YT_ACCESS_TOKEN, null)

    fun saveChatHistory(messages: List<ChatMessage>) {
        val arr = JSONArray()
        messages.takeLast(100).forEach { msg ->
            val obj = JSONObject().apply {
                put("id", msg.id)
                put("text", msg.text)
                put("isUser", msg.isUser)
                put("timestampMillis", msg.timestampMillis)
            }
            arr.put(obj)
        }
        prefs.edit().putString(KEY_CHAT_HISTORY, arr.toString()).apply()
    }

    fun loadChatHistory(): List<ChatMessage> {
        val raw = prefs.getString(KEY_CHAT_HISTORY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    add(
                        ChatMessage(
                            id = obj.optString("id"),
                            text = obj.optString("text"),
                            isUser = obj.optBoolean("isUser"),
                            timestampMillis = obj.optLong("timestampMillis", System.currentTimeMillis())
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun clearChatHistory() {
        prefs.edit().remove(KEY_CHAT_HISTORY).apply()
    }

    companion object {
        const val DEFAULT_WAKE_PHRASE = "হ্যালো আবু উবাইদা"
        private const val KEY_WAKE_PHRASE = "wake_phrase"
        private const val KEY_TTS_ENABLED = "tts_enabled"
        private const val KEY_CONTINUOUS_VOICE = "continuous_voice_mode"
        private const val KEY_BG_SERVICE_ENABLED = "bg_service_enabled"
        private const val KEY_PROXY_URL = "proxy_endpoint_url"
        private const val KEY_SPEECH_LANG = "speech_language_tag"
        private const val KEY_YT_ACCESS_TOKEN = "yt_oauth_access_token"
        private const val KEY_CHAT_HISTORY = "chat_history_json"
    }
}
