package com.abuubaida.ai.phone

import android.provider.Settings
import com.abuubaida.ai.data.model.AssistantIntentCommand
import com.abuubaida.ai.data.model.Screen
import com.abuubaida.ai.data.model.VolumeCommand
import java.util.Locale

/**
 * সম্পূর্ণ বাংলা প্রাকৃতিক ভাষা কমান্ড বিশ্লেষক (Bengali Natural Command Engine)
 * ব্যবহারকারী বাংলায় যা বলেন তা বুঝে সরাসরি সঠিক অ্যান্ড্রয়েড অ্যাকশনে রূপান্তর করে।
 */
object BengaliCommandEngine {

    private val bengaliToAsciiDigits = mapOf(
        '০' to '0', '১' to '1', '২' to '2', '৩' to '3', '৪' to '4',
        '৫' to '5', '৬' to '6', '৭' to '7', '৮' to '8', '৯' to '9'
    )

    private val bengaliWordNumbers = listOf(
        "ষাট" to 60, "পঞ্চাশ" to 50,
        "পঁয়তাল্লিশ" to 45, "পয়তাল্লিশ" to 45, "চল্লিশ" to 40,
        "পঁয়ত্রিশ" to 35, "ত্রিশ" to 30, "আধা" to 30,
        "পঁচিশ" to 25, "বিশ" to 20, "পনেরো" to 15, "পনের" to 15,
        "বারো" to 12, "বার" to 12, "এগারো" to 11, "এগার" to 11,
        "দশ" to 10, "নয়" to 9, "আট" to 8, "সাত" to 7, "ছয়" to 6,
        "পাঁচ" to 5, "চার" to 4, "তিন" to 3, "দুই" to 2, "এক" to 1
    )

    val bengaliAppAliases: Map<String, List<String>> = mapOf(
        "ইউটিউব" to listOf("youtube"),
        "youtube" to listOf("youtube"),
        "হোয়াটসঅ্যাপ" to listOf("whatsapp"),
        "হোয়াটস অ্যাপ" to listOf("whatsapp"),
        "whatsapp" to listOf("whatsapp"),
        "ফেসবুক" to listOf("facebook"),
        "facebook" to listOf("facebook"),
        "মেসেঞ্জার" to listOf("messenger"),
        "messenger" to listOf("messenger"),
        "ক্রোম" to listOf("chrome"),
        "গুগল ক্রোম" to listOf("chrome"),
        "গুগল" to listOf("google", "chrome"),
        "ক্যামেরা" to listOf("camera"),
        "camera" to listOf("camera"),
        "গ্যালারি" to listOf("gallery", "photos", "miui gallery", "album"),
        "ফটো" to listOf("photos", "gallery"),
        "ক্যালকুলেটর" to listOf("calculator"),
        "ক্যালেন্ডার" to listOf("calendar"),
        "প্লে স্টোর" to listOf("play store", "google play"),
        "প্লেস্টোর" to listOf("play store", "google play"),
        "জিমেইল" to listOf("gmail"),
        "ইমেইল" to listOf("gmail", "email"),
        "ম্যাপস" to listOf("maps"),
        "ম্যাপ" to listOf("maps"),
        "টিকটক" to listOf("tiktok"),
        "ইনস্টাগ্রাম" to listOf("instagram"),
        "টেলিগ্রাম" to listOf("telegram"),
        "ইমো" to listOf("imo"),
        "বিকাশ" to listOf("bkash"),
        "নগদ" to listOf("nagad"),
        "রকেট" to listOf("rocket"),
        "ঘড়ি" to listOf("clock"),
        "অ্যালার্ম" to listOf("clock"),
        "ফাইল" to listOf("files", "file manager"),
        "ফাইল ম্যানেজার" to listOf("file manager", "files"),
        "মিউজিক" to listOf("music", "yt music", "spotify"),
        "স্পটিফাই" to listOf("spotify"),
        "কন্টাক্ট" to listOf("contacts"),
        "ফোন" to listOf("phone", "dialer"),
        "ডায়ালার" to listOf("phone", "dialer"),
        "সেটিংস" to listOf("settings"),
        "নোট" to listOf("notes", "keep"),
        "শেয়ারইট" to listOf("shareit"),
        "জুম" to listOf("zoom"),
        "স্ন্যাপচ্যাট" to listOf("snapchat"),
        "দারাজ" to listOf("daraz"),
        "পাঠাও" to listOf("pathao"),
        "উবার" to listOf("uber"),
        "ফুডপান্ডা" to listOf("foodpanda"),
        "গ্রামীণফোন" to listOf("mygp"),
        "মাইজিপি" to listOf("mygp"),
        "রবি" to listOf("my robi"),
        "বাংলালিংক" to listOf("mybl")
    )

    fun normalizeDigits(input: String): String {
        val sb = StringBuilder(input.length)
        for (ch in input) {
            sb.append(bengaliToAsciiDigits[ch] ?: ch)
        }
        return sb.toString()
    }

    fun extractNumbers(text: String): List<Int> {
        val normalized = normalizeDigits(text)
        val digitMatches = Regex("\\d+").findAll(normalized).mapNotNull { it.value.toIntOrNull() }.toList()
        if (digitMatches.isNotEmpty()) return digitMatches
        val foundWords = mutableListOf<Int>()
        for ((word, value) in bengaliWordNumbers) {
            if (text.contains(word)) {
                foundWords.add(value)
            }
        }
        return foundWords
    }

    fun parse(rawInput: String): AssistantIntentCommand {
        val text = rawInput.trim()
        if (text.isBlank()) return AssistantIntentCommand.None
        val normalized = normalizeDigits(text)
        val lower = normalized.lowercase()

        // 1. Flashlight / Torch
        if (text.contains("টর্চ") || text.contains("ফ্ল্যাশ") || text.contains("লাইট") && (text.contains("জ্বালা") || text.contains("বন্ধ") || text.contains("অফ") || text.contains("অন")) ||
            lower.contains("torch") || lower.contains("flashlight")
        ) {
            val turnOff = text.contains("বন্ধ") || text.contains("অফ") || text.contains("নিভাও") || text.contains("নিভিয়ে") || lower.contains("off")
            return AssistantIntentCommand.ToggleFlashlight(enable = !turnOff)
        }

        // 2. Volume / Sound Control
        if (text.contains("সাউন্ড") || text.contains("ভলিউম") || text.contains("আওয়াজ") ||
            text.contains("সাইলেন্ট") || text.contains("মিউট") || lower.contains("volume") || lower.contains("silent")
        ) {
            return when {
                text.contains("সাইলেন্ট") || text.contains("মিউট") || text.contains("বন্ধ") || lower.contains("silent") || lower.contains("mute") ->
                    AssistantIntentCommand.ControlVolume(VolumeCommand.MUTE)
                text.contains("ফুল") || text.contains("সর্বোচ্চ") || text.contains("একদম বেশি") || lower.contains("max") ->
                    AssistantIntentCommand.ControlVolume(VolumeCommand.MAX)
                text.contains("কমাও") || text.contains("কমা") || text.contains("কমিয়ে") || text.contains("কম") || lower.contains("down") || lower.contains("decrease") ->
                    AssistantIntentCommand.ControlVolume(VolumeCommand.DOWN)
                text.contains("বাড়াও") || text.contains("বাড়া") || text.contains("বাড়িয়ে") || text.contains("বেশি") || lower.contains("up") || lower.contains("increase") ->
                    AssistantIntentCommand.ControlVolume(VolumeCommand.UP)
                else -> AssistantIntentCommand.ControlVolume(VolumeCommand.NORMAL)
            }
        }

        // 3. Time, Date & Battery Status
        if (text.contains("কয়টা বাজে") || text.contains("কত বাজে") || text.contains("সময় কত") || text.contains("এখন সময়") || text.contains("টাইম কত") || lower.contains("what time")) {
            return AssistantIntentCommand.QueryTime
        }
        if (text.contains("তারিখ") || text.contains("কী বার") || text.contains("কি বার") || text.contains("আজকের দিন")) {
            return AssistantIntentCommand.QueryDate
        }
        if (text.contains("চার্জ") || text.contains("ব্যাটারি") && (text.contains("কত") || text.contains("পার্সেন্ট") || text.contains("অবস্থা"))) {
            return AssistantIntentCommand.QueryBattery
        }

        // 4. YouTube & Video Content Creation (must run BEFORE YouTube search & app open)
        val wantsCreation = text.contains("বানাও") || text.contains("তৈরি") || text.contains("বানিয়ে") ||
            text.contains("লেখো") || text.contains("লিখে দাও") ||
            lower.contains("create video") || lower.contains("make video")
        if ((text.contains("ভিডিও") || text.contains("স্ক্রিপ্ট") || text.contains("কন্টেন্ট") || text.contains("ইউটিউব") || lower.contains("youtube") || lower.contains("video")) &&
            wantsCreation
        ) {
            val topic = text
                .replace("তুমি", "")
                .replace("আমার জন্য", "")
                .replace("আমাদের জন্য", "")
                .replace("ইউটিউবের জন্য", "")
                .replace("ইউটিউব এর জন্য", "")
                .replace("ইউটিউবের", "")
                .replace("ইউটিউব", "")
                .replace("চ্যানেলের জন্য", "")
                .replace("চ্যানেল", "")
                .replace("তৈরি করে দাও", "")
                .replace("বানিয়ে দাও", "")
                .replace("তৈরি করো", "")
                .replace("তৈরি কর", "")
                .replace("তৈরি", "")
                .replace("বানাও", "")
                .replace("বানিয়ে", "")
                .replace("লিখে দাও", "")
                .replace("লেখো", "")
                .replace("নিয়ে", "")
                .replace("সম্পর্কে", "")
                .replace("বিষয়ে", "")
                .replace("ভিডিও", "")
                .replace("স্ক্রিপ্ট", "")
                .replace("কন্টেন্ট", "")
                .replace("একটি", "")
                .replace("একটা", "")
                .replace("সব", "")
                .replace("করে দাও", "")
                .replace("দাও", "")
                .replace("youtube", "", ignoreCase = true)
                .replace("video", "", ignoreCase = true)
                .replace("content", "", ignoreCase = true)
                .replace("script", "", ignoreCase = true)
                .replace("create", "", ignoreCase = true)
                .replace("make", "", ignoreCase = true)
                .replace("for", "", ignoreCase = true)
                .trim()
            val finalTopic = if (topic.length >= 2) topic else "সফল জীবনের ৫টি গুরুত্বপূর্ণ উপদেশ"
            return AssistantIntentCommand.CreateVideoScript(finalTopic)
        }

        // 5. YouTube Search & Play Media
        if ((text.contains("ইউটিউব") || lower.contains("youtube")) &&
            (text.contains("সার্চ") || text.contains("খুঁজ") || text.contains("দেখাও") || text.contains("দেখা") || text.contains("চালাও") || text.contains("চালা") || text.contains("শোনাও") || text.contains("শোনা") || text.contains("বাজা") || text.contains("বের কর"))
        ) {
            val query = text
                .replace("ইউটিউবে", "")
                .replace("ইউটিউব", "")
                .replace("সার্চ করো", "")
                .replace("সার্চ কর", "")
                .replace("সার্চ", "")
                .replace("খুঁজো", "")
                .replace("খুঁজে দাও", "")
                .replace("বের করো", "")
                .replace("বের কর", "")
                .replace("দেখাও", "")
                .replace("চালাও", "")
                .replace("শোনাও", "")
                .replace("বাজাও", "")
                .replace("youtube", "", ignoreCase = true)
                .trim()
            if (query.isNotBlank()) {
                return AssistantIntentCommand.SearchYouTube(query)
            }
        }

        if ((text.contains("গজল") || text.contains("তেলাওয়াত") || text.contains("তিলাওয়াত") || text.contains("ওয়াজ") || text.contains("গান") || text.contains("নাশিদ") || text.contains("ভিডিও")) &&
            (text.contains("চালাও") || text.contains("চালা") || text.contains("শোনাও") || text.contains("বাজাও") || text.contains("দেখাও") || text.contains("বের কর"))
        ) {
            val query = text
                .replace("চালাও", "")
                .replace("শোনাও", "")
                .replace("বাজাও", "")
                .replace("দেখাও", "")
                .replace("বের করো", "")
                .replace("বের কর", "")
                .trim()
            if (query.isNotBlank()) {
                return AssistantIntentCommand.SearchYouTube(query)
            }
        }

        // 6. Google Web Search
        if (text.contains("গুগলে") || text.contains("গুগল করো") || text.contains("সার্চ করো") || text.contains("সার্চ কর") || text.contains("খুঁজে দাও") || lower.contains("google search")) {
            val query = text
                .replace("গুগলে", "")
                .replace("গুগল করো", "")
                .replace("গুগল", "")
                .replace("সার্চ করো", "")
                .replace("সার্চ কর", "")
                .replace("খুঁজে দাও", "")
                .replace("খুঁজো", "")
                .replace("google", "", ignoreCase = true)
                .trim()
            if (query.isNotBlank()) {
                return AssistantIntentCommand.SearchGoogle(query)
            }
        }

        // 7. In-app Screen Navigation
        if (text.contains("ইউটিউব স্টুডিও")) return AssistantIntentCommand.NavigateScreen(Screen.YouTubeStudio)
        if (text.contains("ভিডিও স্টুডিও")) return AssistantIntentCommand.NavigateScreen(Screen.VideoStudio)
        if (text.contains("ফোন কন্ট্রোল")) return AssistantIntentCommand.NavigateScreen(Screen.PhoneControl)
        if (text.contains("ভয়েস অ্যাসিস্ট্যান্ট")) return AssistantIntentCommand.NavigateScreen(Screen.VoiceAssistant)
        if (text.contains("অনুমতি") || text.contains("প্রাইভেসি") || text.contains("গোপনীয়তা")) {
            return AssistantIntentCommand.NavigateScreen(Screen.PermissionsPrivacy)
        }
        if (text.contains("অ্যাপ সেটিংস") || text.contains("অ্যাপের সেটিংস")) {
            return AssistantIntentCommand.NavigateScreen(Screen.Settings)
        }
        if (text.contains("হোমে যাও") || text.contains("হোম স্ক্রিন")) {
            return AssistantIntentCommand.NavigateScreen(Screen.Home)
        }
        if (text.contains("চ্যাটে যাও") || text.contains("এআই চ্যাট") || text.contains("চ্যাট স্ক্রিন")) {
            return AssistantIntentCommand.NavigateScreen(Screen.AiChat)
        }

        // 8. Phone Call (word-safe detection so words like "সকল" never misfire)
        val hasCallIntent = text.contains("কল করো") || text.contains("কল কর") ||
            text.contains("কল দাও") || text.contains("কল দে") ||
            text.contains("ফোন করো") || text.contains("ফোন কর") ||
            text.contains("ফোন দাও") || text.contains("রিং দাও") ||
            text.contains("ডায়াল") ||
            Regex("(?:^|\\s)কল(?:\\s|$)").containsMatchIn(text) ||
            Regex("\\bcall\\b", RegexOption.IGNORE_CASE).containsMatchIn(lower)
        if (hasCallIntent) {
            val target = normalized
                .replace("কল করো", "")
                .replace("কল কর", "")
                .replace("কল দাও", "")
                .replace("কল দে", "")
                .replace("ফোন করো", "")
                .replace("ফোন কর", "")
                .replace("ফোন দাও", "")
                .replace("রিং দাও", "")
                .replace("ডায়াল করো", "")
                .replace("ডায়াল", "")
                .replace(Regex("(?:^|\\s)কল(?:\\s|$)"), " ")
                .replace("নম্বরে", "")
                .replace("নম্বর", "")
                .replace("কে ", " ")
                .replace(Regex("\\bcall\\b", RegexOption.IGNORE_CASE), "")
                .trim()
                .removeSuffix("কে")
                .trim()
            if (target.isNotBlank()) {
                return AssistantIntentCommand.CallContact(target)
            }
        }

        // 9. SMS
        if (text.contains("মেসেজ") || text.contains("এসএমএস") || lower.contains("sms")) {
            val cleaned = normalized
                .replace("মেসেজ পাঠাও", "|")
                .replace("এসএমএস পাঠাও", "|")
                .replace("মেসেজ দাও", "|")
                .replace("মেসেজ লেখো", "|")
                .replace("sms", "|", ignoreCase = true)
            val parts = cleaned.split("|", limit = 2)
            val target = parts.getOrNull(0)?.trim()?.removeSuffix("কে")?.trim().orEmpty()
            val body = parts.getOrNull(1)?.trim().orEmpty()
            return AssistantIntentCommand.ComposeSms(target, body)
        }

        // 10. Timer
        if (text.contains("টাইমার") || lower.contains("timer")) {
            val nums = extractNumbers(text)
            val amount = nums.firstOrNull() ?: 5
            val seconds = when {
                text.contains("ঘণ্টা") || text.contains("ঘন্টা") -> amount * 3600
                text.contains("সেকেন্ড") -> amount
                else -> amount * 60
            }
            return AssistantIntentCommand.SetTimer(seconds, "আবু উবাইদা AI টাইমার")
        }

        // 11. Alarm
        if (text.contains("অ্যালার্ম") || lower.contains("alarm")) {
            val nums = extractNumbers(text)
            var hour = nums.getOrNull(0)?.coerceIn(0, 23) ?: 7
            var minute = nums.getOrNull(1)?.coerceIn(0, 59) ?: 0
            if (text.contains("সাড়ে") && minute == 0) minute = 30
            if ((text.contains("রাত") || text.contains("বিকাল") || text.contains("সন্ধ্যা") || text.contains("দুপুর")) && hour < 12) {
                hour += 12
            }
            return AssistantIntentCommand.SetAlarm(hour, minute, "আবু উবাইদা AI অ্যালার্ম")
        }

        // 12. Android System Settings
        if (text.contains("ওয়াইফাই") || lower.contains("wifi") || lower.contains("wi-fi")) {
            return AssistantIntentCommand.OpenSettings(Settings.ACTION_WIFI_SETTINGS, "Wi-Fi সেটিংস")
        }
        if (text.contains("ব্লুটুথ") || lower.contains("bluetooth")) {
            return AssistantIntentCommand.OpenSettings(Settings.ACTION_BLUETOOTH_SETTINGS, "Bluetooth সেটিংস")
        }
        if (text.contains("মোবাইল ডাটা") || text.contains("ইন্টারনেট সেটিংস") || text.contains("নেটওয়ার্ক সেটিংস")) {
            return AssistantIntentCommand.OpenSettings(Settings.ACTION_WIRELESS_SETTINGS, "মোবাইল নেটওয়ার্ক সেটিংস")
        }
        if (text.contains("লোকেশন") || text.contains("জিপিএস")) {
            return AssistantIntentCommand.OpenSettings(Settings.ACTION_LOCATION_SOURCE_SETTINGS, "লোকেশন সেটিংস")
        }
        if (text.contains("ডিসপ্লে") || text.contains("আলো সেটিংস")) {
            return AssistantIntentCommand.OpenSettings(Settings.ACTION_DISPLAY_SETTINGS, "ডিসপ্লে সেটিংস")
        }
        if (text.contains("সেটিংস") || lower.contains("settings")) {
            return AssistantIntentCommand.OpenSettings(Settings.ACTION_SETTINGS, "অ্যান্ড্রয়েড সেটিংস")
        }

        // 13. Open Installed App (with Bengali alias resolution)
        val hasExplicitOpen = text.contains("খোলো") || text.contains("খুলো") || text.contains("খোল") || text.contains("খুল") ||
            text.contains("ওপেন") || text.contains("চালু করো") || text.contains("চালু কর") ||
            Regex("\\bopen\\b", RegexOption.IGNORE_CASE).containsMatchIn(lower)
        val hasAppAliasWithGo = text.contains("যাও") && bengaliAppAliases.keys.any { text.contains(it, ignoreCase = true) }
        if (hasExplicitOpen || hasAppAliasWithGo) {
            val appName = text
                .replace("খোলো", "")
                .replace("খুলো", "")
                .replace("খোল", "")
                .replace("খুল", "")
                .replace("ওপেন করো", "")
                .replace("ওপেন কর", "")
                .replace("ওপেন", "")
                .replace("চালু করো", "")
                .replace("চালু কর", "")
                .replace("অ্যাপটি", "")
                .replace("অ্যাপ", "")
                .replace("তে যাও", "")
                .replace("এ যাও", "")
                .replace("যাও", "")
                .replace(Regex("\\bopen\\b", RegexOption.IGNORE_CASE), "")
                .trim()
            if (appName.isNotBlank()) {
                return AssistantIntentCommand.OpenApp(appName)
            }
        }

        // 14. Quick Bengali Arithmetic
        tryEvaluateBengaliMath(normalized)?.let { answer ->
            return AssistantIntentCommand.DirectAnswer(answer)
        }

        // 15. Natural Bengali Greetings & Identity
        if (text.contains("আসসালামু আলাইকুম") || text.contains("সালাম")) {
            return AssistantIntentCommand.DirectAnswer("ওয়ালাইকুম আসসালাম ওয়া রাহমাতুল্লাহ! আমি আবু উবাইদা AI, আপনার বাংলা সহকারী। বলুন, কীভাবে সাহায্য করতে পারি?")
        }
        if (text.contains("কেমন আছো") || text.contains("কেমন আছেন")) {
            return AssistantIntentCommand.DirectAnswer("আলহামদুলিল্লাহ, আমি ভালো আছি এবং আপনার নির্দেশ পালনের জন্য প্রস্তুত। আপনি কেমন আছেন?")
        }
        if (text.contains("তোমার নাম") || text.contains("তুমি কে")) {
            return AssistantIntentCommand.DirectAnswer("আমি আবু উবাইদা AI — আপনার বাংলা ভয়েস অ্যাসিস্ট্যান্ট। আমি কল, SMS, অ্যালার্ম, টাইমার, টর্চলাইট, সাউন্ড, অ্যাপ চালু এবং বাংলা AI প্রশ্নের উত্তর দিতে পারি।")
        }
        if (text.contains("ধন্যবাদ") || text.contains("শুকরিয়া")) {
            return AssistantIntentCommand.DirectAnswer("আপনাকেও অসংখ্য ধন্যবাদ! প্রয়োজনে আবার ডাকুন—হ্যালো আবু উবাইদা।")
        }

        return AssistantIntentCommand.None
    }

    private fun tryEvaluateBengaliMath(normalized: String): String? {
        val opRegex = Regex("(\\d+(?:\\.\\d+)?)\\s*(যোগ|\\+|বিয়োগ|-|গুণ|\\*|x|×|ভাগ|/|÷)\\s*(\\d+(?:\\.\\d+)?)")
        val match = opRegex.find(normalized) ?: return null
        val a = match.groupValues[1].toDoubleOrNull() ?: return null
        val op = match.groupValues[2]
        val b = match.groupValues[3].toDoubleOrNull() ?: return null
        val result = when (op) {
            "যোগ", "+" -> a + b
            "বিয়োগ", "-" -> a - b
            "গুণ", "*", "x", "×" -> a * b
            "ভাগ", "/", "÷" -> if (b == 0.0) return "শূন্য দিয়ে ভাগ করা যায় না।" else a / b
            else -> return null
        }
        val formatted = if (result % 1.0 == 0.0) {
            result.toLong().toString()
        } else {
            String.format(Locale.US, "%.2f", result)
        }
        return "হিসাবের ফলাফল হলো: $formatted"
    }
}
