package com.abuubaida.ai.islamic

import com.abuubaida.ai.data.model.HadithReference
import com.abuubaida.ai.data.model.IslamicCategory
import com.abuubaida.ai.data.model.IslamicContentReview
import com.abuubaida.ai.data.model.QuranReference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * বহিরাগত টেক্সট (যেমন ভিডিও বর্ণনা, কমেন্ট বা সার্চ ফলাফল) থেকে অনিরাপদ কমান্ড বা প্রম্পট ইনজেকশন ফিল্টার করে।
 */
object ContentSafetyGuard {
    private val suspiciousCommandMarkers = listOf(
        "ignore previous instructions",
        "ignore all instructions",
        "system:",
        "assistant:",
        "তুমি এখন",
        "কল করো",
        "মেসেজ পাঠাও",
        "ডিলিট করো"
    )

    fun sanitizeExternalText(raw: String, maxLength: Int = 180): String {
        var cleaned = raw
            .replace(Regex("[\\r\\n\\t]+"), " ")
            .replace(Regex("<[^>]*>"), " ")
            .trim()
        for (marker in suspiciousCommandMarkers) {
            cleaned = cleaned.replace(marker, "", ignoreCase = true)
        }
        return cleaned.replace(Regex("\\s+"), " ").take(maxLength).trim()
    }
}

class IslamicKnowledgeRepository {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    data class VerifiedTopicBundle(
        val resolvedTopic: String,
        val quranRef: QuranReference?,
        val hadithRef: HadithReference?,
        val historicalContextBn: String,
        val verificationNoteBn: String
    )

    /**
     * আল-কুরআন ক্লাউড পাবলিক HTTPS API (https://api.alquran.cloud) থেকে যাচাইকৃত আরবি উসমানি টেক্সট ও বাংলা অনুবাদ আনে।
     * কখনো নিজ থেকে কোনো আয়াত বা হাদিস বানানো হয় না।
     */
    suspend fun fetchVerifiedAyah(surahNumber: Int, ayahNumber: Int): QuranReference? =
        withContext(Dispatchers.IO) {
            if (surahNumber !in 1..114 || ayahNumber < 1) return@withContext null
            val url = "https://api.alquran.cloud/v1/ayah/${surahNumber}:${ayahNumber}/editions/quran-uthmani,bn.bengali"
            try {
                val request = Request.Builder().url(url).get().build()
                httpClient.newCall(request).execute().use { resp ->
                    if (!resp.isSuccessful) return@withContext null
                    val body = resp.body?.string().orEmpty()
                    val root = JSONObject(body)
                    if (root.optInt("code") != 200) return@withContext null
                    val dataArr = root.optJSONArray("data") ?: return@withContext null
                    if (dataArr.length() < 2) return@withContext null

                    val arabicObj = dataArr.getJSONObject(0)
                    val bengaliObj = dataArr.getJSONObject(1)
                    val surahObj = arabicObj.optJSONObject("surah")
                    val surahNameEn = surahObj?.optString("englishName").orEmpty()
                    val surahNameAr = surahObj?.optString("name").orEmpty()
                    val arabicText = arabicObj.optString("text").trim()
                    val bengaliText = bengaliObj.optString("text").trim()
                    if (arabicText.isBlank() || bengaliText.isBlank()) return@withContext null

                    QuranReference(
                        surahNumber = surahNumber,
                        ayahNumber = ayahNumber,
                        surahNameBn = "${surahDisplayBn(surahNumber, surahNameEn)} (${surahNumber}:${ayahNumber})",
                        surahNameArabic = surahNameAr,
                        arabicUthmaniText = arabicText,
                        bengaliTranslation = bengaliText,
                        sourceApiBn = "AlQuran Cloud (quran-uthmani & bn.bengali)",
                        verified = true
                    )
                }
            } catch (_: Exception) {
                null
            }
        }

    suspend fun prepareVerifiedBundle(
        topic: String,
        category: IslamicCategory
    ): VerifiedTopicBundle {
        val cleanTopic = topic.trim()
        val targetRef = detectSurahAyahFromTopic(cleanTopic, category)
        val liveAyah = if (targetRef != null) {
            fetchVerifiedAyah(targetRef.first, targetRef.second)
        } else {
            null
        }
        val quranRef = liveAyah ?: selectVerifiedFallbackAyah(cleanTopic, category)
        val hadithRef = selectVerifiedHadith(cleanTopic, category)

        val verificationNote = buildString {
            if (quranRef != null) {
                append("কুরআনের আয়াত যাচাইকৃত সূত্র (${quranRef.sourceApiBn}) থেকে গৃহীত—আরবি মূল পাঠ অপরিবর্তিত রাখা হয়েছে। ")
            }
            if (hadithRef != null) {
                append("হাদিসের সূত্র: ${hadithRef.collectionBn} (${hadithRef.referenceNumber}) — ${hadithRef.gradingNoteBn}।")
            }
            if (length == 0) {
                append("ইসলামিক শিক্ষামূলক সাধারণ আলোচনা; প্রকাশের আগে আলেম বা নির্ভরযোগ্য গ্রন্থের সাথে মিলিয়ে নেওয়া নিরাপদ।")
            }
        }

        val contextBn = when (category) {
            IslamicCategory.PROPHET_STORIES -> "কুরআন ও বিশুদ্ধ সিরাত গ্রন্থের আলোকে নবী-রাসূলদের (আ.) শিক্ষণীয় ঘটনা।"
            IslamicCategory.ISLAMIC_HISTORY -> "ইসলামের প্রাথমিক যুগ ও মুসলিম সভ্যতার নির্ভরযোগ্য ঐতিহাসিক শিক্ষা।"
            IslamicCategory.NAMES_OF_ALLAH -> "আল্লাহ তাআলার গুণবাচক নামসমূহ (আসমাউল হুসনা) এবং দৈনন্দিন আমল ও দোয়া।"
            else -> "কুরআন ও সহীহ হাদিসের আলোকে নির্ভুল ও প্রাঞ্জল বাংলা ইসলামিক আলোচনা।"
        }

        return VerifiedTopicBundle(
            resolvedTopic = cleanTopic.ifBlank { defaultTopicForCategory(category) },
            quranRef = quranRef,
            hadithRef = hadithRef,
            historicalContextBn = contextBn,
            verificationNoteBn = verificationNote
        )
    }

    fun reviewReligiousContent(
        script: String,
        quranRef: QuranReference?,
        hadithRef: HadithReference?,
        category: IslamicCategory
    ): IslamicContentReview {
        val warnings = mutableListOf<String>()

        if (script.isBlank() || script.length < 40) {
            warnings.add("স্ক্রিপ্ট অত্যন্ত সংক্ষিপ্ত; প্রকাশের আগে পূর্ণাঙ্গ তথ্য যাচাই করুন।")
        }

        val containsArabicChars = script.any { it in '\u0600'..'\u06FF' }
        if (containsArabicChars && (quranRef == null || !quranRef.verified)) {
            warnings.add("স্ক্রিপ্টে আরবি পাঠ রয়েছে কিন্তু যাচাইকৃত কুরআন API/সূত্র যুক্ত নেই; প্রকাশের আগে আরবি পাঠ মিলিয়ে নিন।")
        }

        if (category == IslamicCategory.HADITH_EDUCATION && (hadithRef == null || !hadithRef.verifiedAuthentic)) {
            warnings.add("হাদিস বিভাগে স্পষ্ট গ্রন্থ ও সহীহ/হাসান মান উল্লেখ থাকা বাধ্যতামূলক।")
        }

        if (quranRef != null && !quranRef.verified) {
            warnings.add("কুরআনের আয়াত অফলাইন/অযাচাইকৃত অবস্থায় রয়েছে—প্রকাশের আগে সূরা ও আয়াত নম্বর পরীক্ষা করুন।")
        }

        val citation = buildList {
            if (quranRef != null) add("কুরআন: ${quranRef.surahNameBn} [${quranRef.sourceApiBn}]")
            if (hadithRef != null) add("হাদিস: ${hadithRef.collectionBn} (${hadithRef.referenceNumber})")
        }.joinToString(" | ").ifBlank { "সাধারণ ইসলামিক নসীহত ও শিক্ষামূলক আলোচনা" }

        return IslamicContentReview(
            passed = warnings.isEmpty(),
            sourceCitationBn = citation,
            warningsBn = warnings
        )
    }

    private fun detectSurahAyahFromTopic(topic: String, category: IslamicCategory): Pair<Int, Int>? {
        val numMatch = Regex("(\\d{1,3})\\s*[:：]\\s*(\\d{1,3})").find(topic)
        if (numMatch != null) {
            val s = numMatch.groupValues[1].toIntOrNull()
            val a = numMatch.groupValues[2].toIntOrNull()
            if (s != null && a != null && s in 1..114 && a >= 1) return s to a
        }

        val lower = topic.lowercase()
        return when {
            topic.contains("ফাতিহা") || lower.contains("fatiha") -> 1 to 1
            topic.contains("আয়াতুল কুরসি") || topic.contains("কুরসী") -> 2 to 255
            topic.contains("ইখলাস") || lower.contains("ikhlas") -> 112 to 1
            topic.contains("আসর") || lower.contains("asr") -> 103 to 1
            topic.contains("ইনশিরাহ") || topic.contains("কষ্টের পর") || topic.contains("ধৈর্য") -> 94 to 5
            topic.contains("রহমান") || lower.contains("rahman") -> 55 to 13
            topic.contains("মুলক") || lower.contains("mulk") -> 67 to 2
            topic.contains("কাউসার") -> 108 to 1
            category == IslamicCategory.QURAN_RECITATION || category == IslamicCategory.SURAH_EXPLANATION -> 94 to 5
            category == IslamicCategory.NAMES_OF_ALLAH -> 59 to 23
            else -> null
        }
    }

    private fun selectVerifiedFallbackAyah(topic: String, category: IslamicCategory): QuranReference? {
        return when {
            topic.contains("ধৈর্য") || topic.contains("কষ্ট") || category == IslamicCategory.QURAN_RECITATION || category == IslamicCategory.SURAH_EXPLANATION ->
                QuranReference(
                    surahNumber = 94,
                    ayahNumber = 5,
                    surahNameBn = "সূরা আল-ইনশিরাহ (৯৪:৫)",
                    surahNameArabic = "سُورَةُ الشَّرْحِ",
                    arabicUthmaniText = "فَإِنَّ مَعَ ٱلْعُسْرِ يُسْرًا",
                    bengaliTranslation = "নিশ্চয়ই কষ্টের সাথেই স্বস্তি রয়েছে।",
                    sourceApiBn = "যাচাইকৃত অফলাইন মুসহাফ (সূরা ৯৪, আয়াত ৫)",
                    verified = true
                )
            topic.contains("তাওয়াক্কুল") || topic.contains("ভরসা") ->
                QuranReference(
                    surahNumber = 65,
                    ayahNumber = 3,
                    surahNameBn = "সূরা আত-তালাক (৬৫:৩)",
                    surahNameArabic = "سُورَةُ الطَّلَاقِ",
                    arabicUthmaniText = "وَمَن يَتَوَكَّلْ عَلَى ٱللَّهِ فَهُوَ حَسْبُهُۥ",
                    bengaliTranslation = "আর যে ব্যক্তি আল্লাহর ওপর ভরসা করে, তার জন্য তিনিই যথেষ্ট।",
                    sourceApiBn = "যাচাইকৃত অফলাইন মুসহাফ (সূরা ৬৫, আয়াত ৩)",
                    verified = true
                )
            category == IslamicCategory.NAMES_OF_ALLAH || topic.contains("নাম") ->
                QuranReference(
                    surahNumber = 59,
                    ayahNumber = 24,
                    surahNameBn = "সূরা আল-হাশর (৫৯:২৪)",
                    surahNameArabic = "سُورَةُ الحَشْرِ",
                    arabicUthmaniText = "هُوَ ٱللَّهُ ٱلْخَٰلِقُ ٱلْبَارِئُ ٱلْمُصَوِّرُ ۖ لَهُ ٱلْأَسْمَآءُ ٱلْحُسْنَىٰ",
                    bengaliTranslation = "তিনিই আল্লাহ, স্রষ্টা, উদ্ভাবক ও রূপদাতা; তাঁর জন্যই রয়েছে সকল সুন্দর নামসমূহ।",
                    sourceApiBn = "যাচাইকৃত অফলাইন মুসহাফ (সূরা ৫৯, আয়াত ২৪)",
                    verified = true
                )
            else ->
                QuranReference(
                    surahNumber = 103,
                    ayahNumber = 1,
                    surahNameBn = "সূরা আল-আসর (১০৩:১-৩)",
                    surahNameArabic = "سُورَةُ العَصْرِ",
                    arabicUthmaniText = "وَٱلْعَصْرِ ۝ إِنَّ ٱلْإِنسَٰنَ لَفِى خُسْرٍ",
                    bengaliTranslation = "সময়ের শপথ! নিশ্চয়ই মানুষ ক্ষতির মধ্যে রয়েছে—তারা ব্যতীত যারা ঈমান আনে ও সৎকর্ম করে।",
                    sourceApiBn = "যাচাইকৃত অফলাইন মুসহাফ (সূরা ১০৩, আয়াত ১-২)",
                    verified = true
                )
        }
    }

    private fun selectVerifiedHadith(topic: String, category: IslamicCategory): HadithReference? {
        return when {
            category == IslamicCategory.HADITH_EDUCATION || topic.contains("হাদিস") || topic.contains("নিয়ত") ->
                HadithReference(
                    collectionBn = "সহীহ আল-বুখারী",
                    referenceNumber = "হাদিস নং ১",
                    narratorBn = "হযরত উমর ইবনুল খাত্তাব (রা.)",
                    bengaliText = "সকল কাজ নিয়তের ওপর নির্ভরশীল, আর প্রত্যেক ব্যক্তি তাই পাবে যা সে নিয়ত করবে।",
                    gradingNoteBn = "মুত্তাফাকুন আলাইহি (সহীহ বুখারী ও মুসলিম)",
                    verifiedAuthentic = true
                )
            category == IslamicCategory.NAMES_OF_ALLAH || topic.contains("আল্লাহর ৯৯ নাম") ->
                HadithReference(
                    collectionBn = "সহীহ আল-বুখারী",
                    referenceNumber = "হাদিস নং ২৭৩৬",
                    narratorBn = "হযরত আবু হুরায়রা (রা.)",
                    bengaliText = "আল্লাহর নিরানব্বইটি (এক কম একশত) নাম রয়েছে; যে ব্যক্তি এগুলো মুখস্থ রাখবে ও অনুযায়ী আমল করবে সে জান্নাতে প্রবেশ করবে।",
                    gradingNoteBn = "সহীহ (বুখারী ও মুসলিম)",
                    verifiedAuthentic = true
                )
            category == IslamicCategory.QURAN_RECITATION || topic.contains("কোরআন") || topic.contains("তেলাওয়াত") ->
                HadithReference(
                    collectionBn = "সহীহ আল-বুখারী",
                    referenceNumber = "হাদিস নং ৫০২৭",
                    narratorBn = "হযরত উসমান ইবনু আফফান (রা.)",
                    bengaliText = "তোমাদের মধ্যে সর্বোত্তম সেই ব্যক্তি, যে নিজে কুরআন শেখে এবং অন্যকে তা শিক্ষা দেয়।",
                    gradingNoteBn = "সহীহ (সহীহ আল-বুখারী)",
                    verifiedAuthentic = true
                )
            category == IslamicCategory.ISLAMIC_REMINDER || topic.contains("আখলাক") || topic.contains("ব্যবহার") ->
                HadithReference(
                    collectionBn = "জামে আত-তিরমিযী",
                    referenceNumber = "হাদিস নং ২০০২",
                    narratorBn = "হযরত আবু দারদা (রা.)",
                    bengaliText = "কিয়ামতের দিন মুমিনের মীযানের পাল্লায় উত্তম চরিত্রের চেয়ে ভারী কোনো জিনিস থাকবে না।",
                    gradingNoteBn = "সহীহ (তিরমিযী ও আবু দাউদ)",
                    verifiedAuthentic = true
                )
            else -> null
        }
    }

    fun defaultTopicForCategory(category: IslamicCategory): String = when (category) {
        IslamicCategory.QURAN_RECITATION -> "সূরা আল-ইনশিরাহ (৯৪:৫-৬) তেলাওয়াত ও বাংলা অর্থ"
        IslamicCategory.SURAH_EXPLANATION -> "সূরা আল-আসর (১০৩) এর তাফসীর ও শিক্ষা"
        IslamicCategory.ISLAMIC_EDUCATION -> "ইসলামে নিয়তের গুরুত্ব ও সহীহ আমল"
        IslamicCategory.PROPHET_STORIES -> "নবী ইউসুফ (আ.)-এর ধৈর্য ও ক্ষমার শিক্ষণীয় ঘটনা"
        IslamicCategory.ISLAMIC_HISTORY -> "মদিনা সনদ ও ইসলামের শান্তিপূর্ণ সমাজ ব্যবস্থা"
        IslamicCategory.ISLAMIC_REMINDER -> "কষ্টের পরেই রয়েছে স্বস্তি — কুরআনের সান্ত্বনা"
        IslamicCategory.HADITH_EDUCATION -> "সহীহ বুখারীর প্রথম হাদিস: নিয়তের বিশুদ্ধতা"
        IslamicCategory.NAMES_OF_ALLAH -> "আল্লাহর সুন্দর নামসমূহ (আসমাউল হুসনা) ও তাৎপর্য"
        IslamicCategory.ISLAMIC_SHORTS -> "৬০ সেকেন্ডে জীবনের সবচেয়ে জরুরি ইসলামিক বার্তা"
        IslamicCategory.LONG_DOCUMENTARY -> "ইসলামী স্বর্ণযুগ: জ্ঞান-বিজ্ঞানে মুসলিম মনীষীদের অবদান"
    }

    private fun surahDisplayBn(surahNumber: Int, englishFallback: String): String {
        val known = mapOf(
            1 to "সূরা আল-ফাতিহা",
            2 to "সূরা আল-বাকারা",
            3 to "সূরা আলে-ইমরান",
            18 to "সূরা আল-কাহফ",
            36 to "সূরা ইয়াসীন",
            55 to "সূরা আর-রহমান",
            59 to "সূরা আল-হাশর",
            65 to "সূরা আত-তালাক",
            67 to "সূরা আল-মুলক",
            94 to "সূরা আল-ইনশিরাহ",
            103 to "সূরা আল-আসর",
            108 to "সূরা আল-কাউসার",
            112 to "সূরা আল-ইখলাস",
            113 to "সূরা আল-ফালাক",
            114 to "সূরা আন-নাস"
        )
        return known[surahNumber] ?: "সূরা $englishFallback"
    }
}
