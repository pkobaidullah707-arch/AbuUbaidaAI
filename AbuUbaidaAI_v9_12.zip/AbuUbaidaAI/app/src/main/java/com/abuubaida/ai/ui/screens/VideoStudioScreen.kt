package com.abuubaida.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.SaveAlt
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.abuubaida.ai.data.model.AssistantSettings
import com.abuubaida.ai.data.model.IslamicCategory
import com.abuubaida.ai.data.model.IslamicVoicePreset
import com.abuubaida.ai.data.model.PublishingRecommendation
import com.abuubaida.ai.data.model.TtsVoiceOption
import com.abuubaida.ai.data.model.VideoDurationOption
import com.abuubaida.ai.data.model.VideoFormat
import com.abuubaida.ai.data.model.VideoProject
import com.abuubaida.ai.ui.components.GlassCard
import com.abuubaida.ai.ui.theme.AmberGold
import com.abuubaida.ai.ui.theme.BrightGold
import com.abuubaida.ai.ui.theme.DeepNavyBg
import com.abuubaida.ai.ui.theme.ElectricBlue
import com.abuubaida.ai.ui.theme.EmeraldOk
import com.abuubaida.ai.ui.theme.ImperialGold
import com.abuubaida.ai.ui.theme.NavyBorder
import com.abuubaida.ai.ui.theme.RoyalBlue
import com.abuubaida.ai.ui.theme.TextPrimary
import com.abuubaida.ai.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VideoStudioScreen(
    project: VideoProject?,
    recommendation: PublishingRecommendation?,
    currentSettings: AssistantSettings,
    availableVoices: List<TtsVoiceOption>,
    isBusy: Boolean,
    autonomousProgressBn: String,
    mp4ProviderConnected: Boolean,
    contentCreationEnabled: Boolean,
    onGenerateProject: (String, IslamicCategory, VideoFormat, VideoDurationOption) -> Unit,
    onRunDailyAutonomous: (VideoDurationOption) -> Unit,
    onExportMp4OrScript: () -> Unit,
    onSpeakScript: (String) -> Unit,
    onUpdateSettings: (AssistantSettings) -> Unit,
    onPreviewVoice: (AssistantSettings) -> Unit,
    onCopiedAll: () -> Unit,
    onSendToYouTubeStudio: () -> Unit,
    onSendToFacebookStudio: () -> Unit
) {
    var topicInput by remember(project?.topic) { mutableStateOf(project?.topic.orEmpty()) }
    var selectedCategory by remember(project?.category) {
        mutableStateOf(project?.category ?: IslamicCategory.ISLAMIC_EDUCATION)
    }
    var selectedFormat by remember(project?.format) {
        mutableStateOf(project?.format ?: selectedCategory.defaultFormat)
    }
    var selectedDuration by remember(project?.durationOption) {
        mutableStateOf(
            project?.durationOption
                ?: if (selectedFormat == VideoFormat.SHORTS_9_16) VideoDurationOption.SHORT_1M else VideoDurationOption.LONG_10M
        )
    }
    val clipboardManager = LocalClipboardManager.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("ইসলামিক AI ভিডিও স্টুডিও", style = MaterialTheme.typography.headlineMedium, color = BrightGold)

        GlassCard(borderColor = ImperialGold.copy(alpha = 0.45f)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.Movie, contentDescription = null, tint = BrightGold)
                Text("লং ও শর্টস ইসলামিক ভিডিও পাইপলাইন", style = MaterialTheme.typography.titleMedium, color = BrightGold)
            }
            Spacer(modifier = Modifier.height(8.dp))

            Text("কনটেন্ট বিভাগ:", style = MaterialTheme.typography.labelLarge, color = ElectricBlue)
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                IslamicCategory.entries.forEach { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = {
                            selectedCategory = cat
                            selectedFormat = cat.defaultFormat
                            if (cat.defaultFormat == VideoFormat.SHORTS_9_16 && selectedDuration == VideoDurationOption.LONG_10M) {
                                selectedDuration = VideoDurationOption.SHORT_1M
                            }
                        },
                        label = { Text(cat.labelBn) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = RoyalBlue,
                            selectedLabelColor = TextPrimary,
                            containerColor = DeepNavyBg,
                            labelColor = TextSecondary
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text("ভিডিওর দৈর্ঘ্য নির্বাচন করুন (১ মিনিট — ২০ মিনিট):", style = MaterialTheme.typography.labelLarge, color = ElectricBlue)
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                VideoDurationOption.entries.forEach { dur ->
                    FilterChip(
                        selected = selectedDuration == dur,
                        onClick = {
                            selectedDuration = dur
                            selectedFormat = if (dur == VideoDurationOption.SHORT_1M) {
                                VideoFormat.SHORTS_9_16
                            } else {
                                VideoFormat.LONG_16_9
                            }
                        },
                        label = { Text(dur.labelBn) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EmeraldOk,
                            selectedLabelColor = DeepNavyBg,
                            containerColor = DeepNavyBg,
                            labelColor = TextSecondary
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text("ভিডিও ফরম্যাট:", style = MaterialTheme.typography.labelLarge, color = ElectricBlue)
            Spacer(modifier = Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                VideoFormat.entries.forEach { fmt ->
                    FilterChip(
                        selected = selectedFormat == fmt,
                        onClick = { selectedFormat = fmt },
                        label = { Text(fmt.labelBn) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ImperialGold,
                            selectedLabelColor = DeepNavyBg,
                            containerColor = DeepNavyBg,
                            labelColor = TextSecondary
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = topicInput,
                onValueChange = { topicInput = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("বিষয় লিখুন (ফাঁকা রাখলে যাচাইকৃত সেরা বিষয় নেবে)") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = NavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = { onGenerateProject(topicInput, selectedCategory, selectedFormat, selectedDuration) },
                enabled = !isBusy && contentCreationEnabled,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = ImperialGold, contentColor = DeepNavyBg)
            ) {
                Icon(Icons.Rounded.AutoAwesome, contentDescription = null)
                Text(
                    if (contentCreationEnabled) "  ${selectedDuration.labelBn} ভিডিও ও MP4 তৈরি করুন"
                    else "  কনটেন্ট তৈরি মাস্টার কন্ট্রোল থেকে বন্ধ"
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedButton(
                onClick = { onRunDailyAutonomous(selectedDuration) },
                enabled = !isBusy && contentCreationEnabled,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("ট্রেন্ড দেখে স্বয়ংক্রিয়ভাবে ${selectedDuration.labelBn} ভিডিও বানান", color = ElectricBlue)
            }

            if (isBusy) {
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = ImperialGold)
                if (autonomousProgressBn.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(autonomousProgressBn, color = BrightGold, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        // Islamic Speaker Voice & Video Options (ON/OFF toggles + Preset switcher)
        GlassCard(borderColor = ElectricBlue.copy(alpha = 0.45f)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.RecordVoiceOver, contentDescription = null, tint = ElectricBlue)
                Text("ইসলামিক বক্তা কণ্ঠ ও অডিও অপশন", style = MaterialTheme.typography.titleMedium, color = BrightGold)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                "ভয়েসওভারে কোনো ভূমিকা/সূচনা/সমাপ্তি বা টাইমিং পড়া হবে না — শুধু মধুর ওয়াজের মতো প্রাকৃতিক বয়ান শোনাবে।",
                color = TextSecondary,
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("ভিডিওতে ভয়েসওভার অডিও", color = TextPrimary)
                    Text("বন্ধ রাখলে শুধু টেক্সট ও ভিজ্যুয়াল স্লাইড তৈরি হবে", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                }
                Switch(
                    checked = currentSettings.includeVoiceoverInVideo,
                    onCheckedChange = { onUpdateSettings(currentSettings.copy(includeVoiceoverInVideo = it)) }
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("তৈরির পর ফোনে MP4 অটো-সেভ", color = TextPrimary)
                    Text("Movies/AbuUbaidaAI ফোল্ডারে সরাসরি MP4 সেভ করবে", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                }
                Switch(
                    checked = currentSettings.autoSaveMp4ToPhone,
                    onCheckedChange = { onUpdateSettings(currentSettings.copy(autoSaveMp4ToPhone = it)) }
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text("বক্তার কণ্ঠ পরিবর্তন করুন:", style = MaterialTheme.typography.labelLarge, color = ElectricBlue)
            Spacer(modifier = Modifier.height(4.dp))
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                IslamicVoicePreset.entries.forEach { preset ->
                    FilterChip(
                        selected = currentSettings.voicePreset == preset,
                        onClick = {
                            onUpdateSettings(
                                currentSettings.copy(
                                    voicePreset = preset,
                                    voicePitch = preset.pitch,
                                    voiceRate = preset.rate
                                )
                            )
                        },
                        label = { Text(preset.labelBn) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = RoyalBlue,
                            selectedLabelColor = TextPrimary,
                            containerColor = DeepNavyBg,
                            labelColor = TextSecondary
                        )
                    )
                }
            }
            if (availableVoices.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text("ফোনের বাংলা কণ্ঠ (${availableVoices.size}টি পাওয়া গেছে):", style = MaterialTheme.typography.labelLarge, color = BrightGold)
                Spacer(modifier = Modifier.height(4.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = currentSettings.selectedTtsVoiceName.isBlank(),
                        onClick = { onUpdateSettings(currentSettings.copy(selectedTtsVoiceName = "")) },
                        label = { Text("অটো সেরা বাংলা কণ্ঠ") }
                    )
                    availableVoices.take(4).forEach { v ->
                        FilterChip(
                            selected = currentSettings.selectedTtsVoiceName == v.name,
                            onClick = { onUpdateSettings(currentSettings.copy(selectedTtsVoiceName = v.name)) },
                            label = { Text(v.labelBn) }
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedButton(
                onClick = { onPreviewVoice(currentSettings) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Rounded.VolumeUp, contentDescription = null, tint = BrightGold)
                Text("  বর্তমান ওয়াজ ভয়েস নমুনা শুনুন", color = BrightGold)
            }
        }

        if (project != null) {
            // Islamic Content Accuracy & Sources Review
            GlassCard(
                borderColor = if (project.accuracyReview.passed) EmeraldOk.copy(alpha = 0.5f) else AmberGold.copy(alpha = 0.6f)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(
                        Icons.Rounded.Verified,
                        contentDescription = null,
                        tint = if (project.accuracyReview.passed) EmeraldOk else AmberGold
                    )
                    Text(
                        text = if (project.accuracyReview.passed) "ইসলামিক তথ্য ও সূত্র যাচাই সম্পন্ন" else "প্রকাশের আগে সতর্কতা পর্যালোচনা করুন",
                        style = MaterialTheme.typography.titleMedium,
                        color = if (project.accuracyReview.passed) EmeraldOk else AmberGold
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text("সূত্র: ${project.accuracyReview.sourceCitationBn}", color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                project.quranReference?.let { q ->
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(q.arabicUthmaniText, color = BrightGold, style = MaterialTheme.typography.titleMedium)
                    Text("${q.surahNameBn}: ${q.bengaliTranslation}", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                }
                project.hadithReference?.let { h ->
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("${h.collectionBn} (${h.referenceNumber}): ${h.bengaliText}", color = ElectricBlue, style = MaterialTheme.typography.bodyMedium)
                }
                project.accuracyReview.warningsBn.forEach { w ->
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("• $w", color = AmberGold, style = MaterialTheme.typography.bodyMedium)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(project.audioRightsNoteBn, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
            }

            // Smart Publishing Evaluation
            recommendation?.let { plan ->
                GlassCard(borderColor = ElectricBlue.copy(alpha = 0.4f)) {
                    Text("স্মার্ট পাবলিশিং পরামর্শ", style = MaterialTheme.typography.titleMedium, color = ElectricBlue)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("সেরা প্রকাশের সময়: ${plan.targetTimeLabelBn}", color = EmeraldOk, style = MaterialTheme.typography.bodyLarge)
                    Text(plan.reasonBn, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                }
            }

            // MP4 & Thumbnail Status
            GlassCard(borderColor = NavyBorder) {
                Text("প্রস্তুতকৃত মিডিয়া ও ফোনে সংরক্ষণ", style = MaterialTheme.typography.titleMedium, color = BrightGold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (project.renderedMp4UriString.isNotBlank()) {
                        val loc = project.savedMp4DisplayPath.ifBlank { "Movies/AbuUbaidaAI" }
                        "• MP4 ভিডিও (${project.durationOption.labelBn} · ${project.format.labelBn}): প্রস্তুত ও ফোনের '$loc'-এ সেভ হয়েছে!"
                    } else {
                        "• MP4 ভিডিও (${project.durationOption.labelBn}): ফোনে সেভ করতে নিচের 'ফোনে MP4 সেভ করুন' বাটনে চাপ দিন।"
                    },
                    color = if (project.renderedMp4UriString.isNotBlank()) EmeraldOk else AmberGold
                )
                Text(
                    text = if (project.thumbnailLocalPath.isNotBlank()) {
                        "• Thumbnail PNG: প্রস্তুত (YouTube ও গ্যালারিতে যুক্ত)"
                    } else {
                        "• Thumbnail Text: ${project.thumbnailText}"
                    },
                    color = TextPrimary
                )
            }

            // Bilingual SEO Card
            GlassCard {
                Text("বাংলা SEO শিরোনাম", style = MaterialTheme.typography.labelLarge, color = BrightGold)
                Text(project.seoTitle, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                if (project.englishTitle.isNotBlank()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("English Title", style = MaterialTheme.typography.labelLarge, color = ElectricBlue)
                    Text(project.englishTitle, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text("বিবরণ (Description)", style = MaterialTheme.typography.labelLarge, color = BrightGold)
                Text(project.seoDescription, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                Spacer(modifier = Modifier.height(8.dp))
                Text("ট্যাগ ও হ্যাশট্যাগ", style = MaterialTheme.typography.labelLarge, color = BrightGold)
                Text(project.seoTags.joinToString(", "), style = MaterialTheme.typography.bodyMedium, color = ElectricBlue)
                if (project.hashtags.isNotEmpty()) {
                    Text(project.hashtags.joinToString(" "), style = MaterialTheme.typography.bodyMedium, color = BrightGold)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text("থাম্বনেইল টেক্সট: ${project.thumbnailText}", color = TextPrimary)
                Text(project.thumbnailDesignSummary, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
            }

            GlassCard {
                Text("পরিচ্ছন্ন বাংলা ভয়েসওভার বয়ান (টাইমিং/হেডিংমুক্ত)", style = MaterialTheme.typography.titleMedium, color = BrightGold)
                Spacer(modifier = Modifier.height(6.dp))
                Text(project.script, style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { onSpeakScript(project.script) },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.VolumeUp, contentDescription = null, tint = BrightGold)
                    Text("  বয়ান শুনুন", color = BrightGold)
                }
                OutlinedButton(
                    onClick = {
                        val fullBundle = buildString {
                            appendLine("বাংলা শিরোনাম: ${project.seoTitle}")
                            appendLine("English Title: ${project.englishTitle}")
                            appendLine("\nবর্ণনা:\n${project.seoDescription}")
                            appendLine("\nট্যাগ: ${project.seoTags.joinToString(", ")}")
                            appendLine("হ্যাশট্যাগ: ${project.hashtags.joinToString(" ")}")
                            appendLine("\nস্ক্রিপ্ট:\n${project.script}")
                        }
                        clipboardManager.setText(AnnotatedString(fullBundle))
                        onCopiedAll()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.ContentCopy, contentDescription = null, tint = ElectricBlue)
                    Text("  সব কপি", color = ElectricBlue)
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onExportMp4OrScript,
                    enabled = !isBusy,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldOk, contentColor = DeepNavyBg)
                ) {
                    Icon(Icons.Rounded.SaveAlt, contentDescription = null)
                    Text(if (mp4ProviderConnected) " ফোনে MP4 সেভ" else " স্ক্রিপ্ট সেভ")
                }
                Button(
                    onClick = onSendToYouTubeStudio,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue, contentColor = TextPrimary)
                ) {
                    Text("YouTube স্টুডিও")
                }
            }

            Button(
                onClick = onSendToFacebookStudio,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = ImperialGold, contentColor = DeepNavyBg)
            ) {
                Text("Facebook পেজ স্টুডিওতে পাঠান")
            }
        }
    }
}
