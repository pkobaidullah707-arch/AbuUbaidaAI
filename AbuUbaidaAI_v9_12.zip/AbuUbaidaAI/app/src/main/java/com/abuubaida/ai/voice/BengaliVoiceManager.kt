package com.abuubaida.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.abuubaida.ai.data.model.AssistantSettings
import com.abuubaida.ai.data.model.IslamicVoicePreset
import com.abuubaida.ai.data.model.TtsVoiceOption
import com.abuubaida.ai.data.model.VoiceState
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class BengaliVoiceManager(private val context: Context) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false
    private var speechFinishedCallback: (() -> Unit)? = null
    private var activeFinalUtteranceId: String? = null
    private val pendingSynthesis = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()

    private var activeSettings: AssistantSettings = AssistantSettings()
    private val rawVoicesMap = ConcurrentHashMap<String, Voice>()

    private val _voiceState = MutableStateFlow<VoiceState>(VoiceState.Idle)
    val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

    private val _rmsLevel = MutableStateFlow(0f)
    val rmsLevel: StateFlow<Float> = _rmsLevel.asStateFlow()

    private val _partialTranscript = MutableStateFlow("")
    val partialTranscript: StateFlow<String> = _partialTranscript.asStateFlow()

    private val _ttsSupportedBn = MutableStateFlow(true)
    val ttsSupportedBn: StateFlow<Boolean> = _ttsSupportedBn.asStateFlow()

    private val _availableVoices = MutableStateFlow<List<TtsVoiceOption>>(emptyList())
    val availableVoices: StateFlow<List<TtsVoiceOption>> = _availableVoices.asStateFlow()

    init {
        initTextToSpeech()
    }

    private fun initTextToSpeech() {
        try {
            textToSpeech = TextToSpeech(context.applicationContext) { status ->
                try {
                    if (status == TextToSpeech.SUCCESS) {
                        val bdLocale = Locale("bn", "BD")
                        val result = textToSpeech?.setLanguage(bdLocale)
                        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                            val fallbackResult = textToSpeech?.setLanguage(Locale("bn"))
                            _ttsSupportedBn.value =
                                fallbackResult != TextToSpeech.LANG_MISSING_DATA &&
                                fallbackResult != TextToSpeech.LANG_NOT_SUPPORTED
                        } else {
                            _ttsSupportedBn.value = true
                        }

                        refreshAvailableVoicesLocked()
                        applyVoiceSettingsInternal(activeSettings)

                        textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                            override fun onStart(utteranceId: String?) {}
                            override fun onDone(utteranceId: String?) {
                                val syn = utteranceId?.let { pendingSynthesis.remove(it) }
                                if (syn != null) {
                                    syn.complete(true)
                                    return
                                }
                                if (utteranceId == activeFinalUtteranceId || activeFinalUtteranceId == null) {
                                    mainHandler.post {
                                        activeFinalUtteranceId = null
                                        _voiceState.value = VoiceState.Idle
                                        val cb = speechFinishedCallback
                                        speechFinishedCallback = null
                                        cb?.invoke()
                                    }
                                }
                            }

                            @Deprecated("Deprecated in Java")
                            override fun onError(utteranceId: String?) {
                                val syn = utteranceId?.let { pendingSynthesis.remove(it) }
                                if (syn != null) {
                                    syn.complete(false)
                                    return
                                }
                                if (utteranceId == activeFinalUtteranceId || activeFinalUtteranceId == null) {
                                    mainHandler.post {
                                        activeFinalUtteranceId = null
                                        _voiceState.value = VoiceState.Idle
                                        speechFinishedCallback = null
                                    }
                                }
                            }

                            override fun onError(utteranceId: String?, errorCode: Int) {
                                val syn = utteranceId?.let { pendingSynthesis.remove(it) }
                                if (syn != null) {
                                    syn.complete(false)
                                    return
                                }
                                if (utteranceId == activeFinalUtteranceId || activeFinalUtteranceId == null) {
                                    mainHandler.post {
                                        activeFinalUtteranceId = null
                                        _voiceState.value = VoiceState.Idle
                                        speechFinishedCallback = null
                                    }
                                }
                            }
                        })
                        isTtsReady = true
                    } else {
                        isTtsReady = false
                        _ttsSupportedBn.value = false
                    }
                } catch (_: Throwable) {
                    isTtsReady = false
                    _ttsSupportedBn.value = false
                }
            }
        } catch (_: Throwable) {
            isTtsReady = false
            _ttsSupportedBn.value = false
        }
    }

    private fun refreshAvailableVoicesLocked() {
        try {
            val allVoices = textToSpeech?.voices ?: return
            rawVoicesMap.clear()
            val bnVoices = allVoices
                .filter { v ->
                    val lang = v.locale?.language?.lowercase().orEmpty()
                    lang == "bn" || v.name.contains("bn-", ignoreCase = true) || v.name.contains("bengali", ignoreCase = true)
                }
                .sortedWith(
                    compareByDescending<Voice> { it.locale?.country.equals("BD", ignoreCase = true) }
                        .thenByDescending { !it.isNetworkConnectionRequired }
                        .thenBy { it.name }
                )

            val options = bnVoices.mapIndexed { idx, voice ->
                rawVoicesMap[voice.name] = voice
                val countryLabel = when {
                    voice.locale?.country.equals("BD", ignoreCase = true) -> "বাংলাদেশি"
                    voice.locale?.country.equals("IN", ignoreCase = true) -> "বাংলা"
                    else -> "বাংলা কণ্ঠ"
                }
                val netLabel = if (voice.isNetworkConnectionRequired) "অনলাইন HD" else "অফলাইন"
                val codeSuffix = voice.name.substringAfterLast("-").take(8)
                TtsVoiceOption(
                    name = voice.name,
                    labelBn = "$countryLabel কণ্ঠ ${idx + 1} ($netLabel · $codeSuffix)",
                    localeTag = voice.locale?.toLanguageTag().orEmpty()
                )
            }
            _availableVoices.value = options
        } catch (_: Throwable) {
        }
    }

    fun applyVoiceSettings(settings: AssistantSettings) {
        activeSettings = settings
        mainHandler.post {
            applyVoiceSettingsInternal(settings)
        }
    }

    private fun applyVoiceSettingsInternal(settings: AssistantSettings) {
        val tts = textToSpeech ?: return
        try {
            val pitch = settings.voicePitch.coerceIn(0.65f, 1.35f)
            val rate = settings.voiceRate.coerceIn(0.65f, 1.25f)
            tts.setPitch(pitch)
            tts.setSpeechRate(rate)
            if (settings.selectedTtsVoiceName.isNotBlank()) {
                val chosen = rawVoicesMap[settings.selectedTtsVoiceName]
                    ?: tts.voices?.firstOrNull { it.name == settings.selectedTtsVoiceName }
                if (chosen != null) {
                    tts.voice = chosen
                }
            }
        } catch (_: Throwable) {
        }
    }

    fun isSpeechRecognitionAvailable(): Boolean {
        return SpeechRecognizer.isRecognitionAvailable(context)
    }

    fun buildBengaliSpeechIntent(
        languageTag: String = "bn-BD",
        promptBn: String = "আবু উবাইদা AI-কে বলুন..."
    ): Intent {
        val cleanLang = languageTag.ifBlank { "bn-BD" }
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, cleanLang)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, cleanLang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PROMPT, promptBn)
        }
    }

    fun startListening(
        languageTag: String = "bn-BD",
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        mainHandler.post {
            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                val msg = "সরাসরি মাইক্রোফোন সেবা পাওয়া যায়নি—নিচের 'গুগল ভয়েস ডায়ালগ' বাটনটি ব্যবহার করুন।"
                _voiceState.value = VoiceState.Error(msg)
                onError(msg)
                return@post
            }

            stopSpeaking()
            try {
                speechRecognizer?.cancel()
                speechRecognizer?.destroy()
            } catch (_: Exception) {
            }
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context.applicationContext).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _partialTranscript.value = ""
                        _voiceState.value = VoiceState.Listening
                    }

                    override fun onBeginningOfSpeech() {}

                    override fun onRmsChanged(rmsdB: Float) {
                        val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                        _rmsLevel.value = normalized
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        _rmsLevel.value = 0f
                        _voiceState.value = VoiceState.Processing
                    }

                    override fun onError(error: Int) {
                        _rmsLevel.value = 0f
                        val message = when (error) {
                            SpeechRecognizer.ERROR_AUDIO -> "অডিও রেকর্ডিংয়ে সমস্যা হয়েছে।"
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "মাইক্রোফোন অনুমতি দেওয়া হয়নি।"
                            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                                "ভয়েস চিনতে ইন্টারনেট সংযোগ প্রয়োজন।"
                            SpeechRecognizer.ERROR_NO_MATCH -> "আপনার কথা স্পষ্ট বোঝা যায়নি। আবার বলুন বা 'গুগল ভয়েস' বাটন চাপুন।"
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "কোনো কথা শোনা যায়নি।"
                            else -> "ভয়েস রিকগনিশনে সমস্যা হয়েছে—'গুগল ভয়েস ডায়ালগ' ব্যবহার করে দেখুন।"
                        }
                        _voiceState.value = VoiceState.Error(message)
                        onError(message)
                    }

                    override fun onResults(results: Bundle?) {
                        _rmsLevel.value = 0f
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull()?.trim().orEmpty()
                        if (text.isNotBlank()) {
                            _partialTranscript.value = text
                            onResult(text)
                        } else {
                            val msg = "কোনো বাংলা কথা শনাক্ত করা যায়নি।"
                            _voiceState.value = VoiceState.Error(msg)
                            onError(msg)
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val partial = partialResults
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            .orEmpty()
                        if (partial.isNotBlank()) {
                            _partialTranscript.value = partial
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }

            speechRecognizer?.startListening(buildBengaliSpeechIntent(languageTag = languageTag))
        }
    }

    fun stopListening() {
        mainHandler.post {
            speechRecognizer?.stopListening()
            _rmsLevel.value = 0f
            if (_voiceState.value is VoiceState.Listening) {
                _voiceState.value = VoiceState.Idle
            }
        }
    }

    suspend fun synthesizeBengaliVoiceoverToFile(spokenScript: String, outputWavFile: File): File? {
        if (!isTtsReady || !_ttsSupportedBn.value || spokenScript.isBlank()) return null
        val cleanNarration = cleanNarrationForSpeech(spokenScript)
            .take(3600)
        if (cleanNarration.length < 10) return null

        applyVoiceSettingsInternal(activeSettings)
        outputWavFile.parentFile?.mkdirs()
        if (outputWavFile.exists()) outputWavFile.delete()

        val utteranceId = "vo_${UUID.randomUUID()}"
        val deferred = CompletableDeferred<Boolean>()
        pendingSynthesis[utteranceId] = deferred

        val queued = textToSpeech?.synthesizeToFile(
            cleanNarration,
            Bundle(),
            outputWavFile,
            utteranceId
        ) ?: TextToSpeech.ERROR

        if (queued != TextToSpeech.SUCCESS) {
            pendingSynthesis.remove(utteranceId)
            return null
        }

        val ok = withTimeoutOrNull(30_000L) { deferred.await() } ?: false
        pendingSynthesis.remove(utteranceId)
        return if (ok && outputWavFile.exists() && outputWavFile.length() > 1024L) {
            outputWavFile
        } else {
            null
        }
    }

    fun speak(text: String, onFinished: (() -> Unit)? = null) {
        val cleaned = cleanNarrationForSpeech(text)
        if (!isTtsReady || cleaned.isBlank()) {
            onFinished?.invoke()
            return
        }
        mainHandler.post {
            applyVoiceSettingsInternal(activeSettings)
            val sentences = splitIntoNaturalSentences(cleaned)
            if (sentences.isEmpty()) {
                onFinished?.invoke()
                return@post
            }

            speechFinishedCallback = onFinished
            _voiceState.value = VoiceState.Speaking(cleaned)

            val pauseMs = activeSettings.voicePreset.sentencePauseMs.coerceIn(200L, 800L)
            val finalId = "spk_end_${UUID.randomUUID()}"
            activeFinalUtteranceId = finalId

            sentences.forEachIndexed { idx, sentence ->
                val isFirst = idx == 0
                val isLast = idx == sentences.lastIndex
                val queueMode = if (isFirst) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
                val uid = if (isLast) finalId else "spk_${idx}_${UUID.randomUUID()}"
                textToSpeech?.speak(sentence, queueMode, null, uid)
                if (!isLast) {
                    textToSpeech?.playSilentUtterance(pauseMs, TextToSpeech.QUEUE_ADD, "pause_${idx}_${UUID.randomUUID()}")
                }
            }
        }
    }

    private fun splitIntoNaturalSentences(cleaned: String): List<String> {
        return cleaned
            .split(Regex("[।!?\\n]+"))
            .map { it.trim() }
            .filter { it.length >= 2 }
    }

    fun stopSpeaking() {
        mainHandler.post {
            activeFinalUtteranceId = null
            speechFinishedCallback = null
            textToSpeech?.stop()
            if (_voiceState.value is VoiceState.Speaking) {
                _voiceState.value = VoiceState.Idle
            }
        }
    }

    fun setProcessing() {
        _voiceState.value = VoiceState.Processing
    }

    fun setIdle() {
        _voiceState.value = VoiceState.Idle
    }

    fun release() {
        pendingSynthesis.values.forEach { it.complete(false) }
        pendingSynthesis.clear()
        mainHandler.post {
            activeFinalUtteranceId = null
            speechFinishedCallback = null
            speechRecognizer?.destroy()
            speechRecognizer = null
            textToSpeech?.stop()
            textToSpeech?.shutdown()
            textToSpeech = null
        }
    }

    companion object {
        private val STRUCTURAL_LABELS = listOf(
            "বিসমিল্লাহ ও সূচনা",
            "কুরআনের বাণী",
            "সহীহ হাদিসের শিক্ষা",
            "বাস্তব শিক্ষা ও আমল",
            "মূল আলোচনা",
            "উপসংহার",
            "সমাপ্তি",
            "ভূমিকা",
            "সূচনা",
            "ইনট্রো",
            "আউট্রো",
            "Intro",
            "Outro",
            "Conclusion",
            "Introduction"
        )

        /**
         * ভয়েসওভার ও কথাবার্তা থেকে টাইমকোড (00:10, ০০:১০, ০০৭০), ব্র্যাকেট লেবেল ([...]),
         * এবং 'ভূমিকা / সূচনা / সমাপ্তি' জাতীয় হেডিং সম্পূর্ণ বাদ দেয় যাতে বক্তার মতো মধুর শোনায়।
         */
        fun cleanNarrationForSpeech(rawText: String): String {
            if (rawText.isBlank()) return ""
            var cleaned = rawText
                // Remove [ ... ] blocks even across newlines
                .replace(Regex("\\[[\\s\\S]*?\\]"), "\n")
                // Remove timecodes with colons or hyphens (Bengali & English digits), e.g., 00:10 - 00:30, ০০:১০ থেকে ০০:৩০
                .replace(
                    Regex("[0-9০-৯]{1,2}\\s*[:：.]\\s*[0-9০-৯]{2}(?:\\s*[:：.]\\s*[0-9০-৯]{2})?(?:\\s*(?:-|–|—|থেকে|to)\\s*[0-9০-৯]{1,2}\\s*[:：.]\\s*[0-9০-৯]{2}(?:\\s*[:：.]\\s*[0-9০-৯]{2})?)?"),
                    " "
                )
                // Remove standalone 4-digit timecode runs like 0010, ০০৩০, ০০৫০, ০০৭০
                .replace(Regex("(?:^|\\s)[0০]{2}[0-9০-৯]{2}(?:\\s*(?:-|–|—|থেকে|to)\\s*[0০]{2}[0-9০-৯]{2})?(?=\\s|$|[.,।|])"), " ")
                // Remove Arabic Unicode blocks so Bengali TTS reads smoothly
                .replace(Regex("[\\u0600-\\u06FF\\u0750-\\u077F\\uFB50-\\uFDFF\\uFE70-\\uFEFF]+"), " ")
                // Remove markdown symbols & emojis
                .replace(Regex("[*_#`~|]+"), " ")
                .replace(Regex("[📖📜📚🎬✅⚠️•👉🔊]+"), " ")

            // Strip standalone section headings or line prefixes like "ভূমিকা:", "সূচনা -", "সমাপ্তি", "স্লাইড ১"
            val processedLines = cleaned.lines().mapNotNull { rawLine ->
                var line = rawLine.trim()
                if (line.isBlank()) return@mapNotNull null

                // Remove "স্লাইড ১:", "দৃশ্য ২:", "অংশ ৩:", "ধাপ ১:", "পর্ব ২:"
                line = line.replace(Regex("^(?:স্লাইড|দৃশ্য|অংশ|ধাপ|পর্ব|Scene|Slide|Part)\\s*[0-9০-৯]+\\s*[:：\\-|—]*\\s*", RegexOption.IGNORE_CASE), "").trim()

                for (label in STRUCTURAL_LABELS) {
                    if (line.equals(label, ignoreCase = true)) {
                        line = ""
                        break
                    }
                    val prefixRegex = Regex("^${Regex.escape(label)}\\s*[:：\\-|—।]*\\s*", RegexOption.IGNORE_CASE)
                    line = line.replace(prefixRegex, "").trim()
                }

                line.takeIf { it.isNotBlank() }
            }

            return processedLines
                .joinToString("\n")
                .replace(Regex("[ \\t]+"), " ")
                .replace(Regex("\\n{2,}"), "\n")
                .trim()
        }
    }
}
