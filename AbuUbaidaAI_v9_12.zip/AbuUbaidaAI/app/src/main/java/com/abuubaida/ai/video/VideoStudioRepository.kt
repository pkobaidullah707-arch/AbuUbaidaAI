package com.abuubaida.ai.video

import android.content.Context
import android.net.Uri
import com.abuubaida.ai.data.ai.GeminiAssistantRepository
import com.abuubaida.ai.data.model.IslamicCategory
import com.abuubaida.ai.data.model.VideoDurationOption
import com.abuubaida.ai.data.model.VideoFormat
import com.abuubaida.ai.data.model.VideoProject
import com.abuubaida.ai.data.security.SecurePrefsManager
import com.abuubaida.ai.islamic.IslamicKnowledgeRepository
import com.abuubaida.ai.voice.BengaliVoiceManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

interface VideoGenerationProvider {
    val providerNameBn: String
    val isConnected: Boolean
    suspend fun generateMp4(prompt: String, outputFile: File): Result<Uri>
}

class UnconnectedVideoProvider : VideoGenerationProvider {
    override val providerNameBn: String = "ভিডিও জেনারেশন প্রোভাইডার সংযুক্ত নয়"
    override val isConnected: Boolean = false

    override suspend fun generateMp4(prompt: String, outputFile: File): Result<Uri> {
        return Result.failure(IllegalStateException("MP4 প্রোভাইডার সংযুক্ত নয়।"))
    }
}

class VideoStudioRepository(
    private val context: Context,
    private val securePrefsManager: SecurePrefsManager,
    private val geminiRepo: GeminiAssistantRepository,
    private val islamicKnowledgeRepository: IslamicKnowledgeRepository,
    private val voiceManager: BengaliVoiceManager,
    private val videoProvider: VideoGenerationProvider = LocalMp4VideoProvider(context)
) {
    suspend fun createProjectFromTopic(
        topic: String,
        category: IslamicCategory = IslamicCategory.ISLAMIC_EDUCATION,
        format: VideoFormat = category.defaultFormat,
        durationOption: VideoDurationOption = if (format == VideoFormat.SHORTS_9_16) {
            VideoDurationOption.SHORT_1M
        } else {
            VideoDurationOption.LONG_10M
        }
    ): Result<VideoProject> {
        val controls = securePrefsManager.loadMasterControls()
        if (!controls.contentCreationEnabled) {
            return Result.failure(
                IllegalStateException("মাস্টার কন্ট্রোলে 'কন্টেন্ট তৈরি (Content Creation)' বন্ধ আছে। গোপনীয়তা ড্যাশবোর্ড থেকে চালু করুন।")
            )
        }
        val settings = securePrefsManager.loadSettings()

        // Step 1 & 2: Resolve topic and verify authentic Islamic Quran/Hadith sources
        val verifiedBundle = islamicKnowledgeRepository.prepareVerifiedBundle(topic, category)
        val cleanTopic = verifiedBundle.resolvedTopic

        // Step 3: Script + Bilingual SEO (pure soulful narration — no timestamps or headings)
        val baseProject = if (controls.aiAssistantEnabled) {
            geminiRepo.generateIslamicVideoPackage(cleanTopic, category, format, durationOption, verifiedBundle)
                .getOrElse { buildVerifiedOfflineIslamicPackage(cleanTopic, category, format, durationOption, verifiedBundle) }
        } else {
            buildVerifiedOfflineIslamicPackage(cleanTopic, category, format, durationOption, verifiedBundle)
        }.copy(durationOption = durationOption)

        // Step 4: Pre-publish Islamic Accuracy Review
        val review = islamicKnowledgeRepository.reviewReligiousContent(
            script = baseProject.script,
            quranRef = baseProject.quranReference,
            hadithRef = baseProject.hadithReference,
            category = category
        )

        // Step 5: Synthesize Bengali Islamic speaker TTS Voiceover WAV (when enabled)
        var synthesizedWav: File? = null
        if (settings.includeVoiceoverInVideo) {
            val voDir = File(context.filesDir, "abu_ubaida_voiceovers").apply { mkdirs() }
            val voFile = File(voDir, "vo_${System.currentTimeMillis()}.wav")
            synthesizedWav = voiceManager.synthesizeBengaliVoiceoverToFile(baseProject.script, voFile)
        }

        // Step 6 & 7: Render Thumbnail PNG & Long/Short MP4 Video + Auto-Save to Phone Movies/AbuUbaidaAI
        var projectWithMedia = baseProject.copy(
            accuracyReview = review,
            voiceoverWavPath = synthesizedWav?.absolutePath.orEmpty()
        )

        if (videoProvider is LocalMp4VideoProvider) {
            val thumbDir = File(context.filesDir, "abu_ubaida_thumbnails").apply { mkdirs() }
            val thumbFile = File(thumbDir, "thumb_${System.currentTimeMillis()}.png")
            val thumbRes = videoProvider.renderThumbnailPng(projectWithMedia, thumbFile)
            thumbRes.onSuccess { (uri, localPath) ->
                projectWithMedia = projectWithMedia.copy(
                    thumbnailPngUriString = uri.toString(),
                    thumbnailLocalPath = localPath
                )
            }
        }

        if (!settings.autoSaveMp4ToPhone && videoProvider is LocalMp4VideoProvider) {
            return Result.success(
                projectWithMedia.copy(
                    providerStatusBn = "স্ক্রিপ্ট, থাম্বনেইল ও SEO প্রস্তুত (স্বয়ংক্রিয় MP4 সেভ বন্ধ রাখা আছে — চাইলে নিচে থেকে সংরক্ষণ করুন)।"
                )
            )
        }

        val mp4Res = exportMp4WithDetails(projectWithMedia)
        val finalProject = mp4Res.fold(
            onSuccess = { (mp4Uri, displayPath) ->
                val audioNote = if (!settings.includeVoiceoverInVideo) {
                    "ভয়েসওভার সুইচ বন্ধ থাকায় কেবল ভিজ্যুয়াল ইসলামিক স্লাইড ও সাবটাইটেলসহ MP4 তৈরি হয়েছে।"
                } else if (synthesizedWav != null) {
                    "মধুর বাংলা ইসলামিক কণ্ঠ ও সাবটাইটেলসহ ${durationOption.labelBn} MP4 ফোনে সংরক্ষিত হয়েছে।"
                } else {
                    "স্পষ্ট সাবটাইটেল ও যাচাইকৃত কুরআন-হাদিস কার্ডসহ ${durationOption.labelBn} MP4 ফোনে সংরক্ষিত হয়েছে।"
                }
                projectWithMedia.copy(
                    renderedMp4UriString = mp4Uri.toString(),
                    savedMp4DisplayPath = displayPath,
                    audioRightsNoteBn = audioNote,
                    providerStatusBn = "সম্পূর্ণ ${durationOption.labelBn} ইসলামিক MP4 ভিডিও ফোনে সংরক্ষিত হয়েছে ($displayPath)!"
                )
            },
            onFailure = {
                projectWithMedia.copy(
                    providerStatusBn = "স্ক্রিপ্ট, থাম্বনেইল ও SEO প্রস্তুত।"
                )
            }
        )

        return Result.success(finalProject)
    }

    private fun buildVerifiedOfflineIslamicPackage(
        topic: String,
        category: IslamicCategory,
        format: VideoFormat,
        durationOption: VideoDurationOption,
        bundle: IslamicKnowledgeRepository.VerifiedTopicBundle
    ): VideoProject {
        val quran = bundle.quranRef
        val hadith = bundle.hadithRef
        val isShort = format == VideoFormat.SHORTS_9_16 || durationOption == VideoDurationOption.SHORT_1M

        val narrativeParagraphs = mutableListOf<String>()
        narrativeParagraphs += "বিসমিল্লাহির রাহমানির রাহীম। আসসালামু আলাইকুম ওয়া রাহমাতুল্লাহি ওয়া বারাকাতুহ। প্রিয় দ্বীনি ভাই ও বোনেরা, মহান আল্লাহ তাআলার অশেষ রহমত ও বরকতে আজ আমরা হৃদয়স্পর্শী একটি বিষয় \"$topic\" নিয়ে আলোচনা করব।"

        if (quran != null) {
            narrativeParagraphs += "আমাদের জীবনের প্রতিটি পদক্ষেপে আল-কুরআনের আলোই সবচেয়ে বড় পথপ্রদর্শক। মহান আল্লাহ রাব্বুল আলামীন ${quran.surahNameBn}-এ অত্যন্ত মমতায় আমাদের উদ্দেশ্যে ইরশাদ করেছেন, \"${quran.bengaliTranslation}\"। এই পবিত্র বাণী আমাদের অন্তরে প্রশান্তি ও আল্লাহর প্রতি গভীর ভরসা জাগিয়ে তোলে।"
        }

        if (hadith != null) {
            narrativeParagraphs += "প্রিয় নবী হযরত মুহাম্মাদ মুস্তাফা সাল্লাল্লাহু আলাইহি ওয়া সাল্লাম আমাদেরকে জীবনের বাস্তব পথ দেখিয়েছেন। ${hadith.narratorBn} বর্ণনা করেন, রাসূলুল্লাহ সাল্লাল্লাহু আলাইহি ওয়া সাল্লাম বলেছেন, \"${hadith.bengaliText}\"। এই হাদিসটি ${hadith.collectionBn} গ্রন্থে বর্ণিত হয়েছে এবং আমাদের দৈনন্দিন চরিত্র গঠনের জন্য এক অমূল্য রত্ন।"
        }

        narrativeParagraphs += bundle.historicalContextBn

        if (durationOption.durationSeconds >= 300) {
            narrativeParagraphs += "প্রিয় বন্ধুগণ, একটু গভীরভাবে ভেবে দেখুন তো—দুনিয়ার এই ক্ষণস্থায়ী ব্যস্ততার মাঝে আমরা কতটুকু সময় আমাদের রবের জন্য আলাদা করে রাখছি? প্রতিদিন ফজরের পর কয়েক মিনিট কুরআন তেলাওয়াত ও অর্থ অনুধাবন করলে অন্তরের সমস্ত অস্থিরতা ও দুশ্চিন্তা দূর হয়ে যায়।"
            narrativeParagraphs += "পরিবারের সবাইকে নিয়ে সপ্তাহে অন্তত একদিন ইসলামের সুন্দর শিক্ষা, নবীজির আদর্শ ও সাহাবায়ে কেরামের ত্যাগের গল্প আলোচনা করা উচিত। এতে ঘরে রহমতের ফেরেশতা নাজিল হয় এবং সন্তানদের মনে আল্লাহর ভালোবাসা গড়ে ওঠে।"
            narrativeParagraphs += "বিপদ, অভাব বা অসুস্থতা এলে মুমিন কখনো ভেঙে পড়ে না। বরং সে ধৈর্য ধরে, নামাজে দাঁড়িয়ে অশ্রুসিক্ত চোখে আল্লাহর কাছে চায় এবং দৃঢ় বিশ্বাস রাখে যে প্রতিটি পরীক্ষার পেছনেই আল্লাহর অপার কল্যাণ লুকিয়ে আছে।"
        }

        if (durationOption.durationSeconds >= 600) {
            narrativeParagraphs += "আমাদের আচরণ, কথা ও লেনদেন যেন অন্য মানুষের জন্য শান্তির কারণ হয়। বাবা-মায়ের সেবা, প্রতিবেশীর হক আদায় এবং অসহায় মানুষের পাশে দাঁড়ানো ইবাদতেরই এক অনন্য অংশ। সত্য কথা বলা ও আমানত রক্ষা করার মাধ্যমেই প্রকৃত মুমিনের পরিচয় ফুটে ওঠে।"
            narrativeParagraphs += "সকাল ও সন্ধ্যার যিকির, দুরুদ শরীফ ও ইস্তিগফার মানুষের রিজিক ও হৃদয়ে বরকত বয়ে আনে। যখন আমরা বেশি বেশি আল্লাহকে স্মরণ করি, তখন শয়তানের কুমন্ত্রণা দুর্বল হয়ে যায় এবং মনে এক অদ্ভুত প্রশান্তি নেমে আসে।"
            narrativeParagraphs += "গীবত, পরনিন্দা ও হিংসা আমাদের নেক আমলগুলোকে নষ্ট করে দেয়। তাই আজ থেকেই প্রতিজ্ঞা করি, আমরা কারও ক্ষতি চাইব না, বরং সবার কল্যাণের জন্য দোয়া করব এবং ক্ষমাসুন্দর দৃষ্টিভঙ্গি লালন করব।"
            narrativeParagraphs += "সদকা ও দান কেবল অর্থের মাধ্যমেই নয়, বরং একটি মিষ্টি হাসি, ভালো পরামর্শ এবং কাউকে সৎপথে ডাকাও মহান আল্লাহর কাছে অতি প্রিয় সদকা।"
        }

        if (durationOption.durationSeconds >= 1200) {
            narrativeParagraphs += "ইতিহাসের পাতায় চোখ রাখলে দেখা যায়, যখনই মুসলিম উম্মাহ কুরআন ও সুন্নাহকে দৃঢ়ভাবে আঁকড়ে ধরেছে, তখনই তারা সম্মান ও সফলতা অর্জন করেছে। ব্যক্তি জীবন থেকে শুরু করে সমাজের প্রতিটি স্তরে সততা, ন্যায়বিচার ও তাকওয়া প্রতিষ্ঠা করাই আমাদের মূল লক্ষ্য হওয়া উচিত।"
            narrativeParagraphs += "রাতে ঘুমানোর আগে নিজেকে প্রশ্ন করুন—আজকের দিনটি কি আমার আখিরাতের পাথেয় বাড়াতে কাজে লেগেছে? কোনো ভুল হয়ে থাকলে সাথে সাথে আন্তরিকভাবে তওবা করে নিন, কারণ আল্লাহ তাআলা তওবাকারীকে অত্যন্ত ভালোবাসেন।"
            narrativeParagraphs += "কবর ও আখিরাতের অনন্ত জীবনের প্রস্তুতি এখন থেকেই শুরু করতে হবে। আমাদের উপার্জনে হালাল থাকা, ওয়াক্তমতো পাঁচ ওয়াক্ত নামাজ আদায় করা এবং পিতামাতার দোয়া নেওয়াই আমাদের পরকালের শ্রেষ্ঠ সঞ্চয়।"
        }

        narrativeParagraphs += "মহান আল্লাহ তাআলা আমাদের সবাইকে সহীহ বুঝ, খাঁটি ঈমান এবং কুরআন ও সুন্নাহ অনুযায়ী জীবন গড়ার তাওফীক দান করুন। এই দ্বীনি বার্তাটি প্রিয়জনদের সাথে শেয়ার করে সদকায়ে জারিয়ার অংশীদার হোন। আমীন, ইয়া রাব্বাল আলামীন।"

        val script = narrativeParagraphs.joinToString("\n\n")

        val subtitles = buildList {
            add("বিসমিল্লাহির রাহমানির রাহীম — $topic")
            if (quran != null) add("${quran.surahNameBn}: ${quran.bengaliTranslation}")
            if (hadith != null) add("${hadith.collectionBn}: ${hadith.bengaliText}")
            add("প্রতিদিন অন্তত একটি ভালো আমল নিয়মিত করি ও অন্যকে দাওয়াত দিই।")
            add("আল্লাহ আমাদের সবাইকে সহীহ আমলের তাওফীক দিন — আমীন।")
        }

        val seoTitle = if (isShort) {
            "$topic | ইসলামিক শর্টস #Shorts"
        } else {
            "$topic — কুরআন ও সহীহ হাদিসের আলোকে হৃদয়ছোঁয়া বয়ান (${durationOption.labelBn})"
        }
        val englishTitle = "$topic | Authentic Islamic Lecture & Reminder (Bangla)"

        val description = buildString {
            appendLine("বিষয়: $topic")
            appendLine("বিভাগ: ${category.labelBn} · সময়: ${durationOption.labelBn}")
            appendLine()
            if (quran != null) {
                appendLine("কুরআনের সূত্র: ${quran.surahNameBn}")
                appendLine("আরবি: ${quran.arabicUthmaniText}")
                appendLine("অনুবাদ: ${quran.bengaliTranslation}")
                appendLine()
            }
            if (hadith != null) {
                appendLine("হাদিসের সূত্র: ${hadith.collectionBn} (${hadith.referenceNumber}) — ${hadith.gradingNoteBn}")
                appendLine("${hadith.bengaliText}")
                appendLine()
            }
            appendLine("সতর্কতা: ইসলামিক তথ্যের বিশুদ্ধতা নিশ্চিত করতে নির্ভরযোগ্য আলেম ও মূল গ্রন্থের সাথে মিলিয়ে পড়ার অনুরোধ রইল।")
            appendLine()
            appendLine("#ইসলামিকভিডিও #QuranBangla #HadithBangla #AbuUbaidaAI #BanglaWaz")
        }

        val keywords = listOf(
            topic,
            category.labelBn,
            "বাংলা ইসলামিক বয়ান",
            "কুরআন ও হাদিস",
            "Bangla Islamic Lecture"
        )
        val tags = listOf(
            topic,
            "ইসলামিক ভিডিও বাংলা",
            category.labelBn,
            "কুরআন তেলাওয়াত ও অর্থ",
            "সহীহ হাদিস বাংলা",
            "আবু উবাইদা AI"
        )
        val hashtags = listOf("#ইসলামিকভিডিও", "#কুরআন", "#সহীহহাদিস", "#BanglaWaz", "#AbuUbaidaAI")
        val thumbText = topic.take(36)

        return VideoProject(
            topic = topic,
            category = category,
            format = format,
            durationOption = durationOption,
            script = script,
            subtitleLines = subtitles,
            seoTitle = seoTitle,
            englishTitle = englishTitle,
            seoDescription = description,
            seoKeywords = keywords,
            seoTags = tags,
            hashtags = hashtags,
            thumbnailText = thumbText,
            thumbnailDesignSummary = "ডিপ নেভি ও গোল্ডেন ইসলামিক ৮-কোনা নক্ষত্র ডিজাইন, উপরে স্পষ্ট বাংলা শিরোনাম ও সূরা/হাদিস সূত্র।",
            thumbnailPrompts = listOf(
                "Respectful deep navy blue and radiant gold Islamic geometric 8-point star frame for '$topic', dignified educational style, 4K",
                "Minimalist dark sapphire background with subtle golden arabesque border and room for Bengali headline '$thumbText'"
            ),
            quranReference = quran,
            hadithReference = hadith,
            providerStatusBn = "যাচাইকৃত ইসলামিক সূত্র ও মধুর ওয়াজ স্ক্রিপ্ট প্রস্তুত।"
        )
    }

    fun isMp4ProviderConnected(): Boolean = videoProvider.isConnected

    suspend fun exportMp4IfConnected(project: VideoProject): Result<Uri> =
        exportMp4WithDetails(project).map { it.first }

    suspend fun exportMp4WithDetails(project: VideoProject): Result<Pair<Uri, String>> = withContext(Dispatchers.IO) {
        if (!videoProvider.isConnected) {
            return@withContext videoProvider.generateMp4(project.topic, File(context.cacheDir, "placeholder.mp4"))
                .map { it to "cache" }
        }
        val outDir = File(context.filesDir, "abu_ubaida_videos").apply { mkdirs() }
        val durationTag = "${project.durationOption.durationSeconds / 60}m"
        val file = File(outDir, "AbuUbaida_${durationTag}_${System.currentTimeMillis()}.mp4")
        if (videoProvider is LocalMp4VideoProvider) {
            videoProvider.renderProjectSlidesMp4WithPath(project, file)
        } else {
            videoProvider.generateMp4(
                prompt = project.thumbnailPrompts.firstOrNull() ?: project.topic,
                outputFile = file
            ).map { it to file.absolutePath }
        }
    }

    suspend fun exportScriptTextPackage(project: VideoProject): Result<File> = withContext(Dispatchers.IO) {
        return@withContext try {
            val outDir = File(context.filesDir, "abu_ubaida_scripts").apply { mkdirs() }
            val file = File(outDir, "script_${System.currentTimeMillis()}.txt")
            val content = buildString {
                appendLine("=== আবু উবাইদা AI ইসলামিক ভিডিও স্টুডিও প্যাকেজ ===")
                appendLine("বিষয়: ${project.topic} | বিভাগ: ${project.category.labelBn} | সময়: ${project.durationOption.labelBn}")
                appendLine("ধর্মীয় সূত্র যাচাই: ${project.accuracyReview.sourceCitationBn}")
                appendLine()
                appendLine("বাংলা SEO শিরোনাম: ${project.seoTitle}")
                appendLine("English Title: ${project.englishTitle}")
                appendLine("SEO বর্ণনা:\n${project.seoDescription}")
                appendLine("ট্যাগসমূহ: ${project.seoTags.joinToString(", ")}")
                appendLine("হ্যাশট্যাগ: ${project.hashtags.joinToString(" ")}")
                appendLine()
                appendLine("--- বাংলা চিত্রনাট্য (Script) ---")
                appendLine(project.script)
            }
            file.writeText(content)
            Result.success(file)
        } catch (e: Exception) {
            Result.failure(IllegalStateException("স্ক্রিপ্ট সংরক্ষণ করা যায়নি: ${e.localizedMessage}"))
        }
    }

    fun wipeGeneratedLocalFiles() {
        listOf("abu_ubaida_videos", "abu_ubaida_scripts", "abu_ubaida_thumbnails", "abu_ubaida_voiceovers")
            .forEach { folder ->
                File(context.filesDir, folder).deleteRecursively()
            }
    }
}
