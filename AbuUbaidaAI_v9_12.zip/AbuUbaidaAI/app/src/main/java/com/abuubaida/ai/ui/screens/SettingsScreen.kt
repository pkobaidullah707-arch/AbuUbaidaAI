package com.abuubaida.ai.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.abuubaida.ai.data.model.AssistantSettings
import com.abuubaida.ai.data.model.IslamicVoicePreset
import com.abuubaida.ai.data.model.TtsVoiceOption
import com.abuubaida.ai.ui.components.GlassCard
import com.abuubaida.ai.ui.theme.BrightGold
import com.abuubaida.ai.ui.theme.DeepNavyBg
import com.abuubaida.ai.ui.theme.ElectricBlue
import com.abuubaida.ai.ui.theme.EmeraldOk
import com.abuubaida.ai.ui.theme.ImperialGold
import com.abuubaida.ai.ui.theme.NavyBorder
import com.abuubaida.ai.ui.theme.RoyalBlue
import com.abuubaida.ai.ui.theme.TextPrimary
import com.abuubaida.ai.ui.theme.TextSecondary
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    currentSettings: AssistantSettings,
    availableVoices: List<TtsVoiceOption>,
    isFirebaseConfigured: Boolean,
    onSaveSettings: (AssistantSettings) -> Unit,
    onPreviewVoice: (AssistantSettings) -> Unit,
    onOpenAssistantRoleSettings: () -> Unit,
    onOpenBatterySettings: () -> Unit
) {
    val context = LocalContext.current
    var wakePhrase by remember(currentSettings.wakePhrase) { mutableStateOf(currentSettings.wakePhrase) }
    var ttsEnabled by remember(currentSettings.ttsEnabled) { mutableStateOf(currentSettings.ttsEnabled) }
    var continuousMode by remember(currentSettings.continuousVoiceMode) {
        mutableStateOf(currentSettings.continuousVoiceMode)
    }
    var bgEnabled by remember(currentSettings.backgroundServiceEnabled) {
        mutableStateOf(currentSettings.backgroundServiceEnabled)
    }
    var proxyUrl by remember(currentSettings.proxyEndpointUrl) {
        mutableStateOf(currentSettings.proxyEndpointUrl)
    }
    var voicePreset by remember(currentSettings.voicePreset) {
        mutableStateOf(currentSettings.voicePreset)
    }
    var voicePitch by remember(currentSettings.voicePitch) {
        mutableFloatStateOf(currentSettings.voicePitch)
    }
    var voiceRate by remember(currentSettings.voiceRate) {
        mutableFloatStateOf(currentSettings.voiceRate)
    }
    var selectedTtsVoiceName by remember(currentSettings.selectedTtsVoiceName) {
        mutableStateOf(currentSettings.selectedTtsVoiceName)
    }
    var includeVoiceover by remember(currentSettings.includeVoiceoverInVideo) {
        mutableStateOf(currentSettings.includeVoiceoverInVideo)
    }
    var autoSaveMp4 by remember(currentSettings.autoSaveMp4ToPhone) {
        mutableStateOf(currentSettings.autoSaveMp4ToPhone)
    }

    fun buildCurrentSettings(overrideBg: Boolean = bgEnabled): AssistantSettings =
        AssistantSettings(
            wakePhrase = wakePhrase.ifBlank { "হ্যালো আবু উবাইদা" },
            ttsEnabled = ttsEnabled,
            continuousVoiceMode = continuousMode,
            backgroundServiceEnabled = overrideBg,
            proxyEndpointUrl = proxyUrl,
            speechLanguageTag = currentSettings.speechLanguageTag,
            voicePreset = voicePreset,
            voicePitch = voicePitch,
            voiceRate = voiceRate,
            selectedTtsVoiceName = selectedTtsVoiceName,
            includeVoiceoverInVideo = includeVoiceover,
            autoSaveMp4ToPhone = autoSaveMp4
        )

    val fgPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val micOk = results[Manifest.permission.RECORD_AUDIO] == true
        bgEnabled = micOk
        onSaveSettings(buildCurrentSettings(overrideBg = micOk))
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("সেটিংস — আবু উবাইদা AI", style = MaterialTheme.typography.headlineMedium, color = BrightGold)

        // Islamic Waaz Speaker Voice Customization Card
        GlassCard(borderColor = ImperialGold.copy(alpha = 0.55f)) {
            Text("ইসলামিক বক্তা ও মাধুর্যময় ভয়েস সেটিংস", style = MaterialTheme.typography.titleMedium, color = BrightGold)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                "পছন্দের ওয়াজ-মাহফিলের মিষ্টি কণ্ঠ বেছে নিন, কণ্ঠের সুর ও গতি সাজিয়ে নিন এবং নমুনা শুনে যাচাই করুন:",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                IslamicVoicePreset.entries.forEach { preset ->
                    FilterChip(
                        selected = voicePreset == preset,
                        onClick = {
                            voicePreset = preset
                            voicePitch = preset.pitch
                            voiceRate = preset.rate
                        },
                        label = { Text(preset.labelBn) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = RoyalBlue,
                            selectedLabelColor = TextPrimary,
                            containerColor = DeepNavyBg,
                            labelColor = TextSecondary
                        )
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(voicePreset.descBn, color = EmeraldOk, style = MaterialTheme.typography.bodyMedium)

            Spacer(modifier = Modifier.height(10.dp))
            Text("কণ্ঠের মিষ্টতা / সুর (Pitch): ${(voicePitch * 100).roundToInt()}%", color = TextPrimary)
            Slider(
                value = voicePitch,
                onValueChange = { voicePitch = it.coerceIn(0.70f, 1.25f) },
                valueRange = 0.70f..1.25f
            )

            Text("কথার গতি (Speed): ${(voiceRate * 100).roundToInt()}%", color = TextPrimary)
            Slider(
                value = voiceRate,
                onValueChange = { voiceRate = it.coerceIn(0.70f, 1.15f) },
                valueRange = 0.70f..1.15f
            )

            if (availableVoices.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text("ডিভাইস ভয়েস পরিবর্তন (বাংলা TTS):", style = MaterialTheme.typography.labelLarge, color = ElectricBlue)
                Spacer(modifier = Modifier.height(4.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = selectedTtsVoiceName.isBlank(),
                        onClick = { selectedTtsVoiceName = "" },
                        label = { Text("অটো সেরা বাংলা কণ্ঠ") }
                    )
                    availableVoices.take(6).forEach { v ->
                        FilterChip(
                            selected = selectedTtsVoiceName == v.name,
                            onClick = { selectedTtsVoiceName = v.name },
                            label = { Text(v.labelBn) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { onPreviewVoice(buildCurrentSettings()) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue, contentColor = TextPrimary)
                ) {
                    Text("ভয়েস টেস্ট শুনুন")
                }
                OutlinedButton(
                    onClick = {
                        voicePreset = IslamicVoicePreset.SWEET_WAAZ
                        voicePitch = IslamicVoicePreset.SWEET_WAAZ.pitch
                        voiceRate = IslamicVoicePreset.SWEET_WAAZ.rate
                        selectedTtsVoiceName = ""
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("ওয়াজ মোডে রিসেট", color = BrightGold)
                }
            }
        }

        GlassCard(borderColor = ImperialGold.copy(alpha = 0.45f)) {
            Text("ভয়েস, ভিডিও অডিও ও ওয়েক-ফ্রেজ", style = MaterialTheme.typography.titleMedium, color = BrightGold)
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = wakePhrase,
                onValueChange = { wakePhrase = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("ভয়েস ওয়েক-ফ্রেজ") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = NavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )
            Spacer(modifier = Modifier.height(10.dp))
            SettingToggleRow(
                title = "বাংলা ভয়েস উত্তর (TTS)",
                subtitle = "প্রতিটি উত্তর বাংলায় পড়ে শোনাবে",
                checked = ttsEnabled,
                onCheckedChange = { ttsEnabled = it }
            )
            SettingToggleRow(
                title = "ভিডিওতে ওয়াজ ভয়েসওভার",
                subtitle = "ভিডিও তৈরির সময় মধুর বাংলা ভয়েসওভার যুক্ত করবে",
                checked = includeVoiceover,
                onCheckedChange = { includeVoiceover = it }
            )
            SettingToggleRow(
                title = "ফোনে MP4 অটো-সেভ",
                subtitle = "ভিডিও তৈরির সাথে সাথে Movies/AbuUbaidaAI-এ MP4 সংরক্ষণ করবে",
                checked = autoSaveMp4,
                onCheckedChange = { autoSaveMp4 = it }
            )
            SettingToggleRow(
                title = "হ্যান্ডস-ফ্রি কন্টিনিউয়াস মোড",
                subtitle = "উত্তর বলার পর নিজে থেকেই আবার শুনবে",
                checked = continuousMode,
                onCheckedChange = { continuousMode = it }
            )
        }

        GlassCard(borderColor = ElectricBlue.copy(alpha = 0.4f)) {
            Text("ব্যাকগ্রাউন্ড ভয়েস অ্যাসিস্ট্যান্ট", style = MaterialTheme.typography.titleMedium, color = ElectricBlue)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "চালু করলে স্থায়ী দৃশ্যমান নোটিফিকেশনসহ ফোরগ্রাউন্ড মাইক্রোফোন সার্ভিস চলবে এবং \"$wakePhrase\" শুনবে। কোনো গোপন রেকর্ডিং করা হয় না।",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("ফোরগ্রাউন্ড ওয়েক-ফ্রেজ সার্ভিস", color = TextPrimary)
                Switch(
                    checked = bgEnabled,
                    onCheckedChange = { wantEnable ->
                        if (wantEnable) {
                            val micGranted = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED
                            if (micGranted) {
                                bgEnabled = true
                            } else {
                                val perms = buildList {
                                    add(Manifest.permission.RECORD_AUDIO)
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        add(Manifest.permission.POST_NOTIFICATIONS)
                                    }
                                }.toTypedArray()
                                fgPermLauncher.launch(perms)
                            }
                        } else {
                            bgEnabled = false
                        }
                    }
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = onOpenAssistantRoleSettings, modifier = Modifier.weight(1f)) {
                    Text("ডিফল্ট অ্যাসিস্ট্যান্ট", color = BrightGold)
                }
                OutlinedButton(onClick = onOpenBatterySettings, modifier = Modifier.weight(1f)) {
                    Text("ব্যাটারি সেটিংস", color = ElectricBlue)
                }
            }
        }

        GlassCard {
            Text("স্বয়ংক্রিয় AI ও রিসার্চ ইঞ্জিন", style = MaterialTheme.typography.titleMedium, color = BrightGold)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (isFirebaseConfigured) {
                    "Firebase AI Logic + স্বয়ংক্রিয় কুরআন-হাদিস ও পাবলিক নলেজ রাউটিং সক্রিয় আছে।"
                } else {
                    "স্বয়ংক্রিয় মোড চালু আছে: কুরআন API, ইসলামিক জ্ঞানভাণ্ডার, ভয়েস কমান্ড ও ভিডিও স্টুডিও কোনো ম্যানুয়াল URL ছাড়াই নিজে থেকেই কাজ করবে। (নিচে প্রক্সি URL সম্পূর্ণ ঐচ্ছিক)"
                },
                style = MaterialTheme.typography.bodyMedium,
                color = EmeraldOk
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = proxyUrl,
                onValueChange = { proxyUrl = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("উন্নত সার্ভার প্রক্সি HTTPS URL (সম্পূর্ণ ঐচ্ছিক)") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = NavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                singleLine = true
            )
        }

        Button(
            onClick = { onSaveSettings(buildCurrentSettings()) },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = ImperialGold, contentColor = DeepNavyBg)
        ) {
            Text("সব সেটিংস ও ভয়েস পছন্দ সংরক্ষণ করুন")
        }
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text(title, color = TextPrimary)
            Text(subtitle, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
