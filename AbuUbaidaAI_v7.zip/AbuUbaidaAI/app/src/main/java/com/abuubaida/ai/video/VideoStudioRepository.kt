package com.abuubaida.ai.video

import android.content.Context
import android.net.Uri
import com.abuubaida.ai.data.ai.GeminiAssistantRepository
import com.abuubaida.ai.data.model.IslamicCategory
import com.abuubaida.ai.data.model.VideoFormat
import com.abuubaida.ai.data.model.VideoProject
import com.abuubaida.ai.data.security.SecurePrefsManager
import com.abuubaida.ai.islamic.IslamicKnowledgeRepository
import com.abuubaida.ai.voice.BengaliVoiceManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

interface VideoGenerationProvider {
    val providerNameBn: String
    val isConnected: Boolean
    suspend fun generateMp4(prompt: String, outputFile: File): Result<Uri>
}

class UnconnectedVideoProvider : VideoGenerationProvider {
    override val providerNameBn: String = "ভিডিও জেনারেশন প্রোভাইডার সংযুক্ত নয়"
    override val isConnected: Boolean = false

    override suspend fun generateMp4(prompt: String, outputFile: File): Result<Uri> {
        return Result.failure(IllegalStateException("MP4 প্রোভাইডার সংযুক্ত নয়।"))
    }
}

class VideoStudioRepository(
    private val context: Context,
    private val securePrefsManager: SecurePrefsManager,
    private val geminiRepo: GeminiAssistantRepository,
    private val islamicKnowledgeRepository: IslamicKnowledgeRepository,
    private val voiceManager: BengaliVoiceManager,
    private val videoProvider: VideoGenerationProvider = LocalMp4VideoProvider(context)
) {
    suspend fun createProjectFromTopic(
        topic: String,
        category: IslamicCategory = IslamicCategory.ISLAMIC_EDUCATION,
        format: VideoFormat = category.defaultFormat
    ): Result<VideoProject> {
        val controls = securePrefsManager.loadMasterControls()
        if (!controls.contentCreationEnabled) {
            return Result.failure(
                IllegalStateException("মাস্টার কন্ট্রোলে 'কন্টেন্ট তৈরি (Content Creation)' বন্ধ আছে। গোপনীয়তা ড্যাশবোর্ড থেকে চালু করুন।")
            )
        }

        // Step 1 & 2: Resolve topic and verify authentic Islamic Quran/Hadith sources
        val verifiedBundle = islamicKnowledgeRepository.prepareVerifiedBundle(topic, category)
        val cleanTopic = verifiedBundle.resolvedTopic

        // Step 3: Script + Bilingual SEO via Gemini (if enabled & connected) or verified offline template
        val baseProject = if (controls.aiAssistantEnabled) {
            geminiRepo.generateIslamicVideoPackage(cleanTopic, category, format, verifiedBundle)
                .getOrElse { buildVerifiedOfflineIslamicPackage(cleanTopic, category, format, verifiedBundle) }
        } else {
            buildVerifiedOfflineIslamicPackage(cleanTopic, category, format, verifiedBundle)
        }

        // Step 4: Pre-publish Islamic Accuracy Review
        val review = islamicKnowledgeRepository.reviewReligiousContent(
            script = baseProject.script,
            quranRef = baseProject.quranReference,
            hadithRef = baseProject.hadithReference,
            category = category
        )

        // Step 5: Synthesize Bengali TTS Voiceover WAV (if device Bengali TTS exists)
        val voDir = File(context.filesDir, "abu_ubaida_voiceovers").apply { mkdirs() }
        val voFile = File(voDir, "vo_${System.currentTimeMillis()}.wav")
        val synthesizedWav = voiceManager.synthesizeBengaliVoiceoverToFile(baseProject.script, voFile)

        // Step 6 & 7: Render Thumbnail PNG & MP4 Video (with burned-in subtitles & optional voiceover muxing)
        var projectWithMedia = baseProject.copy(
            accuracyReview = review,
            voiceoverWavPath = synthesizedWav?.absolutePath.orEmpty()
        )

        if (videoProvider is LocalMp4VideoProvider) {
            val thumbDir = File(context.filesDir, "abu_ubaida_thumbnails").apply { mkdirs() }
            val thumbFile = File(thumbDir, "thumb_${System.currentTimeMillis()}.png")
            val thumbRes = videoProvider.renderThumbnailPng(projectWithMedia, thumbFile)
            thumbRes.onSuccess { (uri, localPath) ->
                projectWithMedia = projectWithMedia.copy(
                    thumbnailPngUriString = uri.toString(),
                    thumbnailLocalPath = localPath
                )
            }
        }

        val mp4Res = exportMp4IfConnected(projectWithMedia)
        val finalProject = mp4Res.fold(
            onSuccess = { mp4Uri ->
                val audioNote = if (synthesizedWav != null) {
                    "বাংলা TTS ভয়েসওভার ও সাবটাইটেলসহ MP4 তৈরি হয়েছে। কোনো কপিরাইটযুক্ত মিউজিক যুক্ত করা হয়নি।"
                } else {
                    "সাবটাইটেল ও যাচাইকৃত কার্ডসহ MP4 তৈরি হয়েছে (ডিভাইসে অফলাইন বাংলা TTS ভয়েস ফাইল না থাকায় ভিজ্যুয়াল কার্ড রেন্ডার হয়েছে)।"
                }
                projectWithMedia.copy(
                    renderedMp4UriString = mp4Uri.toString(),
                    audioRightsNoteBn = audioNote,
                    providerStatusBn = "সম্পূর্ণ ইসলামিক ভিডিও, থাম্বনেইল, SEO ও সাবটাইটেল প্রস্তুত!"
                )
            },
            onFailure = {
                projectWithMedia.copy(
                    providerStatusBn = "স্ক্রিপ্ট, থাম্বনেইল ও SEO প্রস্তুত।"
                )
            }
        )

        return Result.success(finalProject)
    }

    private fun buildVerifiedOfflineIslamicPackage(
        topic: String,
        category: IslamicCategory,
        format: VideoFormat,
        bundle: IslamicKnowledgeRepository.VerifiedTopicBundle
    ): VideoProject {
        val quran = bundle.quranRef
        val hadith = bundle.hadithRef
        val isShort = format == VideoFormat.SHORTS_9_16

        val script = buildString {
            appendLine("[০:০০ - ০:১০ | বিসমিল্লাহ ও সূচনা]")
            appendLine("বিসমিল্লাহির রাহমানির রাহীম। আসসালামু আলাইকুম!")
            appendLine("আজকের ${category.labelBn} পর্বে আমাদের বিষয়: \"$topic\"।")
            appendLine()
            if (quran != null) {
                appendLine("[০:১০ - ০:৩০ | কুরআনের বাণী — ${quran.surahNameBn}]")
                appendLine("আল্লাহ তাআলা কুরআনুল কারীমে ইরশাদ করেন (${quran.surahNameBn}):")
                appendLine("\"${quran.bengaliTranslation}\"")
                appendLine()
            }
            if (hadith != null) {
                appendLine("[০:৩০ - ০:৫০ | সহীহ হাদিসের শিক্ষা — ${hadith.collectionBn}]")
                appendLine("${hadith.narratorBn} বর্ণনা করেন, রাসূলুল্লাহ (সা.) বলেছেন:")
                appendLine("\"${hadith.bengaliText}\" (${hadith.collectionBn}, ${hadith.referenceNumber})।")
                appendLine()
            }
            appendLine("[বাস্তব শিক্ষা ও আমল]")
            appendLine(bundle.historicalContextBn)
            appendLine("আসুন, আমরা প্রতিদিন অন্তত একটি ভালো আমল নিয়মিত করি এবং অন্যকে সৎকাজের দাওয়াত দিই।")
            appendLine()
            appendLine("[সমাপ্তি]")
            appendLine("আল্লাহ তাআলা আমাদের সবাইকে সহীহ বুঝ ও আমলের তাওফীক দিন। ভিডিওটি শেয়ার করে সদকায়ে জারিয়ার অংশীদার হোন।")
        }

        val subtitles = buildList {
            add("বিসমিল্লাহির রাহমানির রাহীম — $topic")
            if (quran != null) add("${quran.surahNameBn}: ${quran.bengaliTranslation}")
            if (hadith != null) add("${hadith.collectionBn}: ${hadith.bengaliText}")
            add("আল্লাহ আমাদের সবাইকে সহীহ আমলের তাওফীক দিন — আমীন।")
        }

        val seoTitle = if (isShort) {
            "$topic | ইসলামিক শর্টস #Shorts"
        } else {
            "$topic — কুরআন ও সহীহ হাদিসের আলোকে বিস্তারিত আলোচনা"
        }
        val englishTitle = "$topic | Authentic Islamic Reminder & Education (Bangla)"

        val description = buildString {
            appendLine("বিষয়: $topic")
            appendLine("বিভাগ: ${category.labelBn}")
            appendLine()
            if (quran != null) {
                appendLine("📖 কুরআনের সূত্র: ${quran.surahNameBn}")
                appendLine("আরবি: ${quran.arabicUthmaniText}")
                appendLine("অনুবাদ: ${quran.bengaliTranslation}")
                appendLine()
            }
            if (hadith != null) {
                appendLine("📚 হাদিসের সূত্র: ${hadith.collectionBn} (${hadith.referenceNumber}) — ${hadith.gradingNoteBn}")
                appendLine("${hadith.bengaliText}")
                appendLine()
            }
            appendLine("সতর্কতা: ইসলামিক তথ্যের বিশুদ্ধতা নিশ্চিত করতে নির্ভরযোগ্য আলেম ও মূল গ্রন্থের সাথে মিলিয়ে পড়ার অনুরোধ রইল।")
            appendLine()
            appendLine("#ইসলামিকভিডিও #QuranBangla #HadithBangla #AbuUbaidaAI #IslamicReminder")
        }

        val keywords = listOf(
            topic,
            category.labelBn,
            "বাংলা ইসলামিক ভিডিও",
            "কুরআন ও হাদিস",
            "Bangla Islamic Lecture"
        )
        val tags = listOf(
            topic,
            "ইসলামিক ভিডিও বাংলা",
            category.labelBn,
            "কুরআন তেলাওয়াত ও অর্থ",
            "সহীহ হাদিস বাংলা",
            "আবু উবাইদা AI"
        )
        val hashtags = listOf("#ইসলামিকভিডিও", "#কুরআন", "#সহীহহাদিস", "#BanglaIslamic", "#AbuUbaidaAI")
        val thumbText = topic.take(36)

        return VideoProject(
            topic = topic,
            category = category,
            format = format,
            script = script,
            subtitleLines = subtitles,
            seoTitle = seoTitle,
            englishTitle = englishTitle,
            seoDescription = description,
            seoKeywords = keywords,
            seoTags = tags,
            hashtags = hashtags,
            thumbnailText = thumbText,
            thumbnailDesignSummary = "ডিপ নেভি ও গোল্ডেন ইসলামিক ৮-কোনা নক্ষত্র ডিজাইন, উপরে স্পষ্ট বাংলা শিরোনাম ও সূরা/হাদিস সূত্র।",
            thumbnailPrompts = listOf(
                "Respectful deep navy blue and radiant gold Islamic geometric 8-point star frame for '$topic', dignified educational style, 4K",
                "Minimalist dark sapphire background with subtle golden arabesque border and room for Bengali headline '$thumbText'"
            ),
            quranReference = quran,
            hadithReference = hadith,
            providerStatusBn = "যাচাইকৃত ইসলামিক সূত্র ও অফলাইন স্টুডিও থেকে স্ক্রিপ্ট, SEO এবং থাম্বনেইল প্রস্তুত।"
        )
    }

    fun isMp4ProviderConnected(): Boolean = videoProvider.isConnected

    suspend fun exportMp4IfConnected(project: VideoProject): Result<Uri> = withContext(Dispatchers.IO) {
        if (!videoProvider.isConnected) {
            return@withContext videoProvider.generateMp4(project.topic, File(context.cacheDir, "placeholder.mp4"))
        }
        val outDir = File(context.filesDir, "abu_ubaida_videos").apply { mkdirs() }
        val file = File(outDir, "AbuUbaida_${System.currentTimeMillis()}.mp4")
        if (videoProvider is LocalMp4VideoProvider) {
            videoProvider.renderProjectSlidesMp4(project, file)
        } else {
            videoProvider.generateMp4(
                prompt = project.thumbnailPrompts.firstOrNull() ?: project.topic,
                outputFile = file
            )
        }
    }

    suspend fun exportScriptTextPackage(project: VideoProject): Result<File> = withContext(Dispatchers.IO) {
        return@withContext try {
            val outDir = File(context.filesDir, "abu_ubaida_scripts").apply { mkdirs() }
            val file = File(outDir, "script_${System.currentTimeMillis()}.txt")
            val content = buildString {
                appendLine("=== আবু উবাইদা AI ইসলামিক ভিডিও স্টুডিও প্যাকেজ ===")
                appendLine("বিষয়: ${project.topic} | বিভাগ: ${project.category.labelBn} | ফরম্যাট: ${project.format.labelBn}")
                appendLine("ধর্মীয় সূত্র যাচাই: ${project.accuracyReview.sourceCitationBn}")
                appendLine()
                appendLine("বাংলা SEO শিরোনাম: ${project.seoTitle}")
                appendLine("English Title: ${project.englishTitle}")
                appendLine("SEO বর্ণনা:\n${project.seoDescription}")
                appendLine("ট্যাগসমূহ: ${project.seoTags.joinToString(", ")}")
                appendLine("হ্যাশট্যাগ: ${project.hashtags.joinToString(" ")}")
                appendLine()
                appendLine("--- বাংলা চিত্রনাট্য (Script) ---")
                appendLine(project.script)
            }
            file.writeText(content)
            Result.success(file)
        } catch (e: Exception) {
            Result.failure(IllegalStateException("স্ক্রিপ্ট সংরক্ষণ করা যায়নি: ${e.localizedMessage}"))
        }
    }

    fun wipeGeneratedLocalFiles() {
        listOf("abu_ubaida_videos", "abu_ubaida_scripts", "abu_ubaida_thumbnails", "abu_ubaida_voiceovers")
            .forEach { folder ->
                File(context.filesDir, folder).deleteRecursively()
            }
    }
}
