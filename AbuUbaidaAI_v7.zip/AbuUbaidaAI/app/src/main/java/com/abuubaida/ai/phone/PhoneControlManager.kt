package com.abuubaida.ai.phone

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import com.abuubaida.ai.data.model.ContactItem
import com.abuubaida.ai.data.model.InstalledAppInfo
import com.abuubaida.ai.data.model.VolumeCommand
import java.util.Calendar
import java.util.Locale

class PhoneControlManager(private val context: Context) {

    fun hasPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }

    fun loadContacts(query: String = ""): List<ContactItem> {
        if (!hasPermission(Manifest.permission.READ_CONTACTS)) return emptyList()

        val contacts = mutableListOf<ContactItem>()
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val trimmedQuery = query.trim()
        val hasBengaliQuery = trimmedQuery.any { it in '\u0980'..'\u09FF' }
        val useSqlFilter = trimmedQuery.isNotBlank() && !hasBengaliQuery
        val selection = if (useSqlFilter) {
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ? OR ${ContactsContract.CommonDataKinds.Phone.NUMBER} LIKE ?"
        } else null
        val selectionArgs = if (useSqlFilter) arrayOf("%$trimmedQuery%", "%$trimmedQuery%") else null

        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection,
            selection,
            selectionArgs,
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
        )?.use { cursor ->
            val idIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
            val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            val seen = HashSet<String>()
            while (cursor.moveToNext() && contacts.size < 2000) {
                val id = if (idIdx >= 0) cursor.getString(idIdx) else ""
                val name = if (nameIdx >= 0) cursor.getString(nameIdx) else "অজানা পরিচিতি"
                val num = if (numIdx >= 0) cursor.getString(numIdx) else ""
                val normalized = num.replace("\\s+".toRegex(), "")
                if (normalized.isNotBlank() && seen.add("$name:$normalized")) {
                    contacts.add(ContactItem(id = id, name = name, phoneNumber = normalized))
                }
            }
        }
        if (hasBengaliQuery) {
            val candidates = BengaliPhoneticMatcher.expandCandidates(trimmedQuery)
                .map { BengaliPhoneticMatcher.phoneticSkeleton(it) }
                .filter { it.isNotBlank() }
            return contacts.filter { c ->
                val nameSkeleton = BengaliPhoneticMatcher.phoneticSkeleton(c.name)
                candidates.any { cand -> nameSkeleton.contains(cand) }
            }.ifEmpty {
                listOfNotNull(BengaliPhoneticMatcher.findBestContact(trimmedQuery, contacts))
            }
        }
        return contacts
    }

    fun placeCall(phoneNumber: String, directCall: Boolean): Result<String> {
        val cleanNumber = BengaliCommandEngine.normalizeDigits(phoneNumber).trim()
        if (cleanNumber.isBlank()) {
            return Result.failure(IllegalArgumentException("সঠিক ফোন নম্বর দিন।"))
        }

        return try {
            val useDirect = directCall && hasPermission(Manifest.permission.CALL_PHONE)
            val action = if (useDirect) Intent.ACTION_CALL else Intent.ACTION_DIAL
            val intent = Intent(action, Uri.parse("tel:${Uri.encode(cleanNumber)}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            if (useDirect) {
                Result.success("$cleanNumber নম্বরে সরাসরি কল করা হচ্ছে।")
            } else {
                Result.success("ডায়ালারে $cleanNumber নম্বর খোলা হয়েছে।")
            }
        } catch (e: Exception) {
            Result.failure(IllegalStateException("কল শুরু করা যায়নি: ${e.localizedMessage}"))
        }
    }

    fun sendSms(phoneNumber: String, message: String, useDirectApi: Boolean): Result<String> {
        val cleanNumber = BengaliCommandEngine.normalizeDigits(phoneNumber).trim()
        val cleanMsg = message.trim()
        if (cleanNumber.isBlank() || cleanMsg.isBlank()) {
            return Result.failure(IllegalArgumentException("প্রাপকের নম্বর ও বার্তা উভয়ই প্রয়োজন।"))
        }

        return try {
            if (useDirectApi && hasPermission(Manifest.permission.SEND_SMS)) {
                val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    context.getSystemService(SmsManager::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    SmsManager.getDefault()
                }
                val parts = smsManager.divideMessage(cleanMsg)
                if (parts.size > 1) {
                    smsManager.sendMultipartTextMessage(cleanNumber, null, parts, null, null)
                } else {
                    smsManager.sendTextMessage(cleanNumber, null, cleanMsg, null, null)
                }
                Result.success("$cleanNumber নম্বরে SMS পাঠানো হয়েছে।")
            } else {
                val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(cleanNumber)}")).apply {
                    putExtra("sms_body", cleanMsg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                Result.success("নিরাপদ SMS কম্পোজার খোলা হয়েছে।")
            }
        } catch (e: Exception) {
            Result.failure(IllegalStateException("SMS পাঠানো যায়নি: ${e.localizedMessage}"))
        }
    }

    fun getInstalledLauncherApps(): List<InstalledAppInfo> {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
        return resolveInfos.mapNotNull { info ->
            val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
            if (pkg == context.packageName) return@mapNotNull null
            val label = info.loadLabel(pm)?.toString() ?: pkg
            InstalledAppInfo(packageName = pkg, appName = label)
        }.distinctBy { it.packageName }.sortedBy { it.appName.lowercase() }
    }

    fun launchAppByNameOrPackage(query: String): Result<String> {
        val q = query.trim().lowercase()
        val apps = getInstalledLauncherApps()

        val candidateTerms = buildList {
            add(q)
            add(q.replace(" ", ""))
            BengaliCommandEngine.bengaliAppAliases.forEach { (bnKey, enTargets) ->
                if (q.contains(bnKey.lowercase()) || bnKey.lowercase() == q) {
                    addAll(enTargets)
                }
            }
        }.distinct()

        val match = apps.firstOrNull { app ->
            val appLower = app.appName.lowercase()
            val appCompact = appLower.replace(" ", "")
            val pkgLower = app.packageName.lowercase()
            candidateTerms.any { term ->
                pkgLower == term || appLower == term || appCompact == term ||
                    appLower.contains(term) || pkgLower.contains(term)
            }
        } ?: return Result.failure(IllegalStateException("\"$query\" নামে কোনো ইনস্টল করা অ্যাপ পাওয়া যায়নি।"))

        val launchIntent = context.packageManager.getLaunchIntentForPackage(match.packageName)
            ?: return Result.failure(IllegalStateException("${match.appName} চালু করা যাচ্ছে না।"))
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launchIntent)
        return Result.success("${match.appName} চালু করা হয়েছে।")
    }

    fun toggleFlashlight(enable: Boolean): Result<String> {
        return try {
            val camManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = camManager.cameraIdList.firstOrNull { id ->
                camManager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return Result.failure(IllegalStateException("এই ডিভাইসে ফ্ল্যাশলাইট হার্ডওয়্যার পাওয়া যায়নি।"))

            camManager.setTorchMode(cameraId, enable)
            Result.success(if (enable) "টর্চলাইট চালু করা হয়েছে।" else "টর্চলাইট বন্ধ করা হয়েছে।")
        } catch (e: Exception) {
            Result.failure(IllegalStateException("টর্চলাইট নিয়ন্ত্রণ করা যায়নি: ${e.localizedMessage}"))
        }
    }

    fun adjustVolume(command: VolumeCommand): Result<String> {
        return try {
            val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            when (command) {
                VolumeCommand.UP -> {
                    audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                    Result.success("মিডিয়া সাউন্ড বাড়ানো হয়েছে।")
                }
                VolumeCommand.DOWN -> {
                    audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                    Result.success("মিডিয়া সাউন্ড কমানো হয়েছে।")
                }
                VolumeCommand.MUTE -> {
                    audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                    Result.success("মিডিয়া সাউন্ড মিউট করা হয়েছে।")
                }
                VolumeCommand.NORMAL -> {
                    audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
                    Result.success("সাউন্ড স্বাভাবিক করা হয়েছে।")
                }
                VolumeCommand.MAX -> {
                    val maxVol = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    audio.setStreamVolume(AudioManager.STREAM_MUSIC, maxVol, AudioManager.FLAG_SHOW_UI)
                    Result.success("মিডিয়া সাউন্ড সর্বোচ্চ করা হয়েছে।")
                }
            }
        } catch (e: Exception) {
            Result.failure(IllegalStateException("সাউন্ড পরিবর্তন করা যায়নি: ${e.localizedMessage}"))
        }
    }

    fun searchYouTube(query: String): Result<String> {
        return try {
            val url = "https://www.youtube.com/results?search_query=${Uri.encode(query)}"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success("ইউটিউবে \"$query\" খোঁজা হচ্ছে।")
        } catch (e: Exception) {
            Result.failure(IllegalStateException("ইউটিউব সার্চ খোলা যায়নি: ${e.localizedMessage}"))
        }
    }

    fun searchGoogle(query: String): Result<String> {
        return try {
            val url = "https://www.google.com/search?q=${Uri.encode(query)}"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success("গুগলে \"$query\" খোঁজা হচ্ছে।")
        } catch (e: Exception) {
            Result.failure(IllegalStateException("গুগল সার্চ খোলা যায়নি: ${e.localizedMessage}"))
        }
    }

    fun getCurrentTimeBn(): String {
        val cal = Calendar.getInstance()
        val hour24 = cal.get(Calendar.HOUR_OF_DAY)
        val minute = cal.get(Calendar.MINUTE)
        val period = when (hour24) {
            in 4..11 -> "সকাল"
            in 12..15 -> "দুপুর"
            in 16..18 -> "বিকাল"
            in 19..20 -> "সন্ধ্যা"
            else -> "রাত"
        }
        val hour12 = when {
            hour24 == 0 -> 12
            hour24 > 12 -> hour24 - 12
            else -> hour24
        }
        return if (minute == 0) {
            "এখন $period ${hour12}টা বাজে।"
        } else {
            "এখন $period ${hour12}টা বেজে $minute মিনিট।"
        }
    }

    fun getCurrentDateBn(): String {
        val cal = Calendar.getInstance()
        val dayName = when (cal.get(Calendar.DAY_OF_WEEK)) {
            Calendar.SATURDAY -> "শনিবার"
            Calendar.SUNDAY -> "রবিবার"
            Calendar.MONDAY -> "সোমবার"
            Calendar.TUESDAY -> "মঙ্গলবার"
            Calendar.WEDNESDAY -> "বুধবার"
            Calendar.THURSDAY -> "বৃহস্পতিবার"
            Calendar.FRIDAY -> "শুক্রবার"
            else -> ""
        }
        val months = listOf(
            "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
            "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
        )
        val day = cal.get(Calendar.DAY_OF_MONTH)
        val month = months.getOrElse(cal.get(Calendar.MONTH)) { "" }
        val year = cal.get(Calendar.YEAR)
        return "আজ $dayName, $day $month ${year}।"
    }

    fun getBatteryStatusBn(): String {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val chargingText = if (bm.isCharging) "এবং ফোনটি এখন চার্জ হচ্ছে" else "এবং চার্জার যুক্ত নেই"
        return "আপনার ফোনে এখন $pct শতাংশ চার্জ আছে ${chargingText}।"
    }

    fun openAndroidSettings(action: String = Settings.ACTION_SETTINGS, labelBn: String = "অ্যান্ড্রয়েড সেটিংস"): Result<String> {
        return try {
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success("$labelBn খোলা হয়েছে।")
        } catch (_: Exception) {
            val fallback = Intent(Settings.ACTION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(fallback)
            Result.success("সিস্টেম সেটিংস খোলা হয়েছে।")
        }
    }

    fun setAlarm(hour: Int, minute: Int, label: String): Result<String> {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour.coerceIn(0, 23))
                putExtra(AlarmClock.EXTRA_MINUTES, minute.coerceIn(0, 59))
                putExtra(AlarmClock.EXTRA_MESSAGE, label.ifBlank { "আবু উবাইদা AI অ্যালার্ম" })
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success(String.format(Locale.US, "%02d:%02d এর জন্য অ্যালার্ম অ্যাপ খোলা হয়েছে।", hour, minute))
        } catch (e: Exception) {
            Result.failure(IllegalStateException("অ্যালার্ম সেট করা যায়নি: ${e.localizedMessage}"))
        }
    }

    fun setTimer(seconds: Int, label: String): Result<String> {
        return try {
            val safeSeconds = seconds.coerceAtLeast(1)
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, safeSeconds)
                putExtra(AlarmClock.EXTRA_MESSAGE, label.ifBlank { "আবু উবাইদা AI টাইমার" })
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            val mins = safeSeconds / 60
            val rem = safeSeconds % 60
            val desc = if (mins > 0 && rem == 0) "$mins মিনিটের" else "$safeSeconds সেকেন্ডের"
            Result.success("$desc টাইমার সেট করার জন্য ঘড়ি অ্যাপ খোলা হয়েছে।")
        } catch (e: Exception) {
            Result.failure(IllegalStateException("টাইমার সেট করা যায়নি: ${e.localizedMessage}"))
        }
    }

    fun openAssistantRoleSettings(): Result<String> {
        return openAndroidSettings(Settings.ACTION_VOICE_INPUT_SETTINGS, "ডিফল্ট অ্যাসিস্ট্যান্ট সেটিংস")
    }

    fun openBatteryOptimizationSettings(): Result<String> {
        return try {
            val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success("ব্যাটারি অপটিমাইজেশন সেটিংস খোলা হয়েছে।")
        } catch (_: Exception) {
            openAndroidSettings(Settings.ACTION_SETTINGS, "সিস্টেম সেটিংস")
        }
    }

    fun openAppPermissionSettings(): Result<String> {
        return try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", context.packageName, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success("অ্যাপ অনুমতি সেটিংস খোলা হয়েছে।")
        } catch (_: Exception) {
            openAndroidSettings(Settings.ACTION_SETTINGS, "সিস্টেম সেটিংস")
        }
    }
}
