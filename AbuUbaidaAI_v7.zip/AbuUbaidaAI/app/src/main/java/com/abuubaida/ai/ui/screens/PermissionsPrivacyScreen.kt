package com.abuubaida.ai.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.abuubaida.ai.data.model.FacebookAccountInfo
import com.abuubaida.ai.data.model.MasterControlSettings
import com.abuubaida.ai.data.model.PublishingMode
import com.abuubaida.ai.ui.components.GlassCard
import com.abuubaida.ai.ui.components.PermissionStatusRow
import com.abuubaida.ai.ui.theme.AmberGold
import com.abuubaida.ai.ui.theme.BrightGold
import com.abuubaida.ai.ui.theme.ElectricBlue
import com.abuubaida.ai.ui.theme.EmeraldOk
import com.abuubaida.ai.ui.theme.ImperialGold
import com.abuubaida.ai.ui.theme.NavyBorder
import com.abuubaida.ai.ui.theme.TextPrimary
import com.abuubaida.ai.ui.theme.TextSecondary

@Composable
fun PermissionsPrivacyScreen(
    masterControls: MasterControlSettings,
    backgroundVoiceEnabled: Boolean,
    isKeystoreEncrypted: Boolean,
    youTubeConnected: Boolean,
    facebookAccount: FacebookAccountInfo,
    onUpdateMasterControls: (MasterControlSettings) -> Unit,
    onToggleBackgroundVoice: (Boolean) -> Unit,
    onEmergencyStopAll: () -> Unit,
    onDisconnectYouTube: () -> Unit,
    onDisconnectFacebook: () -> Unit,
    onWipeAllData: () -> Unit,
    onOpenAppSettings: () -> Unit,
    onOpenBatterySettings: () -> Unit,
    onOpenAssistantRoleSettings: () -> Unit
) {
    val context = LocalContext.current
    var refreshTick by remember { mutableIntStateOf(0) }
    var confirmWipeArmed by remember { mutableStateOf(false) }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        refreshTick++
    }

    fun isGranted(permission: String): Boolean {
        @Suppress("UNUSED_EXPRESSION")
        refreshTick
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("মাস্টার কন্ট্রোল ও গোপনীয়তা ড্যাশবোর্ড", style = MaterialTheme.typography.headlineMedium, color = BrightGold)

        // Immediate Emergency Stop Card
        GlassCard(borderColor = AmberGold.copy(alpha = 0.7f)) {
            Text("জরুরি নিয়ন্ত্রণ (Emergency Stop)", style = MaterialTheme.typography.titleMedium, color = AmberGold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                "এক ট্যাপে সব ব্যাকগ্রাউন্ড ভয়েস সার্ভিস, অটো-আপলোড এবং চলমান অটোনোমাস কাজ বন্ধ করুন।",
                color = TextSecondary,
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = onEmergencyStopAll,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = AmberGold, contentColor = com.abuubaida.ai.ui.theme.DeepNavyBg)
            ) {
                Text("সব ব্যাকগ্রাউন্ড কার্যক্রম এখনই বন্ধ করুন")
            }
        }

        // 7 Master ON/OFF Controls
        GlassCard(borderColor = ImperialGold.copy(alpha = 0.45f)) {
            Text("মাস্টার সুইচ কন্ট্রোল (ON / OFF)", style = MaterialTheme.typography.titleMedium, color = BrightGold)
            Spacer(modifier = Modifier.height(6.dp))

            MasterSwitchRow(
                title = "AI অ্যাসিস্ট্যান্ট (AI Assistant)",
                subtitle = "বন্ধ থাকলে কোনো অনলাইন AI উত্তর বা স্ক্রিপ্ট জেনারেটর চলবে না",
                checked = masterControls.aiAssistantEnabled,
                onCheckedChange = { onUpdateMasterControls(masterControls.copy(aiAssistantEnabled = it)) }
            )
            MasterSwitchRow(
                title = "কন্টেন্ট তৈরি (Content Creation)",
                subtitle = "বন্ধ থাকলে ইসলামিক ভিডিও ও থাম্বনেইল তৈরি বন্ধ থাকবে",
                checked = masterControls.contentCreationEnabled,
                onCheckedChange = { onUpdateMasterControls(masterControls.copy(contentCreationEnabled = it)) }
            )
            MasterSwitchRow(
                title = "স্বয়ংক্রিয় আপলোড (Automatic Upload)",
                subtitle = "নিরাপত্তার জন্য ডিফল্ট OFF—কেবল স্পষ্ট অনুমতি দিলে চালু রাখুন",
                checked = masterControls.autoUploadEnabled,
                onCheckedChange = { onUpdateMasterControls(masterControls.copy(autoUploadEnabled = it)) }
            )
            MasterSwitchRow(
                title = "YouTube সংযোগ (YouTube Connection)",
                subtitle = "বন্ধ করলে YouTube আপলোড ও চ্যানেল অ্যানালিটিক্স বন্ধ হবে",
                checked = masterControls.youTubeConnectionEnabled,
                onCheckedChange = { onUpdateMasterControls(masterControls.copy(youTubeConnectionEnabled = it)) }
            )
            MasterSwitchRow(
                title = "Facebook সংযোগ (Facebook Connection)",
                subtitle = "বন্ধ করলে Facebook পেজ প্রকাশনা ও ইনসাইটস বন্ধ হবে",
                checked = masterControls.facebookConnectionEnabled,
                onCheckedChange = { onUpdateMasterControls(masterControls.copy(facebookConnectionEnabled = it)) }
            )
            MasterSwitchRow(
                title = "ট্রেন্ড রিসার্চ (Trend Research)",
                subtitle = "বন্ধ করলে কোনো পাবলিক ট্রেন্ড বা সার্চ সাজেশন আনা হবে না",
                checked = masterControls.trendResearchEnabled,
                onCheckedChange = { onUpdateMasterControls(masterControls.copy(trendResearchEnabled = it)) }
            )
            MasterSwitchRow(
                title = "ব্যাকগ্রাউন্ড ভয়েস (Background Voice)",
                subtitle = "দৃশ্যমান নোটিফিকেশনসহ ওয়েক-ফ্রেজ ভয়েস সার্ভিস",
                checked = backgroundVoiceEnabled,
                onCheckedChange = onToggleBackgroundVoice
            )
        }

        // Smart Publishing Mode Selection
        GlassCard(borderColor = ElectricBlue.copy(alpha = 0.4f)) {
            Text("স্মার্ট পাবলিশিং নীতি", style = MaterialTheme.typography.titleMedium, color = ElectricBlue)
            Spacer(modifier = Modifier.height(6.dp))
            PublishingMode.entries.forEach { mode ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    RadioButton(
                        selected = masterControls.publishingMode == mode,
                        onClick = { onUpdateMasterControls(masterControls.copy(publishingMode = mode)) }
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(mode.labelBn, color = TextPrimary, style = MaterialTheme.typography.bodyLarge)
                        Text(mode.descBn, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        // Connected Accounts & Data Deletion
        GlassCard(borderColor = EmeraldOk.copy(alpha = 0.4f)) {
            Text("সংযুক্ত অ্যাকাউন্ট ও Keystore নিরাপত্তা", style = MaterialTheme.typography.titleMedium, color = EmeraldOk)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (isKeystoreEncrypted) {
                    "টোকেন স্টোরেজ: Android Keystore (AES256-GCM এনক্রিপ্টেড) সক্রিয়।"
                } else {
                    "টোকেন স্টোরেজ: প্রাইভেট অ্যাপ স্টোরেজ সক্রিয়।"
                },
                color = TextPrimary,
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                text = "• YouTube OAuth: ${if (youTubeConnected) "সংযুক্ত" else "সংযুক্ত নয়"}",
                color = if (youTubeConnected) EmeraldOk else TextSecondary
            )
            Text(
                text = "• Facebook পেজ: ${if (facebookAccount.hasAccessToken) facebookAccount.pageName.ifBlank { facebookAccount.pageId } else "সংযুক্ত নয়"}",
                color = if (facebookAccount.hasAccessToken) EmeraldOk else TextSecondary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = onDisconnectYouTube,
                    enabled = youTubeConnected,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("YouTube বিচ্ছিন্ন", color = ElectricBlue)
                }
                OutlinedButton(
                    onClick = onDisconnectFacebook,
                    enabled = facebookAccount.hasAccessToken,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Facebook বিচ্ছিন্ন", color = ElectricBlue)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            if (!confirmWipeArmed) {
                OutlinedButton(
                    onClick = { confirmWipeArmed = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("সব স্থানীয় ডেটা ও টোকেন মুছুন", color = AmberGold)
                }
            } else {
                Button(
                    onClick = {
                        confirmWipeArmed = false
                        onWipeAllData()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = AmberGold, contentColor = com.abuubaida.ai.ui.theme.DeepNavyBg)
                ) {
                    Text("নিশ্চিত করুন: সব ডেটা ও তৈরি করা ফাইল স্থায়ীভাবে মুছুন")
                }
            }
        }

        // Strict Privacy Policy Guarantees
        GlassCard(borderColor = NavyBorder) {
            Text("কঠোর গোপনীয়তা সুরক্ষা নীতি", style = MaterialTheme.typography.titleMedium, color = BrightGold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "• এই অ্যাপ কখনো ব্যক্তিগত SMS ইনবক্স, WhatsApp বার্তা, ব্যক্তিগত ছবি বা কন্টাক্ট লিস্ট সার্ভারে আপলোড করে না।\n" +
                    "• কোনো কিনে নেওয়া বা আর্থিক লেনদেন কখনো স্বয়ংক্রিয়ভাবে করে না।\n" +
                    "• বাহ্যিক ভিডিও বিবরণ বা কমেন্ট থেকে কোনো অপ্রত্যাশিত কমান্ড চালানো হয় না।\n" +
                    "• কেবল HTTPS এনক্রিপ্টেড সংযোগ ব্যবহার করা হয়।",
                color = TextSecondary,
                style = MaterialTheme.typography.bodyMedium
            )
        }

        Text("অ্যান্ড্রয়েড রানটাইম অনুমতিসমূহ", style = MaterialTheme.typography.titleLarge, color = BrightGold)

        PermissionStatusRow(
            title = "মাইক্রোফোন (RECORD_AUDIO)",
            description = "বাংলা ভয়েস কমান্ডের জন্য প্রয়োজন। কোনো গোপন রেকর্ডিং করা হয় না।",
            granted = isGranted(Manifest.permission.RECORD_AUDIO),
            onRequestClick = { permLauncher.launch(Manifest.permission.RECORD_AUDIO) }
        )

        PermissionStatusRow(
            title = "কন্টাক্টস (READ_CONTACTS)",
            description = "কেবল আপনার অনুরোধে ফোন কল বা SMS প্রাপক খোঁজার জন্য (কখনো আপলোড হয় না)।",
            granted = isGranted(Manifest.permission.READ_CONTACTS),
            onRequestClick = { permLauncher.launch(Manifest.permission.READ_CONTACTS) }
        )

        PermissionStatusRow(
            title = "ফোন কল (CALL_PHONE)",
            description = "প্রতিটি কলের আগে স্পষ্ট নিশ্চিতকরণ ডায়ালগ দেখানো হয়।",
            granted = isGranted(Manifest.permission.CALL_PHONE),
            onRequestClick = { permLauncher.launch(Manifest.permission.CALL_PHONE) }
        )

        PermissionStatusRow(
            title = "SMS পাঠানো (SEND_SMS)",
            description = "অ্যাপ কখনো ইনবক্স SMS পড়ে না; কেবল আপনার অনুমোদিত বার্তা পাঠায়।",
            granted = isGranted(Manifest.permission.SEND_SMS),
            onRequestClick = { permLauncher.launch(Manifest.permission.SEND_SMS) }
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            PermissionStatusRow(
                title = "নোটিফিকেশন (POST_NOTIFICATIONS)",
                description = "ব্যাকগ্রাউন্ড সার্ভিস ও আপলোড নোটিফিকেশন দেখাতে।",
                granted = isGranted(Manifest.permission.POST_NOTIFICATIONS),
                onRequestClick = { permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
            )
        }

        GlassCard(borderColor = NavyBorder) {
            OutlinedButton(onClick = onOpenAssistantRoleSettings, modifier = Modifier.fillMaxWidth()) {
                Text("ডিফল্ট ডিজিটাল অ্যাসিস্ট্যান্ট সেটিংস", color = BrightGold)
            }
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedButton(onClick = onOpenBatterySettings, modifier = Modifier.fillMaxWidth()) {
                Text("ব্যাটারি অপটিমাইজেশন সেটিংস", color = ElectricBlue)
            }
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedButton(onClick = onOpenAppSettings, modifier = Modifier.fillMaxWidth()) {
                Text("সিস্টেম অ্যাপ পারমিশন পেজ", color = ElectricBlue)
            }
        }
    }
}

@Composable
private fun MasterSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text(title, color = TextPrimary, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
