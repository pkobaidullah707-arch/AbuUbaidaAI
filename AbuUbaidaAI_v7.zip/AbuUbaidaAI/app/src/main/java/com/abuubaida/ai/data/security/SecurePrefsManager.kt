package com.abuubaida.ai.data.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.abuubaida.ai.data.model.AssistantSettings
import com.abuubaida.ai.data.model.ChatMessage
import com.abuubaida.ai.data.model.FacebookAccountInfo
import com.abuubaida.ai.data.model.MasterControlSettings
import com.abuubaida.ai.data.model.PublishingMode
import org.json.JSONArray
import org.json.JSONObject

class SecurePrefsManager(context: Context) {

    private val prefs: SharedPreferences = createEncryptedPrefs(context)
    val isKeystoreEncrypted: Boolean

    init {
        isKeystoreEncrypted = prefs !is FallbackMarkerPrefs
    }

    private class FallbackMarkerPrefs(private val delegate: SharedPreferences) : SharedPreferences by delegate

    private fun createEncryptedPrefs(context: Context): SharedPreferences {
        return try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                "abu_ubaida_secure_prefs",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (_: Exception) {
            FallbackMarkerPrefs(
                context.getSharedPreferences("abu_ubaida_fallback_prefs", Context.MODE_PRIVATE)
            )
        }
    }

    fun loadSettings(): AssistantSettings {
        return AssistantSettings(
            wakePhrase = prefs.getString(KEY_WAKE_PHRASE, DEFAULT_WAKE_PHRASE) ?: DEFAULT_WAKE_PHRASE,
            ttsEnabled = prefs.getBoolean(KEY_TTS_ENABLED, true),
            continuousVoiceMode = prefs.getBoolean(KEY_CONTINUOUS_VOICE, false),
            backgroundServiceEnabled = prefs.getBoolean(KEY_BG_SERVICE_ENABLED, false),
            proxyEndpointUrl = prefs.getString(KEY_PROXY_URL, "") ?: "",
            speechLanguageTag = prefs.getString(KEY_SPEECH_LANG, "bn-BD") ?: "bn-BD"
        )
    }

    fun saveSettings(settings: AssistantSettings) {
        prefs.edit()
            .putString(KEY_WAKE_PHRASE, settings.wakePhrase.ifBlank { DEFAULT_WAKE_PHRASE })
            .putBoolean(KEY_TTS_ENABLED, settings.ttsEnabled)
            .putBoolean(KEY_CONTINUOUS_VOICE, settings.continuousVoiceMode)
            .putBoolean(KEY_BG_SERVICE_ENABLED, settings.backgroundServiceEnabled)
            .putString(KEY_PROXY_URL, settings.proxyEndpointUrl.trim())
            .putString(KEY_SPEECH_LANG, settings.speechLanguageTag.ifBlank { "bn-BD" })
            .apply()
    }

    fun loadMasterControls(): MasterControlSettings {
        val modeName = prefs.getString(KEY_PUBLISHING_MODE, PublishingMode.ASK_BEFORE_PUBLISHING.name)
            ?: PublishingMode.ASK_BEFORE_PUBLISHING.name
        val mode = try {
            PublishingMode.valueOf(modeName)
        } catch (_: Exception) {
            PublishingMode.ASK_BEFORE_PUBLISHING
        }
        return MasterControlSettings(
            aiAssistantEnabled = prefs.getBoolean(KEY_MASTER_AI, true),
            contentCreationEnabled = prefs.getBoolean(KEY_MASTER_CREATION, true),
            autoUploadEnabled = prefs.getBoolean(KEY_MASTER_AUTO_UPLOAD, false),
            youTubeConnectionEnabled = prefs.getBoolean(KEY_MASTER_YOUTUBE, true),
            facebookConnectionEnabled = prefs.getBoolean(KEY_MASTER_FACEBOOK, true),
            trendResearchEnabled = prefs.getBoolean(KEY_MASTER_TRENDS, true),
            publishingMode = mode
        )
    }

    fun saveMasterControls(controls: MasterControlSettings) {
        prefs.edit()
            .putBoolean(KEY_MASTER_AI, controls.aiAssistantEnabled)
            .putBoolean(KEY_MASTER_CREATION, controls.contentCreationEnabled)
            .putBoolean(KEY_MASTER_AUTO_UPLOAD, controls.autoUploadEnabled)
            .putBoolean(KEY_MASTER_YOUTUBE, controls.youTubeConnectionEnabled)
            .putBoolean(KEY_MASTER_FACEBOOK, controls.facebookConnectionEnabled)
            .putBoolean(KEY_MASTER_TRENDS, controls.trendResearchEnabled)
            .putString(KEY_PUBLISHING_MODE, controls.publishingMode.name)
            .apply()
    }

    fun saveOAuthAccessToken(token: String?) {
        if (token.isNullOrBlank()) {
            prefs.edit().remove(KEY_YT_ACCESS_TOKEN).apply()
        } else {
            prefs.edit().putString(KEY_YT_ACCESS_TOKEN, token).apply()
        }
    }

    fun getOAuthAccessToken(): String? = prefs.getString(KEY_YT_ACCESS_TOKEN, null)

    fun saveFacebookCredentials(
        pageId: String,
        pageName: String,
        accessToken: String,
        followersCount: Long = -1L
    ) {
        prefs.edit()
            .putString(KEY_FB_PAGE_ID, pageId.trim())
            .putString(KEY_FB_PAGE_NAME, pageName.trim())
            .putString(KEY_FB_ACCESS_TOKEN, accessToken.trim())
            .putLong(KEY_FB_FOLLOWERS, followersCount)
            .apply()
    }

    fun getFacebookAccessToken(): String? = prefs.getString(KEY_FB_ACCESS_TOKEN, null)

    fun getFacebookAccountInfo(): FacebookAccountInfo {
        val token = prefs.getString(KEY_FB_ACCESS_TOKEN, null)
        return FacebookAccountInfo(
            pageId = prefs.getString(KEY_FB_PAGE_ID, "") ?: "",
            pageName = prefs.getString(KEY_FB_PAGE_NAME, "") ?: "",
            followersCount = prefs.getLong(KEY_FB_FOLLOWERS, -1L),
            hasAccessToken = !token.isNullOrBlank()
        )
    }

    fun clearFacebookCredentials() {
        prefs.edit()
            .remove(KEY_FB_PAGE_ID)
            .remove(KEY_FB_PAGE_NAME)
            .remove(KEY_FB_ACCESS_TOKEN)
            .remove(KEY_FB_FOLLOWERS)
            .apply()
    }

    fun saveMetaAppId(appId: String) {
        prefs.edit().putString(KEY_META_APP_ID, appId.trim()).apply()
    }

    fun getMetaAppId(): String = prefs.getString(KEY_META_APP_ID, "") ?: ""

    fun saveChatHistory(messages: List<ChatMessage>) {
        val arr = JSONArray()
        messages.takeLast(100).forEach { msg ->
            val obj = JSONObject().apply {
                put("id", msg.id)
                put("text", msg.text)
                put("isUser", msg.isUser)
                put("timestampMillis", msg.timestampMillis)
            }
            arr.put(obj)
        }
        prefs.edit().putString(KEY_CHAT_HISTORY, arr.toString()).apply()
    }

    fun loadChatHistory(): List<ChatMessage> {
        val raw = prefs.getString(KEY_CHAT_HISTORY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    add(
                        ChatMessage(
                            id = obj.optString("id"),
                            text = obj.optString("text"),
                            isUser = obj.optBoolean("isUser"),
                            timestampMillis = obj.optLong("timestampMillis", System.currentTimeMillis())
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun clearChatHistory() {
        prefs.edit().remove(KEY_CHAT_HISTORY).apply()
    }

    fun wipeAllLocalData() {
        prefs.edit().clear().apply()
    }

    companion object {
        const val DEFAULT_WAKE_PHRASE = "হ্যালো আবু উবাইদা"
        private const val KEY_WAKE_PHRASE = "wake_phrase"
        private const val KEY_TTS_ENABLED = "tts_enabled"
        private const val KEY_CONTINUOUS_VOICE = "continuous_voice_mode"
        private const val KEY_BG_SERVICE_ENABLED = "bg_service_enabled"
        private const val KEY_PROXY_URL = "proxy_endpoint_url"
        private const val KEY_SPEECH_LANG = "speech_language_tag"
        private const val KEY_YT_ACCESS_TOKEN = "yt_oauth_access_token"
        private const val KEY_FB_PAGE_ID = "fb_page_id"
        private const val KEY_FB_PAGE_NAME = "fb_page_name"
        private const val KEY_FB_ACCESS_TOKEN = "fb_page_access_token"
        private const val KEY_FB_FOLLOWERS = "fb_followers_count"
        private const val KEY_META_APP_ID = "fb_meta_app_id"
        private const val KEY_CHAT_HISTORY = "chat_history_json"
        private const val KEY_MASTER_AI = "master_ai_assistant_enabled"
        private const val KEY_MASTER_CREATION = "master_content_creation_enabled"
        private const val KEY_MASTER_AUTO_UPLOAD = "master_auto_upload_enabled"
        private const val KEY_MASTER_YOUTUBE = "master_youtube_connection_enabled"
        private const val KEY_MASTER_FACEBOOK = "master_facebook_connection_enabled"
        private const val KEY_MASTER_TRENDS = "master_trend_research_enabled"
        private const val KEY_PUBLISHING_MODE = "master_publishing_mode"
    }
}
