package com.abuubaida.ai.youtube

import android.app.Activity
import android.content.Context
import android.content.IntentSender
import android.net.Uri
import android.provider.OpenableColumns
import com.abuubaida.ai.data.model.ChannelPerformanceSummary
import com.abuubaida.ai.data.model.YouTubeUploadRequest
import com.abuubaida.ai.data.security.SecurePrefsManager
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okio.BufferedSink
import okio.source
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

sealed class OAuthFlowOutcome {
    data class Authorized(val accessToken: String) : OAuthFlowOutcome()
    data class NeedsConsent(val intentSender: IntentSender) : OAuthFlowOutcome()
    data class Failed(val errorBn: String) : OAuthFlowOutcome()
}

class YouTubeStudioRepository(
    private val context: Context,
    private val securePrefsManager: SecurePrefsManager
) {
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(180, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    fun getSavedAccessToken(): String? = securePrefsManager.getOAuthAccessToken()

    fun disconnectAccount() {
        securePrefsManager.saveOAuthAccessToken(null)
    }

    suspend fun requestYouTubeAuthorization(activity: Activity): OAuthFlowOutcome =
        suspendCancellableCoroutine { cont ->
            val request = AuthorizationRequest.builder()
                .setRequestedScopes(
                    listOf(
                        Scope(SCOPE_YOUTUBE_UPLOAD),
                        Scope(SCOPE_YOUTUBE_READONLY)
                    )
                )
                .build()

            Identity.getAuthorizationClient(activity)
                .authorize(request)
                .addOnSuccessListener { result ->
                    if (result.hasResolution()) {
                        val pendingIntent = result.pendingIntent
                        if (pendingIntent != null) {
                            cont.resume(OAuthFlowOutcome.NeedsConsent(pendingIntent.intentSender))
                        } else {
                            cont.resume(OAuthFlowOutcome.Failed("Google OAuth অনুমোদন পর্দা খোলা যায়নি।"))
                        }
                    } else {
                        val token = result.accessToken
                        if (!token.isNullOrBlank()) {
                            securePrefsManager.saveOAuthAccessToken(token)
                            cont.resume(OAuthFlowOutcome.Authorized(token))
                        } else {
                            cont.resume(OAuthFlowOutcome.Failed("OAuth অ্যাক্সেস টোকেন পাওয়া যায়নি।"))
                        }
                    }
                }
                .addOnFailureListener { e ->
                    cont.resume(
                        OAuthFlowOutcome.Failed(
                            "Google OAuth ব্যর্থ হয়েছে (${e.localizedMessage ?: "Google Cloud OAuth কনফিগারেশন পরীক্ষা করুন"})।"
                        )
                    )
                }
        }

    fun handleAuthorizationResultIntent(authResult: AuthorizationResult?): Result<String> {
        val token = authResult?.accessToken
        return if (!token.isNullOrBlank()) {
            securePrefsManager.saveOAuthAccessToken(token)
            Result.success(token)
        } else {
            Result.failure(IllegalStateException("YouTube OAuth অনুমোদন সম্পন্ন হয়নি।"))
        }
    }

    fun resolveFileDisplayName(uri: Uri): String {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && nameIdx >= 0) {
                return cursor.getString(nameIdx)
            }
        }
        return uri.lastPathSegment ?: "video.mp4"
    }

    suspend fun fetchAuthorizedChannelPerformance(): ChannelPerformanceSummary? =
        withContext(Dispatchers.IO) {
            val token = securePrefsManager.getOAuthAccessToken()
            if (token.isNullOrBlank()) return@withContext null

            try {
                val chanReq = Request.Builder()
                    .url("https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&mine=true")
                    .addHeader("Authorization", "Bearer $token")
                    .get()
                    .build()

                var channelTitle = ""
                var subscriberCount = -1L
                var videoCount = -1L

                httpClient.newCall(chanReq).execute().use { resp ->
                    if (!resp.isSuccessful) return@withContext null
                    val items = JSONObject(resp.body?.string().orEmpty()).optJSONArray("items")
                    if (items == null || items.length() == 0) return@withContext null
                    val ch = items.getJSONObject(0)
                    channelTitle = ch.optJSONObject("snippet")?.optString("title").orEmpty()
                    val stats = ch.optJSONObject("statistics")
                    subscriberCount = stats?.optString("subscriberCount")?.toLongOrNull() ?: -1L
                    videoCount = stats?.optString("videoCount")?.toLongOrNull() ?: -1L
                }

                val searchReq = Request.Builder()
                    .url("https://www.googleapis.com/youtube/v3/search?part=snippet&forMine=true&type=video&order=date&maxResults=8")
                    .addHeader("Authorization", "Bearer $token")
                    .get()
                    .build()

                val videoIds = mutableListOf<String>()
                httpClient.newCall(searchReq).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val items = JSONObject(resp.body?.string().orEmpty()).optJSONArray("items") ?: JSONArray()
                        for (i in 0 until items.length()) {
                            val vid = items.getJSONObject(i).optJSONObject("id")?.optString("videoId").orEmpty()
                            if (vid.isNotBlank()) videoIds.add(vid)
                        }
                    }
                }

                var shortsViewsSum = 0L
                var shortsCount = 0
                var longViewsSum = 0L
                var longCount = 0
                var totalViews = 0L
                var bestHour: Int? = null
                var bestVideoViews = -1L

                if (videoIds.isNotEmpty()) {
                    val statsReq = Request.Builder()
                        .url("https://www.googleapis.com/youtube/v3/videos?part=statistics,contentDetails,snippet&id=${videoIds.joinToString(",")}")
                        .addHeader("Authorization", "Bearer $token")
                        .get()
                        .build()
                    httpClient.newCall(statsReq).execute().use { resp ->
                        if (resp.isSuccessful) {
                            val items = JSONObject(resp.body?.string().orEmpty()).optJSONArray("items") ?: JSONArray()
                            for (i in 0 until items.length()) {
                                val v = items.getJSONObject(i)
                                val views = v.optJSONObject("statistics")?.optString("viewCount")?.toLongOrNull() ?: 0L
                                val durationIso = v.optJSONObject("contentDetails")?.optString("duration").orEmpty()
                                val publishedAt = v.optJSONObject("snippet")?.optString("publishedAt").orEmpty()
                                totalViews += views
                                val secs = parseIsoDurationSeconds(durationIso)
                                if (secs in 1..65) {
                                    shortsViewsSum += views
                                    shortsCount++
                                } else {
                                    longViewsSum += views
                                    longCount++
                                }
                                if (views > bestVideoViews && publishedAt.isNotBlank()) {
                                    bestVideoViews = views
                                    bestHour = extractLocalHourFromIso(publishedAt)
                                }
                            }
                        }
                    }
                }

                val analyzed = shortsCount + longCount
                val avgViews = if (analyzed > 0) totalViews / analyzed else 0L
                val avgShorts = if (shortsCount > 0) shortsViewsSum / shortsCount else 0L
                val avgLong = if (longCount > 0) longViewsSum / longCount else 0L
                val bestFormatBn = when {
                    analyzed == 0 -> "আপনার চ্যানেলে এখনো পর্যাপ্ত ভিডিও ডেটা নেই"
                    avgShorts >= avgLong -> "ইসলামিক Shorts (গড় $avgShorts ভিউ)"
                    else -> "লং-ফর্ম ভিডিও (গড় $avgLong ভিউ)"
                }

                ChannelPerformanceSummary(
                    channelTitle = channelTitle,
                    subscriberCount = subscriberCount,
                    totalVideoCount = videoCount,
                    recentVideosAnalyzed = analyzed,
                    avgRecentViews = avgViews,
                    bestPerformingFormatBn = bestFormatBn,
                    bestHistoricalHour24 = bestHour,
                    noteBn = "আপনার অনুমোদিত YouTube চ্যানেলের বাস্তব পরিসংখ্যান থেকে বিশ্লেষিত।"
                )
            } catch (_: Exception) {
                null
            }
        }

    suspend fun uploadVideoToYouTube(uploadRequest: YouTubeUploadRequest): Result<Pair<String, String>> =
        withContext(Dispatchers.IO) {
            val controls = securePrefsManager.loadMasterControls()
            if (!controls.youTubeConnectionEnabled) {
                return@withContext Result.failure(
                    IllegalStateException("মাস্টার কন্ট্রোলে YouTube সংযোগ বন্ধ আছে। গোপনীয়তা ড্যাশবোর্ড থেকে চালু করুন।")
                )
            }

            val token = securePrefsManager.getOAuthAccessToken()
            if (token.isNullOrBlank()) {
                return@withContext Result.failure(
                    IllegalStateException("আগে Google অ্যাকাউন্ট দিয়ে YouTube OAuth সংযুক্ত করুন।")
                )
            }

            if (uploadRequest.videoUriString.isBlank()) {
                return@withContext Result.failure(
                    IllegalArgumentException("আপলোডের জন্য একটি ভিডিও ফাইল নির্বাচন করুন।")
                )
            }

            val videoUri = Uri.parse(uploadRequest.videoUriString)
            val mimeType = context.contentResolver.getType(videoUri) ?: "video/mp4"
            val hasSchedule = uploadRequest.scheduledPublishIsoUtc.isNotBlank()

            try {
                // Step 1: Initiate YouTube Data API v3 Resumable Upload Session
                val metadata = JSONObject().apply {
                    put("snippet", JSONObject().apply {
                        put("title", uploadRequest.title.ifBlank { "আবু উবাইদা AI ভিডিও" }.take(100))
                        put("description", uploadRequest.description)
                        put("tags", JSONArray(uploadRequest.tags.take(25)))
                        put("categoryId", "27") // Education
                        put("defaultLanguage", "bn")
                        put("defaultAudioLanguage", "bn")
                    })
                    put("status", JSONObject().apply {
                        // YouTube Data API v3 requires privacyStatus = "private" whenever publishAt is set
                        put("privacyStatus", if (hasSchedule) "private" else uploadRequest.visibility.apiValue)
                        if (hasSchedule) {
                            put("publishAt", uploadRequest.scheduledPublishIsoUtc)
                        }
                    })
                }

                val initReq = Request.Builder()
                    .url(YOUTUBE_RESUMABLE_UPLOAD_URL)
                    .addHeader("Authorization", "Bearer $token")
                    .addHeader("X-Upload-Content-Type", mimeType)
                    .post(metadata.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                    .build()

                val uploadSessionUrl = httpClient.newCall(initReq).execute().use { resp ->
                    if (!resp.isSuccessful) {
                        return@withContext Result.failure(
                            IllegalStateException("YouTube আপলোড সেশন শুরু ব্যর্থ (${resp.code})। টোকেন বা স্কোপ যাচাই করুন।")
                        )
                    }
                    resp.header("Location")
                } ?: return@withContext Result.failure(
                    IllegalStateException("YouTube থেকে আপলোড সেশন URL পাওয়া যায়নি।")
                )

                // Step 2: Stream Video Content directly from ContentResolver (memory-safe)
                val streamingBody = object : RequestBody() {
                    override fun contentType() = mimeType.toMediaType()
                    override fun writeTo(sink: BufferedSink) {
                        context.contentResolver.openInputStream(videoUri)?.use { input ->
                            sink.writeAll(input.source())
                        } ?: throw IllegalStateException("ভিডিও ফাইল পড়া যাচ্ছে না।")
                    }
                }

                val putReq = Request.Builder()
                    .url(uploadSessionUrl)
                    .put(streamingBody)
                    .build()

                val videoId = httpClient.newCall(putReq).execute().use { uploadResp ->
                    val bodyText = uploadResp.body?.string().orEmpty()
                    if (!uploadResp.isSuccessful) {
                        return@withContext Result.failure(
                            IllegalStateException("ভিডিও আপলোড ব্যর্থ (${uploadResp.code})")
                        )
                    }
                    JSONObject(bodyText).optString("id")
                }

                // Step 3: Upload generated Thumbnail PNG if available (requires verified YouTube channel; fails gracefully)
                var thumbNote = ""
                val thumbPath = uploadRequest.thumbnailLocalPath
                if (videoId.isNotBlank() && thumbPath.isNotBlank()) {
                    val thumbFile = File(thumbPath)
                    if (thumbFile.exists() && thumbFile.length() > 100L) {
                        val thumbReq = Request.Builder()
                            .url("https://www.googleapis.com/upload/youtube/v3/thumbnails/set?videoId=${Uri.encode(videoId)}")
                            .addHeader("Authorization", "Bearer $token")
                            .post(thumbFile.asRequestBody("image/png".toMediaType()))
                            .build()
                        try {
                            httpClient.newCall(thumbReq).execute().use { tResp ->
                                thumbNote = if (tResp.isSuccessful) {
                                    " থাম্বনেইলও যুক্ত হয়েছে!"
                                } else {
                                    " (নোট: কাস্টম থাম্বনেইল সেট করতে চ্যানেল ফোন-ভেরিফায়েড হতে হয়)"
                                }
                            }
                        } catch (_: Exception) {
                        }
                    }
                }

                val scheduleText = if (hasSchedule) {
                    "শিডিউল: ${uploadRequest.scheduledLabelBn}"
                } else {
                    uploadRequest.visibility.labelBn
                }
                val msg = if (videoId.isNotBlank()) {
                    "ভিডিও সফলভাবে YouTube-এ আপলোড হয়েছে! ভিডিও আইডি: $videoId ($scheduleText)$thumbNote"
                } else {
                    "ভিডিও আপলোড সম্পন্ন হয়েছে ($scheduleText)।"
                }
                Result.success(videoId to msg)
            } catch (e: Exception) {
                Result.failure(
                    IllegalStateException("YouTube আপলোডে ত্রুটি: ${e.localizedMessage ?: "অজানা সমস্যা"}")
                )
            }
        }

    suspend fun checkVideoStatus(videoId: String): Result<String> = withContext(Dispatchers.IO) {
        val token = securePrefsManager.getOAuthAccessToken()
        if (token.isNullOrBlank() || videoId.isBlank()) {
            return@withContext Result.failure(IllegalStateException("ভিডিও আইডি বা YouTube OAuth টোকেন পাওয়া যায়নি।"))
        }
        try {
            val req = Request.Builder()
                .url("https://www.googleapis.com/youtube/v3/videos?part=status,processingDetails,statistics&id=${Uri.encode(videoId)}")
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    return@withContext Result.failure(IllegalStateException("YouTube স্ট্যাটাস পরীক্ষা ব্যর্থ (${resp.code})"))
                }
                val items = JSONObject(resp.body?.string().orEmpty()).optJSONArray("items")
                if (items == null || items.length() == 0) {
                    return@withContext Result.failure(IllegalStateException("এই ভিডিও আইডি চ্যানেলে পাওয়া যায়নি।"))
                }
                val item = items.getJSONObject(0)
                val status = item.optJSONObject("status")
                val processing = item.optJSONObject("processingDetails")
                val stats = item.optJSONObject("statistics")
                val uploadStatus = status?.optString("uploadStatus").orEmpty()
                val privacy = status?.optString("privacyStatus").orEmpty()
                val procStatus = processing?.optString("processingStatus").orEmpty()
                val views = stats?.optString("viewCount").orEmpty().ifBlank { "0" }
                Result.success(
                    "আপলোড: $uploadStatus | প্রসেসিং: $procStatus | দৃশ্যমানতা: $privacy | ভিউ: $views"
                )
            }
        } catch (e: Exception) {
            Result.failure(IllegalStateException("স্ট্যাটাস পরীক্ষা ব্যর্থ: ${e.localizedMessage}"))
        }
    }

    private fun parseIsoDurationSeconds(iso: String): Int {
        val m = Regex("PT(?:(\\d+)H)?(?:(\\d+)M)?(?:(\\d+)S)?").find(iso) ?: return 0
        val h = m.groupValues[1].toIntOrNull() ?: 0
        val min = m.groupValues[2].toIntOrNull() ?: 0
        val s = m.groupValues[3].toIntOrNull() ?: 0
        return h * 3600 + min * 60 + s
    }

    private fun extractLocalHourFromIso(isoUtc: String): Int? {
        return try {
            val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            val date = fmt.parse(isoUtc) ?: return null
            val cal = Calendar.getInstance().apply { time = date }
            cal.get(Calendar.HOUR_OF_DAY)
        } catch (_: Exception) {
            null
        }
    }

    companion object {
        private const val SCOPE_YOUTUBE_UPLOAD = "https://www.googleapis.com/auth/youtube.upload"
        private const val SCOPE_YOUTUBE_READONLY = "https://www.googleapis.com/auth/youtube.readonly"
        private const val YOUTUBE_RESUMABLE_UPLOAD_URL =
            "https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status"
    }
}
