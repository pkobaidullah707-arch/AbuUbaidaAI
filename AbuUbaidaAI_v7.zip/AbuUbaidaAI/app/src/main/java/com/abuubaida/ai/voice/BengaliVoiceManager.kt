package com.abuubaida.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.abuubaida.ai.data.model.VoiceState
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class BengaliVoiceManager(private val context: Context) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false
    private var speechFinishedCallback: (() -> Unit)? = null
    private val pendingSynthesis = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()

    private val _voiceState = MutableStateFlow<VoiceState>(VoiceState.Idle)
    val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

    private val _rmsLevel = MutableStateFlow(0f)
    val rmsLevel: StateFlow<Float> = _rmsLevel.asStateFlow()

    private val _partialTranscript = MutableStateFlow("")
    val partialTranscript: StateFlow<String> = _partialTranscript.asStateFlow()

    private val _ttsSupportedBn = MutableStateFlow(true)
    val ttsSupportedBn: StateFlow<Boolean> = _ttsSupportedBn.asStateFlow()

    init {
        initTextToSpeech()
    }

    private fun initTextToSpeech() {
        textToSpeech = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val bdLocale = Locale("bn", "BD")
                val result = textToSpeech?.setLanguage(bdLocale)
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    val fallbackResult = textToSpeech?.setLanguage(Locale("bn"))
                    _ttsSupportedBn.value =
                        fallbackResult != TextToSpeech.LANG_MISSING_DATA &&
                        fallbackResult != TextToSpeech.LANG_NOT_SUPPORTED
                } else {
                    _ttsSupportedBn.value = true
                }
                textToSpeech?.setSpeechRate(1.0f)
                textToSpeech?.setPitch(1.0f)
                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        val syn = utteranceId?.let { pendingSynthesis.remove(it) }
                        if (syn != null) {
                            syn.complete(true)
                            return
                        }
                        mainHandler.post {
                            _voiceState.value = VoiceState.Idle
                            val cb = speechFinishedCallback
                            speechFinishedCallback = null
                            cb?.invoke()
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        val syn = utteranceId?.let { pendingSynthesis.remove(it) }
                        if (syn != null) {
                            syn.complete(false)
                            return
                        }
                        mainHandler.post {
                            _voiceState.value = VoiceState.Idle
                            speechFinishedCallback = null
                        }
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        val syn = utteranceId?.let { pendingSynthesis.remove(it) }
                        if (syn != null) {
                            syn.complete(false)
                            return
                        }
                        mainHandler.post {
                            _voiceState.value = VoiceState.Idle
                            speechFinishedCallback = null
                        }
                    }
                })
                isTtsReady = true
            } else {
                isTtsReady = false
                _ttsSupportedBn.value = false
            }
        }
    }

    fun isSpeechRecognitionAvailable(): Boolean {
        return SpeechRecognizer.isRecognitionAvailable(context)
    }

    fun buildBengaliSpeechIntent(
        languageTag: String = "bn-BD",
        promptBn: String = "আবু উবাইদা AI-কে বলুন..."
    ): Intent {
        val cleanLang = languageTag.ifBlank { "bn-BD" }
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, cleanLang)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, cleanLang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PROMPT, promptBn)
        }
    }

    fun startListening(
        languageTag: String = "bn-BD",
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        mainHandler.post {
            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                val msg = "সরাসরি মাইক্রোফোন সেবা পাওয়া যায়নি—নিচের 'গুগল ভয়েস ডায়ালগ' বাটনটি ব্যবহার করুন।"
                _voiceState.value = VoiceState.Error(msg)
                onError(msg)
                return@post
            }

            stopSpeaking()
            try {
                speechRecognizer?.cancel()
                speechRecognizer?.destroy()
            } catch (_: Exception) {
            }
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context.applicationContext).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _partialTranscript.value = ""
                        _voiceState.value = VoiceState.Listening
                    }

                    override fun onBeginningOfSpeech() {}

                    override fun onRmsChanged(rmsdB: Float) {
                        val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                        _rmsLevel.value = normalized
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        _rmsLevel.value = 0f
                        _voiceState.value = VoiceState.Processing
                    }

                    override fun onError(error: Int) {
                        _rmsLevel.value = 0f
                        val message = when (error) {
                            SpeechRecognizer.ERROR_AUDIO -> "অডিও রেকর্ডিংয়ে সমস্যা হয়েছে।"
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "মাইক্রোফোন অনুমতি দেওয়া হয়নি।"
                            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                                "ভয়েস চিনতে ইন্টারনেট সংযোগ প্রয়োজন।"
                            SpeechRecognizer.ERROR_NO_MATCH -> "আপনার কথা স্পষ্ট বোঝা যায়নি। আবার বলুন বা 'গুগল ভয়েস' বাটন চাপুন।"
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "কোনো কথা শোনা যায়নি।"
                            else -> "ভয়েস রিকগনিশনে সমস্যা হয়েছে—'গুগল ভয়েস ডায়ালগ' ব্যবহার করে দেখুন।"
                        }
                        _voiceState.value = VoiceState.Error(message)
                        onError(message)
                    }

                    override fun onResults(results: Bundle?) {
                        _rmsLevel.value = 0f
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull()?.trim().orEmpty()
                        if (text.isNotBlank()) {
                            _partialTranscript.value = text
                            onResult(text)
                        } else {
                            val msg = "কোনো বাংলা কথা শনাক্ত করা যায়নি।"
                            _voiceState.value = VoiceState.Error(msg)
                            onError(msg)
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val partial = partialResults
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            .orEmpty()
                        if (partial.isNotBlank()) {
                            _partialTranscript.value = partial
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }

            speechRecognizer?.startListening(buildBengaliSpeechIntent(languageTag = languageTag))
        }
    }

    fun stopListening() {
        mainHandler.post {
            speechRecognizer?.stopListening()
            _rmsLevel.value = 0f
            if (_voiceState.value is VoiceState.Listening) {
                _voiceState.value = VoiceState.Idle
            }
        }
    }

    suspend fun synthesizeBengaliVoiceoverToFile(spokenScript: String, outputWavFile: File): File? {
        if (!isTtsReady || !_ttsSupportedBn.value || spokenScript.isBlank()) return null
        val cleanNarration = spokenScript
            .replace(Regex("\\[.*?\\]"), " ")
            .replace(Regex("[\\u0600-\\u06FF]+"), " ") // Keep narration cleanly Bengali; Quran Arabic shown visually
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(1500)
        if (cleanNarration.length < 10) return null

        outputWavFile.parentFile?.mkdirs()
        if (outputWavFile.exists()) outputWavFile.delete()

        val utteranceId = "vo_${UUID.randomUUID()}"
        val deferred = CompletableDeferred<Boolean>()
        pendingSynthesis[utteranceId] = deferred

        val queued = textToSpeech?.synthesizeToFile(
            cleanNarration,
            Bundle(),
            outputWavFile,
            utteranceId
        ) ?: TextToSpeech.ERROR

        if (queued != TextToSpeech.SUCCESS) {
            pendingSynthesis.remove(utteranceId)
            return null
        }

        val ok = withTimeoutOrNull(18_000L) { deferred.await() } ?: false
        pendingSynthesis.remove(utteranceId)
        return if (ok && outputWavFile.exists() && outputWavFile.length() > 1024L) {
            outputWavFile
        } else {
            null
        }
    }

    fun speak(text: String, onFinished: (() -> Unit)? = null) {
        if (!isTtsReady || text.isBlank()) {
            onFinished?.invoke()
            return
        }
        mainHandler.post {
            speechFinishedCallback = onFinished
            _voiceState.value = VoiceState.Speaking(text)
            textToSpeech?.speak(
                text,
                TextToSpeech.QUEUE_FLUSH,
                null,
                UUID.randomUUID().toString()
            )
        }
    }

    fun stopSpeaking() {
        mainHandler.post {
            speechFinishedCallback = null
            textToSpeech?.stop()
            if (_voiceState.value is VoiceState.Speaking) {
                _voiceState.value = VoiceState.Idle
            }
        }
    }

    fun setProcessing() {
        _voiceState.value = VoiceState.Processing
    }

    fun setIdle() {
        _voiceState.value = VoiceState.Idle
    }

    fun release() {
        pendingSynthesis.values.forEach { it.complete(false) }
        pendingSynthesis.clear()
        mainHandler.post {
            speechFinishedCallback = null
            speechRecognizer?.destroy()
            speechRecognizer = null
            textToSpeech?.stop()
            textToSpeech?.shutdown()
            textToSpeech = null
        }
    }
}
