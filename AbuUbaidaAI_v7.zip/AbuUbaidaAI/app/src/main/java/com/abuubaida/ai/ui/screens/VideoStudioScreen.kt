package com.abuubaida.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.abuubaida.ai.data.model.IslamicCategory
import com.abuubaida.ai.data.model.PublishingRecommendation
import com.abuubaida.ai.data.model.VideoFormat
import com.abuubaida.ai.data.model.VideoProject
import com.abuubaida.ai.ui.components.GlassCard
import com.abuubaida.ai.ui.theme.AmberGold
import com.abuubaida.ai.ui.theme.BrightGold
import com.abuubaida.ai.ui.theme.DeepNavyBg
import com.abuubaida.ai.ui.theme.ElectricBlue
import com.abuubaida.ai.ui.theme.EmeraldOk
import com.abuubaida.ai.ui.theme.ImperialGold
import com.abuubaida.ai.ui.theme.NavyBorder
import com.abuubaida.ai.ui.theme.RoyalBlue
import com.abuubaida.ai.ui.theme.TextPrimary
import com.abuubaida.ai.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VideoStudioScreen(
    project: VideoProject?,
    recommendation: PublishingRecommendation?,
    isBusy: Boolean,
    autonomousProgressBn: String,
    mp4ProviderConnected: Boolean,
    contentCreationEnabled: Boolean,
    onGenerateProject: (String, IslamicCategory, VideoFormat) -> Unit,
    onRunDailyAutonomous: () -> Unit,
    onExportMp4OrScript: () -> Unit,
    onSpeakScript: (String) -> Unit,
    onCopiedAll: () -> Unit,
    onSendToYouTubeStudio: () -> Unit,
    onSendToFacebookStudio: () -> Unit
) {
    var topicInput by remember(project?.topic) { mutableStateOf(project?.topic.orEmpty()) }
    var selectedCategory by remember(project?.category) {
        mutableStateOf(project?.category ?: IslamicCategory.ISLAMIC_EDUCATION)
    }
    var selectedFormat by remember(project?.format) {
        mutableStateOf(project?.format ?: selectedCategory.defaultFormat)
    }
    val clipboardManager = LocalClipboardManager.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("ইসলামিক AI ভিডিও স্টুডিও", style = MaterialTheme.typography.headlineMedium, color = BrightGold)

        GlassCard(borderColor = ImperialGold.copy(alpha = 0.45f)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.Movie, contentDescription = null, tint = BrightGold)
                Text("সম্পূর্ণ ইসলামিক ভিডিও পাইপলাইন", style = MaterialTheme.typography.titleMedium, color = BrightGold)
            }
            Spacer(modifier = Modifier.height(8.dp))

            Text("কনটেন্ট বিভাগ:", style = MaterialTheme.typography.labelLarge, color = ElectricBlue)
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                IslamicCategory.entries.forEach { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = {
                            selectedCategory = cat
                            selectedFormat = cat.defaultFormat
                        },
                        label = { Text(cat.labelBn) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = RoyalBlue,
                            selectedLabelColor = TextPrimary,
                            containerColor = DeepNavyBg,
                            labelColor = TextSecondary
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text("ভিডিও ফরম্যাট:", style = MaterialTheme.typography.labelLarge, color = ElectricBlue)
            Spacer(modifier = Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                VideoFormat.entries.forEach { fmt ->
                    FilterChip(
                        selected = selectedFormat == fmt,
                        onClick = { selectedFormat = fmt },
                        label = { Text(fmt.labelBn) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ImperialGold,
                            selectedLabelColor = DeepNavyBg,
                            containerColor = DeepNavyBg,
                            labelColor = TextSecondary
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = topicInput,
                onValueChange = { topicInput = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("বিষয় লিখুন (ফাঁকা রাখলে যাচাইকৃত সেরা বিষয় নেবে)") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = NavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = { onGenerateProject(topicInput, selectedCategory, selectedFormat) },
                enabled = !isBusy && contentCreationEnabled,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = ImperialGold, contentColor = DeepNavyBg)
            ) {
                Icon(Icons.Rounded.AutoAwesome, contentDescription = null)
                Text(
                    if (contentCreationEnabled) "  ভিডিও, থাম্বনেইল, SEO ও সাবটাইটেল তৈরি করুন"
                    else "  কনটেন্ট তৈরি মাস্টার কন্ট্রোল থেকে বন্ধ"
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedButton(
                onClick = onRunDailyAutonomous,
                enabled = !isBusy && contentCreationEnabled,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("ট্রেন্ড দেখে আজকের ভিডিও স্বয়ংক্রিয়ভাবে তৈরি করুন", color = ElectricBlue)
            }

            if (isBusy) {
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = ImperialGold)
                if (autonomousProgressBn.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(autonomousProgressBn, color = BrightGold, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        if (project != null) {
            // Islamic Content Accuracy & Sources Review
            GlassCard(
                borderColor = if (project.accuracyReview.passed) EmeraldOk.copy(alpha = 0.5f) else AmberGold.copy(alpha = 0.6f)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(
                        Icons.Rounded.Verified,
                        contentDescription = null,
                        tint = if (project.accuracyReview.passed) EmeraldOk else AmberGold
                    )
                    Text(
                        text = if (project.accuracyReview.passed) "ইসলামিক তথ্য ও সূত্র যাচাই সম্পন্ন" else "প্রকাশের আগে সতর্কতা পর্যালোচনা করুন",
                        style = MaterialTheme.typography.titleMedium,
                        color = if (project.accuracyReview.passed) EmeraldOk else AmberGold
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text("সূত্র: ${project.accuracyReview.sourceCitationBn}", color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                project.quranReference?.let { q ->
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(q.arabicUthmaniText, color = BrightGold, style = MaterialTheme.typography.titleMedium)
                    Text("${q.surahNameBn}: ${q.bengaliTranslation}", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                }
                project.hadithReference?.let { h ->
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("${h.collectionBn} (${h.referenceNumber}): ${h.bengaliText}", color = ElectricBlue, style = MaterialTheme.typography.bodyMedium)
                }
                project.accuracyReview.warningsBn.forEach { w ->
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("• $w", color = AmberGold, style = MaterialTheme.typography.bodyMedium)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(project.audioRightsNoteBn, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
            }

            // Smart Publishing Evaluation
            recommendation?.let { plan ->
                GlassCard(borderColor = ElectricBlue.copy(alpha = 0.4f)) {
                    Text("স্মার্ট পাবলিশিং পরামর্শ", style = MaterialTheme.typography.titleMedium, color = ElectricBlue)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("সেরা প্রকাশের সময়: ${plan.targetTimeLabelBn}", color = EmeraldOk, style = MaterialTheme.typography.bodyLarge)
                    Text(plan.reasonBn, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                }
            }

            // MP4 & Thumbnail Status
            GlassCard(borderColor = NavyBorder) {
                Text("প্রস্তুতকৃত মিডিয়া ফাইল", style = MaterialTheme.typography.titleMedium, color = BrightGold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (project.renderedMp4UriString.isNotBlank()) {
                        "• MP4 ভিডিও (${project.format.labelBn}): প্রস্তুত ও স্টুডিওতে যুক্ত হয়েছে।"
                    } else {
                        "• MP4 ভিডিও: এক্সপোর্ট করতে নিচের বাটনে চাপ দিন।"
                    },
                    color = if (project.renderedMp4UriString.isNotBlank()) EmeraldOk else AmberGold
                )
                Text(
                    text = if (project.thumbnailLocalPath.isNotBlank()) {
                        "• Thumbnail PNG: প্রস্তুত (YouTube ও গ্যালারিতে যুক্ত)"
                    } else {
                        "• Thumbnail Text: ${project.thumbnailText}"
                    },
                    color = TextPrimary
                )
            }

            // Bilingual SEO Card
            GlassCard {
                Text("বাংলা SEO শিরোনাম", style = MaterialTheme.typography.labelLarge, color = BrightGold)
                Text(project.seoTitle, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                if (project.englishTitle.isNotBlank()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("English Title", style = MaterialTheme.typography.labelLarge, color = ElectricBlue)
                    Text(project.englishTitle, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text("বিবরণ (Description)", style = MaterialTheme.typography.labelLarge, color = BrightGold)
                Text(project.seoDescription, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                Spacer(modifier = Modifier.height(8.dp))
                Text("ট্যাগ ও হ্যাশট্যাগ", style = MaterialTheme.typography.labelLarge, color = BrightGold)
                Text(project.seoTags.joinToString(", "), style = MaterialTheme.typography.bodyMedium, color = ElectricBlue)
                if (project.hashtags.isNotEmpty()) {
                    Text(project.hashtags.joinToString(" "), style = MaterialTheme.typography.bodyMedium, color = BrightGold)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text("থাম্বনেইল টেক্সট: ${project.thumbnailText}", color = TextPrimary)
                Text(project.thumbnailDesignSummary, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
            }

            GlassCard {
                Text("বাংলা ভয়েসওভার চিত্রনাট্য (Script)", style = MaterialTheme.typography.titleMedium, color = BrightGold)
                Spacer(modifier = Modifier.height(6.dp))
                Text(project.script, style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { onSpeakScript(project.script) },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.VolumeUp, contentDescription = null, tint = BrightGold)
                    Text("  স্ক্রিপ্ট শুনুন", color = BrightGold)
                }
                OutlinedButton(
                    onClick = {
                        val fullBundle = buildString {
                            appendLine("বাংলা শিরোনাম: ${project.seoTitle}")
                            appendLine("English Title: ${project.englishTitle}")
                            appendLine("\nবর্ণনা:\n${project.seoDescription}")
                            appendLine("\nট্যাগ: ${project.seoTags.joinToString(", ")}")
                            appendLine("হ্যাশট্যাগ: ${project.hashtags.joinToString(" ")}")
                            appendLine("\nস্ক্রিপ্ট:\n${project.script}")
                        }
                        clipboardManager.setText(AnnotatedString(fullBundle))
                        onCopiedAll()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.ContentCopy, contentDescription = null, tint = ElectricBlue)
                    Text("  সব কপি", color = ElectricBlue)
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = onExportMp4OrScript,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (mp4ProviderConnected) "আবার MP4 সংরক্ষণ" else "স্ক্রিপ্ট সংরক্ষণ", color = BrightGold)
                }
                Button(
                    onClick = onSendToYouTubeStudio,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue, contentColor = TextPrimary)
                ) {
                    Text("YouTube স্টুডিও")
                }
            }

            Button(
                onClick = onSendToFacebookStudio,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = ImperialGold, contentColor = DeepNavyBg)
            ) {
                Text("Facebook পেজ স্টুডিওতে পাঠান")
            }
        }
    }
}
