package com.abuubaida.ai.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.abuubaida.ai.data.model.FacebookAccountInfo
import com.abuubaida.ai.data.model.FacebookPublishState
import com.abuubaida.ai.data.model.FacebookUploadRequest
import com.abuubaida.ai.ui.components.GlassCard
import com.abuubaida.ai.ui.theme.BrightGold
import com.abuubaida.ai.ui.theme.DeepNavyBg
import com.abuubaida.ai.ui.theme.ElectricBlue
import com.abuubaida.ai.ui.theme.EmeraldOk
import com.abuubaida.ai.ui.theme.ImperialGold
import com.abuubaida.ai.ui.theme.NavyBorder
import com.abuubaida.ai.ui.theme.RoyalBlue
import com.abuubaida.ai.ui.theme.TextPrimary
import com.abuubaida.ai.ui.theme.TextSecondary

@Composable
fun FacebookStudioScreen(
    accountInfo: FacebookAccountInfo,
    isBusy: Boolean,
    savedMetaAppId: String,
    uploadRequest: FacebookUploadRequest,
    onUpdateRequest: ((FacebookUploadRequest) -> FacebookUploadRequest) -> Unit,
    onPickVideo: (Uri) -> Unit,
    onConnectPage: (String, String) -> Unit,
    onBuildMetaOAuthUrl: (String) -> String?,
    onDisconnectPage: () -> Unit,
    onRequestPublish: (FacebookUploadRequest) -> Unit,
    onCheckStatus: (String) -> Unit
) {
    val context = LocalContext.current
    var pageIdInput by remember(accountInfo.pageId) { mutableStateOf(accountInfo.pageId) }
    var tokenInput by remember { mutableStateOf("") }
    var metaAppIdInput by remember(savedMetaAppId) { mutableStateOf(savedMetaAppId) }
    var hashtagsText by remember(uploadRequest.hashtags) {
        mutableStateOf(uploadRequest.hashtags.joinToString(" "))
    }

    val videoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) onPickVideo(uri)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Facebook স্টুডিও (Meta Graph API)", style = MaterialTheme.typography.headlineMedium, color = BrightGold)

        GlassCard(borderColor = if (accountInfo.hasAccessToken) EmeraldOk.copy(alpha = 0.5f) else ImperialGold.copy(alpha = 0.45f)) {
            Text("অফিসিয়াল Meta পেজ সংযোগ", style = MaterialTheme.typography.titleMedium, color = BrightGold)
            Spacer(modifier = Modifier.height(6.dp))
            if (accountInfo.hasAccessToken) {
                Text(
                    text = "সংযুক্ত পেজ: ${accountInfo.pageName.ifBlank { accountInfo.pageId }} (ID: ${accountInfo.pageId})",
                    color = EmeraldOk,
                    style = MaterialTheme.typography.bodyLarge
                )
                if (accountInfo.followersCount >= 0) {
                    Text("ফলোয়ার: ${accountInfo.followersCount}", color = TextSecondary)
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(onClick = onDisconnectPage) {
                    Text("Facebook পেজ বিচ্ছিন্ন করুন", color = ElectricBlue)
                }
            } else {
                Text(
                    text = "অফিসিয়াল Meta Graph API v21.0 দিয়ে পেজে ভিডিও/Reels প্রকাশ করতে আপনার Meta Page Access Token দিন (টোকেন Android Keystore-এ এনক্রিপ্টেড থাকে)।",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = pageIdInput,
                    onValueChange = { pageIdInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Facebook Page ID (ঐচ্ছিক, ফাঁকা রাখলে অটো-খুঁজবে)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = NavyBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = tokenInput,
                    onValueChange = { tokenInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Meta Page Access Token (pages_manage_posts)") },
                    visualTransformation = PasswordVisualTransformation(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = NavyBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = { onConnectPage(pageIdInput, tokenInput) },
                    enabled = !isBusy && tokenInput.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue, contentColor = TextPrimary)
                ) {
                    Text("যাচাই করে পেজ সংযুক্ত করুন")
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = metaAppIdInput,
                    onValueChange = { metaAppIdInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Meta Developer App ID (OAuth ব্রাউজার লগইনের জন্য ঐচ্ছিক)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = NavyBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedButton(
                    onClick = {
                        val url = onBuildMetaOAuthUrl(metaAppIdInput)
                        if (!url.isNullOrBlank()) {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                        }
                    },
                    enabled = metaAppIdInput.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("ব্রাউজারে Meta OAuth অনুমোদন খুলুন", color = ElectricBlue)
                }
            }
        }

        GlassCard {
            Text("Facebook ভিডিও / Reels প্রকাশনা", style = MaterialTheme.typography.titleMedium, color = ElectricBlue)
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedButton(
                onClick = { videoPicker.launch("video/*") },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = if (uploadRequest.videoDisplayName.isNotBlank()) {
                        "নির্বাচিত ফাইল: ${uploadRequest.videoDisplayName}"
                    } else {
                        "ডিভাইস থেকে ভিডিও (MP4) নির্বাচন করুন"
                    },
                    color = BrightGold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = uploadRequest.title,
                onValueChange = { v -> onUpdateRequest { it.copy(title = v) } },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("ভিডিও শিরোনাম") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = NavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = uploadRequest.caption,
                onValueChange = { v -> onUpdateRequest { it.copy(caption = v) } },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp),
                label = { Text("ক্যাপশন ও বিবরণ") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = NavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = hashtagsText,
                onValueChange = { raw ->
                    hashtagsText = raw
                    val parsed = raw.split(Regex("[\\s,]+")).filter { it.isNotBlank() }
                    onUpdateRequest { it.copy(hashtags = parsed) }
                },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("হ্যাশট্যাগ (#BanglaIslamic #Quran)") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = NavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Facebook Reels ফরম্যাট হিসেবে প্রস্তুত", color = TextPrimary)
                Switch(
                    checked = uploadRequest.isReel,
                    onCheckedChange = { checked -> onUpdateRequest { it.copy(isReel = checked) } }
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text("প্রকাশ মোড:", style = MaterialTheme.typography.labelLarge, color = BrightGold)
            FacebookPublishState.entries.forEach { st ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    RadioButton(
                        selected = uploadRequest.publishState == st,
                        onClick = { onUpdateRequest { it.copy(publishState = st) } }
                    )
                    Text(st.labelBn, color = TextPrimary)
                }
            }
            if (uploadRequest.publishState == FacebookPublishState.SCHEDULE && uploadRequest.scheduledLabelBn.isNotBlank()) {
                Text("স্মার্ট শিডিউল সময়: ${uploadRequest.scheduledLabelBn}", color = EmeraldOk, style = MaterialTheme.typography.bodyMedium)
            }
            if (isBusy) {
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = ImperialGold)
            }
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = { onRequestPublish(uploadRequest) },
                enabled = !isBusy && accountInfo.hasAccessToken && uploadRequest.videoUriString.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = ImperialGold, contentColor = DeepNavyBg)
            ) {
                Text("নিশ্চিত করে Facebook পেজে পাঠান")
            }

            if (uploadRequest.lastPublishedVideoId.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = { onCheckStatus(uploadRequest.lastPublishedVideoId) },
                    enabled = !isBusy,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("প্রকাশ স্ট্যাটাস যাচাই করুন (${uploadRequest.lastPublishedVideoId})", color = ElectricBlue)
                }
            }
            if (uploadRequest.lastStatusReportBn.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(uploadRequest.lastStatusReportBn, color = EmeraldOk, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
