package com.abuubaida.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.abuubaida.ai.data.model.AssistantSettings
import com.abuubaida.ai.data.model.IslamicVoicePreset
import com.abuubaida.ai.data.model.TtsVoiceOption
import com.abuubaida.ai.data.model.VoiceState
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.tanh

class BengaliVoiceManager(private val context: Context) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false
    private var speechFinishedCallback: (() -> Unit)? = null
    private var activeFinalUtteranceId: String? = null
    private val pendingSynthesis = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()

    private var activeSettings: AssistantSettings = AssistantSettings()
    private val rawVoicesMap = ConcurrentHashMap<String, Voice>()
    private var rankedMaleVoices: List<Voice> = emptyList()
    private var deviceHasOnlyFemaleBnVoice: Boolean = false

    private val _voiceState = MutableStateFlow<VoiceState>(VoiceState.Idle)
    val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

    private val _rmsLevel = MutableStateFlow(0f)
    val rmsLevel: StateFlow<Float> = _rmsLevel.asStateFlow()

    private val _partialTranscript = MutableStateFlow("")
    val partialTranscript: StateFlow<String> = _partialTranscript.asStateFlow()

    private val _ttsSupportedBn = MutableStateFlow(true)
    val ttsSupportedBn: StateFlow<Boolean> = _ttsSupportedBn.asStateFlow()

    private val _availableVoices = MutableStateFlow<List<TtsVoiceOption>>(emptyList())
    val availableVoices: StateFlow<List<TtsVoiceOption>> = _availableVoices.asStateFlow()

    init {
        initTextToSpeech()
    }

    private fun initTextToSpeech() {
        try {
            textToSpeech = TextToSpeech(context.applicationContext) { status ->
                try {
                    if (status == TextToSpeech.SUCCESS) {
                        val bdLocale = Locale("bn", "BD")
                        val result = textToSpeech?.setLanguage(bdLocale)
                        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                            val fallbackResult = textToSpeech?.setLanguage(Locale("bn"))
                            _ttsSupportedBn.value =
                                fallbackResult != TextToSpeech.LANG_MISSING_DATA &&
                                fallbackResult != TextToSpeech.LANG_NOT_SUPPORTED
                        } else {
                            _ttsSupportedBn.value = true
                        }

                        refreshAvailableVoicesLocked()
                        applyVoiceSettingsInternal(activeSettings)

                        textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                            override fun onStart(utteranceId: String?) {}
                            override fun onDone(utteranceId: String?) {
                                val syn = utteranceId?.let { pendingSynthesis.remove(it) }
                                if (syn != null) {
                                    syn.complete(true)
                                    return
                                }
                                if (utteranceId == activeFinalUtteranceId || activeFinalUtteranceId == null) {
                                    mainHandler.post {
                                        activeFinalUtteranceId = null
                                        _voiceState.value = VoiceState.Idle
                                        val cb = speechFinishedCallback
                                        speechFinishedCallback = null
                                        cb?.invoke()
                                    }
                                }
                            }

                            @Deprecated("Deprecated in Java")
                            override fun onError(utteranceId: String?) {
                                val syn = utteranceId?.let { pendingSynthesis.remove(it) }
                                if (syn != null) {
                                    syn.complete(false)
                                    return
                                }
                                if (utteranceId == activeFinalUtteranceId || activeFinalUtteranceId == null) {
                                    mainHandler.post {
                                        activeFinalUtteranceId = null
                                        _voiceState.value = VoiceState.Idle
                                        speechFinishedCallback = null
                                    }
                                }
                            }

                            override fun onError(utteranceId: String?, errorCode: Int) {
                                val syn = utteranceId?.let { pendingSynthesis.remove(it) }
                                if (syn != null) {
                                    syn.complete(false)
                                    return
                                }
                                if (utteranceId == activeFinalUtteranceId || activeFinalUtteranceId == null) {
                                    mainHandler.post {
                                        activeFinalUtteranceId = null
                                        _voiceState.value = VoiceState.Idle
                                        speechFinishedCallback = null
                                    }
                                }
                            }
                        })
                        isTtsReady = true
                    } else {
                        isTtsReady = false
                        _ttsSupportedBn.value = false
                    }
                } catch (_: Throwable) {
                    isTtsReady = false
                    _ttsSupportedBn.value = false
                }
            }
        } catch (_: Throwable) {
            isTtsReady = false
            _ttsSupportedBn.value = false
        }
    }

    private fun isLikelyFemaleVoice(voice: Voice): Boolean {
        val tokens = voice.name.lowercase(Locale.US)
            .split('-', '_', '.', ' ', '#')
            .filter { it.isNotBlank() }
            .toSet()
        if (tokens.any {
                it in setOf("female", "woman", "girl", "bnf", "ban", "bng", "sfg", "f")
            }
        ) {
            return true
        }
        val featuresStr = runCatching { voice.features?.joinToString(" ")?.lowercase(Locale.US) }.getOrNull().orEmpty()
        return featuresStr.contains("female")
    }

    private fun isExplicitMaleVoice(voice: Voice): Boolean {
        val tokens = voice.name.lowercase(Locale.US)
            .split('-', '_', '.', ' ', '#')
            .filter { it.isNotBlank() }
            .toSet()
        if (tokens.any { it in setOf("bnm", "bam", "bgm", "male", "man", "m") }) {
            return true
        }
        val featuresStr = runCatching { voice.features?.joinToString(" ")?.lowercase(Locale.US) }.getOrNull().orEmpty()
        return featuresStr.contains("male") && !featuresStr.contains("female")
    }

    private fun refreshAvailableVoicesLocked() {
        try {
            val allVoices = textToSpeech?.voices ?: return
            rawVoicesMap.clear()

            val allBnVoices = allVoices.filter { v ->
                val lang = v.locale?.language?.lowercase(Locale.US).orEmpty()
                lang == "bn" ||
                    v.name.contains("bn-", ignoreCase = true) ||
                    v.name.contains("bn_", ignoreCase = true) ||
                    v.name.contains("bengali", ignoreCase = true)
            }

            // Strictly remove female voices so female audio never plays
            val maleOnly = allBnVoices
                .filterNot { isLikelyFemaleVoice(it) }
                .sortedWith(
                    compareByDescending<Voice> { isExplicitMaleVoice(it) }
                        // Prefer Natural HD Neural network voices first so voice sounds 100% human, not robotic
                        .thenByDescending { it.quality >= Voice.QUALITY_HIGH }
                        .thenByDescending { it.isNetworkConnectionRequired }
                        .thenByDescending { it.locale?.country.equals("BD", ignoreCase = true) }
                        .thenBy { it.name }
                )

            rankedMaleVoices = maleOnly
            deviceHasOnlyFemaleBnVoice = allBnVoices.isNotEmpty() && maleOnly.isEmpty()

            val options = maleOnly.mapIndexed { idx, voice ->
                rawVoicesMap[voice.name] = voice
                val countryLabel = when {
                    voice.locale?.country.equals("BD", ignoreCase = true) -> "বাংলাদেশি পুরুষ কণ্ঠ"
                    voice.locale?.country.equals("IN", ignoreCase = true) -> "বাংলা পুরুষ কণ্ঠ"
                    else -> "ইসলামিক পুরুষ কণ্ঠ"
                }
                val qualityLabel = if (voice.isNetworkConnectionRequired || voice.quality >= Voice.QUALITY_HIGH) {
                    "HD স্বাভাবিক"
                } else {
                    "অফলাইন"
                }
                val codeSuffix = voice.name.substringAfterLast("-").take(8)
                TtsVoiceOption(
                    name = voice.name,
                    labelBn = "$countryLabel ${idx + 1} ($qualityLabel · $codeSuffix)",
                    localeTag = voice.locale?.toLanguageTag().orEmpty()
                )
            }
            _availableVoices.value = options
        } catch (_: Throwable) {
        }
    }

    fun applyVoiceSettings(settings: AssistantSettings) {
        activeSettings = settings
        mainHandler.post {
            applyVoiceSettingsInternal(settings)
        }
    }

    private fun applyVoiceSettingsInternal(settings: AssistantSettings) {
        val tts = textToSpeech ?: return
        try {
            if (rankedMaleVoices.isEmpty() && rawVoicesMap.isEmpty()) {
                refreshAvailableVoicesLocked()
            }

            var chosenVoice: Voice? = null
            if (settings.selectedTtsVoiceName.isNotBlank()) {
                val explicit = rawVoicesMap[settings.selectedTtsVoiceName]
                    ?: tts.voices?.firstOrNull { it.name == settings.selectedTtsVoiceName }
                if (explicit != null && !isLikelyFemaleVoice(explicit)) {
                    chosenVoice = explicit
                }
            }

            // Auto-assign distinct male voice slot for each of the 3 presets so they sound unmistakably different
            if (chosenVoice == null && rankedMaleVoices.isNotEmpty()) {
                val slotIdx = settings.voicePreset.voiceSlot % rankedMaleVoices.size
                chosenVoice = rankedMaleVoices[slotIdx]
            }

            if (chosenVoice != null) {
                tts.voice = chosenVoice
            }

            val basePitch = settings.voicePitch.coerceIn(0.65f, 1.10f)
            // Guard: if device only had a female fallback voice, force baritone male pitch register
            val finalPitch = if (chosenVoice == null && deviceHasOnlyFemaleBnVoice) {
                (basePitch * 0.77f).coerceIn(0.55f, 0.82f)
            } else {
                basePitch
            }
            val finalRate = settings.voiceRate.coerceIn(0.70f, 1.15f)
            tts.setPitch(finalPitch)
            tts.setSpeechRate(finalRate)
        } catch (_: Throwable) {
        }
    }

    fun openInstallTtsVoiceData(): Result<String> {
        return try {
            val intent = Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success("ফোনের TTS ভয়েস প্যাক ইনস্টলার খোলা হয়েছে — এখান থেকে পুরুষ বাংলা (bn-BD / HD) কণ্ঠ ডাউনলোড করতে পারবেন।")
        } catch (_: Exception) {
            Result.failure(IllegalStateException("এই ডিভাইসে সরাসরি ভয়েস ডাউনলোড পর্দা খোলা যায়নি; ফোনের Settings -> Language -> Text-to-Speech থেকে Google ভয়েস আপডেট করুন।"))
        }
    }

    fun isSpeechRecognitionAvailable(): Boolean {
        return SpeechRecognizer.isRecognitionAvailable(context)
    }

    fun buildBengaliSpeechIntent(
        languageTag: String = "bn-BD",
        promptBn: String = "আবু উবাইদা AI-কে বলুন..."
    ): Intent {
        val cleanLang = languageTag.ifBlank { "bn-BD" }
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, cleanLang)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, cleanLang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PROMPT, promptBn)
        }
    }

    fun startListening(
        languageTag: String = "bn-BD",
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        mainHandler.post {
            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                val msg = "সরাসরি মাইক্রোফোন সেবা পাওয়া যায়নি—নিচের 'গুগল ভয়েস ডায়ালগ' বাটনটি ব্যবহার করুন।"
                _voiceState.value = VoiceState.Error(msg)
                onError(msg)
                return@post
            }

            stopSpeaking()
            try {
                speechRecognizer?.cancel()
                speechRecognizer?.destroy()
            } catch (_: Exception) {
            }
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context.applicationContext).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _partialTranscript.value = ""
                        _voiceState.value = VoiceState.Listening
                    }

                    override fun onBeginningOfSpeech() {}

                    override fun onRmsChanged(rmsdB: Float) {
                        val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                        _rmsLevel.value = normalized
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        _rmsLevel.value = 0f
                        _voiceState.value = VoiceState.Processing
                    }

                    override fun onError(error: Int) {
                        _rmsLevel.value = 0f
                        val message = when (error) {
                            SpeechRecognizer.ERROR_AUDIO -> "অডিও রেকর্ডিংয়ে সমস্যা হয়েছে।"
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "মাইক্রোফোন অনুমতি দেওয়া হয়নি।"
                            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                                "ভয়েস চিনতে ইন্টারনেট সংযোগ প্রয়োজন।"
                            SpeechRecognizer.ERROR_NO_MATCH -> "আপনার কথা স্পষ্ট বোঝা যায়নি। আবার বলুন বা 'গুগল ভয়েস' বাটন চাপুন।"
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "কোনো কথা শোনা যায়নি।"
                            else -> "ভয়েস রিকগনিশনে সমস্যা হয়েছে—'গুগল ভয়েস ডায়ালগ' ব্যবহার করে দেখুন।"
                        }
                        _voiceState.value = VoiceState.Error(message)
                        onError(message)
                    }

                    override fun onResults(results: Bundle?) {
                        _rmsLevel.value = 0f
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull()?.trim().orEmpty()
                        if (text.isNotBlank()) {
                            _partialTranscript.value = text
                            onResult(text)
                        } else {
                            val msg = "কোনো বাংলা কথা শনাক্ত করা যায়নি।"
                            _voiceState.value = VoiceState.Error(msg)
                            onError(msg)
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val partial = partialResults
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            .orEmpty()
                        if (partial.isNotBlank()) {
                            _partialTranscript.value = partial
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }

            speechRecognizer?.startListening(buildBengaliSpeechIntent(languageTag = languageTag))
        }
    }

    fun stopListening() {
        mainHandler.post {
            speechRecognizer?.stopListening()
            _rmsLevel.value = 0f
            if (_voiceState.value is VoiceState.Listening) {
                _voiceState.value = VoiceState.Idle
            }
        }
    }

    suspend fun synthesizeBengaliVoiceoverToFile(
        spokenScript: String,
        outputWavFile: File
    ): File? = withContext(Dispatchers.IO) {
        if (!isTtsReady || !_ttsSupportedBn.value || spokenScript.isBlank()) return@withContext null
        val cleanNarration = cleanNarrationForSpeech(spokenScript)
        if (cleanNarration.length < 10) return@withContext null

        withContext(Dispatchers.Main) {
            applyVoiceSettingsInternal(activeSettings)
        }
        outputWavFile.parentFile?.mkdirs()
        if (outputWavFile.exists()) outputWavFile.delete()

        val sentences = splitIntoNaturalSentences(cleanNarration)
        val batches = chunkSentencesIntoSafeBatches(sentences, maxCharsPerBatch = 1350)
        if (batches.isEmpty()) return@withContext null

        val tempParts = mutableListOf<File>()
        try {
            batches.forEachIndexed { idx, batchText ->
                val partFile = File(context.cacheDir, "vo_part_${idx}_${UUID.randomUUID()}.wav")
                val utteranceId = "vo_${idx}_${UUID.randomUUID()}"
                val deferred = CompletableDeferred<Boolean>()
                pendingSynthesis[utteranceId] = deferred

                val queued = withContext(Dispatchers.Main) {
                    applyVoiceSettingsInternal(activeSettings)
                    textToSpeech?.synthesizeToFile(batchText, Bundle(), partFile, utteranceId) ?: TextToSpeech.ERROR
                }
                if (queued != TextToSpeech.SUCCESS) {
                    pendingSynthesis.remove(utteranceId)
                    partFile.delete()
                    return@forEachIndexed
                }

                val ok = withTimeoutOrNull(35_000L) { deferred.await() } ?: false
                pendingSynthesis.remove(utteranceId)
                if (ok && partFile.exists() && partFile.length() > 128L) {
                    tempParts.add(partFile)
                } else {
                    partFile.delete()
                }
            }

            if (tempParts.isEmpty()) return@withContext null

            val merged = mergeAndMasterWavParts(
                parts = tempParts,
                outputWavFile = outputWavFile,
                preset = activeSettings.voicePreset,
                interChunkPauseMs = activeSettings.voicePreset.sentencePauseMs.coerceIn(240L, 650L)
            )
            if (merged && outputWavFile.exists() && outputWavFile.length() > 1024L) {
                outputWavFile
            } else {
                outputWavFile.delete()
                null
            }
        } catch (_: Exception) {
            null
        } finally {
            tempParts.forEach { runCatching { it.delete() } }
        }
    }

    private fun chunkSentencesIntoSafeBatches(sentences: List<String>, maxCharsPerBatch: Int): List<String> {
        if (sentences.isEmpty()) return emptyList()
        val batches = mutableListOf<String>()
        val current = StringBuilder()
        for (sentence in sentences) {
            val formatted = if (sentence.endsWith("।") || sentence.endsWith("?") || sentence.endsWith("!")) {
                sentence
            } else {
                "$sentence।"
            }
            if (current.length > 0 && current.length + formatted.length + 1 > maxCharsPerBatch) {
                batches.add(current.toString().trim())
                current.setLength(0)
            }
            if (current.length > 0) current.append(" ")
            current.append(formatted)
        }
        if (current.length > 0) {
            batches.add(current.toString().trim())
        }
        return batches
    }

    private data class WavMeta(
        val sampleRate: Int,
        val channels: Int,
        val dataOffset: Int,
        val dataSize: Int
    )

    private fun readWavMeta(file: File): WavMeta? {
        if (!file.exists() || file.length() < 44L) return null
        return try {
            RandomAccessFile(file, "r").use { raf ->
                val headerSize = min(4096, file.length().toInt())
                val buf = ByteArray(headerSize)
                raf.readFully(buf)
                val riff = String(buf, 0, 4, Charsets.US_ASCII)
                val wave = String(buf, 8, 4, Charsets.US_ASCII)
                if (riff != "RIFF" || wave != "WAVE") return null

                val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
                var pos = 12
                var channels = 1
                var sampleRate = 22050
                var bitsPerSample = 16
                while (pos + 8 <= buf.size) {
                    val chunkId = String(buf, pos, 4, Charsets.US_ASCII)
                    val chunkSize = bb.getInt(pos + 4)
                    if (chunkSize < 0) return null
                    if (chunkId == "fmt " && pos + 8 + 16 <= buf.size) {
                        channels = bb.getShort(pos + 10).toInt()
                        sampleRate = bb.getInt(pos + 12)
                        bitsPerSample = bb.getShort(pos + 22).toInt()
                    } else if (chunkId == "data") {
                        if (channels !in 1..2 || sampleRate <= 0 || bitsPerSample != 16) return null
                        val maxAvailable = (file.length() - (pos + 8)).toInt().coerceAtLeast(0)
                        return WavMeta(sampleRate, channels, pos + 8, min(chunkSize, maxAvailable))
                    }
                    pos += 8 + chunkSize + (chunkSize and 1)
                }
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Merges TTS batches cleanly in streaming memory and applies Human Male Acoustic Mastering
     * so all 3 speaker presets sound natural, warm, chest-resonant, and distinctly human (not metallic AI).
     */
    private fun mergeAndMasterWavParts(
        parts: List<File>,
        outputWavFile: File,
        preset: IslamicVoicePreset,
        interChunkPauseMs: Long
    ): Boolean {
        val firstMeta = readWavMeta(parts.first()) ?: return false
        val sampleRate = firstMeta.sampleRate
        val channels = firstMeta.channels
        val bytesPerFrame = channels * 2

        val compatibleParts = parts.mapNotNull { f ->
            val meta = readWavMeta(f)
            if (meta != null && meta.sampleRate == sampleRate && meta.channels == channels && meta.dataSize > 0) {
                f to meta
            } else null
        }
        if (compatibleParts.isEmpty()) return false

        // 3 genuinely distinct acoustic profiles:
        // 1) MAULANA_UBAIDA: warm studio waaz + silky 28ms warmth + subtle human chest bloom
        // 2) QARI_ABDULLAH: deep baritone + fuller bass warmth + 48ms majestic mahfil hall presence
        // 3) HAFIZ_RAYHAN: crisp natural human dialogue + ultra-clean dry clarity
        val lpfAlpha = when (preset) {
            IslamicVoicePreset.MAULANA_UBAIDA -> 0.64f
            IslamicVoicePreset.QARI_ABDULLAH -> 0.52f
            IslamicVoicePreset.HAFIZ_RAYHAN -> 0.78f
        }
        val bassBoost = when (preset) {
            IslamicVoicePreset.MAULANA_UBAIDA -> 0.22f
            IslamicVoicePreset.QARI_ABDULLAH -> 0.36f
            IslamicVoicePreset.HAFIZ_RAYHAN -> 0.12f
        }
        val reverbDelaySamples = when (preset) {
            IslamicVoicePreset.MAULANA_UBAIDA -> ((sampleRate * 0.028f).toInt() * channels).coerceAtLeast(1)
            IslamicVoicePreset.QARI_ABDULLAH -> ((sampleRate * 0.048f).toInt() * channels).coerceAtLeast(1)
            IslamicVoicePreset.HAFIZ_RAYHAN -> 1
        }
        val reverbMix = when (preset) {
            IslamicVoicePreset.MAULANA_UBAIDA -> 0.13f
            IslamicVoicePreset.QARI_ABDULLAH -> 0.21f
            IslamicVoicePreset.HAFIZ_RAYHAN -> 0.0f
        }

        val delayRing = FloatArray(reverbDelaySamples)
        var ringPos = 0
        val prevLp = FloatArray(channels)
        val prevBass = FloatArray(channels)

        val pauseFrames = ((sampleRate * interChunkPauseMs) / 1000L).toInt().coerceAtLeast(0)
        val pauseBuffer = ByteArray(pauseFrames * bytesPerFrame)
        val ioBuffer = ByteArray(8192 - (8192 % bytesPerFrame))
        var totalPcmBytesWritten = 0L

        BufferedOutputStream(FileOutputStream(outputWavFile), 32_768).use { out ->
            // Write placeholder 44-byte RIFF/WAV header
            out.write(buildWavHeader(sampleRate, channels, 0))

            compatibleParts.forEachIndexed { idx, (file, meta) ->
                BufferedInputStream(FileInputStream(file), 16_384).use { input ->
                    var skipped = 0L
                    while (skipped < meta.dataOffset) {
                        val s = input.skip(meta.dataOffset - skipped)
                        if (s <= 0) break
                        skipped += s
                    }
                    var remaining = meta.dataSize
                    while (remaining > 0) {
                        val toRead = min(ioBuffer.size, remaining)
                        val alignedToRead = toRead - (toRead % bytesPerFrame)
                        if (alignedToRead <= 0) break
                        val n = input.read(ioBuffer, 0, alignedToRead)
                        if (n <= 0) break
                        val validBytes = n - (n % bytesPerFrame)
                        if (validBytes > 0) {
                            processPcmBlockInPlace(
                                bytes = ioBuffer,
                                length = validBytes,
                                channels = channels,
                                lpfAlpha = lpfAlpha,
                                bassBoost = bassBoost,
                                reverbMix = reverbMix,
                                delayRing = delayRing,
                                ringPosRef = intArrayOf(ringPos),
                                prevLp = prevLp,
                                prevBass = prevBass
                            ).also { newRingPos -> ringPos = newRingPos }
                            out.write(ioBuffer, 0, validBytes)
                            totalPcmBytesWritten += validBytes
                        }
                        remaining -= validBytes
                    }
                }
                if (idx < compatibleParts.lastIndex && pauseBuffer.isNotEmpty()) {
                    out.write(pauseBuffer)
                    totalPcmBytesWritten += pauseBuffer.size
                }
            }
        }

        if (totalPcmBytesWritten <= 0L) return false
        val clampedSize = totalPcmBytesWritten.coerceAtMost(Int.MAX_VALUE.toLong() - 64L).toInt()
        RandomAccessFile(outputWavFile, "rw").use { raf ->
            raf.seek(0L)
            raf.write(buildWavHeader(sampleRate, channels, clampedSize))
        }
        return true
    }

    private fun processPcmBlockInPlace(
        bytes: ByteArray,
        length: Int,
        channels: Int,
        lpfAlpha: Float,
        bassBoost: Float,
        reverbMix: Float,
        delayRing: FloatArray,
        ringPosRef: IntArray,
        prevLp: FloatArray,
        prevBass: FloatArray
    ): Int {
        var ringIdx = ringPosRef[0]
        val ringLen = delayRing.size
        var i = 0
        var ch = 0
        while (i + 1 < length) {
            val lo = bytes[i].toInt() and 0xFF
            val hi = bytes[i + 1].toInt()
            val sampleInt = (hi shl 8) or lo
            val x = sampleInt / 32768.0f

            // Remove tinny metallic robotic edge via smooth 1-pole vocal LPF
            val smoothed = prevLp[ch] + lpfAlpha * (x - prevLp[ch])
            prevLp[ch] = smoothed

            // Gentle chest/baritone warmth shelf around ~180Hz
            val lowBand = prevBass[ch] + 0.045f * (smoothed - prevBass[ch])
            prevBass[ch] = lowBand
            val warm = smoothed + lowBand * bassBoost

            // Optional natural studio / mahfil room reflection
            val shaped = if (reverbMix > 0.001f && ringLen > 1) {
                val delayed = delayRing[ringIdx]
                val wet = warm + delayed * reverbMix
                delayRing[ringIdx] = (warm + delayed * 0.25f).coerceIn(-0.98f, 0.98f)
                ringIdx = (ringIdx + 1) % ringLen
                wet
            } else {
                warm
            }

            // Soft natural analog saturation/limiter to prevent harsh clipping
            val normalized = tanh((shaped * 1.12f).toDouble()).toFloat()
            val outSample = (normalized * 32760.0f).toInt().coerceIn(-32767, 32767)
            bytes[i] = (outSample and 0xFF).toByte()
            bytes[i + 1] = ((outSample ushr 8) and 0xFF).toByte()

            ch = (ch + 1) % channels
            i += 2
        }
        return ringIdx
    }

    private fun buildWavHeader(sampleRate: Int, channels: Int, dataSize: Int): ByteArray {
        val byteRate = sampleRate * channels * 2
        val blockAlign = (channels * 2).toShort()
        val chunkSize = 36 + dataSize
        return ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray(Charsets.US_ASCII))
            putInt(chunkSize)
            put("WAVE".toByteArray(Charsets.US_ASCII))
            put("fmt ".toByteArray(Charsets.US_ASCII))
            putInt(16) // PCM subchunk size
            putShort(1.toShort()) // AudioFormat = 1 (PCM)
            putShort(channels.toShort())
            putInt(sampleRate)
            putInt(byteRate)
            putShort(blockAlign)
            putShort(16.toShort()) // BitsPerSample
            put("data".toByteArray(Charsets.US_ASCII))
            putInt(dataSize)
        }.array()
    }

    fun speak(text: String, onFinished: (() -> Unit)? = null) {
        val cleaned = cleanNarrationForSpeech(text)
        if (!isTtsReady || cleaned.isBlank()) {
            onFinished?.invoke()
            return
        }
        mainHandler.post {
            applyVoiceSettingsInternal(activeSettings)
            val sentences = splitIntoNaturalSentences(cleaned)
            if (sentences.isEmpty()) {
                onFinished?.invoke()
                return@post
            }

            speechFinishedCallback = onFinished
            _voiceState.value = VoiceState.Speaking(cleaned)

            val pauseMs = activeSettings.voicePreset.sentencePauseMs.coerceIn(220L, 700L)
            val finalId = "spk_end_${UUID.randomUUID()}"
            activeFinalUtteranceId = finalId

            sentences.forEachIndexed { idx, sentence ->
                val isFirst = idx == 0
                val isLast = idx == sentences.lastIndex
                val queueMode = if (isFirst) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
                val uid = if (isLast) finalId else "spk_${idx}_${UUID.randomUUID()}"
                textToSpeech?.speak(sentence, queueMode, null, uid)
                if (!isLast) {
                    textToSpeech?.playSilentUtterance(pauseMs, TextToSpeech.QUEUE_ADD, "pause_${idx}_${UUID.randomUUID()}")
                }
            }
        }
    }

    private fun splitIntoNaturalSentences(cleaned: String): List<String> {
        return cleaned
            .split(Regex("[।!?\\n]+"))
            .map { it.trim() }
            .filter { it.length >= 2 }
    }

    fun stopSpeaking() {
        mainHandler.post {
            activeFinalUtteranceId = null
            speechFinishedCallback = null
            textToSpeech?.stop()
            if (_voiceState.value is VoiceState.Speaking) {
                _voiceState.value = VoiceState.Idle
            }
        }
    }

    fun setProcessing() {
        _voiceState.value = VoiceState.Processing
    }

    fun setIdle() {
        _voiceState.value = VoiceState.Idle
    }

    fun release() {
        pendingSynthesis.values.forEach { it.complete(false) }
        pendingSynthesis.clear()
        mainHandler.post {
            activeFinalUtteranceId = null
            speechFinishedCallback = null
            speechRecognizer?.destroy()
            speechRecognizer = null
            textToSpeech?.stop()
            textToSpeech?.shutdown()
            textToSpeech = null
        }
    }

    companion object {
        private val STRUCTURAL_LABELS = listOf(
            "বিসমিল্লাহ ও সূচনা",
            "কুরআনের বাণী",
            "সহীহ হাদিসের শিক্ষা",
            "বাস্তব শিক্ষা ও আমল",
            "মূল আলোচনা",
            "উপসংহার",
            "সমাপ্তি",
            "ভূমিকা",
            "সূচনা",
            "ইনট্রো",
            "আউট্রো",
            "Intro",
            "Outro",
            "Conclusion",
            "Introduction"
        )

        /**
         * ভয়েসওভার ও কথাবার্তা থেকে টাইমকোড (00:10, ০০:১০, ০০৭০), ব্র্যাকেট লেবেল ([...]),
         * এবং 'ভূমিকা / সূচনা / সমাপ্তি' জাতীয় হেডিং সম্পূর্ণ বাদ দেয় যাতে বক্তার মতো মধুর শোনায়।
         */
        fun cleanNarrationForSpeech(rawText: String): String {
            if (rawText.isBlank()) return ""
            val cleaned = rawText
                // Remove [ ... ] blocks even across newlines
                .replace(Regex("\\[[\\s\\S]*?\\]"), "\n")
                // Remove timecodes with colons or hyphens (Bengali & English digits)
                .replace(
                    Regex("[0-9০-৯]{1,2}\\s*[:：.]\\s*[0-9০-৯]{2}(?:\\s*[:：.]\\s*[0-9০-৯]{2})?(?:\\s*(?:-|–|—|থেকে|to)\\s*[0-9০-৯]{1,2}\\s*[:：.]\\s*[0-9০-৯]{2}(?:\\s*[:：.]\\s*[0-9০-৯]{2})?)?"),
                    " "
                )
                // Remove standalone 4-digit timecode runs like 0010, ০০৩০, ০০৫০, ০০৭০
                .replace(Regex("(?:^|\\s)[0০]{2}[0-9০-৯]{2}(?:\\s*(?:-|–|—|থেকে|to)\\s*[0০]{2}[0-9০-৯]{2})?(?=\\s|$|[.,।|])"), " ")
                // Remove Arabic Unicode blocks so Bengali TTS reads smoothly
                .replace(Regex("[\\u0600-\\u06FF\\u0750-\\u077F\\uFB50-\\uFDFF\\uFE70-\\uFEFF]+"), " ")
                // Remove markdown symbols & emojis
                .replace(Regex("[*_#`~|]+"), " ")
                .replace(Regex("[📖📜📚🎬✅⚠️•👉🔊]+"), " ")

            val processedLines = cleaned.lines().mapNotNull { rawLine ->
                var line = rawLine.trim()
                if (line.isBlank()) return@mapNotNull null

                line = line.replace(Regex("^(?:স্লাইড|দৃশ্য|অংশ|ধাপ|পর্ব|Scene|Slide|Part)\\s*[0-9০-৯]+\\s*[:：\\-|—]*\\s*", RegexOption.IGNORE_CASE), "").trim()

                for (label in STRUCTURAL_LABELS) {
                    if (line.equals(label, ignoreCase = true)) {
                        line = ""
                        break
                    }
                    val prefixRegex = Regex("^${Regex.escape(label)}\\s*[:：\\-|—।]*\\s*", RegexOption.IGNORE_CASE)
                    line = line.replace(prefixRegex, "").trim()
                }

                line.takeIf { it.isNotBlank() }
            }

            return processedLines
                .joinToString("\n")
                .replace(Regex("[ \\t]+"), " ")
                .replace(Regex("\\n{2,}"), "\n")
                .trim()
        }
    }
}
