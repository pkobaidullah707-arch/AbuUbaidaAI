package com.abuubaida.ai.data.model

import java.util.UUID

enum class Screen(val route: String, val titleBn: String) {
    Home("home", "হোম"),
    VoiceAssistant("voice_assistant", "ভয়েস অ্যাসিস্ট্যান্ট"),
    AiChat("ai_chat", "AI চ্যাট"),
    TrendResearch("trend_research", "ট্রেন্ড রিসার্চ"),
    VideoStudio("video_studio", "ভিডিও স্টুডিও"),
    YouTubeStudio("youtube_studio", "YouTube স্টুডিও"),
    FacebookStudio("facebook_studio", "Facebook স্টুডিও"),
    PhoneControl("phone_control", "ফোন কন্ট্রোল"),
    Sms("sms", "SMS"),
    PermissionsPrivacy("permissions_privacy", "গোপনীয়তা ও কন্ট্রোল"),
    Settings("settings", "সেটিংস")
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val isUser: Boolean,
    val timestampMillis: Long = System.currentTimeMillis()
)

data class ContactItem(
    val id: String,
    val name: String,
    val phoneNumber: String
)

data class InstalledAppInfo(
    val packageName: String,
    val appName: String
)

enum class YouTubeVisibility(val apiValue: String, val labelBn: String) {
    PRIVATE("private", "প্রাইভেট (শুধু আপনি)"),
    UNLISTED("unlisted", "আনলিস্টেড (লিংকযুক্ত)"),
    PUBLIC("public", "পাবলিক (সবার জন্য)")
}

enum class IslamicCategory(val labelBn: String, val defaultFormat: VideoFormat) {
    QURAN_RECITATION("কোরআন তেলাওয়াত ও অর্থ", VideoFormat.SHORTS_9_16),
    SURAH_EXPLANATION("সূরা তাফসীর ও ব্যাখ্যা", VideoFormat.LONG_16_9),
    ISLAMIC_EDUCATION("ইসলামিক শিক্ষা", VideoFormat.LONG_16_9),
    PROPHET_STORIES("নবীদের কাহিনী", VideoFormat.LONG_16_9),
    ISLAMIC_HISTORY("ইসলামের ইতিহাস", VideoFormat.LONG_16_9),
    ISLAMIC_REMINDER("ইসলামিক রিমাইন্ডার", VideoFormat.SHORTS_9_16),
    HADITH_EDUCATION("হাদিস শিক্ষা", VideoFormat.SHORTS_9_16),
    NAMES_OF_ALLAH("আল্লাহর ৯৯ নাম", VideoFormat.SHORTS_9_16),
    ISLAMIC_SHORTS("ইসলামিক শর্টস (Shorts)", VideoFormat.SHORTS_9_16),
    LONG_DOCUMENTARY("বিস্তারিত ডকুমেন্টারি", VideoFormat.LONG_16_9)
}

enum class VideoFormat(val labelBn: String, val width: Int, val height: Int) {
    SHORTS_9_16("Shorts / Reels Full HD (9:16)", 1080, 1920),
    LONG_16_9("হলিউড Full HD সিনেমাটিক (16:9)", 1920, 1080)
}

enum class VideoDurationOption(
    val labelBn: String,
    val durationSeconds: Int,
    val slideCount: Int
) {
    SHORT_1M("১ মিনিট (Shorts)", 60, 8),
    MEDIUM_5M("৫ মিনিট", 300, 12),
    LONG_10M("১০ মিনিট (লং ওয়াজ)", 600, 16),
    LONG_20M("২০ মিনিট (বিস্তারিত)", 1200, 20)
}

enum class IslamicVoicePreset(
    val labelBn: String,
    val descBn: String,
    val pitch: Float,
    val rate: Float,
    val sentencePauseMs: Long,
    val voiceSlot: Int
) {
    MAULANA_UBAIDA(
        labelBn = "১. মাওলানা উবাইদা (দরদী ওয়াজ কণ্ঠ)",
        descBn = "মিষ্টি, দরদী ও হৃদয়ছোঁয়া মানুষের স্বাভাবিক ওয়াজ কণ্ঠ",
        pitch = 0.87f,
        rate = 0.85f,
        sentencePauseMs = 450L,
        voiceSlot = 0
    ),
    QARI_ABDULLAH(
        labelBn = "২. কারী আব্দুল্লাহ (গম্ভীর ও ভরাট কণ্ঠ)",
        descBn = "গভীর, ভরাট ও প্রাজ্ঞ মাহফিল বক্তার পুরুষ কণ্ঠ",
        pitch = 0.76f,
        rate = 0.79f,
        sentencePauseMs = 520L,
        voiceSlot = 1
    ),
    HAFIZ_RAYHAN(
        labelBn = "৩. হাফেজ রায়হান (স্পষ্ট ও স্বাভাবিক কণ্ঠ)",
        descBn = "প্রাণবন্ত, সহজ ও ১০০% মানুষের মতো স্বাভাবিক পুরুষ কণ্ঠ",
        pitch = 0.95f,
        rate = 0.93f,
        sentencePauseMs = 310L,
        voiceSlot = 2
    )
}

data class TtsVoiceOption(
    val name: String,
    val labelBn: String,
    val localeTag: String
)

enum class PublishingMode(val labelBn: String, val descBn: String) {
    ASK_BEFORE_PUBLISHING("আপলোডের আগে জিজ্ঞাসা করুন", "প্রতিটি প্রকাশের আগে নিশ্চিতকরণ ডায়ালগ দেখাবে"),
    PUBLISH_IMMEDIATELY("তাৎক্ষণিক প্রকাশ (Auto ON হলে)", "অনুমতি সক্রিয় থাকলে সাথে সাথে আপলোড করবে"),
    SCHEDULE_AUTOMATICALLY("স্মার্ট সময়ে শিডিউল করুন", "উপযুক্ত সেরা সময়ে স্বয়ংক্রিয়ভাবে শিডিউল করবে"),
    SAVE_AS_DRAFT("ড্রাফট হিসেবে সংরক্ষণ করুন", "পাবলিক না করে প্রাইভেট/ড্রাফট হিসেবে রাখবে")
}

data class QuranReference(
    val surahNumber: Int = 0,
    val ayahNumber: Int = 0,
    val surahNameBn: String = "",
    val surahNameArabic: String = "",
    val arabicUthmaniText: String = "",
    val bengaliTranslation: String = "",
    val sourceApiBn: String = "",
    val audioUrl: String = "",
    val verified: Boolean = false
)

data class HadithReference(
    val collectionBn: String = "",
    val referenceNumber: String = "",
    val narratorBn: String = "",
    val arabicText: String = "",
    val bengaliText: String = "",
    val gradingNoteBn: String = "",
    val verifiedAuthentic: Boolean = false
)

data class IslamicContentReview(
    val passed: Boolean = true,
    val sourceCitationBn: String = "",
    val warningsBn: List<String> = emptyList(),
    val reviewedAtMillis: Long = System.currentTimeMillis()
)

data class VideoProject(
    val topic: String = "",
    val category: IslamicCategory = IslamicCategory.ISLAMIC_EDUCATION,
    val format: VideoFormat = VideoFormat.LONG_16_9,
    val durationOption: VideoDurationOption = VideoDurationOption.LONG_10M,
    val script: String = "",
    val subtitleLines: List<String> = emptyList(),
    val seoTitle: String = "",
    val englishTitle: String = "",
    val seoDescription: String = "",
    val seoKeywords: List<String> = emptyList(),
    val seoTags: List<String> = emptyList(),
    val hashtags: List<String> = emptyList(),
    val thumbnailText: String = "",
    val thumbnailDesignSummary: String = "",
    val thumbnailPrompts: List<String> = emptyList(),
    val categoryLabel: String = "Education",
    val videoLanguage: String = "bn",
    val quranReference: QuranReference? = null,
    val hadithReference: HadithReference? = null,
    val accuracyReview: IslamicContentReview = IslamicContentReview(),
    val voiceoverWavPath: String = "",
    val thumbnailPngUriString: String = "",
    val thumbnailLocalPath: String = "",
    val renderedMp4UriString: String = "",
    val savedMp4DisplayPath: String = "",
    val audioRightsNoteBn: String = "কোনো কপিরাইটযুক্ত মিউজিক যুক্ত করা হয়নি; সম্পূর্ণ বৈধ ও কপিরাইটমুক্ত অডিও নীতি অনুসরণ করা হয়েছে।",
    val recommendedPublishMillis: Long? = null,
    val recommendedPublishLabelBn: String = "",
    val providerStatusBn: String = "অন-ডিভাইস ইসলামিক ভিডিও ও কন্টেন্ট স্টুডিও প্রস্তুত।"
)

data class YouTubeAccountInfo(
    val channelName: String = "",
    val channelUrl: String = "",
    val hasOAuthToken: Boolean = false
) {
    val isConnected: Boolean
        get() = hasOAuthToken || channelName.isNotBlank() || channelUrl.isNotBlank()
}

data class YouTubeUploadRequest(
    val videoUriString: String = "",
    val videoDisplayName: String = "",
    val thumbnailLocalPath: String = "",
    val title: String = "",
    val description: String = "",
    val tags: List<String> = emptyList(),
    val visibility: YouTubeVisibility = YouTubeVisibility.PRIVATE,
    val scheduledPublishIsoUtc: String = "",
    val scheduledLabelBn: String = "",
    val lastUploadedVideoId: String = "",
    val lastStatusReportBn: String = ""
)

enum class FacebookPublishState(val labelBn: String) {
    PUBLISH_NOW("এখনই পেজে প্রকাশ করুন"),
    SCHEDULE("নির্ধারিত সময়ে শিডিউল করুন"),
    DRAFT("ড্রাফট / অপ্রকাশিত রাখুন")
}

data class FacebookUploadRequest(
    val videoUriString: String = "",
    val videoDisplayName: String = "",
    val title: String = "",
    val caption: String = "",
    val hashtags: List<String> = emptyList(),
    val isReel: Boolean = false,
    val publishState: FacebookPublishState = FacebookPublishState.DRAFT,
    val scheduledUnixSeconds: Long? = null,
    val scheduledLabelBn: String = "",
    val lastPublishedVideoId: String = "",
    val lastStatusReportBn: String = ""
)

data class FacebookAccountInfo(
    val pageId: String = "",
    val pageName: String = "",
    val pageUrl: String = "",
    val followersCount: Long = -1L,
    val hasAccessToken: Boolean = false
) {
    val isConnected: Boolean
        get() = hasAccessToken || pageId.isNotBlank() || pageName.isNotBlank() || pageUrl.isNotBlank()
}

data class TrendItem(
    val topic: String,
    val sourceBn: String,
    val suggestedCategory: IslamicCategory,
    val recommendedFormat: VideoFormat,
    val reasonBn: String
)

data class ChannelPerformanceSummary(
    val channelTitle: String = "",
    val subscriberCount: Long = -1L,
    val totalVideoCount: Long = -1L,
    val recentVideosAnalyzed: Int = 0,
    val avgRecentViews: Long = 0L,
    val bestPerformingFormatBn: String = "পর্যাপ্ত চ্যানেল ডেটা নেই",
    val bestHistoricalHour24: Int? = null,
    val noteBn: String = ""
)

data class TrendResearchReport(
    val generatedAtMillis: Long = System.currentTimeMillis(),
    val trends: List<TrendItem> = emptyList(),
    val channelSummary: ChannelPerformanceSummary? = null,
    val facebookInsightsNoteBn: String = "",
    val recommendedFormat: VideoFormat = VideoFormat.SHORTS_9_16,
    val recommendedPublishTimeBn: String = "",
    val recommendedPublishMillis: Long = System.currentTimeMillis(),
    val dataSourcesStatusBn: List<String> = emptyList()
)

data class PublishingRecommendation(
    val targetTimeMillis: Long,
    val targetTimeLabelBn: String,
    val targetIsoUtc: String,
    val targetUnixSeconds: Long,
    val recommendedFormat: VideoFormat,
    val qualityScore: Int,
    val reasonBn: String
)

data class MasterControlSettings(
    val aiAssistantEnabled: Boolean = true,
    val contentCreationEnabled: Boolean = true,
    val autoUploadEnabled: Boolean = false,
    val youTubeConnectionEnabled: Boolean = true,
    val facebookConnectionEnabled: Boolean = true,
    val trendResearchEnabled: Boolean = true,
    val publishingMode: PublishingMode = PublishingMode.ASK_BEFORE_PUBLISHING
)

data class AssistantSettings(
    val wakePhrase: String = "হ্যালো আবু উবাইদা",
    val ttsEnabled: Boolean = true,
    val continuousVoiceMode: Boolean = false,
    val backgroundServiceEnabled: Boolean = false,
    val proxyEndpointUrl: String = "",
    val speechLanguageTag: String = "bn-BD",
    val voicePreset: IslamicVoicePreset = IslamicVoicePreset.MAULANA_UBAIDA,
    val voicePitch: Float = IslamicVoicePreset.MAULANA_UBAIDA.pitch,
    val voiceRate: Float = IslamicVoicePreset.MAULANA_UBAIDA.rate,
    val selectedTtsVoiceName: String = "",
    val includeVoiceoverInVideo: Boolean = true,
    val autoSaveMp4ToPhone: Boolean = true,
    val motionGraphicsEnabled: Boolean = true
)

sealed class VoiceState {
    data object Idle : VoiceState()
    data object Listening : VoiceState()
    data object Processing : VoiceState()
    data class Speaking(val text: String) : VoiceState()
    data class Error(val messageBn: String) : VoiceState()
}

sealed class PendingSensitiveAction {
    data class CallPhone(
        val displayName: String,
        val phoneNumber: String,
        val directCall: Boolean,
        val alternateMatches: List<ContactItem> = emptyList()
    ) : PendingSensitiveAction()
    data class SendSms(val recipientName: String, val phoneNumber: String, val message: String, val useDirectApi: Boolean) : PendingSensitiveAction()
    data class PublishYouTube(val request: YouTubeUploadRequest) : PendingSensitiveAction()
    data class PublishFacebook(val request: FacebookUploadRequest) : PendingSensitiveAction()
}

enum class VolumeCommand {
    UP,
    DOWN,
    MUTE,
    NORMAL,
    MAX
}

sealed class AssistantIntentCommand {
    data class CallContact(val target: String) : AssistantIntentCommand()
    data class ComposeSms(val target: String, val body: String) : AssistantIntentCommand()
    data class OpenApp(val appName: String) : AssistantIntentCommand()
    data class SetAlarm(val hour: Int, val minute: Int, val label: String) : AssistantIntentCommand()
    data class SetTimer(val seconds: Int, val label: String) : AssistantIntentCommand()
    data class OpenSettings(val settingsAction: String, val labelBn: String) : AssistantIntentCommand()
    data class ToggleFlashlight(val enable: Boolean) : AssistantIntentCommand()
    data class ControlVolume(val command: VolumeCommand) : AssistantIntentCommand()
    data class SearchYouTube(val query: String) : AssistantIntentCommand()
    data class SearchGoogle(val query: String) : AssistantIntentCommand()
    data class NavigateScreen(val screen: Screen) : AssistantIntentCommand()
    data class CreateVideoScript(
        val topic: String,
        val category: IslamicCategory = IslamicCategory.ISLAMIC_EDUCATION,
        val useTrends: Boolean = false,
        val durationOption: VideoDurationOption? = null
    ) : AssistantIntentCommand()
    data class RunAutonomousDailyWorkflow(
        val uploadToYouTube: Boolean = true,
        val uploadToFacebook: Boolean = false,
        val scheduleForTomorrow: Boolean = false,
        val customTopic: String = "",
        val durationOption: VideoDurationOption? = null
    ) : AssistantIntentCommand()
    data object ResearchIslamicTrends : AssistantIntentCommand()
    data object PublishCurrentToYouTube : AssistantIntentCommand()
    data object PublishCurrentToFacebook : AssistantIntentCommand()
    data class DirectAnswer(val replyBn: String) : AssistantIntentCommand()
    data object QueryTime : AssistantIntentCommand()
    data object QueryDate : AssistantIntentCommand()
    data object QueryBattery : AssistantIntentCommand()
    data object None : AssistantIntentCommand()
}
