package com.abuubaida.ai.islamic

import com.abuubaida.ai.data.model.HadithReference
import com.abuubaida.ai.data.model.IslamicCategory
import com.abuubaida.ai.data.model.IslamicContentReview
import com.abuubaida.ai.data.model.QuranReference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * বহিরাগত টেক্সট (যেমন ভিডিও বর্ণনা, কমেন্ট বা সার্চ ফলাফল) থেকে অনিরাপদ কমান্ড বা প্রম্পট ইনজেকশন ফিল্টার করে।
 */
object ContentSafetyGuard {
    private val suspiciousCommandMarkers = listOf(
        "ignore previous instructions",
        "ignore all instructions",
        "system:",
        "assistant:",
        "তুমি এখন",
        "কল করো",
        "মেসেজ পাঠাও",
        "ডিলিট করো"
    )

    fun sanitizeExternalText(raw: String, maxLength: Int = 180): String {
        var cleaned = raw
            .replace(Regex("[\\r\\n\\t]+"), " ")
            .replace(Regex("<[^>]*>"), " ")
            .trim()
        for (marker in suspiciousCommandMarkers) {
            cleaned = cleaned.replace(marker, "", ignoreCase = true)
        }
        return cleaned.replace(Regex("\\s+"), " ").take(maxLength).trim()
    }
}

class IslamicKnowledgeRepository {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    data class VerifiedTopicBundle(
        val resolvedTopic: String,
        val quranRef: QuranReference?,
        val hadithRef: HadithReference?,
        val historicalContextBn: String,
        val verificationNoteBn: String
    )

    /**
     * আল-কুরআন ক্লাউড পাবলিক HTTPS API (https://api.alquran.cloud) থেকে ১০০% যাচাইকৃত আরবি উসমানি পাঠ,
     * নির্ভরযোগ্য বাংলা অনুবাদ এবং শায়েখ মিশারী রশিদ আল-আফাসীর (ar.alafasy) আসল তেলাওয়াত অডিও আনে।
     * কখনো নিজ থেকে কোনো আয়াত বা হাদিস বানানো বা বিকৃত করা হয় না।
     */
    suspend fun fetchVerifiedAyah(surahNumber: Int, ayahNumber: Int): QuranReference? =
        fetchVerifiedAyahRange(surahNumber, ayahNumber, ayahNumber)

    suspend fun fetchVerifiedAyahRange(
        surahNumber: Int,
        startAyah: Int,
        endAyah: Int
    ): QuranReference? = withContext(Dispatchers.IO) {
        if (surahNumber !in 1..114 || startAyah < 1 || endAyah < startAyah) return@withContext null
        val boundedEnd = endAyah.coerceAtMost(startAyah + 6)
        val arabicParts = mutableListOf<String>()
        val bengaliParts = mutableListOf<String>()
        var surahNameEn = ""
        var surahNameAr = ""
        var firstAudioUrl = ""

        try {
            for (ayah in startAyah..boundedEnd) {
                val url = "https://api.alquran.cloud/v1/ayah/${surahNumber}:${ayah}/editions/quran-uthmani,bn.bengali,ar.alafasy"
                val request = Request.Builder().url(url).get().build()
                val fetched = httpClient.newCall(request).execute().use { resp ->
                    if (!resp.isSuccessful) return@use false
                    val body = resp.body?.string().orEmpty()
                    val root = JSONObject(body)
                    if (root.optInt("code") != 200) return@use false
                    val dataArr = root.optJSONArray("data") ?: return@use false
                    if (dataArr.length() < 2) return@use false

                    val arabicObj = dataArr.getJSONObject(0)
                    val bengaliObj = dataArr.getJSONObject(1)
                    val audioObj = if (dataArr.length() >= 3) dataArr.getJSONObject(2) else null

                    if (surahNameEn.isBlank()) {
                        val surahObj = arabicObj.optJSONObject("surah")
                        surahNameEn = surahObj?.optString("englishName").orEmpty()
                        surahNameAr = surahObj?.optString("name").orEmpty()
                    }
                    if (firstAudioUrl.isBlank()) {
                        val candidateAudio = audioObj?.optString("audio").orEmpty().trim()
                        if (candidateAudio.startsWith("https://")) {
                            firstAudioUrl = candidateAudio
                        } else if (candidateAudio.startsWith("http://")) {
                            firstAudioUrl = "https://" + candidateAudio.removePrefix("http://")
                        }
                    }

                    val ar = arabicObj.optString("text").trim()
                    val bn = bengaliObj.optString("text").trim()
                    if (ar.isBlank() || bn.isBlank()) return@use false
                    arabicParts.add(ar)
                    bengaliParts.add(bn)
                    true
                }
                if (!fetched) {
                    if (arabicParts.isEmpty()) return@withContext null
                    break
                }
            }

            if (arabicParts.isEmpty()) return@withContext null
            val ayahLabel = if (startAyah == boundedEnd) "$surahNumber:$startAyah" else "$surahNumber:$startAyah-$boundedEnd"
            QuranReference(
                surahNumber = surahNumber,
                ayahNumber = startAyah,
                surahNameBn = "${surahDisplayBn(surahNumber, surahNameEn)} ($ayahLabel)",
                surahNameArabic = surahNameAr,
                arabicUthmaniText = arabicParts.joinToString(" ۝ "),
                bengaliTranslation = bengaliParts.joinToString(" "),
                sourceApiBn = "AlQuran Cloud ১০০% যাচাইকৃত (quran-uthmani, bn.bengali ও শায়েখ আল-আফাসী তেলাওয়াত)",
                audioUrl = firstAudioUrl,
                verified = true
            )
        } catch (_: Exception) {
            null
        }
    }

    suspend fun prepareVerifiedBundle(
        topic: String,
        category: IslamicCategory
    ): VerifiedTopicBundle {
        val cleanTopic = topic.trim()
        val targetRange = detectSurahAyahRangeFromTopic(cleanTopic, category)
        val liveAyah = if (targetRange != null) {
            fetchVerifiedAyahRange(targetRange.first, targetRange.second, targetRange.third)
        } else {
            null
        }
        val quranRef = liveAyah ?: selectVerifiedFallbackAyah(cleanTopic, category)
        val hadithRef = selectVerifiedHadith(cleanTopic, category)

        val verificationNote = buildString {
            if (quranRef != null) {
                append("কুরআনের আয়াত ও তেলাওয়াত ১০০% যাচাইকৃত সূত্র (${quranRef.sourceApiBn}) থেকে গৃহীত—আরবি মূল পাঠ অপরিবর্তিত রাখা হয়েছে। ")
            }
            if (hadithRef != null) {
                append("হাদিসের সূত্র: ${hadithRef.collectionBn} (${hadithRef.referenceNumber}) — ${hadithRef.gradingNoteBn}।")
            }
            if (length == 0) {
                append("ইসলামিক শিক্ষামূলক সাধারণ আলোচনা; কুরআন ও সহীহ সুন্নাহর সাথে সামঞ্জস্যপূর্ণ।")
            }
        }

        val contextBn = when (category) {
            IslamicCategory.PROPHET_STORIES -> "কুরআন ও বিশুদ্ধ সিরাত গ্রন্থের আলোকে নবী-রাসূলদের (আ.) শিক্ষণীয় ঘটনা।"
            IslamicCategory.ISLAMIC_HISTORY -> "ইসলামের প্রাথমিক যুগ ও মুসলিম সভ্যতার নির্ভরযোগ্য ঐতিহাসিক শিক্ষা।"
            IslamicCategory.NAMES_OF_ALLAH -> "আল্লাহ তাআলার গুণবাচক নামসমূহ (আসমাউল হুসনা) এবং দৈনন্দিন আমল ও দোয়া।"
            else -> "কুরআন ও সহীহ হাদিসের আলোকে ১০০% নির্ভুল ও প্রাঞ্জল বাংলা ইসলামিক আলোচনা।"
        }

        return VerifiedTopicBundle(
            resolvedTopic = cleanTopic.ifBlank { defaultTopicForCategory(category) },
            quranRef = quranRef,
            hadithRef = hadithRef,
            historicalContextBn = contextBn,
            verificationNoteBn = verificationNote
        )
    }

    fun reviewReligiousContent(
        script: String,
        quranRef: QuranReference?,
        hadithRef: HadithReference?,
        category: IslamicCategory
    ): IslamicContentReview {
        val warnings = mutableListOf<String>()

        if (script.isBlank() || script.length < 40) {
            warnings.add("স্ক্রিপ্ট অত্যন্ত সংক্ষিপ্ত; প্রকাশের আগে পূর্ণাঙ্গ তথ্য যাচাই করুন।")
        }

        val containsArabicChars = script.any { it in '\u0600'..'\u06FF' }
        if (containsArabicChars && (quranRef == null || !quranRef.verified) && hadithRef?.verifiedAuthentic != true) {
            warnings.add("স্ক্রিপ্টে আরবি পাঠ রয়েছে কিন্তু যাচাইকৃত কুরআন/হাদিস সূত্র যুক্ত নেই; আরবি পাঠ মিলিয়ে নিন।")
        }

        if (category == IslamicCategory.HADITH_EDUCATION && (hadithRef == null || !hadithRef.verifiedAuthentic)) {
            warnings.add("হাদিস বিভাগে স্পষ্ট গ্রন্থ ও সহীহ/হাসান মান উল্লেখ থাকা বাধ্যতামূলক।")
        }

        if (quranRef != null && !quranRef.verified) {
            warnings.add("কুরআনের আয়াত অযাচাইকৃত অবস্থায় রয়েছে—সূরা ও আয়াত নম্বর পরীক্ষা করুন।")
        }

        val citation = buildList {
            if (quranRef != null) add("কুরআন: ${quranRef.surahNameBn} [${quranRef.sourceApiBn}]")
            if (hadithRef != null) add("হাদিস: ${hadithRef.collectionBn} (${hadithRef.referenceNumber})")
        }.joinToString(" | ").ifBlank { "সহীহ ইসলামিক নসীহত ও শিক্ষামূলক আলোচনা" }

        return IslamicContentReview(
            passed = warnings.isEmpty(),
            sourceCitationBn = citation,
            warningsBn = warnings
        )
    }

    private fun detectSurahAyahRangeFromTopic(topic: String, category: IslamicCategory): Triple<Int, Int, Int>? {
        val rangeMatch = Regex("(\\d{1,3})\\s*[:：]\\s*(\\d{1,3})\\s*[-–—]\\s*(\\d{1,3})").find(topic)
        if (rangeMatch != null) {
            val s = rangeMatch.groupValues[1].toIntOrNull()
            val a1 = rangeMatch.groupValues[2].toIntOrNull()
            val a2 = rangeMatch.groupValues[3].toIntOrNull()
            if (s != null && a1 != null && a2 != null && s in 1..114 && a1 >= 1 && a2 >= a1) {
                return Triple(s, a1, a2)
            }
        }
        val numMatch = Regex("(\\d{1,3})\\s*[:：]\\s*(\\d{1,3})").find(topic)
        if (numMatch != null) {
            val s = numMatch.groupValues[1].toIntOrNull()
            val a = numMatch.groupValues[2].toIntOrNull()
            if (s != null && a != null && s in 1..114 && a >= 1) return Triple(s, a, a)
        }

        val lower = topic.lowercase()
        return when {
            topic.contains("ফাতিহা") || lower.contains("fatiha") -> Triple(1, 1, 7)
            topic.contains("আয়াতুল কুরসি") || topic.contains("কুরসী") -> Triple(2, 255, 255)
            topic.contains("ইখলাস") || lower.contains("ikhlas") -> Triple(112, 1, 4)
            topic.contains("ফালাক") -> Triple(113, 1, 5)
            topic.contains("নাস") -> Triple(114, 1, 6)
            topic.contains("আসর") || lower.contains("asr") -> Triple(103, 1, 3)
            topic.contains("কাউসার") -> Triple(108, 1, 3)
            topic.contains("ইনশিরাহ") || topic.contains("কষ্টের পর") || topic.contains("ধৈর্য") || topic.contains("সবর") -> Triple(94, 5, 6)
            topic.contains("রহমান") || lower.contains("rahman") -> Triple(55, 13, 13)
            topic.contains("মুলক") || lower.contains("mulk") -> Triple(67, 2, 2)
            topic.contains("তাওয়াক্কুল") || topic.contains("ভরসা") -> Triple(65, 3, 3)
            topic.contains("তাওবা") || topic.contains("তওবা") || topic.contains("ক্ষমা") -> Triple(39, 53, 53)
            topic.contains("নামাজ") || topic.contains("সলাত") -> Triple(29, 45, 45)
            topic.contains("মা-বাবা") || topic.contains("পিতামাতা") -> Triple(17, 23, 24)
            topic.contains("দুরুদ") || topic.contains("নবী") -> Triple(33, 56, 56)
            topic.contains("সদকা") || topic.contains("দান") -> Triple(2, 261, 261)
            category == IslamicCategory.QURAN_RECITATION || category == IslamicCategory.SURAH_EXPLANATION -> Triple(94, 5, 6)
            category == IslamicCategory.NAMES_OF_ALLAH -> Triple(59, 24, 24)
            else -> null
        }
    }

    private fun selectVerifiedFallbackAyah(topic: String, category: IslamicCategory): QuranReference? {
        return when {
            topic.contains("ফাতিহা") -> QuranReference(
                surahNumber = 1,
                ayahNumber = 1,
                surahNameBn = "সূরা আল-ফাতিহা (১:১-৭)",
                surahNameArabic = "سُورَةُ ٱلْفَاتِحَةِ",
                arabicUthmaniText = "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ ۝ ٱلْحَمْدُ لِلَّهِ رَبِّ ٱلْعَٰلَمِينَ ۝ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ ۝ مَٰلِكِ يَوْمِ ٱلدِّينِ ۝ إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ ۝ ٱهْدِنَا ٱلصِّرَٰطَ ٱلْمُسْتَقِيمَ ۝ صِرَٰطَ ٱلَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ ٱلْمَغْضُوبِ عَلَيْهِمْ وَلَا ٱلضَّآلِّينَ",
                bengaliTranslation = "পরম করুণাময় অসীম দয়ালু আল্লাহর নামে। সমস্ত প্রশংসা জগৎসমূহের প্রতিপালক আল্লাহর জন্য। যিনি পরম করুণাময়, অতি দয়ালু। বিচার দিনের মালিক। আমরা কেবল আপনারই ইবাদত করি এবং আপনারই সাহায্য চাই। আমাদেরকে সরল পথ প্রদর্শন করুন। সেই সমস্ত লোকের পথ, যাদেরকে আপনি অনুগ্রহ করেছেন; তাদের পথ নয়, যারা অভিশপ্ত ও পথভ্রষ্ট হয়েছে।",
                sourceApiBn = "যাচাইকৃত মুসহাফ উসমানি (সূরা ১, আয়াত ১-৭)",
                audioUrl = "https://cdn.islamic.network/quran/audio/128/ar.alafasy/1.mp3",
                verified = true
            )
            topic.contains("ধৈর্য") || topic.contains("কষ্ট") || topic.contains("সবর") || category == IslamicCategory.QURAN_RECITATION || category == IslamicCategory.SURAH_EXPLANATION ->
                QuranReference(
                    surahNumber = 94,
                    ayahNumber = 5,
                    surahNameBn = "সূরা আল-ইনশিরাহ (৯৪:৫-৬)",
                    surahNameArabic = "سُورَةُ الشَّرْحِ",
                    arabicUthmaniText = "فَإِنَّ مَعَ ٱلْعُسْرِ يُسْرًا ۝ إِنَّ مَعَ ٱلْعُسْرِ يُسْرًا",
                    bengaliTranslation = "অতএব, নিশ্চয়ই কষ্টের সাথেই রয়েছে স্বস্তি। নিশ্চয়ই কষ্টের সাথেই রয়েছে স্বস্তি।",
                    sourceApiBn = "যাচাইকৃত মুসহাফ উসমানি (সূরা ৯৪, আয়াত ৫-৬)",
                    audioUrl = "https://cdn.islamic.network/quran/audio/128/ar.alafasy/6095.mp3",
                    verified = true
                )
            topic.contains("তাওয়াক্কুল") || topic.contains("ভরসা") ->
                QuranReference(
                    surahNumber = 65,
                    ayahNumber = 3,
                    surahNameBn = "সূরা আত-তালাক (৬৫:৩)",
                    surahNameArabic = "سُورَةُ الطَّلَاقِ",
                    arabicUthmaniText = "وَيَرْزُقْهُ مِنْ حَيْثُ لَا يَحْتَسِبُ ۚ وَمَن يَتَوَكَّلْ عَلَى ٱللَّهِ فَهُوَ حَسْبُهُۥٓ ۚ إِنَّ ٱللَّهَ بَٰلِغُ أَمْرِهِۦ ۚ قَدْ جَعَلَ ٱللَّهُ لِكُلِّ شَىْءٍ قَدْرًا",
                    bengaliTranslation = "এবং তিনি তাকে এমন উৎস থেকে রিজিক দেবেন, যা সে কল্পনাও করতে পারবে না। আর যে আল্লাহর ওপর তাওয়াক্কুল করে, আল্লাহ তার জন্য যথেষ্ট। নিশ্চয়ই আল্লাহ তাঁর কাজ সম্পূর্ণ করবেন; আল্লাহ প্রতিটি জিনিসের জন্য একটি পরিমাণ নির্ধারণ করে দিয়েছেন।",
                    sourceApiBn = "যাচাইকৃত মুসহাফ উসমানি (সূরা ৬৫, আয়াত ৩)",
                    audioUrl = "https://cdn.islamic.network/quran/audio/128/ar.alafasy/5220.mp3",
                    verified = true
                )
            category == IslamicCategory.NAMES_OF_ALLAH || topic.contains("নাম") ->
                QuranReference(
                    surahNumber = 59,
                    ayahNumber = 24,
                    surahNameBn = "সূরা আল-হাশর (৫৯:২৪)",
                    surahNameArabic = "سُورَةُ الحَشْرِ",
                    arabicUthmaniText = "هُوَ ٱللَّهُ ٱلْخَٰلِقُ ٱلْبَارِئُ ٱلْمُصَوِّرُ ۖ لَهُ ٱلْأَسْمَآءُ ٱلْحُسْنَىٰ ۚ يُسَبِّحُ لَهُۥ مَا فِى ٱلسَّمَٰوَٰتِ وَٱلْأَرْضِ ۖ وَهُوَ ٱلْعَزِيزُ ٱلْحَكِيمُ",
                    bengaliTranslation = "তিনিই আল্লাহ—স্রষ্টা, উদ্ভাবক ও আকৃতিদাতা; সকল উত্তম নাম তাঁরই। আসমানসমূহ ও জমিনে যা কিছু আছে, সবই তাঁর পবিত্রতা ঘোষণা করে এবং তিনি পরাক্রমশালী, প্রজ্ঞাময়।",
                    sourceApiBn = "যাচাইকৃত মুসহাফ উসমানি (সূরা ৫৯, আয়াত ২৪)",
                    audioUrl = "https://cdn.islamic.network/quran/audio/128/ar.alafasy/5150.mp3",
                    verified = true
                )
            else ->
                QuranReference(
                    surahNumber = 103,
                    ayahNumber = 1,
                    surahNameBn = "সূরা আল-আসর (১০৩:১-৩)",
                    surahNameArabic = "سُورَةُ العَصْرِ",
                    arabicUthmaniText = "وَٱلْعَصْرِ ۝ إِنَّ ٱلْإِنسَٰنَ لَفِى خُسْرٍ ۝ إِلَّا ٱلَّذِينَ ءَامَنُوا۟ وَعَمِلُوا۟ ٱلصَّٰلِحَٰتِ وَتَوَاصَوْا۟ بِٱلْحَقِّ وَتَوَاصَوْا۟ بِٱلصَّبْرِ",
                    bengaliTranslation = "মহাকালের শপথ! নিশ্চয়ই সকল মানুষ ক্ষতির মধ্যে রয়েছে; তবে তারা ব্যতীত যারা ঈমান এনেছে, সৎকর্ম করেছে এবং পরস্পরকে সত্যের উপদেশ দিয়েছে ও পরস্পরকে ধৈর্যের উপদেশ দিয়েছে।",
                    sourceApiBn = "যাচাইকৃত মুসহাফ উসমানি (সূরা ১০৩, আয়াত ১-৩ সম্পূর্ণ)",
                    audioUrl = "https://cdn.islamic.network/quran/audio/128/ar.alafasy/6177.mp3",
                    verified = true
                )
        }
    }

    private fun selectVerifiedHadith(topic: String, category: IslamicCategory): HadithReference? {
        return when {
            topic.contains("রাগ") || topic.contains("ক্রোধ") ->
                HadithReference(
                    collectionBn = "সহীহ আল-বুখারী",
                    referenceNumber = "হাদিস নং ৬১১৬",
                    narratorBn = "হযরত আবু হুরায়রা (রা.)",
                    arabicText = "لَا تَغْضَبْ",
                    bengaliText = "এক ব্যক্তি নবী (সা.)-কে বলল, আমাকে উপদেশ দিন। তিনি বললেন: 'রাগ করো না।' লোকটি কয়েকবার একই কথা জিজ্ঞাসা করলে প্রত্যেকবারই তিনি বললেন: 'রাগ করো না।'",
                    gradingNoteBn = "সহীহ (সহীহ আল-বুখারী)",
                    verifiedAuthentic = true
                )
            topic.contains("অন্তর") || topic.contains("আমল") && topic.contains("চেহারা") ->
                HadithReference(
                    collectionBn = "সহীহ মুসলিম",
                    referenceNumber = "হাদিস নং ২৫৬৪",
                    narratorBn = "হযরত আবু হুরায়রা (রা.)",
                    arabicText = "إِنَّ اللَّهَ لَا يَنْظُرُ إِلَى صُوَرِكُمْ وَأَمْوَالِكُمْ وَلَكِنْ يَنْظُرُ إِلَى قُلُوبِكُمْ وَأَعْمَالِكُمْ",
                    bengaliText = "নিশ্চয়ই আল্লাহ তাআলা তোমাদের চেহারা ও সম্পদের দিকে তাকান না, বরং তিনি তোমাদের অন্তর ও আমলের দিকে তাকান।",
                    gradingNoteBn = "সহীহ (সহীহ মুসলিম)",
                    verifiedAuthentic = true
                )
            category == IslamicCategory.NAMES_OF_ALLAH || topic.contains("আল্লাহর ৯৯ নাম") ->
                HadithReference(
                    collectionBn = "সহীহ আল-বুখারী",
                    referenceNumber = "হাদিস নং ২৭৩৬",
                    narratorBn = "হযরত আবু হুরায়রা (রা.)",
                    arabicText = "إِنَّ لِلَّهِ تِسْعَةً وَتِسْعِينَ اسْمًا مِائَةً إِلَّا وَاحِدًا مَنْ أَحْصَاهَا دَخَلَ الْجَنَّةَ",
                    bengaliText = "আল্লাহ তাআলার নিরানব্বইটি (এক কম একশত) নাম রয়েছে; যে ব্যক্তি এগুলো সংরক্ষণ করবে ও অনুযায়ী আমল করবে, সে জান্নাতে প্রবেশ করবে।",
                    gradingNoteBn = "মুত্তাফাকুন আলাইহি (সহীহ বুখারী ও মুসলিম)",
                    verifiedAuthentic = true
                )
            category == IslamicCategory.QURAN_RECITATION || topic.contains("কোরআন") || topic.contains("কুরআন") || topic.contains("তেলাওয়াত") ->
                HadithReference(
                    collectionBn = "সহীহ আল-বুখারী",
                    referenceNumber = "হাদিস নং ৫০২৭",
                    narratorBn = "হযরত উসমান ইবনু আফফান (রা.)",
                    arabicText = "خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ",
                    bengaliText = "তোমাদের মধ্যে সর্বোত্তম সেই ব্যক্তি, যে নিজে কুরআন শেখে এবং অন্যকে তা শিক্ষা দেয়।",
                    gradingNoteBn = "সহীহ (সহীহ আল-বুখারী)",
                    verifiedAuthentic = true
                )
            category == IslamicCategory.ISLAMIC_REMINDER || topic.contains("আখলাক") || topic.contains("চরিত্র") || topic.contains("ব্যবহার") ->
                HadithReference(
                    collectionBn = "জামে আত-তিরমিযী",
                    referenceNumber = "হাদিস নং ২০০২",
                    narratorBn = "হযরত আবু দারদা (রা.)",
                    arabicText = "مَا شَيْءٌ أَثْقَلُ فِي مِيزَانِ الْمُؤْمِنِ يَوْمَ الْقِيَامَةِ مِنْ خُلُقٍ حَسَنٍ",
                    bengaliText = "কিয়ামতের দিন মুমিনের মীযানের পাল্লায় উত্তম চরিত্রের চেয়ে ভারী কোনো জিনিস থাকবে না।",
                    gradingNoteBn = "সহীহ (তিরমিযী ও আবু দাউদ)",
                    verifiedAuthentic = true
                )
            category == IslamicCategory.HADITH_EDUCATION || topic.contains("হাদিস") || topic.contains("নিয়ত") ->
                HadithReference(
                    collectionBn = "সহীহ আল-বুখারী",
                    referenceNumber = "হাদিস নং ১",
                    narratorBn = "হযরত উমর ইবনুল খাত্তাব (রা.)",
                    arabicText = "إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى",
                    bengaliText = "সকল কাজ নিয়তের ওপর নির্ভরশীল, আর প্রত্যেক ব্যক্তি তাই পাবে যা সে নিয়ত করবে।",
                    gradingNoteBn = "মুত্তাফাকুন আলাইহি (সহীহ বুখারী ও মুসলিম)",
                    verifiedAuthentic = true
                )
            else ->
                HadithReference(
                    collectionBn = "সহীহ মুসলিম",
                    referenceNumber = "হাদিস নং ২৬৯৯",
                    narratorBn = "হযরত আবু হুরায়রা (রা.)",
                    arabicText = "مَنْ سَلَكَ طَرِيقًا يَلْتَمِسُ فِيهِ عِلْمًا سَهَّلَ اللَّهُ لَهُ بِهِ طَرِيقًا إِلَى الْجَنَّةِ",
                    bengaliText = "যে ব্যক্তি দ্বীনি জ্ঞান অন্বেষণের পথে চলে, আল্লাহ তাআলা তার জন্য জান্নাতের পথ সহজ করে দেন।",
                    gradingNoteBn = "সহীহ (সহীহ মুসলিম)",
                    verifiedAuthentic = true
                )
        }
    }

    fun defaultTopicForCategory(category: IslamicCategory): String = when (category) {
        IslamicCategory.QURAN_RECITATION -> "সূরা আল-ইনশিরাহ (৯৪:৫-৬) তেলাওয়াত ও বাংলা অর্থ"
        IslamicCategory.SURAH_EXPLANATION -> "সূরা আল-আসর (১০৩:১-৩) এর তাফসীর ও শিক্ষা"
        IslamicCategory.ISLAMIC_EDUCATION -> "ইসলামে নিয়তের গুরুত্ব ও সহীহ আমল"
        IslamicCategory.PROPHET_STORIES -> "নবী ইউসুফ (আ.)-এর ধৈর্য ও ক্ষমার শিক্ষণীয় ঘটনা"
        IslamicCategory.ISLAMIC_HISTORY -> "মদিনা সনদ ও ইসলামের শান্তিপূর্ণ সমাজ ব্যবস্থা"
        IslamicCategory.ISLAMIC_REMINDER -> "কষ্টের পরেই রয়েছে স্বস্তি — কুরআনের সান্ত্বনা"
        IslamicCategory.HADITH_EDUCATION -> "সহীহ বুখারীর প্রথম হাদিস: নিয়তের বিশুদ্ধতা"
        IslamicCategory.NAMES_OF_ALLAH -> "আল্লাহর সুন্দর নামসমূহ (আসমাউল হুসনা) ও তাৎপর্য"
        IslamicCategory.ISLAMIC_SHORTS -> "৬০ সেকেন্ডে জীবনের সবচেয়ে জরুরি ইসলামিক বার্তা"
        IslamicCategory.LONG_DOCUMENTARY -> "ইসলামী স্বর্ণযুগ: জ্ঞান-বিজ্ঞানে মুসলিম মনীষীদের অবদান"
    }

    private fun surahDisplayBn(surahNumber: Int, englishFallback: String): String {
        val known = mapOf(
            1 to "সূরা আল-ফাতিহা",
            2 to "সূরা আল-বাকারা",
            3 to "সূরা আলে-ইমরান",
            17 to "সূরা বনী-ইসরাঈল",
            18 to "সূরা আল-কাহফ",
            29 to "সূরা আল-আনকাবুত",
            33 to "সূরা আল-আহযাব",
            36 to "সূরা ইয়াসীন",
            39 to "সূরা আয-যুমার",
            55 to "সূরা আর-রহমান",
            59 to "সূরা আল-হাশর",
            65 to "সূরা আত-তালাক",
            67 to "সূরা আল-মুলক",
            94 to "সূরা আল-ইনশিরাহ",
            103 to "সূরা আল-আসর",
            108 to "সূরা আল-কাউসার",
            112 to "সূরা আল-ইখলাস",
            113 to "সূরা আল-ফালাক",
            114 to "সূরা আন-নাস"
        )
        return known[surahNumber] ?: "সূরা $englishFallback"
    }
}
