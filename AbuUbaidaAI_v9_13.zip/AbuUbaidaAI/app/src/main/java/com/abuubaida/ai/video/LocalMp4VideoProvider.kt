package com.abuubaida.ai.video

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.abuubaida.ai.data.model.VideoDurationOption
import com.abuubaida.ai.data.model.VideoFormat
import com.abuubaida.ai.data.model.VideoProject
import com.abuubaida.ai.voice.BengaliVoiceManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * হলিউড Full HD (1920x1080 / 1080x1920) সিনেমাটিক ইসলামিক MP4 ও থাম্বনেইল স্টুডিও:
 * - অন/অফ যোগ্য মসৃণ ১৫ FPS মোশন গ্রাফিক্স (লাইট রশ্মি, মসজিদ স্কাইলাইন, ঘূর্ণায়মান ১২-কোনা ম্যান্ডালা, গোল্ডেন কণা, অডিও ওয়েভ)
 * - যাচাইকৃত আরবি কুরআন ও হাদিস টেক্সট + বাংলা সাবটাইটেল কার্ড
 * - মানুষের মতো ৩টি স্বতন্ত্র পুরুষ ওয়াজ কণ্ঠ অডিও মাক্সিং (১ মিনিট থেকে ২০ মিনিট)
 */
class LocalMp4VideoProvider(private val context: Context) : VideoGenerationProvider {

    override val providerNameBn: String = "হলিউড Full HD সিনেমাটিক MP4 ও মোশন গ্রাফিক্স স্টুডিও (সক্রিয়)"
    override val isConnected: Boolean = true

    private data class SlideCard(
        val badge: String,
        val mainBody: String,
        val arabicText: String = "",
        val subtitle: String = ""
    )

    private data class EncodedPacket(
        val data: ByteArray,
        val flags: Int
    )

    override suspend fun generateMp4(prompt: String, outputFile: File): Result<Uri> {
        return renderProjectSlidesMp4(
            VideoProject(
                topic = prompt,
                seoTitle = prompt,
                script = prompt,
                durationOption = VideoDurationOption.SHORT_1M
            ),
            outputFile
        )
    }

    suspend fun renderProjectSlidesMp4(
        project: VideoProject,
        internalOutputFile: File,
        motionGraphicsEnabled: Boolean = true
    ): Result<Uri> = renderProjectSlidesMp4WithPath(project, internalOutputFile, motionGraphicsEnabled).map { it.first }

    suspend fun renderProjectSlidesMp4WithPath(
        project: VideoProject,
        internalOutputFile: File,
        motionGraphicsEnabled: Boolean = true
    ): Result<Pair<Uri, String>> = withContext(Dispatchers.IO) {
        val targetDurationSec = project.durationOption.durationSeconds.coerceAtLeast(30)
        val slides = buildSlidesFromProject(project)
        val width = project.format.width
        val height = project.format.height
        val encoderFps = 15
        val loopCycleSec = 2
        val framesPerSlide = if (motionGraphicsEnabled) encoderFps * loopCycleSec else 2
        val videoOnlyTempFile = File(internalOutputFile.parentFile ?: context.cacheDir, "video_hd_${System.currentTimeMillis()}.mp4")

        var codec: MediaCodec? = null
        var surface: android.view.Surface? = null
        var muxer: MediaMuxer? = null
        var muxerStarted = false

        try {
            internalOutputFile.parentFile?.mkdirs()
            if (internalOutputFile.exists()) internalOutputFile.delete()
            if (videoOnlyTempFile.exists()) videoOnlyTempFile.delete()

            val bitRate = if (motionGraphicsEnabled) 5_500_000 else 3_200_000
            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
                setInteger(MediaFormat.KEY_FRAME_RATE, encoderFps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, if (motionGraphicsEnabled) loopCycleSec else 1)
            }

            val activeCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            codec = activeCodec
            activeCodec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val activeSurface = activeCodec.createInputSurface()
            surface = activeSurface
            activeCodec.start()

            val bufferInfo = MediaCodec.BufferInfo()
            var outputFormat: MediaFormat? = null
            val slidePacketGroups = MutableList(slides.size) { mutableListOf<EncodedPacket>() }
            val avgSecPerSlide = targetDurationSec.toDouble() / slides.size.coerceAtLeast(1)

            slides.forEachIndexed { slideIdx, slide ->
                val currentPackets = slidePacketGroups[slideIdx]
                for (frameIdx in 0 until framesPerSlide) {
                    if (frameIdx == 0) {
                        runCatching {
                            val syncBundle = Bundle().apply {
                                putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0)
                            }
                            activeCodec.setParameters(syncBundle)
                        }
                    }

                    val animPhase = if (motionGraphicsEnabled) {
                        frameIdx.toFloat() / framesPerSlide.toFloat()
                    } else {
                        0.25f
                    }
                    val slideStartSec = (slideIdx * avgSecPerSlide).roundToInt()
                    val overallProgress = ((slideIdx.toFloat() + (frameIdx.toFloat() / framesPerSlide.toFloat())) / slides.size.toFloat()).coerceIn(0f, 1f)

                    val canvas = activeSurface.lockCanvas(null)
                    try {
                        drawCinematicSlide(
                            canvas = canvas,
                            width = width,
                            height = height,
                            slide = slide,
                            slideNum = slideIdx + 1,
                            totalSlides = slides.size,
                            progress = overallProgress,
                            elapsedSec = slideStartSec,
                            totalSec = targetDurationSec,
                            animPhase = animPhase,
                            motionEnabled = motionGraphicsEnabled
                        )
                    } finally {
                        activeSurface.unlockCanvasAndPost(canvas)
                    }

                    drainEncoderToPacketList(
                        codec = activeCodec,
                        bufferInfo = bufferInfo,
                        packetSink = currentPackets,
                        endOfStream = false,
                        onFormatChanged = { fmt -> if (outputFormat == null) outputFormat = fmt }
                    )
                }
            }

            drainEncoderToPacketList(
                codec = activeCodec,
                bufferInfo = bufferInfo,
                packetSink = slidePacketGroups.lastOrNull() ?: mutableListOf(),
                endOfStream = true,
                onFormatChanged = { fmt -> if (outputFormat == null) outputFormat = fmt }
            )

            val resolvedFormat = outputFormat
                ?: return@withContext Result.failure(IllegalStateException("হলিউড HD ভিডিও এনকোডার ফরম্যাট তৈরি করতে পারেনি।"))

            val activeMuxer = MediaMuxer(videoOnlyTempFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = activeMuxer
            val videoTrack = activeMuxer.addTrack(resolvedFormat)
            activeMuxer.start()
            muxerStarted = true

            // Check whether every slide starts cleanly on an IDR sync keyframe so GOP looping is 100% artifact-free
            val allSlidesKeyFrameAligned = motionGraphicsEnabled &&
                slidePacketGroups.all { group ->
                    group.size >= encoderFps &&
                        (group.first().flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0
                }

            val writeInfo = MediaCodec.BufferInfo()
            if (allSlidesKeyFrameAligned) {
                val frameDurationUs = 1_000_000L / encoderFps.toLong()
                var frameCounter = 0L
                val loopsPerSlide = max(1, (avgSecPerSlide / loopCycleSec.toDouble()).roundToInt())

                slidePacketGroups.forEach { group ->
                    repeat(loopsPerSlide) {
                        group.forEachIndexed { idxInGroup, pkt ->
                            val cleanFlags = if (idxInGroup == 0) {
                                pkt.flags or MediaCodec.BUFFER_FLAG_KEY_FRAME
                            } else {
                                pkt.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM.inv()
                            }
                            writeInfo.set(0, pkt.data.size, frameCounter * frameDurationUs, cleanFlags)
                            activeMuxer.writeSampleData(videoTrack, ByteBuffer.wrap(pkt.data), writeInfo)
                            frameCounter++
                        }
                    }
                }
            } else {
                // Safe stretched fallback if hardware codec skipped intermediate IDR frame
                val totalEncodedPackets = slidePacketGroups.sumOf { it.size }.coerceAtLeast(1)
                val stretchedFrameUs = (targetDurationSec.toLong() * 1_000_000L) / totalEncodedPackets.toLong()
                var frameCounter = 0L
                slidePacketGroups.forEach { group ->
                    group.forEach { pkt ->
                        val cleanFlags = pkt.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM.inv()
                        writeInfo.set(0, pkt.data.size, frameCounter * stretchedFrameUs, cleanFlags)
                        activeMuxer.writeSampleData(videoTrack, ByteBuffer.wrap(pkt.data), writeInfo)
                        frameCounter++
                    }
                }
            }
        } catch (e: Exception) {
            videoOnlyTempFile.delete()
            return@withContext Result.failure(
                IllegalStateException("হলিউড HD MP4 রেন্ডার ব্যর্থ হয়েছে: ${e.localizedMessage ?: "অজানা ত্রুটি"}")
            )
        } finally {
            try { surface?.release() } catch (_: Exception) {}
            try { codec?.stop(); codec?.release() } catch (_: Exception) {}
            try { if (muxerStarted) muxer?.stop(); muxer?.release() } catch (_: Exception) {}
        }

        // Stream-mux Bengali Male TTS voiceover WAV -> AAC track with video track
        val wavFile = project.voiceoverWavPath.takeIf { it.isNotBlank() }?.let { File(it) }
        val muxedOk = if (wavFile != null && wavFile.exists() && wavFile.length() > 1024L) {
            tryMuxVideoAndWavVoiceover(videoOnlyTempFile, wavFile, internalOutputFile)
        } else false

        if (!muxedOk) {
            videoOnlyTempFile.copyTo(internalOutputFile, overwrite = true)
        }
        videoOnlyTempFile.delete()

        val savedPair = publishVideoToMediaStoreOrFileUri(internalOutputFile)
        Result.success(savedPair)
    }

    private fun drainEncoderToPacketList(
        codec: MediaCodec,
        bufferInfo: MediaCodec.BufferInfo,
        packetSink: MutableList<EncodedPacket>,
        endOfStream: Boolean,
        onFormatChanged: (MediaFormat) -> Unit
    ) {
        if (endOfStream) {
            codec.signalEndOfInputStream()
        }
        while (true) {
            val outIndex = codec.dequeueOutputBuffer(bufferInfo, 10_000L)
            when {
                outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!endOfStream) break
                }
                outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    onFormatChanged(codec.outputFormat)
                }
                outIndex >= 0 -> {
                    val encoded = codec.getOutputBuffer(outIndex)
                    if (encoded != null) {
                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                            bufferInfo.size = 0
                        }
                        if (bufferInfo.size > 0) {
                            encoded.position(bufferInfo.offset)
                            encoded.limit(bufferInfo.offset + bufferInfo.size)
                            val copy = ByteArray(bufferInfo.size)
                            encoded.get(copy)
                            packetSink.add(EncodedPacket(copy, bufferInfo.flags))
                        }
                    }
                    codec.releaseOutputBuffer(outIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        break
                    }
                }
            }
        }
    }

    suspend fun renderThumbnailPng(
        project: VideoProject,
        internalPngFile: File
    ): Result<Pair<Uri, String>> = withContext(Dispatchers.IO) {
        try {
            internalPngFile.parentFile?.mkdirs()
            val width = 1920
            val height = 1080
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)

            drawCosmicBackdrop(canvas, width, height, paletteIndex = 0, animPhase = 0.18f, motionEnabled = true)
            drawMasjidSkylineAndMoon(canvas, width, height, animPhase = 0.18f, motionEnabled = true)
            drawRotatingMandala(canvas, width - 310f, height * 0.48f, 240f, animPhase = 0.18f, motionEnabled = true)

            val frameRect = RectF(52f, 52f, width - 52f, height - 52f)
            val frameStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 7f
                color = Color.parseColor("#D4AF37")
            }
            canvas.drawRoundRect(frameRect, 34f, 34f, frameStroke)

            val badgeRect = RectF(110f, 110f, 840f, 188f)
            val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#D4AF37") }
            canvas.drawRoundRect(badgeRect, 18f, 18f, badgePaint)
            val badgeTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#060B18")
                textSize = 36f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            canvas.drawText("${project.category.labelBn} · ${project.durationOption.labelBn}", 140f, 162f, badgeTextPaint)

            val headline = project.thumbnailText.ifBlank { project.seoTitle }.ifBlank { project.topic }
            val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#FDE68A")
                textSize = 84f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                setShadowLayer(14f, 0f, 6f, Color.BLACK)
            }
            val titleLayout = StaticLayout.Builder
                .obtain(headline, 0, headline.length, titlePaint, 1220)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(16f, 1.0f)
                .setMaxLines(4)
                .build()
            canvas.save()
            canvas.translate(110f, 250f)
            titleLayout.draw(canvas)
            canvas.restore()

            val footer = project.quranReference?.surahNameBn
                ?: project.hadithReference?.collectionBn
                ?: "আবু উবাইদা AI · হলিউড ইসলামিক স্টুডিও"
            val footerPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#38BDF8")
                textSize = 42f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                setShadowLayer(8f, 0f, 2f, Color.BLACK)
            }
            canvas.drawText(footer, 110f, height - 115f, footerPaint)

            FileOutputStream(internalPngFile).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 95, out)
            }
            bitmap.recycle()

            val uri = publishImageToMediaStoreOrFileUri(internalPngFile)
            Result.success(uri to internalPngFile.absolutePath)
        } catch (e: Exception) {
            Result.failure(IllegalStateException("থাম্বনেইল তৈরি ব্যর্থ: ${e.localizedMessage}"))
        }
    }

    /**
     * Streams PCM blocks incrementally from FileInputStream into AAC encoder so long voiceovers
     * NEVER cause OutOfMemoryError by calling file.readBytes() on uncompressed WAV audio.
     */
    private fun tryMuxVideoAndWavVoiceover(videoFile: File, wavFile: File, outFile: File): Boolean {
        val wavInfo = parseWavHeaderStreaming(wavFile) ?: return false
        var audioCodec: MediaCodec? = null
        var videoExtractor: MediaExtractor? = null
        var muxer: MediaMuxer? = null
        var muxerStarted = false

        return try {
            val activeExtractor = MediaExtractor().apply { setDataSource(videoFile.absolutePath) }
            videoExtractor = activeExtractor
            var videoTrackIndex = -1
            var videoFormat: MediaFormat? = null
            for (i in 0 until activeExtractor.trackCount) {
                val fmt = activeExtractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("video/")) {
                    videoTrackIndex = i
                    videoFormat = fmt
                    break
                }
            }
            val resolvedVideoFormat = videoFormat
            if (videoTrackIndex < 0 || resolvedVideoFormat == null) return false
            activeExtractor.selectTrack(videoTrackIndex)

            val aacFormat = MediaFormat.createAudioFormat(
                MediaFormat.MIMETYPE_AUDIO_AAC,
                wavInfo.sampleRate,
                wavInfo.channels
            ).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16_384)
            }
            val activeAudioCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            audioCodec = activeAudioCodec
            activeAudioCodec.configure(aacFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            activeAudioCodec.start()

            val activeMuxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = activeMuxer
            val muxVideoTrack = activeMuxer.addTrack(resolvedVideoFormat)
            var muxAudioTrack = -1

            val bytesPerSampleFrame = wavInfo.channels * 2
            var remainingWavBytes = wavInfo.dataSize
            var totalSamplesWritten = 0L
            var inputDone = false
            var outputDone = false
            val audioInfo = MediaCodec.BufferInfo()
            val encodedAudioSamples = mutableListOf<Pair<ByteArray, MediaCodec.BufferInfo>>()
            val pcmReadChunk = ByteArray(16_384)

            BufferedInputStream(FileInputStream(wavFile), 32_768).use { wavInput ->
                var skipped = 0L
                while (skipped < wavInfo.dataOffset) {
                    val s = wavInput.skip(wavInfo.dataOffset - skipped)
                    if (s <= 0) break
                    skipped += s
                }

                while (!outputDone) {
                    if (!inputDone) {
                        val inIdx = activeAudioCodec.dequeueInputBuffer(5_000L)
                        if (inIdx >= 0) {
                            val inBuf = activeAudioCodec.getInputBuffer(inIdx)
                            if (inBuf != null) {
                                inBuf.clear()
                                val maxAccept = min(inBuf.capacity(), min(pcmReadChunk.size, remainingWavBytes))
                                val alignedAccept = maxAccept - (maxAccept % bytesPerSampleFrame)
                                if (alignedAccept <= 0) {
                                    activeAudioCodec.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                    inputDone = true
                                } else {
                                    val bytesRead = wavInput.read(pcmReadChunk, 0, alignedAccept)
                                    val validRead = if (bytesRead > 0) bytesRead - (bytesRead % bytesPerSampleFrame) else 0
                                    if (validRead <= 0) {
                                        activeAudioCodec.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                        inputDone = true
                                    } else {
                                        inBuf.put(pcmReadChunk, 0, validRead)
                                        val ptsUs = (totalSamplesWritten * 1_000_000L) / wavInfo.sampleRate
                                        totalSamplesWritten += (validRead / bytesPerSampleFrame)
                                        remainingWavBytes -= validRead
                                        activeAudioCodec.queueInputBuffer(inIdx, 0, validRead, ptsUs, 0)
                                    }
                                }
                            }
                        }
                    }

                    val outIdx = activeAudioCodec.dequeueOutputBuffer(audioInfo, 5_000L)
                    when {
                        outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            muxAudioTrack = activeMuxer.addTrack(activeAudioCodec.outputFormat)
                        }
                        outIdx >= 0 -> {
                            val outBuf = activeAudioCodec.getOutputBuffer(outIdx)
                            if (outBuf != null && (audioInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && audioInfo.size > 0) {
                                outBuf.position(audioInfo.offset)
                                outBuf.limit(audioInfo.offset + audioInfo.size)
                                val copy = ByteArray(audioInfo.size)
                                outBuf.get(copy)
                                val clonedInfo = MediaCodec.BufferInfo().apply {
                                    set(0, copy.size, audioInfo.presentationTimeUs, audioInfo.flags)
                                }
                                encodedAudioSamples.add(copy to clonedInfo)
                            }
                            activeAudioCodec.releaseOutputBuffer(outIdx, false)
                            if ((audioInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                                outputDone = true
                            }
                        }
                    }
                }
            }

            if (muxAudioTrack < 0 || encodedAudioSamples.isEmpty()) return false
            activeMuxer.start()
            muxerStarted = true

            val vBuf = ByteBuffer.allocate(1024 * 1024)
            val vInfo = MediaCodec.BufferInfo()
            while (true) {
                val sampleSize = activeExtractor.readSampleData(vBuf, 0)
                if (sampleSize < 0) break
                vInfo.offset = 0
                vInfo.size = sampleSize
                vInfo.presentationTimeUs = activeExtractor.sampleTime
                vInfo.flags = activeExtractor.sampleFlags
                activeMuxer.writeSampleData(muxVideoTrack, vBuf, vInfo)
                activeExtractor.advance()
            }

            encodedAudioSamples.forEach { (bytes, info) ->
                activeMuxer.writeSampleData(muxAudioTrack, ByteBuffer.wrap(bytes), info)
            }
            true
        } catch (_: Exception) {
            false
        } finally {
            try { audioCodec?.stop(); audioCodec?.release() } catch (_: Exception) {}
            try { videoExtractor?.release() } catch (_: Exception) {}
            try { if (muxerStarted) muxer?.stop(); muxer?.release() } catch (_: Exception) {}
        }
    }

    private data class WavHeader(val sampleRate: Int, val channels: Int, val dataOffset: Int, val dataSize: Int)

    private fun parseWavHeaderStreaming(file: File): WavHeader? {
        if (!file.exists() || file.length() < 44L) return null
        return try {
            RandomAccessFile(file, "r").use { raf ->
                val headerSize = min(4096, file.length().toInt())
                val bytes = ByteArray(headerSize)
                raf.readFully(bytes)
                val riff = String(bytes, 0, 4, Charsets.US_ASCII)
                val wave = String(bytes, 8, 4, Charsets.US_ASCII)
                if (riff != "RIFF" || wave != "WAVE") return null

                val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                var pos = 12
                var channels = 1
                var sampleRate = 22050
                var bitsPerSample = 16
                while (pos + 8 <= bytes.size) {
                    val chunkId = String(bytes, pos, 4, Charsets.US_ASCII)
                    val chunkSize = bb.getInt(pos + 4)
                    if (chunkSize < 0) return null
                    if (chunkId == "fmt " && pos + 24 <= bytes.size) {
                        channels = bb.getShort(pos + 10).toInt()
                        sampleRate = bb.getInt(pos + 12)
                        bitsPerSample = bb.getShort(pos + 22).toInt()
                    } else if (chunkId == "data") {
                        if (channels !in 1..2 || sampleRate <= 0 || bitsPerSample != 16) return null
                        val maxAvail = (file.length() - (pos + 8)).toInt().coerceAtLeast(0)
                        return WavHeader(sampleRate, channels, pos + 8, min(chunkSize, maxAvail))
                    }
                    pos += 8 + chunkSize + (chunkSize and 1)
                }
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun publishVideoToMediaStoreOrFileUri(internalFile: File): Pair<Uri, String> {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val relPath = "${Environment.DIRECTORY_MOVIES}/AbuUbaidaAI"
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, internalFile.name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, relPath)
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(internalFile).use { input -> input.copyTo(out) }
                    }
                    resolver.update(uri, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
                    return uri to "$relPath/${internalFile.name}"
                }
            } catch (_: Exception) {
            }
        } else {
            try {
                @Suppress("DEPRECATION")
                val moviesDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "AbuUbaidaAI")
                if (moviesDir.exists() || moviesDir.mkdirs()) {
                    val publicFile = File(moviesDir, internalFile.name)
                    internalFile.copyTo(publicFile, overwrite = true)
                    MediaScannerConnection.scanFile(context, arrayOf(publicFile.absolutePath), arrayOf("video/mp4"), null)
                    return Uri.fromFile(publicFile) to "Movies/AbuUbaidaAI/${internalFile.name}"
                }
            } catch (_: Exception) {
            }
        }
        return Uri.fromFile(internalFile) to internalFile.absolutePath
    }

    private fun publishImageToMediaStoreOrFileUri(internalFile: File): Uri {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, internalFile.name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/AbuUbaidaAI")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(internalFile).use { input -> input.copyTo(out) }
                    }
                    resolver.update(uri, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)
                    return uri
                }
            } catch (_: Exception) {
            }
        }
        return Uri.fromFile(internalFile)
    }

    private fun buildSlidesFromProject(project: VideoProject): List<SlideCard> {
        val slides = mutableListOf<SlideCard>()
        val targetSlides = project.durationOption.slideCount.coerceIn(6, 24)
        val title = project.seoTitle.ifBlank { project.topic }.ifBlank { "আবু উবাইদা AI · ইসলামিক বয়ান" }

        slides.add(
            SlideCard(
                badge = "আবু উবাইদা AI · ${project.category.labelBn}",
                mainBody = title,
                subtitle = "বিসমিল্লাহির রাহমানির রাহীম"
            )
        )

        project.quranReference?.let { q ->
            slides.add(
                SlideCard(
                    badge = q.surahNameBn,
                    arabicText = q.arabicUthmaniText,
                    mainBody = q.bengaliTranslation,
                    subtitle = "সূত্র: ${q.sourceApiBn}"
                )
            )
        }

        project.hadithReference?.let { h ->
            slides.add(
                SlideCard(
                    badge = "${h.collectionBn} (${h.referenceNumber})",
                    arabicText = h.arabicText,
                    mainBody = h.bengaliText,
                    subtitle = "${h.narratorBn} · ${h.gradingNoteBn}"
                )
            )
        }

        val cleanScript = BengaliVoiceManager.cleanNarrationForSpeech(project.script)
        val sentences = cleanScript
            .split(Regex("[।!?\\n]+"))
            .map { it.trim() }
            .filter { it.length >= 10 }

        val subs = project.subtitleLines.ifEmpty { sentences }
        val remainingSlots = (targetSlides - slides.size - 1).coerceAtLeast(3)

        val reflections = listOf(
            "আল্লাহর স্মরণ ও নিয়মিত তেলাওয়াত হৃদয়কে শান্ত রাখে এবং ঈমানকে সজীব করে তোলে।",
            "সৎ চরিত্র, সত্যবাদিতা ও আমানতদারিতা একজন মুমিনের সবচেয়ে বড় সৌন্দর্য।",
            "প্রতিদিন পিতামাতার জন্য দোয়া করা ও তাঁদের খিদমত করা জান্নাতের অন্যতম সহজ পথ।",
            "বিপদে ধৈর্য এবং সুখে শোকর আদায় করলে প্রতিটি মুহূর্তই নেক আমলে পরিণত হয়।",
            "অসহায় মানুষের প্রতি দয়া ও সদকা রিজিকে বরকত এনে দেয়।",
            "নামাজ হলো মুমিনের মেরাজ; সময়মতো মনোযোগ দিয়ে নামাজ আদায়েই প্রকৃত সফলতা।"
        )

        val bodyChunks = if (sentences.isNotEmpty()) {
            sentences.chunked(2).toMutableList()
        } else {
            mutableListOf()
        }
        var refIdx = 0
        while (bodyChunks.size < remainingSlots) {
            bodyChunks.add(listOf(reflections[refIdx % reflections.size]))
            refIdx++
        }

        bodyChunks.take(remainingSlots).forEachIndexed { idx, group ->
            slides.add(
                SlideCard(
                    badge = project.topic.ifBlank { project.category.labelBn },
                    mainBody = group.joinToString("। ") + "।",
                    subtitle = subs.getOrElse(idx % subs.size.coerceAtLeast(1)) { group.firstOrNull().orEmpty() }
                )
            )
        }

        slides.add(
            SlideCard(
                badge = "দাওয়াহ ও শেয়ার করুন",
                mainBody = "ভিডিওটি উপকারী মনে হলে লাইক দিন, প্রিয়জনদের সাথে শেয়ার করুন এবং চ্যানেলটি সাবস্ক্রাইব করুন।",
                subtitle = "জাযাকাল্লাহু খাইরান — আবু উবাইদা AI"
            )
        )
        return slides
    }

    private fun formatMinSec(seconds: Int): String {
        val m = seconds / 60
        val s = seconds % 60
        return String.format(Locale.US, "%02d:%02d", m, s)
    }

    private fun drawCinematicSlide(
        canvas: Canvas,
        width: Int,
        height: Int,
        slide: SlideCard,
        slideNum: Int,
        totalSlides: Int,
        progress: Float,
        elapsedSec: Int,
        totalSec: Int,
        animPhase: Float,
        motionEnabled: Boolean
    ) {
        val isPortrait = height > width
        val padX = if (isPortrait) 64f else 110f
        val padY = if (isPortrait) 88f else 74f

        // 1. Hollywood multi-stop cosmic sky gradient
        drawCosmicBackdrop(canvas, width, height, paletteIndex = slideNum - 1, animPhase = animPhase, motionEnabled = motionEnabled)

        // 2. Volumetric Light Rays & Parallax Masjid Skyline + Moon
        if (motionEnabled) {
            drawVolumetricGodRays(canvas, width, height, animPhase)
            drawNoorBokehParticles(canvas, width, height, animPhase, slideNum)
        }
        drawMasjidSkylineAndMoon(canvas, width, height, animPhase, motionEnabled)

        // 3. Dual counter-rotating 12-point Islamic geometric Mandala
        val mandalaRadius = if (isPortrait) 210f else 225f
        val mandalaCx = width - padX - 85f
        val mandalaCy = padY + 125f
        drawRotatingMandala(canvas, mandalaCx, mandalaCy, mandalaRadius, animPhase, motionEnabled)

        // 4. Deep Cinematic Vignette Framing
        val vignettePaint = Paint().apply {
            shader = RadialGradient(
                width * 0.5f,
                height * 0.48f,
                max(width, height) * 0.72f,
                intArrayOf(Color.TRANSPARENT, Color.argb(65, 2, 4, 12), Color.argb(170, 2, 4, 10)),
                floatArrayOf(0.45f, 0.78f, 1.0f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), vignettePaint)

        // 5. Glassmorphic Stage Card with Imperial Gold Double Rim + Corner Flourishes
        val cardRect = RectF(padX, padY, width - padX, height - padY)
        val cardFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                cardRect.left, cardRect.top, cardRect.right, cardRect.bottom,
                intArrayOf(Color.argb(198, 10, 20, 46), Color.argb(214, 16, 29, 64), Color.argb(196, 8, 16, 36)),
                null,
                Shader.TileMode.CLAMP
            )
        }
        val cardOuterGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 10f
            color = Color.argb(55, 212, 175, 55)
        }
        val cardGoldStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 4f
            color = Color.parseColor("#D4AF37")
        }
        val cardInnerHairline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1.6f
            color = Color.argb(90, 56, 189, 248)
        }
        canvas.drawRoundRect(cardRect, 36f, 36f, cardOuterGlow)
        canvas.drawRoundRect(cardRect, 36f, 36f, cardFill)
        canvas.drawRoundRect(cardRect, 36f, 36f, cardGoldStroke)
        val insetRect = RectF(padX + 14f, padY + 14f, width - padX - 14f, height - padY - 14f)
        canvas.drawRoundRect(insetRect, 26f, 26f, cardInnerHairline)
        drawCornerFlourishes(canvas, cardRect)

        val innerLeft = padX + 58f
        val innerRight = width - padX - 58f
        val textWidth = (innerRight - innerLeft).toInt().coerceAtLeast(480)

        // 6. Top Metadata Bar
        val badgeTextSize = if (isPortrait) 40f else 36f
        val headerPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FCD34D")
            textSize = badgeTextSize
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setShadowLayer(6f, 0f, 3f, Color.BLACK)
        }
        canvas.drawText(slide.badge.take(44), innerLeft, padY + 86f, headerPaint)

        val counterPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#38BDF8")
            textSize = if (isPortrait) 32f else 28f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText(
            "${formatMinSec(elapsedSec)} / ${formatMinSec(totalSec)} · $slideNum/$totalSlides",
            innerRight,
            padY + 84f,
            counterPaint
        )

        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                innerLeft, 0f, innerRight, 0f,
                intArrayOf(Color.parseColor("#D4AF37"), Color.parseColor("#38BDF8"), Color.TRANSPARENT),
                null,
                Shader.TileMode.CLAMP
            )
            strokeWidth = 3.5f
        }
        canvas.drawLine(innerLeft, padY + 114f, innerRight, padY + 114f, linePaint)

        // Subtle kinetic entry pulse for motion mode
        val yDrift = if (motionEnabled) {
            (sin(animPhase * 2.0 * PI) * 4.5).toFloat()
        } else 0f
        var currentY = padY + 158f + yDrift

        // 7. Arabic Calligraphy Box (Quran / Hadith)
        if (slide.arabicText.isNotBlank()) {
            val arabicPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#FDE68A")
                textSize = if (isPortrait) 58f else 54f
                setShadowLayer(8f, 0f, 3f, Color.BLACK)
            }
            val arabicLayout = StaticLayout.Builder
                .obtain(slide.arabicText, 0, slide.arabicText.length, arabicPaint, textWidth - 48)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setLineSpacing(16f, 1.0f)
                .setMaxLines(4)
                .build()
            val arBox = RectF(innerLeft, currentY - 12f, innerRight, currentY + arabicLayout.height + 24f)
            val arBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(110, 212, 175, 55) }
            val arBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 2f
                color = Color.argb(140, 252, 211, 77)
            }
            canvas.drawRoundRect(arBox, 20f, 20f, arBg)
            canvas.drawRoundRect(arBox, 20f, 20f, arBorder)

            canvas.save()
            canvas.translate(innerLeft + 24f, currentY + 4f)
            arabicLayout.draw(canvas)
            canvas.restore()
            currentY += arabicLayout.height + 46f
        }

        // 8. Main Bengali Lecture Narration Copy
        val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F8FAFC")
            textSize = if (isPortrait) 54f else 48f
            setShadowLayer(8f, 0f, 4f, Color.argb(210, 0, 0, 0))
        }
        val bodyLayout = StaticLayout.Builder
            .obtain(slide.mainBody, 0, slide.mainBody.length, bodyPaint, textWidth)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(18f, 1.0f)
            .setMaxLines(if (isPortrait) 10 else 6)
            .build()
        canvas.save()
        canvas.translate(innerLeft, currentY)
        bodyLayout.draw(canvas)
        canvas.restore()

        // 9. Subtitle Highlight Banner
        val footerAreaBottom = height - padY - 30f
        if (slide.subtitle.isNotBlank()) {
            val subBoxTop = footerAreaBottom - if (isPortrait) 225f else 185f
            val subBoxBottom = footerAreaBottom - 68f
            val subBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(228, 5, 11, 26) }
            val subStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 2.5f
                color = Color.parseColor("#38BDF8")
            }
            val subRect = RectF(innerLeft, subBoxTop, innerRight, subBoxBottom)
            canvas.drawRoundRect(subRect, 20f, 20f, subBg)
            canvas.drawRoundRect(subRect, 20f, 20f, subStroke)

            val subPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#E0F2FE")
                textSize = if (isPortrait) 38f else 33f
            }
            val subLayout = StaticLayout.Builder
                .obtain(slide.subtitle, 0, slide.subtitle.length, subPaint, textWidth - 44)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setMaxLines(2)
                .build()
            canvas.save()
            canvas.translate(innerLeft + 22f, subBoxTop + 20f)
            subLayout.draw(canvas)
            canvas.restore()
        }

        // 10. Animated Audio Spectrum Waveform + Progress Timeline
        if (motionEnabled) {
            drawAudioSpectrumBars(
                canvas = canvas,
                left = innerLeft,
                right = innerLeft + 320f,
                baselineY = footerAreaBottom - 26f,
                animPhase = animPhase
            )
        }

        val barLeft = if (motionEnabled) innerLeft + 345f else innerLeft
        val barTop = footerAreaBottom - 36f
        val barBottom = footerAreaBottom - 22f
        val barBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1A2D58") }
        val barFg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                barLeft, barTop, innerRight, barBottom,
                intArrayOf(Color.parseColor("#D4AF37"), Color.parseColor("#FDE68A")),
                null,
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRoundRect(RectF(barLeft, barTop, innerRight, barBottom), 7f, 7f, barBg)
        canvas.drawRoundRect(
            RectF(barLeft, barTop, barLeft + (innerRight - barLeft) * progress, barBottom),
            7f,
            7f,
            barFg
        )
    }

    private fun drawCosmicBackdrop(
        canvas: Canvas,
        width: Int,
        height: Int,
        paletteIndex: Int,
        animPhase: Float,
        motionEnabled: Boolean
    ) {
        val palettes = arrayOf(
            intArrayOf(Color.parseColor("#030714"), Color.parseColor("#0B1A3E"), Color.parseColor("#162E69")),
            intArrayOf(Color.parseColor("#031015"), Color.parseColor("#08292F"), Color.parseColor("#114547")),
            intArrayOf(Color.parseColor("#06081A"), Color.parseColor("#131E4E"), Color.parseColor("#21387A")),
            intArrayOf(Color.parseColor("#090616"), Color.parseColor("#1D1742"), Color.parseColor("#2E2363"))
        )
        val colors = palettes[paletteIndex.mod(palettes.size)]
        val shift = if (motionEnabled) (sin(animPhase * 2.0 * PI) * 140f).toFloat() else 0f
        val bgPaint = Paint().apply {
            shader = LinearGradient(
                shift, 0f, width.toFloat() - shift, height.toFloat(),
                colors,
                null,
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
    }

    private fun drawVolumetricGodRays(canvas: Canvas, width: Int, height: Int, animPhase: Float) {
        val angle = animPhase * 2.0 * PI
        val rayOffsets = floatArrayOf(0.18f, 0.45f, 0.72f)
        rayOffsets.forEachIndexed { idx, baseFrac ->
            val sway = (sin(angle + idx * 1.4) * (width * 0.05)).toFloat()
            val topX = width * baseFrac + sway
            val rayWidth = width * 0.14f
            val path = Path().apply {
                moveTo(topX - rayWidth * 0.35f, 0f)
                lineTo(topX + rayWidth * 0.35f, 0f)
                lineTo(topX + rayWidth * 1.35f, height.toFloat())
                lineTo(topX - rayWidth * 0.65f, height.toFloat())
                close()
            }
            val alpha = (18 + 8 * sin(angle + idx * 2.0)).toInt().coerceIn(8, 30)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(
                    topX, 0f, topX, height * 0.85f,
                    intArrayOf(Color.argb(alpha, 252, 211, 77), Color.argb(alpha / 2, 56, 189, 248), Color.TRANSPARENT),
                    null,
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawPath(path, paint)
        }
    }

    private fun drawNoorBokehParticles(canvas: Canvas, width: Int, height: Int, animPhase: Float, seedShift: Int) {
        val twoPi = 2.0 * PI
        val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        for (i in 0 until 32) {
            val baseX = ((i * 197 + seedShift * 43) % 1000) / 1000f * width
            val baseY = ((i * 313 + seedShift * 71) % 1000) / 1000f * height
            val orbitRx = 18f + (i % 5) * 9f
            val orbitRy = 14f + (i % 4) * 8f
            val speedMult = if (i % 2 == 0) 1.0 else -1.0
            val phase = animPhase * twoPi * speedMult + i * 0.65
            val px = baseX + (cos(phase) * orbitRx).toFloat()
            val py = baseY + (sin(phase) * orbitRy).toFloat()
            val radius = 3.5f + (i % 6) * 2.8f
            val shimmer = (0.55 + 0.45 * sin(animPhase * twoPi + i)).toFloat()
            val isGold = i % 3 != 0
            val alpha = ((if (isGold) 95 else 75) * shimmer).toInt().coerceIn(20, 110)

            particlePaint.color = if (isGold) {
                Color.argb(alpha, 252, 211, 77)
            } else {
                Color.argb(alpha, 56, 189, 248)
            }
            canvas.drawCircle(px, py, radius, particlePaint)
            particlePaint.color = Color.argb(alpha / 3, 255, 255, 255)
            canvas.drawCircle(px, py, radius * 2.1f, particlePaint)
        }
    }

    private fun drawMasjidSkylineAndMoon(
        canvas: Canvas,
        width: Int,
        height: Int,
        animPhase: Float,
        motionEnabled: Boolean
    ) {
        val drift = if (motionEnabled) (sin(animPhase * 2.0 * PI) * 10f).toFloat() else 0f
        // Horizon Masjid Silhouette
        val silhouettePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(95, 3, 8, 22)
            style = Paint.Style.FILL
        }
        val baseY = height.toFloat()
        val horizonY = baseY - height * 0.14f
        val path = Path().apply {
            moveTo(0f, baseY)
            lineTo(0f, horizonY + 30f)
            lineTo(width * 0.22f + drift, horizonY + 12f)
            // Left minaret
            lineTo(width * 0.24f + drift, horizonY - 90f)
            lineTo(width * 0.26f + drift, horizonY - 90f)
            lineTo(width * 0.27f + drift, horizonY + 10f)
            // Central Grand Dome
            val cx = width * 0.50f + drift
            lineTo(cx - 120f, horizonY + 10f)
            cubicTo(cx - 115f, horizonY - 120f, cx + 115f, horizonY - 120f, cx + 120f, horizonY + 10f)
            // Right minaret
            lineTo(width * 0.73f + drift, horizonY + 10f)
            lineTo(width * 0.74f + drift, horizonY - 90f)
            lineTo(width * 0.76f + drift, horizonY - 90f)
            lineTo(width * 0.78f + drift, horizonY + 14f)
            lineTo(width.toFloat(), horizonY + 34f)
            lineTo(width.toFloat(), baseY)
            close()
        }
        canvas.drawPath(path, silhouettePaint)

        // Glowing Crescent Moon top-left aura
        val moonCx = width * 0.14f
        val moonCy = height * 0.18f
        val moonGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                moonCx, moonCy, 95f,
                intArrayOf(Color.argb(65, 252, 211, 77), Color.TRANSPARENT),
                null,
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawCircle(moonCx, moonCy, 95f, moonGlow)
        val moonFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(120, 253, 230, 138) }
        val moonMask = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(230, 6, 14, 34) }
        canvas.drawCircle(moonCx, moonCy, 34f, moonFill)
        canvas.drawCircle(moonCx + 13f, moonCy - 8f, 30f, moonMask)
    }

    private fun drawRotatingMandala(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        radius: Float,
        animPhase: Float,
        motionEnabled: Boolean
    ) {
        val outerRot = if (motionEnabled) (animPhase * 2.0 * PI / 6.0).toFloat() else 0f
        val innerRot = -outerRot * 1.5f

        drawIslamicStar(canvas, cx, cy, radius, Color.argb(38, 212, 175, 55), points = 12, rotationRad = outerRot)
        drawIslamicStar(canvas, cx, cy, radius * 0.68f, Color.argb(46, 56, 189, 248), points = 8, rotationRad = innerRot)

        val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2.2f
            color = Color.argb(55, 252, 211, 77)
        }
        canvas.drawCircle(cx, cy, radius * 0.86f, ringPaint)
        canvas.drawCircle(cx, cy, radius * 0.42f, ringPaint)
    }

    private fun drawCornerFlourishes(canvas: Canvas, rect: RectF) {
        val len = 36f
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 5f
            color = Color.parseColor("#FDE68A")
        }
        // Top-left
        canvas.drawLine(rect.left + 20f, rect.top + 20f, rect.left + 20f + len, rect.top + 20f, p)
        canvas.drawLine(rect.left + 20f, rect.top + 20f, rect.left + 20f, rect.top + 20f + len, p)
        // Top-right
        canvas.drawLine(rect.right - 20f, rect.top + 20f, rect.right - 20f - len, rect.top + 20f, p)
        canvas.drawLine(rect.right - 20f, rect.top + 20f, rect.right - 20f, rect.top + 20f + len, p)
        // Bottom-left
        canvas.drawLine(rect.left + 20f, rect.bottom - 20f, rect.left + 20f + len, rect.bottom - 20f, p)
        canvas.drawLine(rect.left + 20f, rect.bottom - 20f, rect.left + 20f, rect.bottom - 20f - len, p)
        // Bottom-right
        canvas.drawLine(rect.right - 20f, rect.bottom - 20f, rect.right - 20f - len, rect.bottom - 20f, p)
        canvas.drawLine(rect.right - 20f, rect.bottom - 20f, rect.right - 20f, rect.bottom - 20f - len, p)
    }

    private fun drawAudioSpectrumBars(
        canvas: Canvas,
        left: Float,
        right: Float,
        baselineY: Float,
        animPhase: Float
    ) {
        val barCount = 22
        val totalW = right - left
        val step = totalW / barCount.toFloat()
        val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FCD34D") }
        val twoPi = 2.0 * PI
        for (i in 0 until barCount) {
            val env = 1f - abs((i - barCount / 2f) / (barCount / 2f)) * 0.55f
            val wave = (0.35 + 0.65 * abs(sin(animPhase * twoPi + i * 0.62))).toFloat()
            val h = 10f + 26f * env * wave
            val x = left + i * step
            canvas.drawRoundRect(
                RectF(x, baselineY - h, x + step * 0.58f, baselineY),
                3f,
                3f,
                barPaint
            )
        }
    }

    private fun drawIslamicStar(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        radius: Float,
        color: Int,
        points: Int = 8,
        rotationRad: Float = 0f
    ) {
        val path = Path()
        for (i in 0 until points * 2) {
            val r = if (i % 2 == 0) radius else radius * 0.48f
            val angle = (i * PI / points) - (PI / 2.0) + rotationRad
            val x = cx + (r * cos(angle)).toFloat()
            val y = cy + (r * sin(angle)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            style = Paint.Style.FILL
        }
        canvas.drawPath(path, p)
    }
}
