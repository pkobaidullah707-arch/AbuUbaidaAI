package com.abuubaida.ai.video

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.abuubaida.ai.data.model.VideoFormat
import com.abuubaida.ai.data.model.VideoProject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * ডিভাইসের ভেতরেই 9:16 (Shorts/Reels) বা 16:9 (YouTube লং) ইসলামিক MP4 ভিডিও,
 * আরবি কুরআন পাঠ + বাংলা সাবটাইটেল কার্ড, ঐচ্ছিক বাংলা ভয়েসওভার অডিও মাক্সিং এবং Thumbnail PNG তৈরি করে।
 */
class LocalMp4VideoProvider(private val context: Context) : VideoGenerationProvider {

    override val providerNameBn: String = "অফলাইন অন-ডিভাইস ইসলামিক MP4 ও থাম্বনেইল স্টুডিও (সক্রিয়)"
    override val isConnected: Boolean = true

    private data class SlideCard(
        val badge: String,
        val mainBody: String,
        val arabicText: String = "",
        val subtitle: String = ""
    )

    override suspend fun generateMp4(prompt: String, outputFile: File): Result<Uri> {
        return renderProjectSlidesMp4(
            VideoProject(
                topic = prompt,
                seoTitle = prompt,
                script = prompt
            ),
            outputFile
        )
    }

    suspend fun renderProjectSlidesMp4(
        project: VideoProject,
        internalOutputFile: File
    ): Result<Uri> = withContext(Dispatchers.IO) {
        val slides = buildSlidesFromProject(project)
        val width = project.format.width
        val height = project.format.height
        val fps = 10
        val framesPerSlide = 30 // 3.0 seconds per slide

        val videoOnlyTempFile = File(internalOutputFile.parentFile ?: context.cacheDir, "video_only_${System.currentTimeMillis()}.mp4")

        var codec: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var surface: android.view.Surface? = null
        var muxerStarted = false

        try {
            internalOutputFile.parentFile?.mkdirs()
            if (internalOutputFile.exists()) internalOutputFile.delete()
            if (videoOnlyTempFile.exists()) videoOnlyTempFile.delete()

            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, if (project.format == VideoFormat.SHORTS_9_16) 2_600_000 else 2_200_000)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }

            codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            surface = codec.createInputSurface()
            codec.start()

            muxer = MediaMuxer(videoOnlyTempFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val bufferInfo = MediaCodec.BufferInfo()
            var trackIndex = -1
            var writtenFrames = 0L
            val frameDurationUs = 1_000_000L / fps

            fun drainEncoder(endOfStream: Boolean) {
                if (endOfStream) {
                    codec.signalEndOfInputStream()
                }
                while (true) {
                    val outIndex = codec.dequeueOutputBuffer(bufferInfo, 10_000L)
                    when {
                        outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                            if (!endOfStream) break
                        }
                        outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            if (!muxerStarted) {
                                trackIndex = muxer.addTrack(codec.outputFormat)
                                muxer.start()
                                muxerStarted = true
                            }
                        }
                        outIndex >= 0 -> {
                            val encoded = codec.getOutputBuffer(outIndex)
                            if (encoded != null) {
                                if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                                    bufferInfo.size = 0
                                }
                                if (bufferInfo.size > 0 && muxerStarted) {
                                    encoded.position(bufferInfo.offset)
                                    encoded.limit(bufferInfo.offset + bufferInfo.size)
                                    bufferInfo.presentationTimeUs = writtenFrames * frameDurationUs
                                    writtenFrames++
                                    muxer.writeSampleData(trackIndex, encoded, bufferInfo)
                                }
                            }
                            codec.releaseOutputBuffer(outIndex, false)
                            if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                                break
                            }
                        }
                    }
                }
            }

            slides.forEachIndexed { slideIdx, slide ->
                for (frame in 0 until framesPerSlide) {
                    val canvas: Canvas = surface.lockCanvas(null)
                    try {
                        val progress = (frame + 1).toFloat() / framesPerSlide.toFloat()
                        drawSlide(
                            canvas = canvas,
                            width = width,
                            height = height,
                            slide = slide,
                            slideNum = slideIdx + 1,
                            totalSlides = slides.size,
                            progress = progress
                        )
                    } finally {
                        surface.unlockCanvasAndPost(canvas)
                    }
                    drainEncoder(false)
                }
            }
            drainEncoder(true)
        } catch (e: Exception) {
            videoOnlyTempFile.delete()
            return@withContext Result.failure(
                IllegalStateException("MP4 ভিডিও রেন্ডার করা যায়নি: ${e.localizedMessage ?: "অজানা ত্রুটি"}")
            )
        } finally {
            try { surface?.release() } catch (_: Exception) {}
            try { codec?.stop(); codec?.release() } catch (_: Exception) {}
            try { if (muxerStarted) muxer?.stop(); muxer?.release() } catch (_: Exception) {}
        }

        // Try muxing Bengali TTS voiceover WAV -> AAC track with video; fallback safely to crisp video-only MP4
        val wavFile = project.voiceoverWavPath.takeIf { it.isNotBlank() }?.let { File(it) }
        val muxedOk = if (wavFile != null && wavFile.exists() && wavFile.length() > 1024L) {
            tryMuxVideoAndWavVoiceover(videoOnlyTempFile, wavFile, internalOutputFile)
        } else false

        if (!muxedOk) {
            videoOnlyTempFile.copyTo(internalOutputFile, overwrite = true)
        }
        videoOnlyTempFile.delete()

        val savedUri = publishVideoToMediaStoreOrFileUri(internalOutputFile)
        Result.success(savedUri)
    }

    suspend fun renderThumbnailPng(
        project: VideoProject,
        internalPngFile: File
    ): Result<Pair<Uri, String>> = withContext(Dispatchers.IO) {
        try {
            internalPngFile.parentFile?.mkdirs()
            val width = 1280
            val height = 720
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)

            val bgPaint = Paint().apply {
                shader = LinearGradient(
                    0f, 0f, width.toFloat(), height.toFloat(),
                    intArrayOf(Color.parseColor("#040814"), Color.parseColor("#0B1633"), Color.parseColor("#162956")),
                    null,
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

            // Decorative Islamic 8-point star motif on right
            drawIslamicStar(canvas, width - 210f, height / 2f, 150f, Color.argb(65, 212, 175, 55))
            drawIslamicStar(canvas, width - 210f, height / 2f, 105f, Color.argb(120, 56, 189, 248))

            // Outer Gold Frame
            val frameRect = RectF(36f, 36f, width - 36f, height - 36f)
            val frameStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 6f
                color = Color.parseColor("#D4AF37")
            }
            canvas.drawRoundRect(frameRect, 24f, 24f, frameStroke)

            // Category Badge
            val badgeRect = RectF(84f, 84f, 540f, 142f)
            val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#D4AF37") }
            canvas.drawRoundRect(badgeRect, 14f, 14f, badgePaint)
            val badgeTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#060B18")
                textSize = 28f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            canvas.drawText(project.category.labelBn, 108f, 123f, badgeTextPaint)

            // Main Thumbnail Headline
            val headline = project.thumbnailText.ifBlank { project.seoTitle }.ifBlank { project.topic }
            val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#FCD34D")
                textSize = 58f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                setShadowLayer(8f, 0f, 4f, Color.BLACK)
            }
            val titleLayout = StaticLayout.Builder
                .obtain(headline, 0, headline.length, titlePaint, 820)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(12f, 1.0f)
                .setMaxLines(4)
                .build()
            canvas.save()
            canvas.translate(84f, 195f)
            titleLayout.draw(canvas)
            canvas.restore()

            // Verified Source Footer
            val footer = project.quranReference?.surahNameBn
                ?: project.hadithReference?.collectionBn
                ?: "আবু উবাইদা AI · ইসলামিক স্টুডিও"
            val footerPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#38BDF8")
                textSize = 30f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            canvas.drawText(footer, 84f, height - 88f, footerPaint)

            FileOutputStream(internalPngFile).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 95, out)
            }
            bitmap.recycle()

            val uri = publishImageToMediaStoreOrFileUri(internalPngFile)
            Result.success(uri to internalPngFile.absolutePath)
        } catch (e: Exception) {
            Result.failure(IllegalStateException("থাম্বনেইল তৈরি ব্যর্থ: ${e.localizedMessage}"))
        }
    }

    private fun tryMuxVideoAndWavVoiceover(videoFile: File, wavFile: File, outFile: File): Boolean {
        val wavInfo = parseWavHeader(wavFile) ?: return false
        var audioCodec: MediaCodec? = null
        var videoExtractor: MediaExtractor? = null
        var muxer: MediaMuxer? = null
        var muxerStarted = false

        return try {
            videoExtractor = MediaExtractor().apply { setDataSource(videoFile.absolutePath) }
            var videoTrackIndex = -1
            var videoFormat: MediaFormat? = null
            for (i in 0 until videoExtractor.trackCount) {
                val fmt = videoExtractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("video/")) {
                    videoTrackIndex = i
                    videoFormat = fmt
                    break
                }
            }
            if (videoTrackIndex < 0 || videoFormat == null) return false
            videoExtractor.selectTrack(videoTrackIndex)

            val aacFormat = MediaFormat.createAudioFormat(
                MediaFormat.MIMETYPE_AUDIO_AAC,
                wavInfo.sampleRate,
                wavInfo.channels
            ).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 96_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16_384)
            }
            audioCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            audioCodec.configure(aacFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            audioCodec.start()

            muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val muxVideoTrack = muxer.addTrack(videoFormat)
            var muxAudioTrack = -1

            val pcmBytes = wavFile.readBytes()
            var offset = wavInfo.dataOffset
            val endOffset = min(pcmBytes.size, wavInfo.dataOffset + wavInfo.dataSize)
            val bytesPerSampleFrame = wavInfo.channels * 2
            var totalSamplesWritten = 0L
            var inputDone = false
            var outputDone = false
            val audioInfo = MediaCodec.BufferInfo()

            // First encode audio until format changes so we know AAC track before starting muxer
            val encodedAudioSamples = mutableListOf<Pair<ByteArray, MediaCodec.BufferInfo>>()
            while (!outputDone) {
                if (!inputDone) {
                    val inIdx = audioCodec.dequeueInputBuffer(5_000L)
                    if (inIdx >= 0) {
                        val inBuf = audioCodec.getInputBuffer(inIdx)
                        if (inBuf != null) {
                            inBuf.clear()
                            val chunkSize = min(inBuf.capacity(), endOffset - offset)
                            if (chunkSize <= 0) {
                                audioCodec.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                inBuf.put(pcmBytes, offset, chunkSize)
                                val ptsUs = (totalSamplesWritten * 1_000_000L) / wavInfo.sampleRate
                                totalSamplesWritten += (chunkSize / bytesPerSampleFrame)
                                offset += chunkSize
                                audioCodec.queueInputBuffer(inIdx, 0, chunkSize, ptsUs, 0)
                            }
                        }
                    }
                }
                val outIdx = audioCodec.dequeueOutputBuffer(audioInfo, 5_000L)
                when {
                    outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        muxAudioTrack = muxer.addTrack(audioCodec.outputFormat)
                    }
                    outIdx >= 0 -> {
                        val outBuf = audioCodec.getOutputBuffer(outIdx)
                        if (outBuf != null && (audioInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && audioInfo.size > 0) {
                            outBuf.position(audioInfo.offset)
                            outBuf.limit(audioInfo.offset + audioInfo.size)
                            val copy = ByteArray(audioInfo.size)
                            outBuf.get(copy)
                            val clonedInfo = MediaCodec.BufferInfo().apply {
                                set(0, copy.size, audioInfo.presentationTimeUs, audioInfo.flags)
                            }
                            encodedAudioSamples.add(copy to clonedInfo)
                        }
                        audioCodec.releaseOutputBuffer(outIdx, false)
                        if ((audioInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            outputDone = true
                        }
                    }
                }
            }

            if (muxAudioTrack < 0 || encodedAudioSamples.isEmpty()) return false
            muxer.start()
            muxerStarted = true

            // Write Video Track
            val vBuf = ByteBuffer.allocate(512 * 1024)
            val vInfo = MediaCodec.BufferInfo()
            while (true) {
                val sampleSize = videoExtractor.readSampleData(vBuf, 0)
                if (sampleSize < 0) break
                vInfo.offset = 0
                vInfo.size = sampleSize
                vInfo.presentationTimeUs = videoExtractor.sampleTime
                vInfo.flags = videoExtractor.sampleFlags
                muxer.writeSampleData(muxVideoTrack, vBuf, vInfo)
                videoExtractor.advance()
            }

            // Write Audio Track
            encodedAudioSamples.forEach { (bytes, info) ->
                muxer.writeSampleData(muxAudioTrack, ByteBuffer.wrap(bytes), info)
            }
            true
        } catch (_: Exception) {
            false
        } finally {
            try { audioCodec?.stop(); audioCodec?.release() } catch (_: Exception) {}
            try { videoExtractor?.release() } catch (_: Exception) {}
            try { if (muxerStarted) muxer?.stop(); muxer?.release() } catch (_: Exception) {}
        }
    }

    private data class WavHeader(val sampleRate: Int, val channels: Int, val dataOffset: Int, val dataSize: Int)

    private fun parseWavHeader(file: File): WavHeader? {
        val bytes = file.readBytes()
        if (bytes.size < 44) return null
        val riff = String(bytes, 0, 4, Charsets.US_ASCII)
        val wave = String(bytes, 8, 4, Charsets.US_ASCII)
        if (riff != "RIFF" || wave != "WAVE") return null
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val channels = bb.getShort(22).toInt()
        val sampleRate = bb.getInt(24)
        val bitsPerSample = bb.getShort(34).toInt()
        if (channels !in 1..2 || sampleRate <= 0 || bitsPerSample != 16) return null

        var pos = 12
        while (pos + 8 <= bytes.size) {
            val chunkId = String(bytes, pos, 4, Charsets.US_ASCII)
            val chunkSize = bb.getInt(pos + 4)
            if (chunkId == "data") {
                return WavHeader(sampleRate, channels, pos + 8, chunkSize)
            }
            pos += 8 + chunkSize
        }
        return null
    }

    private fun publishVideoToMediaStoreOrFileUri(internalFile: File): Uri {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, internalFile.name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/AbuUbaidaAI")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(internalFile).use { input -> input.copyTo(out) }
                    }
                    resolver.update(uri, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
                    return uri
                }
            } catch (_: Exception) {
            }
        }
        return Uri.fromFile(internalFile)
    }

    private fun publishImageToMediaStoreOrFileUri(internalFile: File): Uri {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, internalFile.name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/AbuUbaidaAI")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(internalFile).use { input -> input.copyTo(out) }
                    }
                    resolver.update(uri, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)
                    return uri
                }
            } catch (_: Exception) {
            }
        }
        return Uri.fromFile(internalFile)
    }

    private fun buildSlidesFromProject(project: VideoProject): List<SlideCard> {
        val slides = mutableListOf<SlideCard>()
        val title = project.seoTitle.ifBlank { project.topic }.ifBlank { "আবু উবাইদা AI · ইসলামিক ভিডিও" }
        slides.add(
            SlideCard(
                badge = "আবু উবাইদা AI · ${project.category.labelBn}",
                mainBody = title,
                subtitle = "বিসমিল্লাহির রাহমানির রাহীম"
            )
        )

        project.quranReference?.let { q ->
            slides.add(
                SlideCard(
                    badge = q.surahNameBn,
                    arabicText = q.arabicUthmaniText,
                    mainBody = q.bengaliTranslation,
                    subtitle = "সূত্র: ${q.sourceApiBn}"
                )
            )
        }

        project.hadithReference?.let { h ->
            slides.add(
                SlideCard(
                    badge = "${h.collectionBn} (${h.referenceNumber})",
                    mainBody = h.bengaliText,
                    subtitle = "${h.narratorBn} · ${h.gradingNoteBn}"
                )
            )
        }

        val scriptLines = project.script
            .lines()
            .map { it.trim() }
            .filter { it.length >= 8 && !it.startsWith("[") }

        val subs = project.subtitleLines.ifEmpty { scriptLines }
        val maxBodySlides = if (project.format == VideoFormat.SHORTS_9_16) 3 else 4
        scriptLines.chunked(2).take(maxBodySlides).forEachIndexed { idx, group ->
            slides.add(
                SlideCard(
                    badge = "আলোচনা — অংশ ${idx + 1}",
                    mainBody = group.joinToString("\n"),
                    subtitle = subs.getOrElse(idx) { group.firstOrNull().orEmpty() }
                )
            )
        }

        slides.add(
            SlideCard(
                badge = "দাওয়াহ ও শেয়ার করুন",
                mainBody = "ভিডিওটি উপকারী মনে হলে লাইক দিন, প্রিয়জনদের সাথে শেয়ার করুন এবং চ্যানেলটি সাবস্ক্রাইব করুন।",
                subtitle = "জাযাকাল্লাহু খাইরান — আবু উবাইদা AI"
            )
        )
        return slides
    }

    private fun drawSlide(
        canvas: Canvas,
        width: Int,
        height: Int,
        slide: SlideCard,
        slideNum: Int,
        totalSlides: Int,
        progress: Float
    ) {
        val isPortrait = height > width
        val pad = if (isPortrait) 54f else 60f

        val bgPaint = Paint().apply {
            shader = LinearGradient(
                0f, 0f, width.toFloat(), height.toFloat(),
                intArrayOf(Color.parseColor("#060B18"), Color.parseColor("#0B1633"), Color.parseColor("#121E3D")),
                null,
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Subtle geometric Islamic motif
        drawIslamicStar(canvas, width - pad - 80f, pad + 90f, if (isPortrait) 75f else 62f, Color.argb(38, 212, 175, 55))

        // Outer gold border card
        val cardRect = RectF(pad, pad, width - pad, height - pad)
        val cardFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(195, 18, 30, 61) }
        val cardStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 4f
            color = Color.parseColor("#D4AF37")
        }
        canvas.drawRoundRect(cardRect, 28f, 28f, cardFill)
        canvas.drawRoundRect(cardRect, 28f, 28f, cardStroke)

        val innerLeft = pad + 42f
        val innerRight = width - pad - 42f
        val textWidth = (innerRight - innerLeft).toInt().coerceAtLeast(300)

        val headerPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FCD34D")
            textSize = if (isPortrait) 38f else 32f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText(slide.badge.take(40), innerLeft, pad + 78f, headerPaint)

        val counterPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#38BDF8")
            textSize = if (isPortrait) 28f else 24f
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText("$slideNum / $totalSlides", innerRight, pad + 76f, counterPaint)

        val linePaint = Paint().apply {
            color = Color.parseColor("#2563EB")
            strokeWidth = 3f
        }
        canvas.drawLine(innerLeft, pad + 104f, innerRight, pad + 104f, linePaint)

        var currentY = pad + 145f

        if (slide.arabicText.isNotBlank()) {
            val arabicPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#FDE68A")
                textSize = if (isPortrait) 52f else 44f
            }
            val arabicLayout = StaticLayout.Builder
                .obtain(slide.arabicText, 0, slide.arabicText.length, arabicPaint, textWidth)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setLineSpacing(14f, 1.0f)
                .setMaxLines(4)
                .build()
            canvas.save()
            canvas.translate(innerLeft, currentY)
            arabicLayout.draw(canvas)
            canvas.restore()
            currentY += arabicLayout.height + 34f
        }

        val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F8FAFC")
            textSize = if (isPortrait) 44f else 38f
        }
        val bodyLayout = StaticLayout.Builder
            .obtain(slide.mainBody, 0, slide.mainBody.length, bodyPaint, textWidth)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(14f, 1.0f)
            .setMaxLines(if (isPortrait) 10 else 6)
            .build()
        canvas.save()
        canvas.translate(innerLeft, currentY)
        bodyLayout.draw(canvas)
        canvas.restore()

        // Burned-in Subtitle Pill at Bottom
        if (slide.subtitle.isNotBlank()) {
            val subBoxTop = height - pad - if (isPortrait) 210f else 148f
            val subBoxBottom = height - pad - 56f
            val subBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(220, 6, 11, 24) }
            val subStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 2f
                color = Color.parseColor("#38BDF8")
            }
            val subRect = RectF(innerLeft, subBoxTop, innerRight, subBoxBottom)
            canvas.drawRoundRect(subRect, 16f, 16f, subBg)
            canvas.drawRoundRect(subRect, 16f, 16f, subStroke)

            val subPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#E0F2FE")
                textSize = if (isPortrait) 30f else 25f
            }
            val subLayout = StaticLayout.Builder
                .obtain(slide.subtitle, 0, slide.subtitle.length, subPaint, textWidth - 32)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setMaxLines(2)
                .build()
            canvas.save()
            canvas.translate(innerLeft + 16f, subBoxTop + 16f)
            subLayout.draw(canvas)
            canvas.restore()
        }

        // Progress bar at bottom
        val barTop = height - pad - 32f
        val barBottom = height - pad - 20f
        val barBg = Paint().apply { color = Color.parseColor("#1E325C") }
        val barFg = Paint().apply { color = Color.parseColor("#D4AF37") }
        canvas.drawRoundRect(RectF(innerLeft, barTop, innerRight, barBottom), 6f, 6f, barBg)
        canvas.drawRoundRect(
            RectF(innerLeft, barTop, innerLeft + (innerRight - innerLeft) * progress, barBottom),
            6f,
            6f,
            barFg
        )
    }

    private fun drawIslamicStar(canvas: Canvas, cx: Float, cy: Float, radius: Float, color: Int) {
        val path = Path()
        val points = 8
        for (i in 0 until points * 2) {
            val r = if (i % 2 == 0) radius else radius * 0.48f
            val angle = (i * PI / points) - (PI / 2.0)
            val x = cx + (r * cos(angle)).toFloat()
            val y = cy + (r * sin(angle)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            style = Paint.Style.FILL
        }
        canvas.drawPath(path, p)
    }
}
