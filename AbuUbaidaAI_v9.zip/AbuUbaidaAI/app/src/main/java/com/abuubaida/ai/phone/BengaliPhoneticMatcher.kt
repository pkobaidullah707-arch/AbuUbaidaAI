package com.abuubaida.ai.phone

import com.abuubaida.ai.data.model.ContactItem
import java.text.Normalizer
import kotlin.math.max
import kotlin.math.min

/**
 * বাংলা উচ্চারণ থেকে ইংরেজিতে সেভ করা কন্টাক্ট ও অ্যাপ খোঁজার ফোনেটিক ম্যাচিং ইঞ্জিন।
 * যেমন: "রহিমকে কল করো" -> "Rahim", "ওবায়দুল্লাহ" -> "Obaidullah", "আব্বু" -> "Abbu" / "Dad"
 */
object BengaliPhoneticMatcher {

    private val kinshipAliases: Map<String, List<String>> = mapOf(
        "আব্বু" to listOf("abbu", "abba", "baba", "dad", "father", "papa"),
        "আব্বা" to listOf("abba", "abbu", "baba", "dad", "father"),
        "বাবা" to listOf("baba", "abbu", "dad", "father", "papa"),
        "আম্মু" to listOf("ammu", "amma", "ma", "mom", "mother", "mama"),
        "আম্মা" to listOf("amma", "ammu", "ma", "mom", "mother"),
        "মা" to listOf("ma", "ammu", "mom", "mother"),
        "ভাই" to listOf("vai", "bhai", "brother", "bro"),
        "ভাইয়া" to listOf("bhaiya", "vaiya", "vai", "bhai", "brother"),
        "আপু" to listOf("apu", "apa", "sister", "sis"),
        "আপা" to listOf("apa", "apu", "sister"),
        "চাচা" to listOf("chacha", "kaka", "uncle"),
        "মামা" to listOf("mama", "uncle"),
        "খালু" to listOf("khalu", "uncle"),
        "ফুফা" to listOf("fufa", "fupha", "uncle"),
        "খালা" to listOf("khala", "aunt", "aunty"),
        "মামী" to listOf("mami", "aunt", "aunty"),
        "ফুফু" to listOf("fupu", "fuphu", "aunt"),
        "দাদা" to listOf("dada", "grandfather"),
        "নানা" to listOf("nana", "grandfather"),
        "ভাবি" to listOf("vabi", "bhabi", "bhabhi"),
        "ভাবী" to listOf("vabi", "bhabi", "bhabhi"),
        "বউ" to listOf("bou", "wife"),
        "অফিস" to listOf("office"),
        "বস" to listOf("boss"),
        "হুজুর" to listOf("hujur", "imam", "maulana")
    )

    private val conjunctMap: List<Pair<String, String>> = listOf(
        "ক্ষ" to "kh",
        "জ্ঞ" to "gg",
        "ত্র" to "tr",
        "শ্র" to "sr",
        "দ্র" to "dr",
        "প্র" to "pr",
        "ব্র" to "br",
        "ক্র" to "kr",
        "গ্র" to "gr",
        "স্ত" to "st",
        "ন্দ" to "nd",
        "ন্ত" to "nt",
        "ম্প" to "mp",
        "ম্ব" to "mb",
        "ল্ল" to "ll",
        "ন্ন" to "nn",
        "ম্ম" to "mm",
        "ব্ব" to "bb"
    )

    private val charMap: Map<Char, String> = mapOf(
        'অ' to "o", 'আ' to "a", 'ই' to "i", 'ঈ' to "i",
        'উ' to "u", 'ঊ' to "u", 'ঋ' to "ri", 'এ' to "e",
        'ঐ' to "oi", 'ও' to "o", 'ঔ' to "ou",
        'া' to "a", 'ি' to "i", 'ী' to "i", 'ু' to "u",
        'ূ' to "u", 'ৃ' to "ri", 'ে' to "e", 'ৈ' to "oi",
        'ো' to "o", 'ৌ' to "ou",
        'ক' to "k", 'খ' to "kh", 'গ' to "g", 'ঘ' to "gh",
        'ঙ' to "ng", 'ং' to "ng",
        'চ' to "ch", 'ছ' to "ch", 'জ' to "j", 'ঝ' to "jh",
        'ঞ' to "n",
        'ট' to "t", 'ঠ' to "th", 'ড' to "d", 'ঢ' to "dh",
        'ণ' to "n",
        'ত' to "t", 'থ' to "th", 'দ' to "d", 'ধ' to "dh",
        'ন' to "n", 'ৎ' to "t",
        'প' to "p", 'ফ' to "f", 'ব' to "b", 'ভ' to "bh",
        'ম' to "m",
        'য' to "j", '\u09DF' to "y", 'র' to "r", '\u09DC' to "r", '\u09DD' to "r",
        'ল' to "l",
        'শ' to "sh", 'ষ' to "sh", 'স' to "s", 'হ' to "h",
        'ঁ' to "", '্' to ""
    )

    private val suffixList = listOf("ভাইকে", "আপুকে", "দেরকে", "কে", "রে", "ের")

    fun cleanTargetName(rawTarget: String): String {
        var cleaned = BengaliCommandEngine.normalizeDigits(rawTarget).trim()
        for (suffix in suffixList) {
            if (cleaned.length > suffix.length + 1 && cleaned.endsWith(suffix)) {
                cleaned = cleaned.removeSuffix(suffix).trim()
                break
            }
        }
        return cleaned
    }

    fun transliterateBengaliToLatin(input: String): String {
        val nfc = Normalizer.normalize(input.trim(), Normalizer.Form.NFC)
        var text = BengaliCommandEngine.normalizeDigits(nfc)
        for ((bn, en) in conjunctMap) {
            text = text.replace(bn, en)
        }
        val sb = StringBuilder(text.length * 2)
        for (ch in text) {
            val mapped = charMap[ch]
            if (mapped != null) {
                sb.append(mapped)
            } else {
                sb.append(ch.lowercaseChar())
            }
        }
        return sb.toString()
    }

    fun phoneticSkeleton(latinOrBn: String): String {
        var s = transliterateBengaliToLatin(latinOrBn).lowercase()
        s = s.replace(Regex("[^a-z0-9\\s]"), " ")
            .replace("ph", "f")
            .replace("bh", "b")
            .replace("vh", "b")
            .replace("v", "b")
            .replace("w", "o")
            .replace("z", "j")
            .replace("q", "k")
            .replace("sh", "s")
            .replace("ch", "c")
            .replace("kh", "k")
            .replace("gh", "g")
            .replace("th", "t")
            .replace("dh", "d")
            .replace("jh", "j")
            .replace("c", "k")
            .replace("oo", "u")
            .replace("ee", "i")
            .replace("aa", "a")
            .replace("ai", "i")
            .replace("ay", "i")
            .replace("ey", "i")
            .replace("ou", "o")
            .replace("au", "o")
        val collapsed = StringBuilder(s.length)
        var prev = '\u0000'
        for (ch in s) {
            if (ch != prev || ch == ' ') {
                collapsed.append(ch)
                prev = ch
            }
        }
        return collapsed.toString().trim().replace(Regex("\\s+"), " ")
    }

    fun consonantSkeleton(phonetic: String): String {
        val clean = phonetic.replace(" ", "")
        if (clean.isEmpty()) return ""
        val sb = StringBuilder(clean.length)
        clean.forEachIndexed { idx, ch ->
            if (idx == 0 || ch !in charArrayOf('a', 'e', 'i', 'o', 'u', 'y')) {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun expandCandidates(rawTarget: String): List<String> {
        val cleaned = cleanTargetName(rawTarget)
        val lower = cleaned.lowercase()
        val list = mutableListOf(lower, transliterateBengaliToLatin(cleaned))
        kinshipAliases.forEach { (bn, aliases) ->
            if (lower == bn || lower.contains(bn)) {
                list.addAll(aliases)
            }
        }
        return list.map { it.trim() }.filter { it.isNotBlank() }.distinct()
    }

    fun findBestContact(rawTarget: String, contacts: List<ContactItem>): ContactItem? {
        if (contacts.isEmpty() || rawTarget.isBlank()) return null

        val cleaned = cleanTargetName(rawTarget)
        val digitsQuery = cleaned.filter { it.isDigit() }
        if (digitsQuery.length >= 3) {
            contacts.firstOrNull { c ->
                c.phoneNumber.filter { it.isDigit() }.contains(digitsQuery)
            }?.let { return it }
        }

        // Direct text match first
        contacts.firstOrNull { c ->
            c.name.equals(cleaned, ignoreCase = true) ||
                c.name.contains(cleaned, ignoreCase = true)
        }?.let { return it }

        val candidates = expandCandidates(cleaned)
        var bestContact: ContactItem? = null
        var bestScore = 0.0

        for (contact in contacts) {
            val nameLower = contact.name.lowercase()
            val namePhonetic = phoneticSkeleton(nameLower)
            val nameConsonants = consonantSkeleton(namePhonetic)
            val nameTokens = namePhonetic.split(" ").filter { it.isNotBlank() }

            for (cand in candidates) {
                val candPhonetic = phoneticSkeleton(cand)
                val candConsonants = consonantSkeleton(candPhonetic)
                if (candPhonetic.isBlank()) continue

                var score = 0.0
                when {
                    nameLower == cand || namePhonetic == candPhonetic -> score = 1.0
                    nameTokens.any { it == candPhonetic } -> score = 0.96
                    nameLower.contains(cand) || namePhonetic.contains(candPhonetic) -> score = 0.90
                    candConsonants.length >= 3 && nameConsonants == candConsonants -> score = 0.88
                    candConsonants.length >= 3 && nameTokens.any { consonantSkeleton(it) == candConsonants } -> score = 0.85
                    else -> {
                        val fullSim = similarity(candPhonetic, namePhonetic)
                        val tokenSim = nameTokens.maxOfOrNull { similarity(candPhonetic, it) } ?: 0.0
                        val consSim = if (candConsonants.length >= 3 && nameConsonants.length >= 3) {
                            similarity(candConsonants, nameConsonants)
                        } else 0.0
                        val tokenConsSim = if (candConsonants.length >= 3) {
                            nameTokens.maxOfOrNull { similarity(candConsonants, consonantSkeleton(it)) } ?: 0.0
                        } else 0.0
                        score = maxOf(fullSim, tokenSim, consSim * 0.92, tokenConsSim * 0.92)
                    }
                }

                if (score > bestScore) {
                    bestScore = score
                    bestContact = contact
                }
            }
        }

        return if (bestScore >= 0.64) bestContact else null
    }

    private fun similarity(a: String, b: String): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        if (a == b) return 1.0
        val dist = levenshtein(a, b)
        return 1.0 - (dist.toDouble() / max(a.length, b.length).toDouble())
    }

    private fun levenshtein(a: String, b: String): Int {
        val m = a.length
        val n = b.length
        val dp = IntArray(n + 1) { it }
        for (i in 1..m) {
            var prevDiag = dp[0]
            dp[0] = i
            for (j in 1..n) {
                val temp = dp[j]
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                dp[j] = min(min(dp[j] + 1, dp[j - 1] + 1), prevDiag + cost)
                prevDiag = temp
            }
        }
        return dp[n]
    }
}
