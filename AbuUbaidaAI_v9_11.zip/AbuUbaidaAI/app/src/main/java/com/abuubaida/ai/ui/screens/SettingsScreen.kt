package com.abuubaida.ai.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.abuubaida.ai.data.model.AssistantSettings
import com.abuubaida.ai.ui.components.GlassCard
import com.abuubaida.ai.ui.theme.BrightGold
import com.abuubaida.ai.ui.theme.DeepNavyBg
import com.abuubaida.ai.ui.theme.ElectricBlue
import com.abuubaida.ai.ui.theme.EmeraldOk
import com.abuubaida.ai.ui.theme.ImperialGold
import com.abuubaida.ai.ui.theme.NavyBorder
import com.abuubaida.ai.ui.theme.TextPrimary
import com.abuubaida.ai.ui.theme.TextSecondary

@Composable
fun SettingsScreen(
    currentSettings: AssistantSettings,
    isFirebaseConfigured: Boolean,
    onSaveSettings: (AssistantSettings) -> Unit,
    onOpenAssistantRoleSettings: () -> Unit,
    onOpenBatterySettings: () -> Unit
) {
    val context = LocalContext.current
    var wakePhrase by remember(currentSettings.wakePhrase) { mutableStateOf(currentSettings.wakePhrase) }
    var ttsEnabled by remember(currentSettings.ttsEnabled) { mutableStateOf(currentSettings.ttsEnabled) }
    var continuousMode by remember(currentSettings.continuousVoiceMode) {
        mutableStateOf(currentSettings.continuousVoiceMode)
    }
    var bgEnabled by remember(currentSettings.backgroundServiceEnabled) {
        mutableStateOf(currentSettings.backgroundServiceEnabled)
    }
    var proxyUrl by remember(currentSettings.proxyEndpointUrl) {
        mutableStateOf(currentSettings.proxyEndpointUrl)
    }

    val fgPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val micOk = results[Manifest.permission.RECORD_AUDIO] == true
        bgEnabled = micOk
        onSaveSettings(
            AssistantSettings(
                wakePhrase = wakePhrase,
                ttsEnabled = ttsEnabled,
                continuousVoiceMode = continuousMode,
                backgroundServiceEnabled = micOk,
                proxyEndpointUrl = proxyUrl,
                speechLanguageTag = currentSettings.speechLanguageTag
            )
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("সেটিংস — আবু উবাইদা AI", style = MaterialTheme.typography.headlineMedium, color = BrightGold)

        GlassCard(borderColor = ImperialGold.copy(alpha = 0.45f)) {
            Text("ভয়েস ও ওয়েক-ফ্রেজ", style = MaterialTheme.typography.titleMedium, color = BrightGold)
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = wakePhrase,
                onValueChange = { wakePhrase = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("ভয়েস ওয়েক-ফ্রেজ") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = NavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("বাংলা ভয়েস উত্তর (TTS)", color = TextPrimary)
                    Text("প্রতিটি উত্তর বাংলায় পড়ে শোনাবে", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                }
                Switch(checked = ttsEnabled, onCheckedChange = { ttsEnabled = it })
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("হ্যান্ডস-ফ্রি কন্টিনিউয়াস মোড", color = TextPrimary)
                    Text("উত্তর বলার পর নিজে থেকেই আবার শুনবে", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                }
                Switch(checked = continuousMode, onCheckedChange = { continuousMode = it })
            }
        }

        GlassCard(borderColor = ElectricBlue.copy(alpha = 0.4f)) {
            Text("ব্যাকগ্রাউন্ড ভয়েস অ্যাসিস্ট্যান্ট", style = MaterialTheme.typography.titleMedium, color = ElectricBlue)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "চালু করলে স্থায়ী দৃশ্যমান নোটিফিকেশনসহ ফোরগ্রাউন্ড মাইক্রোফোন সার্ভিস চলবে এবং \"$wakePhrase\" শুনবে। কোনো গোপন রেকর্ডিং করা হয় না।",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("ফোরগ্রাউন্ড ওয়েক-ফ্রেজ সার্ভিস", color = TextPrimary)
                Switch(
                    checked = bgEnabled,
                    onCheckedChange = { wantEnable ->
                        if (wantEnable) {
                            val micGranted = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED
                            if (micGranted) {
                                bgEnabled = true
                            } else {
                                val perms = buildList {
                                    add(Manifest.permission.RECORD_AUDIO)
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        add(Manifest.permission.POST_NOTIFICATIONS)
                                    }
                                }.toTypedArray()
                                fgPermLauncher.launch(perms)
                            }
                        } else {
                            bgEnabled = false
                        }
                    }
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = onOpenAssistantRoleSettings, modifier = Modifier.weight(1f)) {
                    Text("ডিফল্ট অ্যাসিস্ট্যান্ট", color = BrightGold)
                }
                OutlinedButton(onClick = onOpenBatterySettings, modifier = Modifier.weight(1f)) {
                    Text("ব্যাটারি সেটিংস", color = ElectricBlue)
                }
            }
        }

        GlassCard {
            Text("স্বয়ংক্রিয় AI ও রিসার্চ ইঞ্জিন", style = MaterialTheme.typography.titleMedium, color = BrightGold)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (isFirebaseConfigured) {
                    "Firebase AI Logic + স্বয়ংক্রিয় কুরআন-হাদিস ও পাবলিক নলেজ রাউটিং সক্রিয় আছে।"
                } else {
                    "স্বয়ংক্রিয় মোড চালু আছে: কুরআন API, ইসলামিক জ্ঞানভাণ্ডার, ভয়েস কমান্ড ও ভিডিও স্টুডিও কোনো ম্যানুয়াল URL ছাড়াই নিজে থেকেই কাজ করবে। (নিচে প্রক্সি URL সম্পূর্ণ ঐচ্ছিক)"
                },
                style = MaterialTheme.typography.bodyMedium,
                color = EmeraldOk
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = proxyUrl,
                onValueChange = { proxyUrl = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("উন্নত সার্ভার প্রক্সি HTTPS URL (সম্পূর্ণ ঐচ্ছিক)") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = NavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                singleLine = true
            )
        }

        Button(
            onClick = {
                onSaveSettings(
                    AssistantSettings(
                        wakePhrase = wakePhrase.ifBlank { "হ্যালো আবু উবাইদা" },
                        ttsEnabled = ttsEnabled,
                        continuousVoiceMode = continuousMode,
                        backgroundServiceEnabled = bgEnabled,
                        proxyEndpointUrl = proxyUrl,
                        speechLanguageTag = currentSettings.speechLanguageTag
                    )
                )
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = ImperialGold, contentColor = DeepNavyBg)
        ) {
            Text("সেটিংস সংরক্ষণ করুন")
        }
    }
}
