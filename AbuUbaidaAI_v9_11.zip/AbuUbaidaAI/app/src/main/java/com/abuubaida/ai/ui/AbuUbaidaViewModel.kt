package com.abuubaida.ai.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.net.Uri
import android.provider.Settings
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.abuubaida.ai.AppContainer
import com.abuubaida.ai.data.model.AssistantIntentCommand
import com.abuubaida.ai.data.model.AssistantSettings
import com.abuubaida.ai.data.model.ChatMessage
import com.abuubaida.ai.data.model.ContactItem
import com.abuubaida.ai.data.model.FacebookAccountInfo
import com.abuubaida.ai.data.model.FacebookPublishState
import com.abuubaida.ai.data.model.FacebookUploadRequest
import com.abuubaida.ai.data.model.InstalledAppInfo
import com.abuubaida.ai.data.model.IslamicCategory
import com.abuubaida.ai.data.model.MasterControlSettings
import com.abuubaida.ai.data.model.PendingSensitiveAction
import com.abuubaida.ai.data.model.PublishingMode
import com.abuubaida.ai.data.model.PublishingRecommendation
import com.abuubaida.ai.data.model.Screen
import com.abuubaida.ai.data.model.TrendResearchReport
import com.abuubaida.ai.data.model.VideoFormat
import com.abuubaida.ai.data.model.VideoProject
import com.abuubaida.ai.data.model.VoiceState
import com.abuubaida.ai.data.model.YouTubeUploadRequest
import com.abuubaida.ai.data.model.YouTubeVisibility
import com.abuubaida.ai.phone.BengaliCommandEngine
import com.abuubaida.ai.phone.BengaliPhoneticMatcher
import com.abuubaida.ai.voice.BackgroundVoiceService
import com.abuubaida.ai.youtube.OAuthFlowOutcome
import com.google.android.gms.auth.api.identity.AuthorizationResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AbuUbaidaViewModel(
    private val container: AppContainer
) : ViewModel() {

    private val _currentScreen = MutableStateFlow(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _settings = MutableStateFlow(container.securePrefsManager.loadSettings())
    val settings: StateFlow<AssistantSettings> = _settings.asStateFlow()

    private val _masterControls = MutableStateFlow(container.securePrefsManager.loadMasterControls())
    val masterControls: StateFlow<MasterControlSettings> = _masterControls.asStateFlow()

    private val _contacts = MutableStateFlow<List<ContactItem>>(emptyList())
    val contacts: StateFlow<List<ContactItem>> = _contacts.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _videoProject = MutableStateFlow<VideoProject?>(null)
    val videoProject: StateFlow<VideoProject?> = _videoProject.asStateFlow()

    private val _trendReport = MutableStateFlow<TrendResearchReport?>(null)
    val trendReport: StateFlow<TrendResearchReport?> = _trendReport.asStateFlow()

    private val _publishingRecommendation = MutableStateFlow<PublishingRecommendation?>(null)
    val publishingRecommendation: StateFlow<PublishingRecommendation?> = _publishingRecommendation.asStateFlow()

    private val _autonomousProgressBn = MutableStateFlow("")
    val autonomousProgressBn: StateFlow<String> = _autonomousProgressBn.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _statusBannerBn = MutableStateFlow<String?>(null)
    val statusBannerBn: StateFlow<String?> = _statusBannerBn.asStateFlow()

    private val _pendingAction = MutableStateFlow<PendingSensitiveAction?>(null)
    val pendingAction: StateFlow<PendingSensitiveAction?> = _pendingAction.asStateFlow()

    private val _youTubeConnected = MutableStateFlow(
        !container.youTubeStudioRepository.getSavedAccessToken().isNullOrBlank()
    )
    val youTubeConnected: StateFlow<Boolean> = _youTubeConnected.asStateFlow()

    private val _youTubeUploadRequest = MutableStateFlow(YouTubeUploadRequest())
    val youTubeUploadRequest: StateFlow<YouTubeUploadRequest> = _youTubeUploadRequest.asStateFlow()

    private val _facebookAccount = MutableStateFlow(container.facebookStudioRepository.getAccountInfo())
    val facebookAccount: StateFlow<FacebookAccountInfo> = _facebookAccount.asStateFlow()

    private val _facebookUploadRequest = MutableStateFlow(FacebookUploadRequest())
    val facebookUploadRequest: StateFlow<FacebookUploadRequest> = _facebookUploadRequest.asStateFlow()

    val voiceState: StateFlow<VoiceState> = container.voiceManager.voiceState
    val rmsLevel: StateFlow<Float> = container.voiceManager.rmsLevel
    val partialTranscript: StateFlow<String> = container.voiceManager.partialTranscript
    val ttsSupportedBn: StateFlow<Boolean> = container.voiceManager.ttsSupportedBn

    private var activeWorkflowJob: Job? = null

    init {
        val saved = container.securePrefsManager.loadChatHistory()
        if (saved.isEmpty()) {
            val welcome = ChatMessage(
                text = "আসসালামু আলাইকুম! আমি আবু উবাইদা AI — আপনার ইসলামিক কনটেন্ট ক্রিয়েটর ও বাংলা ভয়েস সহকারী। বলুন: 'আবু উবাইদা, একটি ইসলামিক ভিডিও তৈরি করো' বা 'আমার চ্যানেলের জন্য ভালো কনটেন্ট খুঁজে বের করো'।",
                isUser = false
            )
            _messages.value = listOf(welcome)
        } else {
            _messages.value = saved
        }
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _installedApps.value = container.phoneControlManager.getInstalledLauncherApps()
            } catch (_: Throwable) {
            }
            try {
                _contacts.value = container.phoneControlManager.loadContacts("")
            } catch (_: Throwable) {
            }
        }
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun clearBanner() {
        _statusBannerBn.value = null
    }

    fun showBanner(message: String) {
        _statusBannerBn.value = message
    }

    fun buildFallbackSpeechIntent(): Intent =
        container.voiceManager.buildBengaliSpeechIntent(languageTag = _settings.value.speechLanguageTag)

    fun startVoiceListening() {
        container.voiceManager.startListening(
            languageTag = _settings.value.speechLanguageTag,
            onResult = { spokenText ->
                handleUserPrompt(spokenText, speakReply = _settings.value.ttsEnabled)
            },
            onError = { errMsg ->
                _statusBannerBn.value = errMsg
            }
        )
    }

    fun stopVoiceListening() {
        container.voiceManager.stopListening()
    }

    fun speakText(text: String) {
        container.voiceManager.speak(text)
    }

    fun stopSpeaking() {
        container.voiceManager.stopSpeaking()
    }

    fun toggleContinuousVoiceMode(enabled: Boolean, context: Context) {
        updateSettings(_settings.value.copy(continuousVoiceMode = enabled), context)
    }

    fun toggleSpeechLanguage(languageTag: String, context: Context) {
        updateSettings(_settings.value.copy(speechLanguageTag = languageTag), context)
    }

    fun updateMasterControls(updated: MasterControlSettings) {
        _masterControls.value = updated
        container.securePrefsManager.saveMasterControls(updated)
        if (!updated.youTubeConnectionEnabled) {
            _statusBannerBn.value = "YouTube সংযোগ মাস্টার কন্ট্রোল থেকে বন্ধ করা হয়েছে।"
        } else if (!updated.facebookConnectionEnabled) {
            _statusBannerBn.value = "Facebook সংযোগ মাস্টার কন্ট্রোল থেকে বন্ধ করা হয়েছে।"
        } else {
            _statusBannerBn.value = "মাস্টার কন্ট্রোল ও গোপনীয়তা সেটিংস সংরক্ষিত হয়েছে।"
        }
    }

    fun emergencyStopAllBackgroundActivity(context: Context) {
        activeWorkflowJob?.cancel()
        activeWorkflowJob = null
        _isBusy.value = false
        _autonomousProgressBn.value = ""
        container.voiceManager.stopListening()
        container.voiceManager.stopSpeaking()
        container.voiceManager.setIdle()
        BackgroundVoiceService.stop(context)

        val safeSettings = _settings.value.copy(
            backgroundServiceEnabled = false,
            continuousVoiceMode = false
        )
        _settings.value = safeSettings
        container.securePrefsManager.saveSettings(safeSettings)

        val safeControls = _masterControls.value.copy(autoUploadEnabled = false)
        _masterControls.value = safeControls
        container.securePrefsManager.saveMasterControls(safeControls)

        _statusBannerBn.value = "সকল ব্যাকগ্রাউন্ড কার্যক্রম ও অটো-আপলোড তাৎক্ষণিকভাবে বন্ধ করা হয়েছে।"
    }

    fun wipeAllLocalData(context: Context) {
        emergencyStopAllBackgroundActivity(context)
        container.videoStudioRepository.wipeGeneratedLocalFiles()
        container.securePrefsManager.wipeAllLocalData()
        _youTubeConnected.value = false
        _facebookAccount.value = FacebookAccountInfo()
        _videoProject.value = null
        _trendReport.value = null
        _publishingRecommendation.value = null
        _youTubeUploadRequest.value = YouTubeUploadRequest()
        _facebookUploadRequest.value = FacebookUploadRequest()
        _settings.value = container.securePrefsManager.loadSettings()
        _masterControls.value = container.securePrefsManager.loadMasterControls()
        _messages.value = listOf(
            ChatMessage(
                text = "সব স্থানীয় ডেটা, টোকেন, চ্যাট ইতিহাস ও তৈরি করা ফাইল নিরাপদে মুছে ফেলা হয়েছে।",
                isUser = false
            )
        )
        _statusBannerBn.value = "সব স্থানীয় ডেটা ও অ্যাকাউন্ট সংযোগ সম্পূর্ণ মুছে ফেলা হয়েছে।"
    }

    private fun respondAndOptionallyContinue(reply: String, speakReply: Boolean, allowContinuous: Boolean = true) {
        appendMessage(ChatMessage(text = reply, isUser = false))
        if (speakReply) {
            val shouldContinue = allowContinuous && _settings.value.continuousVoiceMode
            container.voiceManager.speak(reply) {
                if (shouldContinue) {
                    startVoiceListening()
                }
            }
        } else {
            container.voiceManager.setIdle()
        }
    }

    fun handleUserPrompt(rawText: String, speakReply: Boolean = _settings.value.ttsEnabled) {
        val text = rawText.trim()
        if (text.isBlank()) return

        appendMessage(ChatMessage(text = text, isUser = true))

        when (val cmd = container.geminiRepository.parseBengaliDeviceCommand(text)) {
            is AssistantIntentCommand.ToggleFlashlight -> {
                val res = container.phoneControlManager.toggleFlashlight(cmd.enable)
                respondAndOptionallyContinue(res.getOrElse { it.localizedMessage ?: "টর্চলাইট চালানো যায়নি।" }, speakReply)
                return
            }

            is AssistantIntentCommand.ControlVolume -> {
                val res = container.phoneControlManager.adjustVolume(cmd.command)
                respondAndOptionallyContinue(res.getOrElse { it.localizedMessage ?: "সাউন্ড পরিবর্তন করা যায়নি।" }, speakReply)
                return
            }

            is AssistantIntentCommand.QueryTime -> {
                respondAndOptionallyContinue(container.phoneControlManager.getCurrentTimeBn(), speakReply)
                return
            }

            is AssistantIntentCommand.QueryDate -> {
                respondAndOptionallyContinue(container.phoneControlManager.getCurrentDateBn(), speakReply)
                return
            }

            is AssistantIntentCommand.QueryBattery -> {
                respondAndOptionallyContinue(container.phoneControlManager.getBatteryStatusBn(), speakReply)
                return
            }

            is AssistantIntentCommand.SearchYouTube -> {
                val res = container.phoneControlManager.searchYouTube(cmd.query)
                respondAndOptionallyContinue(res.getOrElse { it.localizedMessage ?: "ইউটিউব সার্চ খোলা যায়নি।" }, speakReply, allowContinuous = false)
                return
            }

            is AssistantIntentCommand.SearchGoogle -> {
                val res = container.phoneControlManager.searchGoogle(cmd.query)
                respondAndOptionallyContinue(res.getOrElse { it.localizedMessage ?: "গুগল সার্চ খোলা যায়নি।" }, speakReply, allowContinuous = false)
                return
            }

            is AssistantIntentCommand.NavigateScreen -> {
                _currentScreen.value = cmd.screen
                respondAndOptionallyContinue("${cmd.screen.titleBn} পর্দা খোলা হয়েছে।", speakReply)
                return
            }

            is AssistantIntentCommand.ResearchIslamicTrends -> {
                _currentScreen.value = Screen.TrendResearch
                runTrendResearch(speakSummary = speakReply)
                return
            }

            is AssistantIntentCommand.CreateVideoScript -> {
                _currentScreen.value = Screen.VideoStudio
                if (cmd.useTrends) {
                    runAutonomousDailyWorkflow(
                        uploadToYouTube = false,
                        uploadToFacebook = false,
                        scheduleForTomorrow = false,
                        customTopic = cmd.topic,
                        category = cmd.category,
                        speakResult = speakReply
                    )
                } else {
                    generateVideoStudioProject(
                        topic = cmd.topic,
                        category = cmd.category,
                        format = cmd.category.defaultFormat,
                        speakResult = speakReply
                    )
                }
                return
            }

            is AssistantIntentCommand.RunAutonomousDailyWorkflow -> {
                runAutonomousDailyWorkflow(
                    uploadToYouTube = cmd.uploadToYouTube,
                    uploadToFacebook = cmd.uploadToFacebook,
                    scheduleForTomorrow = cmd.scheduleForTomorrow,
                    customTopic = cmd.customTopic,
                    category = IslamicCategory.ISLAMIC_EDUCATION,
                    speakResult = speakReply
                )
                return
            }

            is AssistantIntentCommand.PublishCurrentToYouTube -> {
                publishCurrentProjectToYouTube(speakResult = speakReply)
                return
            }

            is AssistantIntentCommand.PublishCurrentToFacebook -> {
                publishCurrentProjectToFacebook(speakResult = speakReply)
                return
            }

            is AssistantIntentCommand.DirectAnswer -> {
                respondAndOptionallyContinue(cmd.replyBn, speakReply)
                return
            }

            is AssistantIntentCommand.CallContact -> {
                if (_contacts.value.isEmpty() && container.phoneControlManager.hasPermission(Manifest.permission.READ_CONTACTS)) {
                    refreshContacts()
                }
                val contact = BengaliPhoneticMatcher.findBestContact(cmd.target, _contacts.value)
                val digitsOnly = BengaliCommandEngine.normalizeDigits(cmd.target)
                    .filter { it.isDigit() || it == '+' }
                if (contact == null && digitsOnly.length < 3) {
                    val reply = if (!container.phoneControlManager.hasPermission(Manifest.permission.READ_CONTACTS)) {
                        "\"${cmd.target}\" নামে কন্টাক্ট খুঁজতে 'গোপনীয়তা ও কন্টাক্ট' থেকে Contacts অনুমতি দিন অথবা সরাসরি নম্বর বলুন।"
                    } else {
                        "আপনার ফোনের কন্টাক্টে \"${cmd.target}\" নামে কোনো নম্বর পাওয়া যায়নি (বাংলা ও ইংরেজি দুইভাবেই খোঁজা হয়েছে)।"
                    }
                    respondAndOptionallyContinue(reply, speakReply, allowContinuous = false)
                    return
                }
                val number = contact?.phoneNumber ?: digitsOnly
                val displayName = contact?.name ?: number
                _pendingAction.value = PendingSensitiveAction.CallPhone(displayName, number, directCall = true)
                respondAndOptionallyContinue("$displayName নম্বরে কল করার আগে আপনার নিশ্চিতকরণ প্রয়োজন।", speakReply, allowContinuous = false)
                return
            }

            is AssistantIntentCommand.ComposeSms -> {
                if (_contacts.value.isEmpty() && container.phoneControlManager.hasPermission(Manifest.permission.READ_CONTACTS)) {
                    refreshContacts()
                }
                val contact = BengaliPhoneticMatcher.findBestContact(cmd.target, _contacts.value)
                val digitsOnly = BengaliCommandEngine.normalizeDigits(cmd.target).filter { it.isDigit() || it == '+' }
                val number = contact?.phoneNumber ?: if (digitsOnly.length >= 3) digitsOnly else ""
                val name = contact?.name ?: cmd.target
                if (number.isNotBlank() && cmd.body.isNotBlank()) {
                    _pendingAction.value = PendingSensitiveAction.SendSms(name, number, cmd.body, useDirectApi = false)
                    respondAndOptionallyContinue("$name কে মেসেজ পাঠাতে নিশ্চিত করুন।", speakReply, allowContinuous = false)
                } else {
                    _currentScreen.value = Screen.Sms
                    respondAndOptionallyContinue("SMS পর্দা খোলা হয়েছে। প্রাপক ও বার্তা লিখে পাঠান।", speakReply, allowContinuous = false)
                }
                return
            }

            is AssistantIntentCommand.OpenApp -> {
                val res = container.phoneControlManager.launchAppByNameOrPackage(cmd.appName)
                respondAndOptionallyContinue(res.getOrElse { it.localizedMessage ?: "অ্যাপ খোলা যায়নি।" }, speakReply, allowContinuous = false)
                return
            }

            is AssistantIntentCommand.SetAlarm -> {
                val res = container.phoneControlManager.setAlarm(cmd.hour, cmd.minute, cmd.label)
                respondAndOptionallyContinue(res.getOrElse { it.localizedMessage ?: "অ্যালার্ম সেট করা যায়নি।" }, speakReply, allowContinuous = false)
                return
            }

            is AssistantIntentCommand.SetTimer -> {
                val res = container.phoneControlManager.setTimer(cmd.seconds, cmd.label)
                respondAndOptionallyContinue(res.getOrElse { it.localizedMessage ?: "টাইমার সেট করা যায়নি।" }, speakReply, allowContinuous = false)
                return
            }

            is AssistantIntentCommand.OpenSettings -> {
                val res = container.phoneControlManager.openAndroidSettings(cmd.settingsAction, cmd.labelBn)
                respondAndOptionallyContinue(res.getOrElse { "সেটিংস খোলা যায়নি।" }, speakReply, allowContinuous = false)
                return
            }

            AssistantIntentCommand.None -> Unit
        }

        if (!_masterControls.value.aiAssistantEnabled) {
            respondAndOptionallyContinue(
                "মাস্টার কন্ট্রোলে 'AI অ্যাসিস্ট্যান্ট' বন্ধ আছে। সাধারণ প্রশ্নের জন্য 'গোপনীয়তা ও কন্ট্রোল' থেকে চালু করুন।",
                speakReply,
                allowContinuous = false
            )
            return
        }

        viewModelScope.launch {
            _isBusy.value = true
            container.voiceManager.setProcessing()
            val result = container.geminiRepository.generateAssistantReply(text, _messages.value)
            _isBusy.value = false
            result.fold(
                onSuccess = { reply -> respondAndOptionallyContinue(reply, speakReply) },
                onFailure = { err ->
                    respondAndOptionallyContinue(err.localizedMessage ?: "উত্তর পেতে সমস্যা হয়েছে।", speakReply, allowContinuous = false)
                }
            )
        }
    }

    fun runTrendResearch(speakSummary: Boolean = false) {
        if (!_masterControls.value.trendResearchEnabled) {
            val msg = "মাস্টার কন্ট্রোলে 'ট্রেন্ড রিসার্চ' বন্ধ রাখা হয়েছে।"
            _statusBannerBn.value = msg
            if (speakSummary) respondAndOptionallyContinue(msg, speakReply = true, allowContinuous = false)
            return
        }
        activeWorkflowJob?.cancel()
        activeWorkflowJob = viewModelScope.launch {
            _isBusy.value = true
            val res = container.trendResearchRepository.researchIslamicTrends()
            _isBusy.value = false
            res.fold(
                onSuccess = { report ->
                    _trendReport.value = report
                    val topTopics = report.trends.take(3).joinToString(" | ") { it.topic }
                    val msg = "ট্রেন্ড রিসার্চ সম্পন্ন হয়েছে! প্রস্তাবিত ফরম্যাট: ${report.recommendedFormat.labelBn}। সেরা সময়: ${report.recommendedPublishTimeBn}। শীর্ষ বিষয়: $topTopics"
                    _statusBannerBn.value = "ট্রেন্ড রিসার্চ সম্পন্ন (${report.trends.size}টি বিষয়)।"
                    if (speakSummary) {
                        respondAndOptionallyContinue(msg, speakReply = _settings.value.ttsEnabled, allowContinuous = false)
                    }
                },
                onFailure = { err ->
                    val errMsg = err.localizedMessage ?: "ট্রেন্ড রিসার্চ ব্যর্থ।"
                    _statusBannerBn.value = errMsg
                    if (speakSummary) respondAndOptionallyContinue(errMsg, speakReply = true, allowContinuous = false)
                }
            )
        }
    }

    fun generateVideoStudioProject(
        topic: String,
        category: IslamicCategory = IslamicCategory.ISLAMIC_EDUCATION,
        format: VideoFormat = category.defaultFormat,
        speakResult: Boolean = false
    ) {
        if (!_masterControls.value.contentCreationEnabled) {
            val msg = "মাস্টার কন্ট্রোলে 'কন্টেন্ট তৈরি' বন্ধ আছে। 'গোপনীয়তা ও কন্ট্রোল' থেকে চালু করুন।"
            _statusBannerBn.value = msg
            if (speakResult) respondAndOptionallyContinue(msg, speakReply = true, allowContinuous = false)
            return
        }

        activeWorkflowJob?.cancel()
        activeWorkflowJob = viewModelScope.launch {
            _isBusy.value = true
            _autonomousProgressBn.value = "ধাপ ১/৪: কুরআন ও হাদিস সূত্র যাচাই ও স্ক্রিপ্ট তৈরি..."
            val res = container.videoStudioRepository.createProjectFromTopic(topic, category, format)
            res.fold(
                onSuccess = { project ->
                    applyCompletedProject(project)
                    _isBusy.value = false
                    _autonomousProgressBn.value = ""
                    val msg = "\"${project.topic}\" বিষয়ে যাচাইকৃত ইসলামিক স্ক্রিপ্ট, বাংলা SEO, থাম্বনেইল ও MP4 ভিডিও তৈরি হয়েছে এবং YouTube/Facebook স্টুডিওতে যুক্ত হয়েছে!"
                    _statusBannerBn.value = msg
                    if (speakResult) {
                        respondAndOptionallyContinue(msg, speakReply = _settings.value.ttsEnabled, allowContinuous = false)
                    }
                },
                onFailure = { err ->
                    _isBusy.value = false
                    _autonomousProgressBn.value = ""
                    val errMsg = err.localizedMessage ?: "ভিডিও প্রজেক্ট তৈরি ব্যর্থ।"
                    _statusBannerBn.value = errMsg
                    if (speakResult) respondAndOptionallyContinue(errMsg, speakReply = true, allowContinuous = false)
                }
            )
        }
    }

    fun runAutonomousDailyWorkflow(
        uploadToYouTube: Boolean = true,
        uploadToFacebook: Boolean = false,
        scheduleForTomorrow: Boolean = false,
        customTopic: String = "",
        category: IslamicCategory = IslamicCategory.ISLAMIC_EDUCATION,
        speakResult: Boolean = true
    ) {
        val controls = _masterControls.value
        if (!controls.contentCreationEnabled) {
            val msg = "মাস্টার কন্ট্রোলে 'কন্টেন্ট তৈরি' বন্ধ আছে, তাই স্বয়ংক্রিয় ভিডিও তৈরি চালানো যায়নি।"
            _statusBannerBn.value = msg
            if (speakResult) respondAndOptionallyContinue(msg, speakReply = true, allowContinuous = false)
            return
        }

        activeWorkflowJob?.cancel()
        activeWorkflowJob = viewModelScope.launch {
            _isBusy.value = true
            _currentScreen.value = Screen.VideoStudio

            // Step 1: Research Trends if enabled
            var report: TrendResearchReport? = _trendReport.value
            if (controls.trendResearchEnabled) {
                _autonomousProgressBn.value = "ধাপ ১/৫: সাম্প্রতিক ইসলামিক ট্রেন্ড ও চ্যানেল ডেটা বিশ্লেষণ..."
                container.trendResearchRepository.researchIslamicTrends().onSuccess {
                    report = it
                    _trendReport.value = it
                }
            }

            // Step 2: Select topic & category
            val pickedTrend = report?.trends?.firstOrNull()
            val resolvedTopic = customTopic.ifBlank { pickedTrend?.topic.orEmpty() }
            val resolvedCategory = if (customTopic.isBlank() && pickedTrend != null) pickedTrend.suggestedCategory else category
            val resolvedFormat = resolvedCategory.defaultFormat

            // Step 3 & 4: Verify Islamic content + Create MP4 + Thumbnail + SEO
            _autonomousProgressBn.value = "ধাপ ২/৫: কুরআন-হাদিস যাচাই ও MP4 ভিডিও + থাম্বনেইল রেন্ডারিং..."
            val createRes = container.videoStudioRepository.createProjectFromTopic(resolvedTopic, resolvedCategory, resolvedFormat)
            if (createRes.isFailure) {
                _isBusy.value = false
                _autonomousProgressBn.value = ""
                val errMsg = createRes.exceptionOrNull()?.localizedMessage ?: "অটোনোমাস ভিডিও তৈরি ব্যর্থ।"
                _statusBannerBn.value = errMsg
                if (speakResult) respondAndOptionallyContinue(errMsg, speakReply = true, allowContinuous = false)
                return@launch
            }

            val project = createRes.getOrThrow()

            // Step 5: Smart Publishing evaluation
            _autonomousProgressBn.value = "ধাপ ৩/৫: স্মার্ট পাবলিশিং সময় ও মান যাচাই..."
            val plan = container.smartPublishingManager.evaluateBestPublishingPlan(
                project = project,
                trendReport = report,
                forceTomorrow = scheduleForTomorrow
            )
            _publishingRecommendation.value = plan
            val finalProject = project.copy(
                recommendedPublishMillis = plan.targetTimeMillis,
                recommendedPublishLabelBn = plan.targetTimeLabelBn
            )
            applyCompletedProject(finalProject, plan)

            // Step 6: Respect privacy & publishing controls before uploading
            val mode = controls.publishingMode
            val shouldSchedule = scheduleForTomorrow || mode == PublishingMode.SCHEDULE_AUTOMATICALLY

            if (uploadToYouTube) {
                if (!controls.youTubeConnectionEnabled) {
                    _isBusy.value = false
                    _autonomousProgressBn.value = ""
                    val msg = "\"${finalProject.topic}\" ভিডিও ও থাম্বনেইল তৈরি হয়েছে! তবে মাস্টার কন্ট্রোলে YouTube সংযোগ বন্ধ থাকায় আপলোড করা হয়নি।"
                    _statusBannerBn.value = msg
                    if (speakResult) respondAndOptionallyContinue(msg, speakReply = _settings.value.ttsEnabled, allowContinuous = false)
                    return@launch
                }
                if (!_youTubeConnected.value) {
                    _isBusy.value = false
                    _autonomousProgressBn.value = ""
                    _currentScreen.value = Screen.YouTubeStudio
                    val msg = "\"${finalProject.topic}\" সম্পূর্ণ ভিডিও তৈরি হয়েছে এবং YouTube স্টুডিওতে যুক্ত হয়েছে। তবে আপনার Google YouTube অ্যাকাউন্ট এখনো সংযুক্ত নয়—'Google দিয়ে সংযুক্ত করুন' বাটনে চাপ দিন।"
                    _statusBannerBn.value = msg
                    if (speakResult) respondAndOptionallyContinue(msg, speakReply = _settings.value.ttsEnabled, allowContinuous = false)
                    return@launch
                }

                val ytReq = _youTubeUploadRequest.value.copy(
                    visibility = if (mode == PublishingMode.SAVE_AS_DRAFT || shouldSchedule) YouTubeVisibility.PRIVATE else YouTubeVisibility.PUBLIC,
                    scheduledPublishIsoUtc = if (shouldSchedule) plan.targetIsoUtc else "",
                    scheduledLabelBn = if (shouldSchedule) plan.targetTimeLabelBn else ""
                )
                _youTubeUploadRequest.value = ytReq

                if (!finalProject.accuracyReview.passed || !controls.autoUploadEnabled || mode == PublishingMode.ASK_BEFORE_PUBLISHING) {
                    _isBusy.value = false
                    _autonomousProgressBn.value = ""
                    _currentScreen.value = Screen.YouTubeStudio
                    _pendingAction.value = PendingSensitiveAction.PublishYouTube(ytReq)
                    val msg = "\"${finalProject.topic}\" তৈরি হয়েছে (${plan.targetTimeLabelBn})। আপনার গোপনীয়তা সেটিংস অনুযায়ী প্রকাশের আগে নিশ্চিতকরণ ডায়ালগ খোলা হয়েছে।"
                    _statusBannerBn.value = msg
                    if (speakResult) respondAndOptionallyContinue(msg, speakReply = _settings.value.ttsEnabled, allowContinuous = false)
                    return@launch
                }

                _autonomousProgressBn.value = "ধাপ ৪/৫: অনুমোদিত YouTube চ্যানেলে আপলোড চলছে..."
                val uploadRes = container.youTubeStudioRepository.uploadVideoToYouTube(ytReq)
                _isBusy.value = false
                _autonomousProgressBn.value = ""
                uploadRes.fold(
                    onSuccess = { (vid, statusMsg) ->
                        _youTubeUploadRequest.value = ytReq.copy(lastUploadedVideoId = vid, lastStatusReportBn = statusMsg)
                        _statusBannerBn.value = statusMsg
                        if (speakResult) respondAndOptionallyContinue(statusMsg, speakReply = _settings.value.ttsEnabled, allowContinuous = false)
                    },
                    onFailure = { err ->
                        val msg = err.localizedMessage ?: "YouTube আপলোড ব্যর্থ।"
                        _statusBannerBn.value = msg
                        if (speakResult) respondAndOptionallyContinue(msg, speakReply = _settings.value.ttsEnabled, allowContinuous = false)
                    }
                )
                return@launch
            }

            if (uploadToFacebook) {
                if (!controls.facebookConnectionEnabled || !_facebookAccount.value.hasAccessToken) {
                    _isBusy.value = false
                    _autonomousProgressBn.value = ""
                    _currentScreen.value = Screen.FacebookStudio
                    val msg = "\"${finalProject.topic}\" ভিডিও তৈরি হয়েছে। Facebook পেজ সংযুক্ত হলে এখান থেকেই সরাসরি প্রকাশ করতে পারবেন।"
                    _statusBannerBn.value = msg
                    if (speakResult) respondAndOptionallyContinue(msg, speakReply = _settings.value.ttsEnabled, allowContinuous = false)
                    return@launch
                }
                val fbReq = _facebookUploadRequest.value.copy(
                    publishState = when {
                        shouldSchedule -> FacebookPublishState.SCHEDULE
                        mode == PublishingMode.SAVE_AS_DRAFT -> FacebookPublishState.DRAFT
                        else -> FacebookPublishState.PUBLISH_NOW
                    },
                    scheduledUnixSeconds = if (shouldSchedule) plan.targetUnixSeconds else null,
                    scheduledLabelBn = if (shouldSchedule) plan.targetTimeLabelBn else ""
                )
                _facebookUploadRequest.value = fbReq
                _isBusy.value = false
                _autonomousProgressBn.value = ""
                _currentScreen.value = Screen.FacebookStudio
                _pendingAction.value = PendingSensitiveAction.PublishFacebook(fbReq)
                val msg = "\"${finalProject.topic}\" ভিডিও Facebook পেজে প্রকাশের জন্য প্রস্তুত—নিশ্চিতকরণ দিন।"
                _statusBannerBn.value = msg
                if (speakResult) respondAndOptionallyContinue(msg, speakReply = _settings.value.ttsEnabled, allowContinuous = false)
                return@launch
            }

            _isBusy.value = false
            _autonomousProgressBn.value = ""
            val msg = "আজকের ট্রেন্ড ও ইসলামিক যাচাইকরণসহ \"${finalProject.topic}\" ভিডিও, থাম্বনেইল এবং SEO সম্পন্ন হয়েছে!"
            _statusBannerBn.value = msg
            if (speakResult) respondAndOptionallyContinue(msg, speakReply = _settings.value.ttsEnabled, allowContinuous = false)
        }
    }

    private fun applyCompletedProject(
        project: VideoProject,
        plan: PublishingRecommendation? = null
    ) {
        _videoProject.value = project
        val evaluatedPlan = plan ?: container.smartPublishingManager.evaluateBestPublishingPlan(project, _trendReport.value)
        _publishingRecommendation.value = evaluatedPlan

        val mp4Uri = project.renderedMp4UriString
        val displayName = if (mp4Uri.isNotBlank()) {
            container.youTubeStudioRepository.resolveFileDisplayName(Uri.parse(mp4Uri))
        } else {
            _youTubeUploadRequest.value.videoDisplayName
        }

        _youTubeUploadRequest.value = _youTubeUploadRequest.value.copy(
            videoUriString = mp4Uri.ifBlank { _youTubeUploadRequest.value.videoUriString },
            videoDisplayName = displayName,
            thumbnailLocalPath = project.thumbnailLocalPath,
            title = project.seoTitle,
            description = project.seoDescription,
            tags = project.seoTags,
            scheduledLabelBn = evaluatedPlan.targetTimeLabelBn
        )

        _facebookUploadRequest.value = _facebookUploadRequest.value.copy(
            videoUriString = mp4Uri.ifBlank { _facebookUploadRequest.value.videoUriString },
            videoDisplayName = displayName,
            title = project.seoTitle,
            caption = project.seoDescription,
            hashtags = project.hashtags,
            isReel = project.format == VideoFormat.SHORTS_9_16,
            scheduledUnixSeconds = evaluatedPlan.targetUnixSeconds,
            scheduledLabelBn = evaluatedPlan.targetTimeLabelBn
        )
    }

    private fun publishCurrentProjectToYouTube(speakResult: Boolean) {
        if (!_masterControls.value.youTubeConnectionEnabled) {
            val msg = "মাস্টার কন্ট্রোলে YouTube সংযোগ বন্ধ আছে।"
            _statusBannerBn.value = msg
            if (speakResult) respondAndOptionallyContinue(msg, speakReply = true, allowContinuous = false)
            return
        }
        val req = _youTubeUploadRequest.value
        if (req.videoUriString.isBlank()) {
            runAutonomousDailyWorkflow(uploadToYouTube = true, uploadToFacebook = false, speakResult = speakResult)
            return
        }
        _currentScreen.value = Screen.YouTubeStudio
        if (!_youTubeConnected.value) {
            val msg = "আগে YouTube স্টুডিও থেকে আপনার Google অ্যাকাউন্ট সংযুক্ত করুন।"
            _statusBannerBn.value = msg
            if (speakResult) respondAndOptionallyContinue(msg, speakReply = true, allowContinuous = false)
            return
        }
        _pendingAction.value = PendingSensitiveAction.PublishYouTube(req)
        if (speakResult) {
            respondAndOptionallyContinue("YouTube-এ আপলোডের আগে নিশ্চিতকরণ ডায়ালগ দেখানো হয়েছে।", speakReply = true, allowContinuous = false)
        }
    }

    private fun publishCurrentProjectToFacebook(speakResult: Boolean) {
        if (!_masterControls.value.facebookConnectionEnabled) {
            val msg = "মাস্টার কন্ট্রোলে Facebook সংযোগ বন্ধ আছে।"
            _statusBannerBn.value = msg
            if (speakResult) respondAndOptionallyContinue(msg, speakReply = true, allowContinuous = false)
            return
        }
        val req = _facebookUploadRequest.value
        if (req.videoUriString.isBlank()) {
            runAutonomousDailyWorkflow(uploadToYouTube = false, uploadToFacebook = true, speakResult = speakResult)
            return
        }
        _currentScreen.value = Screen.FacebookStudio
        if (!_facebookAccount.value.hasAccessToken) {
            val msg = "আগে Facebook স্টুডিও থেকে আপনার পেজ ও Meta Access Token সংযুক্ত করুন।"
            _statusBannerBn.value = msg
            if (speakResult) respondAndOptionallyContinue(msg, speakReply = true, allowContinuous = false)
            return
        }
        _pendingAction.value = PendingSensitiveAction.PublishFacebook(req)
        if (speakResult) {
            respondAndOptionallyContinue("Facebook পেজে প্রকাশের আগে নিশ্চিতকরণ ডায়ালগ দেখানো হয়েছে।", speakReply = true, allowContinuous = false)
        }
    }

    private fun appendMessage(msg: ChatMessage) {
        val updated = _messages.value + msg
        _messages.value = updated
        container.securePrefsManager.saveChatHistory(updated)
    }

    fun clearChatHistory() {
        container.securePrefsManager.clearChatHistory()
        _messages.value = listOf(
            ChatMessage(
                text = "চ্যাট ইতিহাস পরিষ্কার করা হয়েছে। আমি আবু উবাইদা AI — নতুন কোনো নির্দেশ বা প্রশ্ন করুন।",
                isUser = false
            )
        )
    }

    fun refreshContacts(query: String = "") {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _contacts.value = container.phoneControlManager.loadContacts(query)
            } catch (_: Throwable) {
            }
        }
    }

    fun refreshInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _installedApps.value = container.phoneControlManager.getInstalledLauncherApps()
            } catch (_: Throwable) {
            }
        }
    }

    fun launchInstalledApp(appNameOrPackage: String) {
        val res = container.phoneControlManager.launchAppByNameOrPackage(appNameOrPackage)
        _statusBannerBn.value = res.getOrElse { it.localizedMessage ?: "অ্যাপ চালু করা যায়নি।" }
    }

    fun openAndroidSettings(action: String = Settings.ACTION_SETTINGS) {
        val res = container.phoneControlManager.openAndroidSettings(action)
        _statusBannerBn.value = res.getOrElse { it.localizedMessage ?: "সেটিংস খোলা যায়নি।" }
    }

    fun setAlarm(hour: Int, minute: Int, label: String) {
        val res = container.phoneControlManager.setAlarm(hour, minute, label)
        _statusBannerBn.value = res.getOrElse { it.localizedMessage ?: "অ্যালার্ম সেট করা যায়নি।" }
    }

    fun requestCallConfirmation(displayName: String, phoneNumber: String, directCall: Boolean) {
        _pendingAction.value = PendingSensitiveAction.CallPhone(displayName, phoneNumber, directCall)
    }

    fun requestSmsConfirmation(recipientName: String, phoneNumber: String, message: String, useDirectApi: Boolean) {
        _pendingAction.value = PendingSensitiveAction.SendSms(recipientName, phoneNumber, message, useDirectApi)
    }

    fun requestYouTubePublishConfirmation(request: YouTubeUploadRequest) {
        if (!_masterControls.value.youTubeConnectionEnabled) {
            _statusBannerBn.value = "মাস্টার কন্ট্রোলে YouTube সংযোগ বন্ধ আছে।"
            return
        }
        _pendingAction.value = PendingSensitiveAction.PublishYouTube(request)
    }

    fun requestFacebookPublishConfirmation(request: FacebookUploadRequest) {
        if (!_masterControls.value.facebookConnectionEnabled) {
            _statusBannerBn.value = "মাস্টার কন্ট্রোলে Facebook সংযোগ বন্ধ আছে।"
            return
        }
        _pendingAction.value = PendingSensitiveAction.PublishFacebook(request)
    }

    fun dismissPendingAction() {
        _pendingAction.value = null
    }

    fun confirmPendingAction() {
        val action = _pendingAction.value ?: return
        _pendingAction.value = null
        when (action) {
            is PendingSensitiveAction.CallPhone -> {
                val res = container.phoneControlManager.placeCall(action.phoneNumber, action.directCall)
                _statusBannerBn.value = res.getOrElse { it.localizedMessage ?: "কল করা যায়নি।" }
            }

            is PendingSensitiveAction.SendSms -> {
                val res = container.phoneControlManager.sendSms(action.phoneNumber, action.message, action.useDirectApi)
                _statusBannerBn.value = res.getOrElse { it.localizedMessage ?: "SMS পাঠানো যায়নি।" }
            }

            is PendingSensitiveAction.PublishYouTube -> {
                viewModelScope.launch {
                    _isBusy.value = true
                    val res = container.youTubeStudioRepository.uploadVideoToYouTube(action.request)
                    _isBusy.value = false
                    res.fold(
                        onSuccess = { (videoId, msg) ->
                            _youTubeUploadRequest.value = _youTubeUploadRequest.value.copy(
                                lastUploadedVideoId = videoId,
                                lastStatusReportBn = msg
                            )
                            _statusBannerBn.value = msg
                        },
                        onFailure = { err ->
                            _statusBannerBn.value = err.localizedMessage ?: "YouTube আপলোড ব্যর্থ।"
                        }
                    )
                }
            }

            is PendingSensitiveAction.PublishFacebook -> {
                viewModelScope.launch {
                    _isBusy.value = true
                    val res = container.facebookStudioRepository.publishVideoToPage(action.request)
                    _isBusy.value = false
                    res.fold(
                        onSuccess = { (videoId, msg) ->
                            _facebookUploadRequest.value = _facebookUploadRequest.value.copy(
                                lastPublishedVideoId = videoId,
                                lastStatusReportBn = msg
                            )
                            _statusBannerBn.value = msg
                        },
                        onFailure = { err ->
                            _statusBannerBn.value = err.localizedMessage ?: "Facebook প্রকাশ ব্যর্থ।"
                        }
                    )
                }
            }
        }
    }

    fun checkYouTubeUploadStatus(videoId: String) {
        viewModelScope.launch {
            _isBusy.value = true
            val res = container.youTubeStudioRepository.checkVideoStatus(videoId)
            _isBusy.value = false
            res.fold(
                onSuccess = { status ->
                    _youTubeUploadRequest.value = _youTubeUploadRequest.value.copy(lastStatusReportBn = status)
                    _statusBannerBn.value = status
                },
                onFailure = { err -> _statusBannerBn.value = err.localizedMessage ?: "স্ট্যাটাস পরীক্ষা ব্যর্থ।" }
            )
        }
    }

    fun connectFacebookPage(pageId: String, pageAccessToken: String) {
        viewModelScope.launch {
            _isBusy.value = true
            val res = container.facebookStudioRepository.verifyAndSavePageToken(pageId, pageAccessToken)
            _isBusy.value = false
            res.fold(
                onSuccess = { info ->
                    _facebookAccount.value = info
                    _statusBannerBn.value = "Facebook পেজ '${info.pageName}' সফলভাবে সংযুক্ত হয়েছে!"
                },
                onFailure = { err ->
                    _statusBannerBn.value = err.localizedMessage ?: "Facebook সংযোগ ব্যর্থ।"
                }
            )
        }
    }

    fun disconnectFacebookPage() {
        container.facebookStudioRepository.disconnectPage()
        _facebookAccount.value = FacebookAccountInfo()
        _statusBannerBn.value = "Facebook পেজ সংযোগ বিচ্ছিন্ন করা হয়েছে।"
    }

    fun getSavedMetaAppId(): String = container.facebookStudioRepository.getSavedMetaAppId()

    fun buildMetaOAuthUrl(metaAppId: String): String? {
        container.facebookStudioRepository.saveMetaAppId(metaAppId)
        return container.facebookStudioRepository.buildOfficialMetaOAuthUrl(metaAppId)
    }

    fun checkFacebookUploadStatus(videoId: String) {
        viewModelScope.launch {
            _isBusy.value = true
            val res = container.facebookStudioRepository.checkVideoStatus(videoId)
            _isBusy.value = false
            res.fold(
                onSuccess = { status ->
                    _facebookUploadRequest.value = _facebookUploadRequest.value.copy(lastStatusReportBn = status)
                    _statusBannerBn.value = status
                },
                onFailure = { err -> _statusBannerBn.value = err.localizedMessage ?: "স্ট্যাটাস পরীক্ষা ব্যর্থ।" }
            )
        }
    }

    fun exportVideoMp4OrScript() {
        val project = _videoProject.value ?: return
        viewModelScope.launch {
            _isBusy.value = true
            val mp4Res = container.videoStudioRepository.exportMp4IfConnected(project)
            mp4Res.fold(
                onSuccess = { uri ->
                    _isBusy.value = false
                    _statusBannerBn.value = "MP4 ভিডিও সংরক্ষিত হয়েছে: $uri"
                },
                onFailure = { mp4Err ->
                    val scriptRes = container.videoStudioRepository.exportScriptTextPackage(project)
                    _isBusy.value = false
                    val scriptNote = scriptRes.fold(
                        onSuccess = { file -> "\nস্ক্রিপ্ট ফাইল সংরক্ষিত হয়েছে: ${file.name}" },
                        onFailure = { "" }
                    )
                    _statusBannerBn.value = (mp4Err.localizedMessage ?: "") + scriptNote
                }
            )
        }
    }

    fun updateYouTubeRequest(updater: (YouTubeUploadRequest) -> YouTubeUploadRequest) {
        _youTubeUploadRequest.value = updater(_youTubeUploadRequest.value)
    }

    fun updateFacebookRequest(updater: (FacebookUploadRequest) -> FacebookUploadRequest) {
        _facebookUploadRequest.value = updater(_facebookUploadRequest.value)
    }

    fun onVideoFilePicked(uri: Uri) {
        val displayName = container.youTubeStudioRepository.resolveFileDisplayName(uri)
        _youTubeUploadRequest.value = _youTubeUploadRequest.value.copy(
            videoUriString = uri.toString(),
            videoDisplayName = displayName
        )
        _facebookUploadRequest.value = _facebookUploadRequest.value.copy(
            videoUriString = uri.toString(),
            videoDisplayName = displayName
        )
    }

    fun connectYouTubeOAuth(activity: Activity, onNeedsConsent: (IntentSender) -> Unit) {
        viewModelScope.launch {
            _isBusy.value = true
            val outcome = container.youTubeStudioRepository.requestYouTubeAuthorization(activity)
            _isBusy.value = false
            when (outcome) {
                is OAuthFlowOutcome.Authorized -> {
                    _youTubeConnected.value = true
                    _statusBannerBn.value = "Google OAuth সফলভাবে YouTube-এর সাথে যুক্ত হয়েছে।"
                }
                is OAuthFlowOutcome.NeedsConsent -> onNeedsConsent(outcome.intentSender)
                is OAuthFlowOutcome.Failed -> _statusBannerBn.value = outcome.errorBn
            }
        }
    }

    fun handleYouTubeConsentResult(authResult: AuthorizationResult?) {
        val res = container.youTubeStudioRepository.handleAuthorizationResultIntent(authResult)
        res.fold(
            onSuccess = {
                _youTubeConnected.value = true
                _statusBannerBn.value = "YouTube অনুমতি সফলভাবে অনুমোদিত হয়েছে।"
            },
            onFailure = { err -> _statusBannerBn.value = err.localizedMessage ?: "YouTube OAuth ব্যর্থ।" }
        )
    }

    fun disconnectYouTube() {
        container.youTubeStudioRepository.disconnectAccount()
        _youTubeConnected.value = false
        _statusBannerBn.value = "YouTube অ্যাকাউন্ট সংযোগ বিচ্ছিন্ন করা হয়েছে।"
    }

    fun updateSettings(newSettings: AssistantSettings, context: Context) {
        _settings.value = newSettings
        container.securePrefsManager.saveSettings(newSettings)
        if (newSettings.backgroundServiceEnabled) {
            BackgroundVoiceService.start(context)
        } else {
            BackgroundVoiceService.stop(context)
        }
        _statusBannerBn.value = "সেটিংস নিরাপদে সংরক্ষিত হয়েছে।"
    }

    fun isFirebaseConfigured(): Boolean = container.geminiRepository.isFirebaseConfigured()
    fun isKeystoreEncrypted(): Boolean = container.securePrefsManager.isKeystoreEncrypted
    fun isSpeechRecognitionAvailable(): Boolean = container.voiceManager.isSpeechRecognitionAvailable()
    fun isMp4ProviderConnected(): Boolean = container.videoStudioRepository.isMp4ProviderConnected()
    fun openAssistantRoleSettings() = container.phoneControlManager.openAssistantRoleSettings()
    fun openBatteryOptimizationSettings() = container.phoneControlManager.openBatteryOptimizationSettings()
    fun openAppPermissionSettings() = container.phoneControlManager.openAppPermissionSettings()

    override fun onCleared() {
        container.voiceManager.release()
        super.onCleared()
    }

    class Factory(private val container: AppContainer) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return AbuUbaidaViewModel(container) as T
        }
    }
}
