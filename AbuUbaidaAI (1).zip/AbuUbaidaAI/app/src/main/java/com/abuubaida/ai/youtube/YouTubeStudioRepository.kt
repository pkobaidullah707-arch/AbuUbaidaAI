package com.abuubaida.ai.youtube

import android.app.Activity
import android.content.Context
import android.content.IntentSender
import android.net.Uri
import android.provider.OpenableColumns
import com.abuubaida.ai.data.model.YouTubeUploadRequest
import com.abuubaida.ai.data.security.SecurePrefsManager
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okio.BufferedSink
import okio.source
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

sealed class OAuthFlowOutcome {
    data class Authorized(val accessToken: String) : OAuthFlowOutcome()
    data class NeedsConsent(val intentSender: IntentSender) : OAuthFlowOutcome()
    data class Failed(val errorBn: String) : OAuthFlowOutcome()
}

class YouTubeStudioRepository(
    private val context: Context,
    private val securePrefsManager: SecurePrefsManager
) {
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(180, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    fun getSavedAccessToken(): String? = securePrefsManager.getOAuthAccessToken()

    fun disconnectAccount() {
        securePrefsManager.saveOAuthAccessToken(null)
    }

    suspend fun requestYouTubeAuthorization(activity: Activity): OAuthFlowOutcome =
        suspendCancellableCoroutine { cont ->
            val request = AuthorizationRequest.builder()
                .setRequestedScopes(
                    listOf(
                        Scope(SCOPE_YOUTUBE_UPLOAD),
                        Scope(SCOPE_YOUTUBE_READONLY)
                    )
                )
                .build()

            Identity.getAuthorizationClient(activity)
                .authorize(request)
                .addOnSuccessListener { result ->
                    if (result.hasResolution()) {
                        val pendingIntent = result.pendingIntent
                        if (pendingIntent != null) {
                            cont.resume(OAuthFlowOutcome.NeedsConsent(pendingIntent.intentSender))
                        } else {
                            cont.resume(OAuthFlowOutcome.Failed("Google OAuth অনুমোদন পর্দা খোলা যায়নি।"))
                        }
                    } else {
                        val token = result.accessToken
                        if (!token.isNullOrBlank()) {
                            securePrefsManager.saveOAuthAccessToken(token)
                            cont.resume(OAuthFlowOutcome.Authorized(token))
                        } else {
                            cont.resume(OAuthFlowOutcome.Failed("OAuth অ্যাক্সেস টোকেন পাওয়া যায়নি।"))
                        }
                    }
                }
                .addOnFailureListener { e ->
                    cont.resume(
                        OAuthFlowOutcome.Failed(
                            "Google OAuth ব্যর্থ হয়েছে (${e.localizedMessage ?: "Google Cloud OAuth কনফিগারেশন পরীক্ষা করুন"})।"
                        )
                    )
                }
        }

    fun handleAuthorizationResultIntent(authResult: AuthorizationResult?): Result<String> {
        val token = authResult?.accessToken
        return if (!token.isNullOrBlank()) {
            securePrefsManager.saveOAuthAccessToken(token)
            Result.success(token)
        } else {
            Result.failure(IllegalStateException("YouTube OAuth অনুমোদন সম্পন্ন হয়নি।"))
        }
    }

    fun resolveFileDisplayName(uri: Uri): String {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && nameIdx >= 0) {
                return cursor.getString(nameIdx)
            }
        }
        return uri.lastPathSegment ?: "video.mp4"
    }

    suspend fun uploadVideoToYouTube(uploadRequest: YouTubeUploadRequest): Result<String> =
        withContext(Dispatchers.IO) {
            val token = securePrefsManager.getOAuthAccessToken()
            if (token.isNullOrBlank()) {
                return@withContext Result.failure(
                    IllegalStateException("আগে Google অ্যাকাউন্ট দিয়ে YouTube OAuth সংযুক্ত করুন।")
                )
            }

            if (uploadRequest.videoUriString.isBlank()) {
                return@withContext Result.failure(
                    IllegalArgumentException("আপলোডের জন্য একটি ভিডিও ফাইল নির্বাচন করুন।")
                )
            }

            val videoUri = Uri.parse(uploadRequest.videoUriString)
            val mimeType = context.contentResolver.getType(videoUri) ?: "video/mp4"

            try {
                // Step 1: Initiate YouTube Data API v3 Resumable Upload Session
                val metadata = JSONObject().apply {
                    put("snippet", JSONObject().apply {
                        put("title", uploadRequest.title.ifBlank { "আবু উবাইদা AI ভিডিও" })
                        put("description", uploadRequest.description)
                        put("tags", JSONArray(uploadRequest.tags))
                    })
                    put("status", JSONObject().apply {
                        put("privacyStatus", uploadRequest.visibility.apiValue)
                    })
                }

                val initReq = Request.Builder()
                    .url(YOUTUBE_RESUMABLE_UPLOAD_URL)
                    .addHeader("Authorization", "Bearer $token")
                    .addHeader("X-Upload-Content-Type", mimeType)
                    .post(metadata.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                    .build()

                val uploadSessionUrl = httpClient.newCall(initReq).execute().use { resp ->
                    if (!resp.isSuccessful) {
                        return@withContext Result.failure(
                            IllegalStateException("YouTube আপলোড সেশন শুরু ব্যর্থ (${resp.code})। টোকেন বা স্কোপ যাচাই করুন।")
                        )
                    }
                    resp.header("Location")
                } ?: return@withContext Result.failure(
                    IllegalStateException("YouTube থেকে আপলোড সেশন URL পাওয়া যায়নি।")
                )

                // Step 2: Stream Video Content directly from ContentResolver (memory-safe)
                val streamingBody = object : RequestBody() {
                    override fun contentType() = mimeType.toMediaType()
                    override fun writeTo(sink: BufferedSink) {
                        context.contentResolver.openInputStream(videoUri)?.use { input ->
                            sink.writeAll(input.source())
                        } ?: throw IllegalStateException("ভিডিও ফাইল পড়া যাচ্ছে না।")
                    }
                }

                val putReq = Request.Builder()
                    .url(uploadSessionUrl)
                    .put(streamingBody)
                    .build()

                httpClient.newCall(putReq).execute().use { uploadResp ->
                    val bodyText = uploadResp.body?.string().orEmpty()
                    if (!uploadResp.isSuccessful) {
                        return@withContext Result.failure(
                            IllegalStateException("ভিডিও আপলোড ব্যর্থ (${uploadResp.code})")
                        )
                    }
                    val videoId = JSONObject(bodyText).optString("id")
                    val msg = if (videoId.isNotBlank()) {
                        "ভিডিও সফলভাবে YouTube-এ আপলোড হয়েছে! ভিডিও আইডি: $videoId (${uploadRequest.visibility.labelBn})"
                    } else {
                        "ভিডিও আপলোড সম্পন্ন হয়েছে (${uploadRequest.visibility.labelBn})।"
                    }
                    Result.success(msg)
                }
            } catch (e: Exception) {
                Result.failure(
                    IllegalStateException("YouTube আপলোডে ত্রুটি: ${e.localizedMessage ?: "অজানা সমস্যা"}")
                )
            }
        }

    companion object {
        private const val SCOPE_YOUTUBE_UPLOAD = "https://www.googleapis.com/auth/youtube.upload"
        private const val SCOPE_YOUTUBE_READONLY = "https://www.googleapis.com/auth/youtube.readonly"
        private const val YOUTUBE_RESUMABLE_UPLOAD_URL =
            "https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status"
    }
}
