package com.abuubaida.ai.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MovieCreation
import androidx.compose.material.icons.rounded.PhoneInTalk
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Sms
import androidx.compose.material.icons.rounded.Upload
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.abuubaida.ai.data.model.Screen
import com.abuubaida.ai.data.model.VoiceState
import com.abuubaida.ai.ui.components.AbuUbaidaLogo
import com.abuubaida.ai.ui.components.AnimatedVoiceOrb
import com.abuubaida.ai.ui.components.GlassCard
import com.abuubaida.ai.ui.theme.BrightGold
import com.abuubaida.ai.ui.theme.ElectricBlue
import com.abuubaida.ai.ui.theme.ImperialGold
import com.abuubaida.ai.ui.theme.NavyBorder
import com.abuubaida.ai.ui.theme.TextPrimary
import com.abuubaida.ai.ui.theme.TextSecondary

@Composable
fun HomeScreen(
    wakePhrase: String,
    voiceState: VoiceState,
    rmsLevel: Float,
    lastReply: String,
    onMicToggle: () -> Unit,
    onNavigate: (Screen) -> Unit
) {
    val context = LocalContext.current
    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) onMicToggle()
    }

    fun triggerVoiceSafely() {
        val granted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) {
            onMicToggle()
        } else {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        GlassCard(borderColor = ImperialGold.copy(alpha = 0.45f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                AbuUbaidaLogo(size = 54.dp)
                Column {
                    Text(
                        text = "আবু উবাইদা AI",
                        style = MaterialTheme.typography.headlineMedium,
                        color = BrightGold
                    )
                    Text(
                        text = "আপনার স্মার্ট বাংলা AI সহকারী",
                        style = MaterialTheme.typography.bodyMedium,
                        color = ElectricBlue
                    )
                    Text(
                        text = "ওয়েক-ফ্রেজ: \"$wakePhrase\"",
                        style = MaterialTheme.typography.labelLarge,
                        color = TextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        AnimatedVoiceOrb(
            voiceState = voiceState,
            rmsLevel = rmsLevel,
            onMicClick = { triggerVoiceSafely() }
        )

        if (lastReply.isNotBlank()) {
            Spacer(modifier = Modifier.height(12.dp))
            GlassCard(borderColor = ElectricBlue.copy(alpha = 0.35f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = BrightGold)
                    Text("সর্বশেষ বার্তা", style = MaterialTheme.typography.labelLarge, color = BrightGold)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = lastReply,
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextPrimary,
                    maxLines = 4
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        Text(
            text = "দ্রুত মডিউলসমূহ",
            style = MaterialTheme.typography.titleLarge,
            color = BrightGold,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(10.dp))

        val tiles = listOf(
            Triple(Screen.VoiceAssistant, Icons.Rounded.Mic, "ভয়েস মোড"),
            Triple(Screen.AiChat, Icons.Rounded.Chat, "বাংলা চ্যাট"),
            Triple(Screen.PhoneControl, Icons.Rounded.PhoneInTalk, "কল ও অ্যাপ"),
            Triple(Screen.Sms, Icons.Rounded.Sms, "SMS পাঠান"),
            Triple(Screen.VideoStudio, Icons.Rounded.MovieCreation, "ভিডিও স্টুডিও"),
            Triple(Screen.YouTubeStudio, Icons.Rounded.Upload, "YouTube"),
            Triple(Screen.PermissionsPrivacy, Icons.Rounded.Security, "অনুমতি ও নিরাপত্তা"),
            Triple(Screen.Settings, Icons.Rounded.Settings, "সেটিংস")
        )

        tiles.chunked(2).forEach { rowItems ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                rowItems.forEach { (screen, icon, subtitle) ->
                    QuickTile(
                        title = screen.titleBn,
                        subtitle = subtitle,
                        icon = icon,
                        onClick = { onNavigate(screen) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}

@Composable
private fun QuickTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassCard(
        modifier = modifier.clickable(onClick = onClick),
        borderColor = NavyBorder
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = BrightGold,
            modifier = Modifier.size(28.dp)
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = TextPrimary
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = ElectricBlue
        )
    }
}
