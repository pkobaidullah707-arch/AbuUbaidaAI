package com.abuubaida.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.abuubaida.ai.data.model.VideoProject
import com.abuubaida.ai.ui.components.GlassCard
import com.abuubaida.ai.ui.theme.AmberGold
import com.abuubaida.ai.ui.theme.BrightGold
import com.abuubaida.ai.ui.theme.DeepNavyBg
import com.abuubaida.ai.ui.theme.ElectricBlue
import com.abuubaida.ai.ui.theme.ImperialGold
import com.abuubaida.ai.ui.theme.NavyBorder
import com.abuubaida.ai.ui.theme.RoyalBlue
import com.abuubaida.ai.ui.theme.TextPrimary
import com.abuubaida.ai.ui.theme.TextSecondary

@Composable
fun VideoStudioScreen(
    project: VideoProject?,
    isBusy: Boolean,
    mp4ProviderConnected: Boolean,
    onGenerateProject: (String) -> Unit,
    onExportMp4OrScript: () -> Unit,
    onSendToYouTubeStudio: () -> Unit
) {
    var topicInput by remember { mutableStateOf(project?.topic.orEmpty()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("AI ভিডিও স্টুডিও", style = MaterialTheme.typography.headlineMedium, color = BrightGold)

        GlassCard(borderColor = ImperialGold.copy(alpha = 0.45f)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.Movie, contentDescription = null, tint = BrightGold)
                Text("বাংলা বিষয় থেকে ভিডিও প্যাকেজ", style = MaterialTheme.typography.titleMedium, color = BrightGold)
            }
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = topicInput,
                onValueChange = { topicInput = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("ভিডিওর বিষয় লিখুন (যেমন: বাংলাদেশে কৃত্রিম বুদ্ধিমত্তার ভবিষ্যৎ)") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = NavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = { onGenerateProject(topicInput) },
                enabled = !isBusy,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = ImperialGold, contentColor = DeepNavyBg)
            ) {
                Icon(Icons.Rounded.AutoAwesome, contentDescription = null)
                Text("  স্ক্রিপ্ট, SEO ও প্রম্পট তৈরি করুন")
            }
            if (isBusy) {
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = ImperialGold)
            }
        }

        GlassCard(borderColor = ElectricBlue.copy(alpha = 0.35f)) {
            Text("MP4 ভিডিও রেন্ডারিং আর্কিটেকচার", style = MaterialTheme.typography.titleMedium, color = ElectricBlue)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (mp4ProviderConnected) {
                    "ভিডিও জেনারেশন প্রোভাইডার সংযুক্ত আছে — MP4 এক্সপোর্ট সক্রিয়।"
                } else {
                    "বর্তমানে কোনো বাহ্যিক ভিডিও জেনারেশন API (যেমন Veo / Vertex AI ব্যাকএন্ড) সংযুক্ত নয়। " +
                        "প্রোভাইডার যুক্ত না থাকা পর্যন্ত স্ক্রিপ্ট ও প্রম্পট ফাইল (.txt) সংরক্ষণ করা যাবে।"
                },
                style = MaterialTheme.typography.bodyMedium,
                color = if (mp4ProviderConnected) TextPrimary else AmberGold
            )
        }

        if (project != null) {
            GlassCard {
                Text("SEO শিরোনাম", style = MaterialTheme.typography.labelLarge, color = BrightGold)
                Text(project.seoTitle, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                Spacer(modifier = Modifier.height(8.dp))

                Text("SEO বর্ণনা", style = MaterialTheme.typography.labelLarge, color = BrightGold)
                Text(project.seoDescription, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                Spacer(modifier = Modifier.height(8.dp))

                Text("ট্যাগসমূহ", style = MaterialTheme.typography.labelLarge, color = BrightGold)
                Text(project.seoTags.joinToString(", "), style = MaterialTheme.typography.bodyMedium, color = ElectricBlue)
            }

            GlassCard {
                Text("বাংলা চিত্রনাট্য (Script)", style = MaterialTheme.typography.titleMedium, color = BrightGold)
                Spacer(modifier = Modifier.height(6.dp))
                Text(project.script, style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
            }

            GlassCard {
                Text("থাম্বনেইল ইমেজ প্রম্পট", style = MaterialTheme.typography.titleMedium, color = ElectricBlue)
                Spacer(modifier = Modifier.height(6.dp))
                project.thumbnailPrompts.forEachIndexed { idx, prompt ->
                    Text("${idx + 1}. $prompt", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    Spacer(modifier = Modifier.height(6.dp))
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onExportMp4OrScript,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        if (mp4ProviderConnected) "MP4 এক্সপোর্ট" else "স্ক্রিপ্ট সংরক্ষণ",
                        color = BrightGold
                    )
                }
                Button(
                    onClick = onSendToYouTubeStudio,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue, contentColor = TextPrimary)
                ) {
                    Text("YouTube-এ পাঠান")
                }
            }
        }
    }
}
