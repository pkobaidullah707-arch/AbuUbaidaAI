package com.abuubaida.ai.data.ai

import android.content.Context
import com.abuubaida.ai.BuildConfig
import com.abuubaida.ai.data.model.AssistantIntentCommand
import com.abuubaida.ai.data.model.ChatMessage
import com.abuubaida.ai.data.model.VideoProject
import com.abuubaida.ai.data.security.SecurePrefsManager
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.content
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiAssistantRepository(
    private val context: Context,
    private val securePrefsManager: SecurePrefsManager
) {
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    fun isFirebaseConfigured(): Boolean = FirebaseApp.getApps(context).isNotEmpty()

    suspend fun generateAssistantReply(
        userPrompt: String,
        history: List<ChatMessage>
    ): Result<String> = withContext(Dispatchers.IO) {
        val recentContext = history.takeLast(6).joinToString("\n") { msg ->
            val role = if (msg.isUser) "ব্যবহারকারী" else "আবু উবাইদা AI"
            "$role: ${msg.text}"
        }
        val fullPrompt = if (recentContext.isBlank()) {
            userPrompt
        } else {
            "পূর্ববর্তী কথোপকথন:\n$recentContext\n\nবর্তমান প্রশ্ন:\n$userPrompt"
        }

        // 1. Primary path: Firebase AI Logic + App Check (no API key in client app)
        if (isFirebaseConfigured()) {
            try {
                val model = Firebase.ai(backend = GenerativeBackend.googleAI())
                    .generativeModel(
                        modelName = GEMINI_MODEL,
                        systemInstruction = content { text(SYSTEM_PROMPT_BN) }
                    )
                val response = model.generateContent(fullPrompt)
                val text = response.text?.trim()
                if (!text.isNullOrBlank()) {
                    return@withContext Result.success(text)
                }
            } catch (e: Exception) {
                return@withContext Result.failure(
                    IllegalStateException("Firebase AI Logic ত্রুটি: ${e.localizedMessage ?: "অজানা সমস্যা"}")
                )
            }
        }

        // 2. Secondary path: User-configured secure server proxy (no API key in client)
        val proxyUrl = securePrefsManager.loadSettings().proxyEndpointUrl
            .ifBlank { BuildConfig.GEMINI_PROXY_URL }
        if (proxyUrl.isNotBlank()) {
            return@withContext callSecureProxy(proxyUrl, fullPrompt)
        }

        // 3. Honest setup guidance if neither Firebase nor Proxy is connected yet
        Result.failure(
            IllegalStateException(
                "আবু উবাইদা AI-তে এখনো Gemini ব্যাকএন্ড যুক্ত করা হয়নি। " +
                    "নিরাপদভাবে Gemini চালাতে Firebase AI Logic (app/google-services.json) " +
                    "অথবা সেটিংসে আপনার সার্ভার প্রক্সি URL যুক্ত করুন।"
            )
        )
    }

    suspend fun generateVideoPackage(topic: String): Result<VideoProject> = withContext(Dispatchers.IO) {
        val prompt = """
            বিষয়: "$topic"
            বাংলায় (বাংলাদেশ) একটি পূর্ণাঙ্গ ইউটিউব ভিডিও প্যাকেজ তৈরি করো এবং নিচের ঠিক এই JSON ফরম্যাটে উত্তর দাও:
            {
              "script": "ভূমিকা, মূল আলোচনা ও সমাপ্তিসহ পূর্ণাঙ্গ বাংলা ভিডিও স্ক্রিপ্ট",
              "seoTitle": "আকর্ষণীয় বাংলা SEO শিরোনাম",
              "seoDescription": "ইউটিউব ভিডিওর জন্য বিস্তারিত বাংলা বর্ণনা ও কল-টু-অ্যাকশন",
              "seoTags": ["ট্যাগ১", "ট্যাগ২", "ট্যাগ৩", "ট্যাগ৪", "ট্যাগ৫"],
              "thumbnailPrompts": [
                "Detailed cinematic thumbnail image prompt 1 in English for AI image generator",
                "Detailed cinematic thumbnail image prompt 2 in English for AI image generator"
              ]
            }
            শুধুমাত্র বৈধ JSON রিটার্ন করো।
        """.trimIndent()

        val aiResult = generateAssistantReply(prompt, emptyList())
        aiResult.fold(
            onSuccess = { raw ->
                try {
                    val cleaned = raw.removePrefix("```json")
                        .removePrefix("```")
                        .removeSuffix("```")
                        .trim()
                    val json = JSONObject(cleaned)
                    val tagsJson = json.optJSONArray("seoTags") ?: JSONArray()
                    val promptsJson = json.optJSONArray("thumbnailPrompts") ?: JSONArray()
                    val tags = buildList {
                        for (i in 0 until tagsJson.length()) add(tagsJson.optString(i))
                    }.filter { it.isNotBlank() }
                    val prompts = buildList {
                        for (i in 0 until promptsJson.length()) add(promptsJson.optString(i))
                    }.filter { it.isNotBlank() }

                    Result.success(
                        VideoProject(
                            topic = topic,
                            script = json.optString("script", raw),
                            seoTitle = json.optString("seoTitle", topic),
                            seoDescription = json.optString("seoDescription", ""),
                            seoTags = tags,
                            thumbnailPrompts = prompts,
                            providerStatusBn = "Gemini থেকে স্ক্রিপ্ট, SEO ও থাম্বনেইল প্রম্পট তৈরি হয়েছে। MP4 রেন্ডারিংয়ের জন্য ভিডিও জেনারেশন API প্রোভাইডার সংযুক্ত করুন।"
                        )
                    )
                } catch (_: Exception) {
                    Result.success(
                        VideoProject(
                            topic = topic,
                            script = raw,
                            seoTitle = "$topic — আবু উবাইদা AI স্টুডিও",
                            seoDescription = "বিষয়: $topic নিয়ে তৈরি বাংলা ভিডিও।",
                            seoTags = listOf("বাংলা", "আবু উবাইদা AI", topic),
                            thumbnailPrompts = listOf(
                                "Futuristic deep navy blue and gold studio lighting thumbnail about $topic, high contrast, 4k",
                                "Minimalist tech creator thumbnail with glowing blue and gold accents for $topic"
                            )
                        )
                    )
                }
            },
            onFailure = { err -> Result.failure(err) }
        )
    }

    private fun callSecureProxy(proxyUrl: String, prompt: String): Result<String> {
        return try {
            val payload = JSONObject().apply {
                put("prompt", prompt)
                put("systemInstruction", SYSTEM_PROMPT_BN)
                put("language", "bn-BD")
            }
            val request = Request.Builder()
                .url(proxyUrl)
                .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()

            httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return Result.failure(
                        IllegalStateException("প্রক্সি সার্ভার ত্রুটি (${response.code})")
                    )
                }
                val json = JSONObject(body)
                val text = json.optString("text")
                    .ifBlank { json.optString("reply") }
                    .ifBlank { body }
                Result.success(text.trim())
            }
        } catch (e: Exception) {
            Result.failure(
                IllegalStateException("নেটওয়ার্ক বা প্রক্সি ত্রুটি: ${e.localizedMessage ?: "সংযোগ ব্যর্থ"}")
            )
        }
    }

    fun parseBengaliDeviceCommand(input: String): AssistantIntentCommand {
        val text = input.trim()
        val lower = text.lowercase()

        // Call detection: e.g. "আব্বুকে কল করো", "01711... নম্বরে ফোন দাও"
        if (text.contains("কল") || text.contains("ফোন") || lower.contains("call")) {
            val target = text
                .replace("কল করো", "")
                .replace("কল দাও", "")
                .replace("ফোন করো", "")
                .replace("ফোন দাও", "")
                .replace("কল", "")
                .replace("কে", "")
                .trim()
            if (target.isNotBlank()) {
                return AssistantIntentCommand.CallContact(target)
            }
        }

        // SMS detection: e.g. "রহিমকে মেসেজ পাঠাও আমি আসছি"
        if (text.contains("মেসেজ") || text.contains("এসএমএস") || lower.contains("sms")) {
            val cleaned = text
                .replace("মেসেজ পাঠাও", "|")
                .replace("এসএমএস পাঠাও", "|")
                .replace("মেসেজ দাও", "|")
                .replace("sms", "|", ignoreCase = true)
            val parts = cleaned.split("|", limit = 2)
            val target = parts.getOrNull(0)?.replace("কে", "")?.trim().orEmpty()
            val body = parts.getOrNull(1)?.trim().orEmpty()
            return AssistantIntentCommand.ComposeSms(target, body)
        }

        // Alarm detection: e.g. "সকাল 6টা 30 মিনিটে অ্যালার্ম সেট করো"
        if (text.contains("অ্যালার্ম") || lower.contains("alarm")) {
            val numbers = Regex("\\d+").findAll(text).map { it.value.toInt() }.toList()
            var hour = numbers.getOrNull(0)?.coerceIn(0, 23) ?: 7
            val minute = numbers.getOrNull(1)?.coerceIn(0, 59) ?: 0
            if ((text.contains("রাত") || text.contains("বিকাল") || text.contains("সন্ধ্যা")) && hour < 12) {
                hour += 12
            }
            return AssistantIntentCommand.SetAlarm(hour, minute, "আবু উবাইদা AI অ্যালার্ম")
        }

        // Open Settings detection
        if (text.contains("সেটিংস") || lower.contains("settings")) {
            return AssistantIntentCommand.OpenSettings(text)
        }

        // Open App detection: e.g. "ইউটিউব খোলো", "হোয়াটসঅ্যাপ ওপেন করো"
        if (text.contains("খোলো") || text.contains("ওপেন") || text.contains("চালু করো") || lower.contains("open")) {
            val appName = text
                .replace("খোলো", "")
                .replace("ওপেন করো", "")
                .replace("চালু করো", "")
                .replace("অ্যাপ", "")
                .replace("open", "", ignoreCase = true)
                .trim()
            if (appName.isNotBlank()) {
                return AssistantIntentCommand.OpenApp(appName)
            }
        }

        return AssistantIntentCommand.None
    }

    companion object {
        private const val GEMINI_MODEL = "gemini-2.5-flash"
        private const val SYSTEM_PROMPT_BN =
            "তুমি 'আবু উবাইদা AI' (Abu Ubaida AI) — একটি সম্মানজনক, বুদ্ধিমান ও সহায়ক বাংলা ভয়েস অ্যাসিস্ট্যান্ট। " +
                "সবসময় বাংলাদেশের স্বাভাবিক, মার্জিত ও স্পষ্ট বাংলায় উত্তর দাও। " +
                "উত্তর সংক্ষিপ্ত, নির্ভুল ও ভয়েস-বান্ধব রাখো। কোনো অনিরাপদ কাজ বা ব্যবহারকারীর অনুমতি ছাড়া ব্যক্তিগত তথ্যে প্রবেশের পরামর্শ দেবে না।"
    }
}
