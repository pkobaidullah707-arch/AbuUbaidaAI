package com.abuubaida.ai.data.model

import java.util.UUID

enum class Screen(val route: String, val titleBn: String) {
    Home("home", "হোম"),
    VoiceAssistant("voice_assistant", "ভয়েস অ্যাসিস্ট্যান্ট"),
    AiChat("ai_chat", "AI চ্যাট"),
    PhoneControl("phone_control", "ফোন কন্ট্রোল"),
    Sms("sms", "SMS"),
    VideoStudio("video_studio", "ভিডিও স্টুডিও"),
    YouTubeStudio("youtube_studio", "YouTube স্টুডিও"),
    Settings("settings", "সেটিংস"),
    PermissionsPrivacy("permissions_privacy", "অনুমতি ও গোপনীয়তা")
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val isUser: Boolean,
    val timestampMillis: Long = System.currentTimeMillis()
)

data class ContactItem(
    val id: String,
    val name: String,
    val phoneNumber: String
)

data class InstalledAppInfo(
    val packageName: String,
    val appName: String
)

enum class YouTubeVisibility(val apiValue: String, val labelBn: String) {
    PRIVATE("private", "প্রাইভেট (শুধু আপনি)"),
    UNLISTED("unlisted", "আনলিস্টেড (লিংকযুক্ত)"),
    PUBLIC("public", "পাবলিক (সবার জন্য)")
}

data class VideoProject(
    val topic: String = "",
    val script: String = "",
    val seoTitle: String = "",
    val seoDescription: String = "",
    val seoTags: List<String> = emptyList(),
    val thumbnailPrompts: List<String> = emptyList(),
    val providerStatusBn: String = "কোনো বাহ্যিক ভিডিও জেনারেশন API প্রোভাইডার যুক্ত করা হয়নি — চিত্রনাট্য ও প্রম্পট প্রস্তুত।"
)

data class YouTubeUploadRequest(
    val videoUriString: String = "",
    val videoDisplayName: String = "",
    val title: String = "",
    val description: String = "",
    val tags: List<String> = emptyList(),
    val visibility: YouTubeVisibility = YouTubeVisibility.PRIVATE
)

data class AssistantSettings(
    val wakePhrase: String = "হ্যালো আবু উবাইদা",
    val ttsEnabled: Boolean = true,
    val backgroundServiceEnabled: Boolean = false,
    val proxyEndpointUrl: String = ""
)

sealed class VoiceState {
    data object Idle : VoiceState()
    data object Listening : VoiceState()
    data object Processing : VoiceState()
    data class Speaking(val text: String) : VoiceState()
    data class Error(val messageBn: String) : VoiceState()
}

sealed class PendingSensitiveAction {
    data class CallPhone(val displayName: String, val phoneNumber: String, val directCall: Boolean) : PendingSensitiveAction()
    data class SendSms(val recipientName: String, val phoneNumber: String, val message: String, val useDirectApi: Boolean) : PendingSensitiveAction()
    data class PublishYouTube(val request: YouTubeUploadRequest) : PendingSensitiveAction()
}

sealed class AssistantIntentCommand {
    data class CallContact(val target: String) : AssistantIntentCommand()
    data class ComposeSms(val target: String, val body: String) : AssistantIntentCommand()
    data class OpenApp(val appName: String) : AssistantIntentCommand()
    data class SetAlarm(val hour: Int, val minute: Int, val label: String) : AssistantIntentCommand()
    data class OpenSettings(val section: String) : AssistantIntentCommand()
    data object None : AssistantIntentCommand()
}
