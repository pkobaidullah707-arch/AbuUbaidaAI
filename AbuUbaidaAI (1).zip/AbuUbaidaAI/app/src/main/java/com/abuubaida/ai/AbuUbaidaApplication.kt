package com.abuubaida.ai

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.abuubaida.ai.data.ai.GeminiAssistantRepository
import com.abuubaida.ai.data.security.SecurePrefsManager
import com.abuubaida.ai.phone.PhoneControlManager
import com.abuubaida.ai.video.VideoStudioRepository
import com.abuubaida.ai.voice.BengaliVoiceManager
import com.abuubaida.ai.youtube.YouTubeStudioRepository
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.AppCheckProviderFactory
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory

class AppContainer(application: Application) {
    val securePrefsManager = SecurePrefsManager(application)
    val geminiRepository = GeminiAssistantRepository(application, securePrefsManager)
    val voiceManager = BengaliVoiceManager(application)
    val phoneControlManager = PhoneControlManager(application)
    val videoStudioRepository = VideoStudioRepository(application, geminiRepository)
    val youTubeStudioRepository = YouTubeStudioRepository(application, securePrefsManager)
}

class AbuUbaidaApplication : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
        initializeFirebaseSafely()
        container = AppContainer(this)
    }

    private fun initializeFirebaseSafely() {
        try {
            if (FirebaseApp.getApps(this).isEmpty()) {
                // Only initializes if google-services.json resources exist
                FirebaseApp.initializeApp(this)
            }
            if (FirebaseApp.getApps(this).isNotEmpty()) {
                val appCheck = FirebaseAppCheck.getInstance()
                val factory: AppCheckProviderFactory = if (BuildConfig.DEBUG) {
                    try {
                        val clazz = Class.forName("com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory")
                        val method = clazz.getMethod("getInstance")
                        method.invoke(null) as AppCheckProviderFactory
                    } catch (_: Exception) {
                        PlayIntegrityAppCheckProviderFactory.getInstance()
                    }
                } else {
                    PlayIntegrityAppCheckProviderFactory.getInstance()
                }
                appCheck.installAppCheckProviderFactory(factory)
            }
        } catch (_: Exception) {
            // App gracefully falls back to secure proxy setup guidance if Firebase is not configured yet
        }
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                VOICE_CHANNEL_ID,
                getString(R.string.voice_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.voice_channel_desc)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        const val VOICE_CHANNEL_ID = "abu_ubaida_voice_channel"
    }
}
