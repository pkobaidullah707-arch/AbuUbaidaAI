package com.abuubaida.ai.ui.screens

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.abuubaida.ai.data.model.YouTubeUploadRequest
import com.abuubaida.ai.data.model.YouTubeVisibility
import com.abuubaida.ai.ui.components.GlassCard
import com.abuubaida.ai.ui.theme.BrightGold
import com.abuubaida.ai.ui.theme.DeepNavyBg
import com.abuubaida.ai.ui.theme.ElectricBlue
import com.abuubaida.ai.ui.theme.EmeraldOk
import com.abuubaida.ai.ui.theme.ImperialGold
import com.abuubaida.ai.ui.theme.NavyBorder
import com.abuubaida.ai.ui.theme.RoyalBlue
import com.abuubaida.ai.ui.theme.TextPrimary
import com.abuubaida.ai.ui.theme.TextSecondary
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity

@Composable
fun YouTubeStudioScreen(
    isConnected: Boolean,
    isBusy: Boolean,
    uploadRequest: YouTubeUploadRequest,
    onUpdateRequest: ((YouTubeUploadRequest) -> YouTubeUploadRequest) -> Unit,
    onPickVideo: (android.net.Uri) -> Unit,
    onConnectOAuth: (Activity, (android.content.IntentSender) -> Unit) -> Unit,
    onConsentResult: (AuthorizationResult?) -> Unit,
    onDisconnectOAuth: () -> Unit,
    onRequestPublish: (YouTubeUploadRequest) -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    var tagsText by remember(uploadRequest.tags) {
        mutableStateOf(uploadRequest.tags.joinToString(", "))
    }

    val videoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) onPickVideo(uri)
    }

    val oauthConsentLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && activity != null) {
            val authResult = try {
                Identity.getAuthorizationClient(activity).getAuthorizationResultFromIntent(result.data)
            } catch (_: Exception) {
                null
            }
            onConsentResult(authResult)
        } else {
            onConsentResult(null)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("YouTube স্টুডিও", style = MaterialTheme.typography.headlineMedium, color = BrightGold)

        GlassCard(borderColor = if (isConnected) EmeraldOk.copy(alpha = 0.5f) else ImperialGold.copy(alpha = 0.45f)) {
            Text("Google OAuth সংযোগ", style = MaterialTheme.typography.titleMedium, color = BrightGold)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (isConnected) {
                    "সংযুক্ত: আপনার Google OAuth সেশন সক্রিয় আছে। পাসওয়ার্ড কখনো সংরক্ষণ করা হয় না।"
                } else {
                    "YouTube Data API v3 দিয়ে ভিডিও আপলোড করতে আপনার Google অ্যাকাউন্ট অনুমোদন করুন।"
                },
                style = MaterialTheme.typography.bodyMedium,
                color = if (isConnected) EmeraldOk else TextSecondary
            )
            Spacer(modifier = Modifier.height(10.dp))
            if (isConnected) {
                OutlinedButton(onClick = onDisconnectOAuth) {
                    Text("সংযোগ বিচ্ছিন্ন করুন", color = ElectricBlue)
                }
            } else {
                Button(
                    onClick = {
                        if (activity != null) {
                            onConnectOAuth(activity) { sender ->
                                oauthConsentLauncher.launch(IntentSenderRequest.Builder(sender).build())
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue, contentColor = TextPrimary)
                ) {
                    Text("Google দিয়ে সংযুক্ত করুন")
                }
            }
        }

        GlassCard {
            Text("ভিডিও ফাইল ও মেটাডেটা", style = MaterialTheme.typography.titleMedium, color = ElectricBlue)
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedButton(
                onClick = { videoPicker.launch("video/*") },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = if (uploadRequest.videoDisplayName.isNotBlank()) {
                        "নির্বাচিত ফাইল: ${uploadRequest.videoDisplayName}"
                    } else {
                        "ডিভাইস থেকে ভিডিও (MP4) নির্বাচন করুন"
                    },
                    color = BrightGold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = uploadRequest.title,
                onValueChange = { v -> onUpdateRequest { it.copy(title = v) } },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("ভিডিও শিরোনাম (Title)") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = NavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )

            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = uploadRequest.description,
                onValueChange = { v -> onUpdateRequest { it.copy(description = v) } },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp),
                label = { Text("ভিডিও বর্ণনা (Description)") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = NavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )

            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = tagsText,
                onValueChange = { raw ->
                    tagsText = raw
                    val parsed = raw.split(",").map { it.trim() }.filter { it.isNotBlank() }
                    onUpdateRequest { it.copy(tags = parsed) }
                },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("ট্যাগসমূহ (কমা দিয়ে আলাদা করুন)") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = NavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )

            Spacer(modifier = Modifier.height(10.dp))
            Text("দৃশ্যমানতা নির্বাচন করুন:", style = MaterialTheme.typography.labelLarge, color = BrightGold)
            YouTubeVisibility.entries.forEach { vis ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    RadioButton(
                        selected = uploadRequest.visibility == vis,
                        onClick = { onUpdateRequest { it.copy(visibility = vis) } }
                    )
                    Text(vis.labelBn, color = TextPrimary)
                }
            }

            if (isBusy) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = ImperialGold)
                Spacer(modifier = Modifier.height(8.dp))
            }

            Button(
                onClick = { onRequestPublish(uploadRequest) },
                enabled = !isBusy && isConnected && uploadRequest.videoUriString.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = ImperialGold, contentColor = DeepNavyBg)
            ) {
                Text("নিশ্চিত করে YouTube-এ আপলোড করুন")
            }
        }
    }
}
