package com.abuubaida.ai.ui

import android.app.Activity
import android.content.IntentSender
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.abuubaida.ai.AppContainer
import com.abuubaida.ai.data.model.AssistantIntentCommand
import com.abuubaida.ai.data.model.AssistantSettings
import com.abuubaida.ai.data.model.ChatMessage
import com.abuubaida.ai.data.model.ContactItem
import com.abuubaida.ai.data.model.InstalledAppInfo
import com.abuubaida.ai.data.model.PendingSensitiveAction
import com.abuubaida.ai.data.model.Screen
import com.abuubaida.ai.data.model.VideoProject
import com.abuubaida.ai.data.model.VoiceState
import com.abuubaida.ai.data.model.YouTubeUploadRequest
import com.abuubaida.ai.voice.BackgroundVoiceService
import com.abuubaida.ai.youtube.OAuthFlowOutcome
import com.google.android.gms.auth.api.identity.AuthorizationResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AbuUbaidaViewModel(
    private val container: AppContainer
) : ViewModel() {

    private val _currentScreen = MutableStateFlow(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _settings = MutableStateFlow(container.securePrefsManager.loadSettings())
    val settings: StateFlow<AssistantSettings> = _settings.asStateFlow()

    private val _contacts = MutableStateFlow<List<ContactItem>>(emptyList())
    val contacts: StateFlow<List<ContactItem>> = _contacts.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _videoProject = MutableStateFlow<VideoProject?>(null)
    val videoProject: StateFlow<VideoProject?> = _videoProject.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _statusBannerBn = MutableStateFlow<String?>(null)
    val statusBannerBn: StateFlow<String?> = _statusBannerBn.asStateFlow()

    private val _pendingAction = MutableStateFlow<PendingSensitiveAction?>(null)
    val pendingAction: StateFlow<PendingSensitiveAction?> = _pendingAction.asStateFlow()

    private val _youTubeConnected = MutableStateFlow(
        !container.youTubeStudioRepository.getSavedAccessToken().isNullOrBlank()
    )
    val youTubeConnected: StateFlow<Boolean> = _youTubeConnected.asStateFlow()

    private val _youTubeUploadRequest = MutableStateFlow(YouTubeUploadRequest())
    val youTubeUploadRequest: StateFlow<YouTubeUploadRequest> = _youTubeUploadRequest.asStateFlow()

    val voiceState: StateFlow<VoiceState> = container.voiceManager.voiceState
    val rmsLevel: StateFlow<Float> = container.voiceManager.rmsLevel
    val partialTranscript: StateFlow<String> = container.voiceManager.partialTranscript
    val ttsSupportedBn: StateFlow<Boolean> = container.voiceManager.ttsSupportedBn

    init {
        val saved = container.securePrefsManager.loadChatHistory()
        if (saved.isEmpty()) {
            val welcome = ChatMessage(
                text = "আসসালামু আলাইকুম! আমি আবু উবাইদা AI। আমি আপনার বাংলা ভয়েস ও ব্যক্তিগত সহকারী। কীভাবে সাহায্য করতে পারি?",
                isUser = false
            )
            _messages.value = listOf(welcome)
        } else {
            _messages.value = saved
        }
        refreshInstalledApps()
        refreshContacts()
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun clearBanner() {
        _statusBannerBn.value = null
    }

    fun showBanner(message: String) {
        _statusBannerBn.value = message
    }

    fun startVoiceListening() {
        container.voiceManager.startListening(
            onResult = { spokenText ->
                handleUserPrompt(spokenText, speakReply = _settings.value.ttsEnabled)
            },
            onError = { errMsg ->
                _statusBannerBn.value = errMsg
            }
        )
    }

    fun stopVoiceListening() {
        container.voiceManager.stopListening()
    }

    fun speakText(text: String) {
        container.voiceManager.speak(text)
    }

    fun stopSpeaking() {
        container.voiceManager.stopSpeaking()
    }

    fun handleUserPrompt(rawText: String, speakReply: Boolean = _settings.value.ttsEnabled) {
        val text = rawText.trim()
        if (text.isBlank()) return

        appendMessage(ChatMessage(text = text, isUser = true))

        // Check if this is a natural Bengali device-control command first
        when (val cmd = container.geminiRepository.parseBengaliDeviceCommand(text)) {
            is AssistantIntentCommand.CallContact -> {
                val contact = _contacts.value.firstOrNull {
                    it.name.contains(cmd.target, ignoreCase = true) ||
                        it.phoneNumber.contains(cmd.target)
                }
                val number = contact?.phoneNumber ?: cmd.target
                val displayName = contact?.name ?: cmd.target
                _pendingAction.value = PendingSensitiveAction.CallPhone(
                    displayName = displayName,
                    phoneNumber = number,
                    directCall = true
                )
                val reply = "$displayName নম্বরে কল করার আগে আপনার নিশ্চিতকরণ প্রয়োজন।"
                appendMessage(ChatMessage(text = reply, isUser = false))
                if (speakReply) container.voiceManager.speak(reply)
                return
            }

            is AssistantIntentCommand.ComposeSms -> {
                val contact = _contacts.value.firstOrNull {
                    it.name.contains(cmd.target, ignoreCase = true)
                }
                val number = contact?.phoneNumber ?: cmd.target
                val name = contact?.name ?: cmd.target
                if (number.isNotBlank() && cmd.body.isNotBlank()) {
                    _pendingAction.value = PendingSensitiveAction.SendSms(
                        recipientName = name,
                        phoneNumber = number,
                        message = cmd.body,
                        useDirectApi = false
                    )
                    val reply = "$name কে মেসেজ পাঠাতে নিশ্চিত করুন।"
                    appendMessage(ChatMessage(text = reply, isUser = false))
                    if (speakReply) container.voiceManager.speak(reply)
                } else {
                    _currentScreen.value = Screen.Sms
                    val reply = "SMS পর্দা খোলা হয়েছে। প্রাপক ও বার্তা লিখে পাঠান।"
                    appendMessage(ChatMessage(text = reply, isUser = false))
                    if (speakReply) container.voiceManager.speak(reply)
                }
                return
            }

            is AssistantIntentCommand.OpenApp -> {
                val res = container.phoneControlManager.launchAppByNameOrPackage(cmd.appName)
                val reply = res.getOrElse { it.localizedMessage ?: "অ্যাপ খোলা যায়নি।" }
                appendMessage(ChatMessage(text = reply, isUser = false))
                if (speakReply) container.voiceManager.speak(reply)
                return
            }

            is AssistantIntentCommand.SetAlarm -> {
                val res = container.phoneControlManager.setAlarm(cmd.hour, cmd.minute, cmd.label)
                val reply = res.getOrElse { it.localizedMessage ?: "অ্যালার্ম সেট করা যায়নি।" }
                appendMessage(ChatMessage(text = reply, isUser = false))
                if (speakReply) container.voiceManager.speak(reply)
                return
            }

            is AssistantIntentCommand.OpenSettings -> {
                val res = container.phoneControlManager.openAndroidSettings()
                val reply = res.getOrElse { "সেটিংস খোলা যায়নি।" }
                appendMessage(ChatMessage(text = reply, isUser = false))
                if (speakReply) container.voiceManager.speak(reply)
                return
            }

            AssistantIntentCommand.None -> Unit
        }

        // Otherwise ask Gemini AI
        viewModelScope.launch {
            _isBusy.value = true
            container.voiceManager.setProcessing()
            val result = container.geminiRepository.generateAssistantReply(text, _messages.value)
            _isBusy.value = false
            result.fold(
                onSuccess = { reply ->
                    appendMessage(ChatMessage(text = reply, isUser = false))
                    if (speakReply) {
                        container.voiceManager.speak(reply)
                    } else {
                        container.voiceManager.setIdle()
                    }
                },
                onFailure = { err ->
                    val errText = err.localizedMessage ?: "উত্তর পেতে সমস্যা হয়েছে।"
                    appendMessage(ChatMessage(text = errText, isUser = false))
                    container.voiceManager.setIdle()
                }
            )
        }
    }

    private fun appendMessage(msg: ChatMessage) {
        val updated = _messages.value + msg
        _messages.value = updated
        container.securePrefsManager.saveChatHistory(updated)
    }

    fun clearChatHistory() {
        container.securePrefsManager.clearChatHistory()
        _messages.value = listOf(
            ChatMessage(
                text = "চ্যাট ইতিহাস পরিষ্কার করা হয়েছে। আমি আবু উবাইদা AI — নতুন কোনো প্রশ্ন করুন।",
                isUser = false
            )
        )
    }

    fun refreshContacts(query: String = "") {
        _contacts.value = container.phoneControlManager.loadContacts(query)
    }

    fun refreshInstalledApps() {
        _installedApps.value = container.phoneControlManager.getInstalledLauncherApps()
    }

    fun launchInstalledApp(appNameOrPackage: String) {
        val res = container.phoneControlManager.launchAppByNameOrPackage(appNameOrPackage)
        _statusBannerBn.value = res.getOrElse { it.localizedMessage ?: "অ্যাপ চালু করা যায়নি।" }
    }

    fun openAndroidSettings(action: String = android.provider.Settings.ACTION_SETTINGS) {
        val res = container.phoneControlManager.openAndroidSettings(action)
        _statusBannerBn.value = res.getOrElse { it.localizedMessage ?: "সেটিংস খোলা যায়নি।" }
    }

    fun setAlarm(hour: Int, minute: Int, label: String) {
        val res = container.phoneControlManager.setAlarm(hour, minute, label)
        _statusBannerBn.value = res.getOrElse { it.localizedMessage ?: "অ্যালার্ম সেট করা যায়নি।" }
    }

    fun requestCallConfirmation(displayName: String, phoneNumber: String, directCall: Boolean) {
        _pendingAction.value = PendingSensitiveAction.CallPhone(displayName, phoneNumber, directCall)
    }

    fun requestSmsConfirmation(
        recipientName: String,
        phoneNumber: String,
        message: String,
        useDirectApi: Boolean
    ) {
        _pendingAction.value = PendingSensitiveAction.SendSms(recipientName, phoneNumber, message, useDirectApi)
    }

    fun requestYouTubePublishConfirmation(request: YouTubeUploadRequest) {
        _pendingAction.value = PendingSensitiveAction.PublishYouTube(request)
    }

    fun dismissPendingAction() {
        _pendingAction.value = null
    }

    fun confirmPendingAction() {
        val action = _pendingAction.value ?: return
        _pendingAction.value = null
        when (action) {
            is PendingSensitiveAction.CallPhone -> {
                val res = container.phoneControlManager.placeCall(action.phoneNumber, action.directCall)
                _statusBannerBn.value = res.getOrElse { it.localizedMessage ?: "কল করা যায়নি।" }
            }

            is PendingSensitiveAction.SendSms -> {
                val res = container.phoneControlManager.sendSms(action.phoneNumber, action.message, action.useDirectApi)
                _statusBannerBn.value = res.getOrElse { it.localizedMessage ?: "SMS পাঠানো যায়নি।" }
            }

            is PendingSensitiveAction.PublishYouTube -> {
                viewModelScope.launch {
                    _isBusy.value = true
                    val res = container.youTubeStudioRepository.uploadVideoToYouTube(action.request)
                    _isBusy.value = false
                    _statusBannerBn.value = res.getOrElse { it.localizedMessage ?: "আপলোড ব্যর্থ।" }
                }
            }
        }
    }

    fun generateVideoStudioProject(topic: String) {
        if (topic.isBlank()) {
            _statusBannerBn.value = "ভিডিওর জন্য একটি বাংলা বিষয় লিখুন।"
            return
        }
        viewModelScope.launch {
            _isBusy.value = true
            val res = container.videoStudioRepository.createProjectFromTopic(topic.trim())
            _isBusy.value = false
            res.fold(
                onSuccess = { project ->
                    _videoProject.value = project
                    _youTubeUploadRequest.value = _youTubeUploadRequest.value.copy(
                        title = project.seoTitle,
                        description = project.seoDescription,
                        tags = project.seoTags
                    )
                    _statusBannerBn.value = "বাংলা ভিডিও স্ক্রিপ্ট, SEO ও থাম্বনেইল প্রম্পট তৈরি হয়েছে!"
                },
                onFailure = { err ->
                    _statusBannerBn.value = err.localizedMessage ?: "ভিডিও প্রজেক্ট তৈরি ব্যর্থ।"
                }
            )
        }
    }

    fun exportVideoMp4OrScript() {
        val project = _videoProject.value ?: return
        viewModelScope.launch {
            _isBusy.value = true
            val mp4Res = container.videoStudioRepository.exportMp4IfConnected(project)
            mp4Res.fold(
                onSuccess = { uri ->
                    _isBusy.value = false
                    _statusBannerBn.value = "MP4 ভিডিও সংরক্ষিত হয়েছে: $uri"
                },
                onFailure = { mp4Err ->
                    val scriptRes = container.videoStudioRepository.exportScriptTextPackage(project)
                    _isBusy.value = false
                    val scriptNote = scriptRes.fold(
                        onSuccess = { file -> "\nস্ক্রিপ্ট ফাইল সংরক্ষিত হয়েছে: ${file.name}" },
                        onFailure = { "" }
                    )
                    _statusBannerBn.value = (mp4Err.localizedMessage ?: "") + scriptNote
                }
            )
        }
    }

    fun updateYouTubeRequest(updater: (YouTubeUploadRequest) -> YouTubeUploadRequest) {
        _youTubeUploadRequest.value = updater(_youTubeUploadRequest.value)
    }

    fun onVideoFilePicked(uri: Uri) {
        val displayName = container.youTubeStudioRepository.resolveFileDisplayName(uri)
        _youTubeUploadRequest.value = _youTubeUploadRequest.value.copy(
            videoUriString = uri.toString(),
            videoDisplayName = displayName
        )
    }

    fun connectYouTubeOAuth(activity: Activity, onNeedsConsent: (IntentSender) -> Unit) {
        viewModelScope.launch {
            _isBusy.value = true
            val outcome = container.youTubeStudioRepository.requestYouTubeAuthorization(activity)
            _isBusy.value = false
            when (outcome) {
                is OAuthFlowOutcome.Authorized -> {
                    _youTubeConnected.value = true
                    _statusBannerBn.value = "Google OAuth সফলভাবে YouTube-এর সাথে যুক্ত হয়েছে।"
                }
                is OAuthFlowOutcome.NeedsConsent -> onNeedsConsent(outcome.intentSender)
                is OAuthFlowOutcome.Failed -> _statusBannerBn.value = outcome.errorBn
            }
        }
    }

    fun handleYouTubeConsentResult(authResult: AuthorizationResult?) {
        val res = container.youTubeStudioRepository.handleAuthorizationResultIntent(authResult)
        res.fold(
            onSuccess = {
                _youTubeConnected.value = true
                _statusBannerBn.value = "YouTube অনুমতি সফলভাবে অনুমোদিত হয়েছে।"
            },
            onFailure = { err ->
                _statusBannerBn.value = err.localizedMessage ?: "YouTube OAuth ব্যর্থ।"
            }
        )
    }

    fun disconnectYouTube() {
        container.youTubeStudioRepository.disconnectAccount()
        _youTubeConnected.value = false
        _statusBannerBn.value = "YouTube অ্যাকাউন্ট সংযোগ বিচ্ছিন্ন করা হয়েছে।"
    }

    fun updateSettings(newSettings: AssistantSettings, context: android.content.Context) {
        _settings.value = newSettings
        container.securePrefsManager.saveSettings(newSettings)
        if (newSettings.backgroundServiceEnabled) {
            BackgroundVoiceService.start(context)
        } else {
            BackgroundVoiceService.stop(context)
        }
        _statusBannerBn.value = "সেটিংস নিরাপদে সংরক্ষিত হয়েছে।"
    }

    fun isFirebaseConfigured(): Boolean = container.geminiRepository.isFirebaseConfigured()
    fun isSpeechRecognitionAvailable(): Boolean = container.voiceManager.isSpeechRecognitionAvailable()
    fun isMp4ProviderConnected(): Boolean = container.videoStudioRepository.isMp4ProviderConnected()
    fun openAssistantRoleSettings() = container.phoneControlManager.openAssistantRoleSettings()
    fun openBatteryOptimizationSettings() = container.phoneControlManager.openBatteryOptimizationSettings()
    fun openAppPermissionSettings() = container.phoneControlManager.openAppPermissionSettings()

    override fun onCleared() {
        container.voiceManager.release()
        super.onCleared()
    }

    class Factory(private val container: AppContainer) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return AbuUbaidaViewModel(container) as T
        }
    }
}
