package com.abuubaida.ai

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.abuubaida.ai.data.model.Screen
import com.abuubaida.ai.ui.AbuUbaidaApp
import com.abuubaida.ai.ui.AbuUbaidaViewModel
import com.abuubaida.ai.ui.theme.AbuUbaidaTheme
import com.abuubaida.ai.voice.BackgroundVoiceService

class MainActivity : ComponentActivity() {

    private val viewModel: AbuUbaidaViewModel by viewModels {
        AbuUbaidaViewModel.Factory((application as AbuUbaidaApplication).container)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleAssistantLaunchIntent(intent)

        setContent {
            AbuUbaidaTheme {
                AbuUbaidaApp(viewModel = viewModel)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleAssistantLaunchIntent(intent)
    }

    private fun handleAssistantLaunchIntent(intent: Intent?) {
        val triggeredByWake = intent?.getBooleanExtra(BackgroundVoiceService.EXTRA_WAKE_TRIGGERED, false) == true
        val isAssistAction = intent?.action == Intent.ACTION_ASSIST
        if (triggeredByWake || isAssistAction) {
            viewModel.navigateTo(Screen.VoiceAssistant)
        }
    }
}
