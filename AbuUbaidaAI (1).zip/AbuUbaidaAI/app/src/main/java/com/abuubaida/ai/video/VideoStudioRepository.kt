package com.abuubaida.ai.video

import android.content.Context
import android.net.Uri
import com.abuubaida.ai.data.ai.GeminiAssistantRepository
import com.abuubaida.ai.data.model.VideoProject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Pluggable Video Generation API Provider interface (e.g., Veo / Vertex AI / external video backend).
 * When a video generation provider is connected, exportMp4() saves the rendered MP4 file.
 */
interface VideoGenerationProvider {
    val providerNameBn: String
    val isConnected: Boolean
    suspend fun generateMp4(prompt: String, outputFile: File): Result<Uri>
}

class UnconnectedVideoProvider : VideoGenerationProvider {
    override val providerNameBn: String = "ভিডিও জেনারেশন প্রোভাইডার সংযুক্ত নয়"
    override val isConnected: Boolean = false

    override suspend fun generateMp4(prompt: String, outputFile: File): Result<Uri> {
        return Result.failure(
            IllegalStateException(
                "MP4 ভিডিও তৈরি করতে একটি বাহ্যিক ভিডিও-জেনারেশন API প্রোভাইডার (যেমন Veo / Vertex AI ব্যাকএন্ড) সংযুক্ত করা প্রয়োজন। " +
                    "বর্তমানে আপনার বাংলা চিত্রনাট্য, SEO এবং থাম্বনেইল প্রম্পট ব্যবহারের জন্য সম্পূর্ণ প্রস্তুত।"
            )
        )
    }
}

class VideoStudioRepository(
    private val context: Context,
    private val geminiRepo: GeminiAssistantRepository,
    private val videoProvider: VideoGenerationProvider = UnconnectedVideoProvider()
) {
    suspend fun createProjectFromTopic(topic: String): Result<VideoProject> {
        return geminiRepo.generateVideoPackage(topic)
    }

    fun isMp4ProviderConnected(): Boolean = videoProvider.isConnected

    fun getProviderStatusMessageBn(): String = videoProvider.providerNameBn

    suspend fun exportMp4IfConnected(project: VideoProject): Result<Uri> = withContext(Dispatchers.IO) {
        if (!videoProvider.isConnected) {
            return@withContext videoProvider.generateMp4(project.topic, File(context.cacheDir, "placeholder.mp4"))
        }
        val outDir = File(context.filesDir, "abu_ubaida_videos").apply { mkdirs() }
        val file = File(outDir, "abu_ubaida_${System.currentTimeMillis()}.mp4")
        videoProvider.generateMp4(
            prompt = project.thumbnailPrompts.firstOrNull() ?: project.topic,
            outputFile = file
        )
    }

    suspend fun exportScriptTextPackage(project: VideoProject): Result<File> = withContext(Dispatchers.IO) {
        return@withContext try {
            val outDir = File(context.filesDir, "abu_ubaida_scripts").apply { mkdirs() }
            val safeName = "script_${System.currentTimeMillis()}.txt"
            val file = File(outDir, safeName)
            val content = buildString {
                appendLine("=== আবু উবাইদা AI ভিডিও স্টুডিও প্যাকেজ ===")
                appendLine("বিষয়: ${project.topic}")
                appendLine()
                appendLine("SEO শিরোনাম: ${project.seoTitle}")
                appendLine("SEO বর্ণনা: ${project.seoDescription}")
                appendLine("ট্যাগসমূহ: ${project.seoTags.joinToString(", ")}")
                appendLine()
                appendLine("--- চিত্রনাট্য (Script) ---")
                appendLine(project.script)
                appendLine()
                appendLine("--- থাম্বনেইল ইমেজ প্রম্পট ---")
                project.thumbnailPrompts.forEachIndexed { idx, p ->
                    appendLine("${idx + 1}. $p")
                }
            }
            file.writeText(content)
            Result.success(file)
        } catch (e: Exception) {
            Result.failure(IllegalStateException("স্ক্রিপ্ট সংরক্ষণ করা যায়নি: ${e.localizedMessage}"))
        }
    }
}
