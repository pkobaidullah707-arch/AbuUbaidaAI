package com.abuubaida.ai.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.abuubaida.ai.ui.components.GlassCard
import com.abuubaida.ai.ui.components.PermissionStatusRow
import com.abuubaida.ai.ui.theme.BrightGold
import com.abuubaida.ai.ui.theme.ElectricBlue
import com.abuubaida.ai.ui.theme.ImperialGold
import com.abuubaida.ai.ui.theme.TextSecondary

@Composable
fun PermissionsPrivacyScreen(
    onOpenAppSettings: () -> Unit,
    onOpenBatterySettings: () -> Unit,
    onOpenAssistantRoleSettings: () -> Unit
) {
    val context = LocalContext.current
    var refreshTick by remember { mutableIntStateOf(0) }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        refreshTick++
    }

    fun isGranted(permission: String): Boolean {
        // Read refreshTick to re-evaluate after runtime permission prompt
        @Suppress("UNUSED_EXPRESSION")
        refreshTick
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("অনুমতি ও গোপনীয়তা", style = MaterialTheme.typography.headlineMedium, color = BrightGold)

        PermissionStatusRow(
            title = "মাইক্রোফোন (RECORD_AUDIO)",
            description = "বাংলা ভয়েস কমান্ড ও কথা বলার জন্য প্রয়োজন। কখনো গোপনে অডিও রেকর্ড করা হয় না।",
            granted = isGranted(Manifest.permission.RECORD_AUDIO),
            onRequestClick = { permLauncher.launch(Manifest.permission.RECORD_AUDIO) }
        )

        PermissionStatusRow(
            title = "কন্টাক্টস (READ_CONTACTS)",
            description = "শুধুমাত্র আপনার অনুরোধে নাম খুঁজে কল বা SMS করার জন্য।",
            granted = isGranted(Manifest.permission.READ_CONTACTS),
            onRequestClick = { permLauncher.launch(Manifest.permission.READ_CONTACTS) }
        )

        PermissionStatusRow(
            title = "ফোন কল (CALL_PHONE)",
            description = "সরাসরি কল শুরু করার আগে প্রতিবার নিশ্চিতকরণ ডায়ালগ দেখানো হয়।",
            granted = isGranted(Manifest.permission.CALL_PHONE),
            onRequestClick = { permLauncher.launch(Manifest.permission.CALL_PHONE) }
        )

        PermissionStatusRow(
            title = "SMS পাঠানো (SEND_SMS)",
            description = "আপনার স্পষ্ট সম্মতি ও নিশ্চিতকরণ ছাড়া কোনো SMS পাঠানো হয় না।",
            granted = isGranted(Manifest.permission.SEND_SMS),
            onRequestClick = { permLauncher.launch(Manifest.permission.SEND_SMS) }
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            PermissionStatusRow(
                title = "নোটিফিকেশন (POST_NOTIFICATIONS)",
                description = "ব্যাকগ্রাউন্ড ভয়েস সার্ভিস চালু থাকলে স্বচ্ছ নোটিফিকেশন দেখাতে।",
                granted = isGranted(Manifest.permission.POST_NOTIFICATIONS),
                onRequestClick = { permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
            )
        }

        GlassCard(borderColor = ImperialGold.copy(alpha = 0.45f)) {
            Text("অ্যান্ড্রয়েড ব্যাকগ্রাউন্ড ও নিরাপত্তা নীতি", style = MaterialTheme.typography.titleMedium, color = BrightGold)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "• Android নিরাপত্তা নীতির কারণে সাধারণ অ্যাপ স্ক্রিন বন্ধ থাকলে সব ফোনে হার্ডওয়্যার হটওয়ার্ড চালু রাখতে পারে না।\n" +
                    "• তাই আবু উবাইদা AI ফোরগ্রাউন্ড নোটিফিকেশনসহ স্বচ্ছ সার্ভিস এবং Android Assistant Role (VoiceInteractionService) ব্যবহার করে।\n" +
                    "• সব API কী ও OAuth টোকেন নিরাপদ এনক্রিপ্টেড স্টোরেজ বা সার্ভার-সাইড অ্যাপ চেকের মাধ্যমে পরিচালিত হয়।",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedButton(onClick = onOpenAssistantRoleSettings, modifier = Modifier.fillMaxWidth()) {
                Text("ডিফল্ট ডিজিটাল অ্যাসিস্ট্যান্ট সেটিংস", color = BrightGold)
            }
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedButton(onClick = onOpenBatterySettings, modifier = Modifier.fillMaxWidth()) {
                Text("ব্যাটারি অপটিমাইজেশন সেটিংস", color = ElectricBlue)
            }
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedButton(onClick = onOpenAppSettings, modifier = Modifier.fillMaxWidth()) {
                Text("সিস্টেম অ্যাপ পারমিশন পেজ", color = ElectricBlue)
            }
        }
    }
}
