package com.abuubaida.ai.phone

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import com.abuubaida.ai.data.model.ContactItem
import com.abuubaida.ai.data.model.InstalledAppInfo

class PhoneControlManager(private val context: Context) {

    fun hasPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }

    fun loadContacts(query: String = ""): List<ContactItem> {
        if (!hasPermission(Manifest.permission.READ_CONTACTS)) return emptyList()

        val contacts = mutableListOf<ContactItem>()
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val selection = if (query.isNotBlank()) {
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ? OR ${ContactsContract.CommonDataKinds.Phone.NUMBER} LIKE ?"
        } else null
        val selectionArgs = if (query.isNotBlank()) arrayOf("%$query%", "%$query%") else null

        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection,
            selection,
            selectionArgs,
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
        )?.use { cursor ->
            val idIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
            val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            val seen = HashSet<String>()
            while (cursor.moveToNext() && contacts.size < 100) {
                val id = if (idIdx >= 0) cursor.getString(idIdx) else ""
                val name = if (nameIdx >= 0) cursor.getString(nameIdx) else "অজানা পরিচিতি"
                val num = if (numIdx >= 0) cursor.getString(numIdx) else ""
                val normalized = num.replace("\\s+".toRegex(), "")
                if (normalized.isNotBlank() && seen.add("$name:$normalized")) {
                    contacts.add(ContactItem(id = id, name = name, phoneNumber = normalized))
                }
            }
        }
        return contacts
    }

    fun placeCall(phoneNumber: String, directCall: Boolean): Result<String> {
        val cleanNumber = phoneNumber.trim()
        if (cleanNumber.isBlank()) {
            return Result.failure(IllegalArgumentException("সঠিক ফোন নম্বর দিন।"))
        }

        return try {
            val useDirect = directCall && hasPermission(Manifest.permission.CALL_PHONE)
            val action = if (useDirect) Intent.ACTION_CALL else Intent.ACTION_DIAL
            val intent = Intent(action, Uri.parse("tel:${Uri.encode(cleanNumber)}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            if (useDirect) {
                Result.success("$cleanNumber নম্বরে সরাসরি কল করা হচ্ছে।")
            } else {
                Result.success("ডায়ালারে $cleanNumber নম্বর খোলা হয়েছে।")
            }
        } catch (e: Exception) {
            Result.failure(IllegalStateException("কল শুরু করা যায়নি: ${e.localizedMessage}"))
        }
    }

    fun sendSms(phoneNumber: String, message: String, useDirectApi: Boolean): Result<String> {
        val cleanNumber = phoneNumber.trim()
        val cleanMsg = message.trim()
        if (cleanNumber.isBlank() || cleanMsg.isBlank()) {
            return Result.failure(IllegalArgumentException("প্রাপকের নম্বর ও বার্তা উভয়ই প্রয়োজন।"))
        }

        return try {
            if (useDirectApi && hasPermission(Manifest.permission.SEND_SMS)) {
                val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    context.getSystemService(SmsManager::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    SmsManager.getDefault()
                }
                val parts = smsManager.divideMessage(cleanMsg)
                if (parts.size > 1) {
                    smsManager.sendMultipartTextMessage(cleanNumber, null, parts, null, null)
                } else {
                    smsManager.sendTextMessage(cleanNumber, null, cleanMsg, null, null)
                }
                Result.success("$cleanNumber নম্বরে SMS পাঠানো হয়েছে।")
            } else {
                val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(cleanNumber)}")).apply {
                    putExtra("sms_body", cleanMsg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                Result.success("নিরাপদ SMS কম্পোজার খোলা হয়েছে।")
            }
        } catch (e: Exception) {
            Result.failure(IllegalStateException("SMS পাঠানো যায়নি: ${e.localizedMessage}"))
        }
    }

    fun getInstalledLauncherApps(): List<InstalledAppInfo> {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
        return resolveInfos.mapNotNull { info ->
            val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
            if (pkg == context.packageName) return@mapNotNull null
            val label = info.loadLabel(pm)?.toString() ?: pkg
            InstalledAppInfo(packageName = pkg, appName = label)
        }.distinctBy { it.packageName }.sortedBy { it.appName.lowercase() }
    }

    fun launchAppByNameOrPackage(query: String): Result<String> {
        val q = query.trim().lowercase()
        val apps = getInstalledLauncherApps()
        val match = apps.firstOrNull {
            it.packageName.lowercase() == q || it.appName.lowercase().contains(q)
        } ?: return Result.failure(IllegalStateException("\"$query\" নামে কোনো ইনস্টল করা অ্যাপ পাওয়া যায়নি।"))

        val launchIntent = context.packageManager.getLaunchIntentForPackage(match.packageName)
            ?: return Result.failure(IllegalStateException("${match.appName} চালু করা যাচ্ছে না।"))
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launchIntent)
        return Result.success("${match.appName} চালু করা হয়েছে।")
    }

    fun openAndroidSettings(action: String = Settings.ACTION_SETTINGS): Result<String> {
        return try {
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success("অ্যান্ড্রয়েড সেটিংস খোলা হয়েছে।")
        } catch (_: Exception) {
            val fallback = Intent(Settings.ACTION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(fallback)
            Result.success("সিস্টেম সেটিংস খোলা হয়েছে।")
        }
    }

    fun setAlarm(hour: Int, minute: Int, label: String): Result<String> {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour.coerceIn(0, 23))
                putExtra(AlarmClock.EXTRA_MINUTES, minute.coerceIn(0, 59))
                putExtra(AlarmClock.EXTRA_MESSAGE, label.ifBlank { "আবু উবাইদা AI অ্যালার্ম" })
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success(String.format("%02d:%02d এর জন্য অ্যালার্ম অ্যাপ খোলা হয়েছে।", hour, minute))
        } catch (e: Exception) {
            Result.failure(IllegalStateException("অ্যালার্ম সেট করা যায়নি: ${e.localizedMessage}"))
        }
    }

    fun openAssistantRoleSettings(): Result<String> {
        return openAndroidSettings(Settings.ACTION_VOICE_INPUT_SETTINGS)
    }

    fun openBatteryOptimizationSettings(): Result<String> {
        return try {
            val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success("ব্যাটারি অপটিমাইজেশন সেটিংস খোলা হয়েছে।")
        } catch (_: Exception) {
            openAndroidSettings(Settings.ACTION_SETTINGS)
        }
    }

    fun openAppPermissionSettings(): Result<String> {
        return try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", context.packageName, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success("অ্যাপ অনুমতি সেটিংস খোলা হয়েছে।")
        } catch (_: Exception) {
            openAndroidSettings(Settings.ACTION_SETTINGS)
        }
    }
}
