# আবু উবাইদা AI (Abu Ubaida AI) — Native Android App

- **App Name:** আবু উবাইদা AI (Abu Ubaida AI)
- **Package ID:** `com.abuubaida.ai`
- **Language:** Bengali (Bangladesh, `bn-BD`)
- **Stack:** Kotlin, Jetpack Compose, Material 3, Firebase AI Logic + App Check, Android `SpeechRecognizer` & `TextToSpeech`, `VoiceInteractionService`, Google OAuth + YouTube Data API v3.

---

## Building the APK Using Only an Android Phone (No PC Required)

Because Jetpack Compose + Android Gradle Plugin builds require JDK 17 and the Android SDK, the **fastest, most reliable way on an Android phone** is **GitHub Actions** (100% free for public repos, runs in the cloud from your phone's browser):

### Method 1: GitHub + GitHub Actions (Recommended on Phone)
1. Download/extract the `AbuUbaidaAI` folder on your phone (using **ZArchiver** or **Files by Google**).
2. Open **GitHub** in your phone browser (or the GitHub Android app) and create a new repository (e.g., `AbuUbaidaAI`).
3. Upload the project files (or push them using **Termux** + `git`). Make sure `.github/workflows/android-build.yml` is included.
4. Go to your repository's **Actions** tab on your phone browser.
5. Tap **Build Abu Ubaida AI APK** -> **Run workflow** (or push to `main`).
6. Once the green checkmark appears (~2–3 minutes), scroll down to **Artifacts**, download **`AbuUbaidaAI-debug-apk`**, unzip it, and install `app-debug.apk` on your phone!

### Method 2: Termux on Android (Advanced, Offline Local Build)
If your phone has at least 6–8 GB RAM and 5+ GB free storage:
1. Install **Termux** from F-Droid (not Play Store).
2. Run:
   ```bash
   pkg update && pkg upgrade -y
   pkg install openjdk-17 gradle git wget unzip -y
   ```
3. Install Android `commandlinetools` (`linux` / `arm64` compatible `aapt2` override in `gradle.properties` using `android.aapt2FromMavenOverride`), accept SDK licenses via `sdkmanager`, and set `sdk.dir` in `local.properties`.
4. Run `gradle assembleDebug` inside the `AbuUbaidaAI` directory. (Note: Method 1 via GitHub Actions is much simpler and avoids ARM64 `aapt2` issues on phones.)

---

## Connecting Firebase AI Logic & YouTube OAuth (No Hardcoded Secrets)
1. **Gemini via Firebase AI Logic:**
   - Create a project in [Firebase Console](https://console.firebase.google.com/), add an Android app with package `com.abuubaida.ai`, enable **Firebase AI Logic (Gemini Developer API)** and **App Check (Play Integrity)**, download `google-services.json`, and place it at `app/google-services.json` (never commit real secrets publicly; use GitHub Actions Secrets if building in a public repo).
   - Alternatively, deploy a lightweight HTTPS proxy server and paste its URL inside **সেটিংস -> সার্ভার প্রক্সি HTTPS URL**.
2. **YouTube Studio OAuth:**
   - Enable **YouTube Data API v3** in Google Cloud Console, configure the OAuth consent screen, and add an **Android OAuth Client ID** using package `com.abuubaida.ai` and your keystore's SHA-1 fingerprint.
