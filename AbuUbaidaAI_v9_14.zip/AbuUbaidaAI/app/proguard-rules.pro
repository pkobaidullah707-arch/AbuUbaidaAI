# Keep Firebase AI Logic & App Check classes
-keep class com.google.firebase.ai.** { *; }
-keep class com.google.firebase.appcheck.** { *; }
-keep class com.google.android.gms.auth.** { *; }
