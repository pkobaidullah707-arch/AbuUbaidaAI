package com.abuubaida.ai.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.abuubaida.ai.data.model.ContactItem
import com.abuubaida.ai.ui.components.GlassCard
import com.abuubaida.ai.ui.theme.BrightGold
import com.abuubaida.ai.ui.theme.DeepNavyBg
import com.abuubaida.ai.ui.theme.ElectricBlue
import com.abuubaida.ai.ui.theme.ImperialGold
import com.abuubaida.ai.ui.theme.NavyBorder
import com.abuubaida.ai.ui.theme.TextPrimary
import com.abuubaida.ai.ui.theme.TextSecondary

@Composable
fun SmsScreen(
    contacts: List<ContactItem>,
    onSendSmsRequested: (recipientName: String, phoneNumber: String, message: String, useDirectApi: Boolean) -> Unit
) {
    val context = LocalContext.current
    var recipientName by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }
    var messageBody by remember { mutableStateOf("") }
    var useDirectSmsManager by remember { mutableStateOf(false) }

    val smsPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            useDirectSmsManager = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("বাংলা SMS স্টুডিও", style = MaterialTheme.typography.headlineMedium, color = BrightGold)

        GlassCard(borderColor = ImperialGold.copy(alpha = 0.45f)) {
            OutlinedTextField(
                value = phoneNumber,
                onValueChange = { phoneNumber = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("প্রাপকের ফোন নম্বর") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = NavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = messageBody,
                onValueChange = { messageBody = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp),
                label = { Text("বার্তা লিখুন (বাংলা বা ইংরেজি)") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = NavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("সরাসরি SmsManager API ব্যবহার", color = TextPrimary, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "বন্ধ রাখলে ফোনের নিরাপদ SMS অ্যাপ খুলবে (সুপারিশকৃত)।",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                Switch(
                    checked = useDirectSmsManager,
                    onCheckedChange = { checked ->
                        if (checked) {
                            val granted = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.SEND_SMS
                            ) == PackageManager.PERMISSION_GRANTED
                            if (!granted) {
                                smsPermissionLauncher.launch(Manifest.permission.SEND_SMS)
                            }
                        }
                        useDirectSmsManager = checked
                    }
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = {
                    onSendSmsRequested(
                        recipientName.ifBlank { phoneNumber },
                        phoneNumber,
                        messageBody,
                        useDirectSmsManager
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = ImperialGold, contentColor = DeepNavyBg)
            ) {
                Text("নিশ্চিত করে SMS পাঠান")
            }
        }

        if (contacts.isNotEmpty()) {
            GlassCard {
                Text("দ্রুত কন্টাক্ট নির্বাচন", style = MaterialTheme.typography.titleMedium, color = ElectricBlue)
                Spacer(modifier = Modifier.height(8.dp))
                contacts.take(5).forEach { contact ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(contact.name, color = TextPrimary)
                            Text(contact.phoneNumber, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                        }
                        OutlinedButton(onClick = {
                            recipientName = contact.name
                            phoneNumber = contact.phoneNumber
                        }) {
                            Text("নির্বাচন", color = BrightGold)
                        }
                    }
                }
            }
        }
    }
}
