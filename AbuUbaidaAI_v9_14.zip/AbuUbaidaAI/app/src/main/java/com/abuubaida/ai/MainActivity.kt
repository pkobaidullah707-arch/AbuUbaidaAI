package com.abuubaida.ai

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.abuubaida.ai.data.model.Screen
import com.abuubaida.ai.ui.AbuUbaidaApp
import com.abuubaida.ai.ui.AbuUbaidaViewModel
import com.abuubaida.ai.ui.theme.AbuUbaidaTheme
import com.abuubaida.ai.voice.BackgroundVoiceService

class MainActivity : ComponentActivity() {

    private val viewModel: AbuUbaidaViewModel by viewModels {
        AbuUbaidaViewModel.Factory((application as AbuUbaidaApplication).container)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            enableEdgeToEdge()
        } catch (_: Throwable) {
        }
        try {
            handleAssistantLaunchIntent(intent)
            setContent {
                AbuUbaidaTheme {
                    AbuUbaidaApp(viewModel = viewModel)
                }
            }
        } catch (t: Throwable) {
            setContent {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF060B18))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "অ্যাপ চালুর সময় ত্রুটি হয়েছে: ${t.localizedMessage ?: t::class.java.simpleName}",
                        color = Color(0xFFFCD34D)
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        try {
            handleAssistantLaunchIntent(intent)
        } catch (_: Throwable) {
        }
    }

    private fun handleAssistantLaunchIntent(intent: Intent?) {
        val triggeredByWake = intent?.getBooleanExtra(BackgroundVoiceService.EXTRA_WAKE_TRIGGERED, false) == true
        val isAssistAction = intent?.action == Intent.ACTION_ASSIST
        if (triggeredByWake || isAssistAction) {
            viewModel.navigateTo(Screen.VoiceAssistant)
        }
    }
}
