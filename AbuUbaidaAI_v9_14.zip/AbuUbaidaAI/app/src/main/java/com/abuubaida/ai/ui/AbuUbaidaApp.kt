package com.abuubaida.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MovieCreation
import androidx.compose.material.icons.rounded.PhoneInTalk
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Sms
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material.icons.rounded.Upload
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.abuubaida.ai.data.model.Screen
import com.abuubaida.ai.data.model.VoiceState
import com.abuubaida.ai.ui.components.AbuUbaidaLogo
import com.abuubaida.ai.ui.components.SensitiveActionConfirmationDialog
import com.abuubaida.ai.ui.screens.AiChatScreen
import com.abuubaida.ai.ui.screens.FacebookStudioScreen
import com.abuubaida.ai.ui.screens.HomeScreen
import com.abuubaida.ai.ui.screens.PermissionsPrivacyScreen
import com.abuubaida.ai.ui.screens.PhoneControlScreen
import com.abuubaida.ai.ui.screens.SettingsScreen
import com.abuubaida.ai.ui.screens.SmsScreen
import com.abuubaida.ai.ui.screens.TrendResearchScreen
import com.abuubaida.ai.ui.screens.VideoStudioScreen
import com.abuubaida.ai.ui.screens.VoiceAssistantScreen
import com.abuubaida.ai.ui.screens.YouTubeStudioScreen
import com.abuubaida.ai.ui.theme.BrightGold
import com.abuubaida.ai.ui.theme.DeepNavyBg
import com.abuubaida.ai.ui.theme.ElectricBlue
import com.abuubaida.ai.ui.theme.NavyCard
import com.abuubaida.ai.ui.theme.NavySurface
import com.abuubaida.ai.ui.theme.TextPrimary
import com.abuubaida.ai.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AbuUbaidaApp(viewModel: AbuUbaidaViewModel) {
    val context = LocalContext.current
    val currentScreen by viewModel.currentScreen.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val masterControls by viewModel.masterControls.collectAsState()
    val contacts by viewModel.contacts.collectAsState()
    val installedApps by viewModel.installedApps.collectAsState()
    val videoProject by viewModel.videoProject.collectAsState()
    val trendReport by viewModel.trendReport.collectAsState()
    val recommendation by viewModel.publishingRecommendation.collectAsState()
    val autonomousProgressBn by viewModel.autonomousProgressBn.collectAsState()
    val isBusy by viewModel.isBusy.collectAsState()
    val banner by viewModel.statusBannerBn.collectAsState()
    val pendingAction by viewModel.pendingAction.collectAsState()
    val youTubeAccount by viewModel.youTubeAccount.collectAsState()
    val youTubeConnected by viewModel.youTubeConnected.collectAsState()
    val youTubeRequest by viewModel.youTubeUploadRequest.collectAsState()
    val facebookAccount by viewModel.facebookAccount.collectAsState()
    val facebookRequest by viewModel.facebookUploadRequest.collectAsState()
    val voiceState by viewModel.voiceState.collectAsState()
    val rmsLevel by viewModel.rmsLevel.collectAsState()
    val partialTranscript by viewModel.partialTranscript.collectAsState()
    val ttsSupportedBn by viewModel.ttsSupportedBn.collectAsState()
    val availableVoices by viewModel.availableVoices.collectAsState()
    val isPlayingQuranAudio by viewModel.isPlayingQuranAudio.collectAsState()

    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(banner) {
        banner?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearBanner()
        }
    }

    pendingAction?.let { action ->
        SensitiveActionConfirmationDialog(
            action = action,
            onConfirm = { viewModel.confirmPendingAction() },
            onSelectAlternateContact = { viewModel.selectAlternateCallContact(it) },
            onDismiss = { viewModel.dismissPendingAction() }
        )
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = NavySurface,
                drawerContentColor = TextPrimary
            ) {
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    AbuUbaidaLogo(size = 42.dp)
                    Text(
                        text = "আবু উবাইদা AI",
                        style = MaterialTheme.typography.titleLarge,
                        color = BrightGold
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
                Screen.entries.forEach { screen ->
                    NavigationDrawerItem(
                        icon = { Icon(iconForScreen(screen), contentDescription = screen.titleBn) },
                        label = { Text(screen.titleBn) },
                        selected = currentScreen == screen,
                        onClick = {
                            viewModel.navigateTo(screen)
                            scope.launch { drawerState.close() }
                        },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = NavyCard,
                            selectedIconColor = BrightGold,
                            selectedTextColor = BrightGold,
                            unselectedIconColor = ElectricBlue,
                            unselectedTextColor = TextPrimary
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 2.dp)
                    )
                }
            }
        }
    ) {
        Scaffold(
            containerColor = DeepNavyBg,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = NavySurface,
                        titleContentColor = BrightGold
                    ),
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Rounded.Menu, contentDescription = "মেনু", tint = BrightGold)
                        }
                    },
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AbuUbaidaLogo(size = 30.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = if (currentScreen == Screen.Home) "আবু উবাইদা AI" else currentScreen.titleBn,
                                style = MaterialTheme.typography.titleLarge,
                                color = BrightGold
                            )
                        }
                    }
                )
            },
            bottomBar = {
                val primaryTabs = listOf(
                    Screen.Home,
                    Screen.VoiceAssistant,
                    Screen.TrendResearch,
                    Screen.VideoStudio,
                    Screen.YouTubeStudio
                )
                NavigationBar(containerColor = NavySurface) {
                    primaryTabs.forEach { tab ->
                        NavigationBarItem(
                            selected = currentScreen == tab,
                            onClick = { viewModel.navigateTo(tab) },
                            icon = { Icon(iconForScreen(tab), contentDescription = tab.titleBn) },
                            label = { Text(tab.titleBn, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BrightGold,
                                selectedTextColor = BrightGold,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary,
                                indicatorColor = NavyCard
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentScreen) {
                    Screen.Home -> HomeScreen(
                        wakePhrase = settings.wakePhrase,
                        voiceState = voiceState,
                        rmsLevel = rmsLevel,
                        lastReply = messages.lastOrNull { !it.isUser }?.text.orEmpty(),
                        masterControls = masterControls,
                        onMicToggle = {
                            if (voiceState is VoiceState.Listening) {
                                viewModel.stopVoiceListening()
                            } else {
                                viewModel.startVoiceListening()
                            }
                        },
                        onRunDailyAutonomous = {
                            viewModel.runAutonomousDailyWorkflow(
                                uploadToYouTube = false,
                                uploadToFacebook = false,
                                speakResult = settings.ttsEnabled
                            )
                        },
                        onNavigate = { viewModel.navigateTo(it) }
                    )

                    Screen.VoiceAssistant -> VoiceAssistantScreen(
                        voiceState = voiceState,
                        rmsLevel = rmsLevel,
                        partialTranscript = partialTranscript,
                        ttsSupportedBn = ttsSupportedBn,
                        continuousVoiceMode = settings.continuousVoiceMode,
                        speechLanguageTag = settings.speechLanguageTag,
                        recentMessages = messages,
                        fallbackSpeechIntent = remember(viewModel, settings.speechLanguageTag) {
                            viewModel.buildFallbackSpeechIntent()
                        },
                        onToggleContinuousMode = { viewModel.toggleContinuousVoiceMode(it, context) },
                        onSelectSpeechLanguage = { viewModel.toggleSpeechLanguage(it, context) },
                        onStartListening = { viewModel.startVoiceListening() },
                        onStopListening = { viewModel.stopVoiceListening() },
                        onStopSpeaking = { viewModel.stopSpeaking() },
                        onSpeakText = { viewModel.speakText(it) },
                        onSubmitCommand = { viewModel.handleUserPrompt(it) }
                    )

                    Screen.AiChat -> AiChatScreen(
                        messages = messages,
                        isBusy = isBusy,
                        onSendMessage = { viewModel.handleUserPrompt(it) },
                        onStartVoiceInput = { viewModel.startVoiceListening() },
                        onSpeakMessage = { viewModel.speakText(it) },
                        onClearHistory = { viewModel.clearChatHistory() }
                    )

                    Screen.TrendResearch -> TrendResearchScreen(
                        report = trendReport,
                        isBusy = isBusy,
                        trendResearchEnabled = masterControls.trendResearchEnabled,
                        onRunResearch = { viewModel.runTrendResearch(speakSummary = false) },
                        onCreateVideoFromTrend = { topic, category, format ->
                            viewModel.navigateTo(Screen.VideoStudio)
                            viewModel.generateVideoStudioProject(topic, category, format, speakResult = false)
                        }
                    )

                    Screen.VideoStudio -> VideoStudioScreen(
                        project = videoProject,
                        recommendation = recommendation,
                        currentSettings = settings,
                        availableVoices = availableVoices,
                        isPlayingQuranAudio = isPlayingQuranAudio,
                        isBusy = isBusy,
                        autonomousProgressBn = autonomousProgressBn,
                        mp4ProviderConnected = viewModel.isMp4ProviderConnected(),
                        contentCreationEnabled = masterControls.contentCreationEnabled,
                        onGenerateProject = { topic, cat, fmt, dur ->
                            viewModel.generateVideoStudioProject(topic, cat, fmt, durationOption = dur, speakResult = false)
                        },
                        onRunDailyAutonomous = { dur ->
                            viewModel.runAutonomousDailyWorkflow(
                                uploadToYouTube = false,
                                uploadToFacebook = false,
                                durationOption = dur,
                                speakResult = false
                            )
                        },
                        onExportMp4OrScript = { viewModel.exportVideoMp4OrScript() },
                        onSpeakScript = { viewModel.speakText(it) },
                        onToggleQuranRecitation = { viewModel.toggleQuranRecitation(it) },
                        onUpdateSettings = { viewModel.updateSettings(it, context) },
                        onPreviewVoice = { viewModel.previewVoiceSettings(it) },
                        onCopiedAll = { viewModel.showBanner("সব ভিডিও কন্টেন্ট ক্লিপবোর্ডে কপি হয়েছে!") },
                        onSendToYouTubeStudio = { viewModel.navigateTo(Screen.YouTubeStudio) },
                        onSendToFacebookStudio = { viewModel.navigateTo(Screen.FacebookStudio) }
                    )

                    Screen.YouTubeStudio -> YouTubeStudioScreen(
                        accountInfo = youTubeAccount,
                        youTubeEnabled = masterControls.youTubeConnectionEnabled,
                        autoUploadEnabled = masterControls.autoUploadEnabled,
                        isBusy = isBusy,
                        uploadRequest = youTubeRequest,
                        recommendation = recommendation,
                        onToggleYouTubeEnabled = { enabled ->
                            viewModel.updateMasterControls(masterControls.copy(youTubeConnectionEnabled = enabled))
                        },
                        onToggleAutoUpload = { enabled ->
                            viewModel.updateMasterControls(masterControls.copy(autoUploadEnabled = enabled))
                        },
                        onUpdateRequest = { viewModel.updateYouTubeRequest(it) },
                        onPickVideo = { viewModel.onVideoFilePicked(it) },
                        onConnectOAuth = { act, onConsent -> viewModel.connectYouTubeOAuth(act, onConsent) },
                        onConnectEasy = { ch, tok -> viewModel.connectYouTubeEasy(ch, tok) },
                        onConsentResult = { viewModel.handleYouTubeConsentResult(it) },
                        onDisconnectOAuth = { viewModel.disconnectYouTube() },
                        onRequestPublish = { viewModel.requestYouTubePublishConfirmation(it) },
                        onShareToYouTubeApp = { req ->
                            viewModel.shareVideoExternally(context, req.videoUriString, req.title, req.description)
                        },
                        onCheckStatus = { viewModel.checkYouTubeUploadStatus(it) }
                    )

                    Screen.FacebookStudio -> FacebookStudioScreen(
                        accountInfo = facebookAccount,
                        facebookEnabled = masterControls.facebookConnectionEnabled,
                        isBusy = isBusy,
                        savedMetaAppId = viewModel.getSavedMetaAppId(),
                        uploadRequest = facebookRequest,
                        onToggleFacebookEnabled = { enabled ->
                            viewModel.updateMasterControls(masterControls.copy(facebookConnectionEnabled = enabled))
                        },
                        onUpdateRequest = { viewModel.updateFacebookRequest(it) },
                        onPickVideo = { viewModel.onVideoFilePicked(it) },
                        onConnectPage = { pageId, token -> viewModel.connectFacebookPage(pageId, token) },
                        onBuildMetaOAuthUrl = { appId -> viewModel.buildMetaOAuthUrl(appId) },
                        onDisconnectPage = { viewModel.disconnectFacebookPage() },
                        onRequestPublish = { viewModel.requestFacebookPublishConfirmation(it) },
                        onShareToFacebookApp = { req ->
                            viewModel.shareVideoExternally(context, req.videoUriString, req.title, req.caption)
                        },
                        onCheckStatus = { viewModel.checkFacebookUploadStatus(it) }
                    )

                    Screen.PhoneControl -> PhoneControlScreen(
                        contacts = contacts,
                        installedApps = installedApps,
                        onRefreshContacts = { viewModel.refreshContacts(it) },
                        onRequestCall = { name, num, direct ->
                            viewModel.requestCallConfirmation(name, num, direct)
                        },
                        onLaunchApp = { viewModel.launchInstalledApp(it) },
                        onOpenSettings = { viewModel.openAndroidSettings(it) },
                        onSetAlarm = { h, m, lbl -> viewModel.setAlarm(h, m, lbl) }
                    )

                    Screen.Sms -> SmsScreen(
                        contacts = contacts,
                        onSendSmsRequested = { name, num, msg, direct ->
                            viewModel.requestSmsConfirmation(name, num, msg, direct)
                        }
                    )

                    Screen.PermissionsPrivacy -> PermissionsPrivacyScreen(
                        masterControls = masterControls,
                        backgroundVoiceEnabled = settings.backgroundServiceEnabled,
                        isKeystoreEncrypted = viewModel.isKeystoreEncrypted(),
                        youTubeAccount = youTubeAccount,
                        facebookAccount = facebookAccount,
                        onUpdateMasterControls = { viewModel.updateMasterControls(it) },
                        onToggleBackgroundVoice = { enabled ->
                            viewModel.updateSettings(settings.copy(backgroundServiceEnabled = enabled), context)
                        },
                        onEmergencyStopAll = { viewModel.emergencyStopAllBackgroundActivity(context) },
                        onDisconnectYouTube = { viewModel.disconnectYouTube() },
                        onDisconnectFacebook = { viewModel.disconnectFacebookPage() },
                        onWipeAllData = { viewModel.wipeAllLocalData(context) },
                        onOpenAppSettings = { viewModel.openAppPermissionSettings() },
                        onOpenBatterySettings = { viewModel.openBatteryOptimizationSettings() },
                        onOpenAssistantRoleSettings = { viewModel.openAssistantRoleSettings() }
                    )

                    Screen.Settings -> SettingsScreen(
                        currentSettings = settings,
                        availableVoices = availableVoices,
                        isFirebaseConfigured = viewModel.isFirebaseConfigured(),
                        onSaveSettings = { viewModel.updateSettings(it, context) },
                        onPreviewVoice = { viewModel.previewVoiceSettings(it) },
                        onOpenInstallTtsData = { viewModel.openInstallTtsVoiceData() },
                        onOpenAssistantRoleSettings = { viewModel.openAssistantRoleSettings() },
                        onOpenBatterySettings = { viewModel.openBatteryOptimizationSettings() }
                    )
                }
            }
        }
    }
}

private fun iconForScreen(screen: Screen): ImageVector = when (screen) {
    Screen.Home -> Icons.Rounded.Home
    Screen.VoiceAssistant -> Icons.Rounded.Mic
    Screen.AiChat -> Icons.Rounded.Chat
    Screen.TrendResearch -> Icons.Rounded.TrendingUp
    Screen.VideoStudio -> Icons.Rounded.MovieCreation
    Screen.YouTubeStudio -> Icons.Rounded.Upload
    Screen.FacebookStudio -> Icons.Rounded.Public
    Screen.PhoneControl -> Icons.Rounded.PhoneInTalk
    Screen.Sms -> Icons.Rounded.Sms
    Screen.PermissionsPrivacy -> Icons.Rounded.Security
    Screen.Settings -> Icons.Rounded.Settings
}
