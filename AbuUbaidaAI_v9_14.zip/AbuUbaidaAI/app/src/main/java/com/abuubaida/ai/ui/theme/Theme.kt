package com.abuubaida.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val AbuUbaidaColorScheme = darkColorScheme(
    primary = ElectricBlue,
    onPrimary = DeepNavyBg,
    primaryContainer = DeepBlueGlow,
    onPrimaryContainer = TextPrimary,
    secondary = ImperialGold,
    onSecondary = DeepNavyBg,
    secondaryContainer = NavyCard,
    onSecondaryContainer = BrightGold,
    tertiary = RoyalBlue,
    background = DeepNavyBg,
    onBackground = TextPrimary,
    surface = NavySurface,
    onSurface = TextPrimary,
    surfaceVariant = NavyCard,
    onSurfaceVariant = TextSecondary,
    outline = NavyBorder,
    error = CrimsonWarn,
    onError = TextPrimary
)

@Composable
fun AbuUbaidaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AbuUbaidaColorScheme,
        typography = AbuUbaidaTypography,
        content = content
    )
}
