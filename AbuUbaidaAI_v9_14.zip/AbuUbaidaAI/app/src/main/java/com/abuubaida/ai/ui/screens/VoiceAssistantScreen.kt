package com.abuubaida.ai.ui.screens

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.SpeechRecognizer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.abuubaida.ai.data.model.ChatMessage
import com.abuubaida.ai.data.model.VoiceState
import com.abuubaida.ai.ui.components.AnimatedVoiceOrb
import com.abuubaida.ai.ui.components.GlassCard
import com.abuubaida.ai.ui.theme.BrightGold
import com.abuubaida.ai.ui.theme.DeepNavyBg
import com.abuubaida.ai.ui.theme.ElectricBlue
import com.abuubaida.ai.ui.theme.ImperialGold
import com.abuubaida.ai.ui.theme.NavyBorder
import com.abuubaida.ai.ui.theme.RoyalBlue
import com.abuubaida.ai.ui.theme.TextPrimary
import com.abuubaida.ai.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VoiceAssistantScreen(
    voiceState: VoiceState,
    rmsLevel: Float,
    partialTranscript: String,
    ttsSupportedBn: Boolean,
    continuousVoiceMode: Boolean,
    speechLanguageTag: String,
    recentMessages: List<ChatMessage>,
    fallbackSpeechIntent: Intent,
    onToggleContinuousMode: (Boolean) -> Unit,
    onSelectSpeechLanguage: (String) -> Unit,
    onStartListening: () -> Unit,
    onStopListening: () -> Unit,
    onStopSpeaking: () -> Unit,
    onSpeakText: (String) -> Unit,
    onSubmitCommand: (String) -> Unit
) {
    val context = LocalContext.current
    var manualInput by remember { mutableStateOf("") }

    val micLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) onStartListening()
    }

    val googleDialogVoiceLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val text = result.data
                ?.getStringArrayListExtra(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.trim()
                .orEmpty()
            if (text.isNotBlank()) {
                onSubmitCommand(text)
            }
        }
    }

    fun handleOrbTap() {
        when (voiceState) {
            is VoiceState.Listening -> onStopListening()
            is VoiceState.Speaking -> onStopSpeaking()
            else -> {
                val ok = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
                if (ok) onStartListening() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "আবু উবাইদা AI — বাংলা ভয়েস",
            style = MaterialTheme.typography.headlineMedium,
            color = BrightGold
        )
        if (!ttsSupportedBn) {
            Text(
                text = "এই ডিভাইসে বাংলা TTS ভয়েস প্যাক অনুপস্থিত; লিখিত উত্তর দেখানো হবে।",
                style = MaterialTheme.typography.bodyMedium,
                color = ImperialGold
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        AnimatedVoiceOrb(
            voiceState = voiceState,
            rmsLevel = rmsLevel,
            onMicClick = { handleOrbTap() }
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(
                onClick = {
                    try {
                        googleDialogVoiceLauncher.launch(fallbackSpeechIntent)
                    } catch (_: Exception) {
                        handleOrbTap()
                    }
                },
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Rounded.Mic, contentDescription = null, tint = BrightGold)
                Text("  গুগল ভয়েস ডায়ালগ", color = ElectricBlue)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        GlassCard(borderColor = NavyBorder) {
            Text(
                text = "ভয়েস শোনার ভাষা (কন্টাক্ট বা ইংরেজি নামের জন্য সুইচ করুন)",
                color = BrightGold,
                style = MaterialTheme.typography.labelLarge
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = speechLanguageTag == "bn-BD",
                    onClick = { onSelectSpeechLanguage("bn-BD") },
                    label = { Text("বাংলা (bn-BD)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = RoyalBlue,
                        selectedLabelColor = TextPrimary,
                        containerColor = DeepNavyBg,
                        labelColor = TextSecondary
                    ),
                    modifier = Modifier.weight(1f)
                )
                FilterChip(
                    selected = speechLanguageTag == "en-US",
                    onClick = { onSelectSpeechLanguage("en-US") },
                    label = { Text("English (en-US)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = RoyalBlue,
                        selectedLabelColor = TextPrimary,
                        containerColor = DeepNavyBg,
                        labelColor = TextSecondary
                    ),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        GlassCard(borderColor = NavyBorder) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("হ্যান্ডস-ফ্রি কন্টিনিউয়াস মোড", color = TextPrimary, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "উত্তর বলার পর নিজে থেকেই আবার আপনার কথা শুনবে",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                Switch(
                    checked = continuousVoiceMode,
                    onCheckedChange = onToggleContinuousMode
                )
            }
        }

        if (partialTranscript.isNotBlank()) {
            Spacer(modifier = Modifier.height(10.dp))
            GlassCard(borderColor = ImperialGold.copy(alpha = 0.5f)) {
                Text("আপনি বলেছেন:", style = MaterialTheme.typography.labelLarge, color = BrightGold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(partialTranscript, style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "এই কমান্ডগুলো মুখে বলে পরীক্ষা করুন:",
            style = MaterialTheme.typography.labelLarge,
            color = BrightGold,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(6.dp))

        val sampleCommands = listOf(
            "আবু উবাইদা, একটি ইসলামিক ভিডিও তৈরি করো",
            "আজকের ট্রেন্ড অনুযায়ী একটি ভিডিও বানাও",
            "একটি কোরআন তেলাওয়াতের ভিডিও তৈরি করো",
            "আমার চ্যানেলের জন্য ভালো কনটেন্ট খুঁজে বের করো",
            "আগামীকালের জন্য একটি ভিডিও তৈরি করে Schedule করো",
            "আমার YouTube চ্যানেলে আপলোড করো",
            "আমার Facebook পেজে আপলোড করো",
            "এখন কয়টা বাজে?",
            "টর্চ জ্বালাও",
            "৫ মিনিটের টাইমার দাও"
        )
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            sampleCommands.forEach { cmd ->
                AssistChip(
                    onClick = { onSubmitCommand(cmd) },
                    label = { Text(cmd, color = TextPrimary) },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = DeepNavyBg,
                        labelColor = TextPrimary
                    ),
                    border = AssistChipDefaults.assistChipBorder(enabled = true, borderColor = NavyBorder)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = manualInput,
                onValueChange = { manualInput = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("বাংলায় নির্দেশ লিখুন...", color = TextSecondary) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = NavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                singleLine = true
            )
            Button(
                onClick = {
                    if (manualInput.isNotBlank()) {
                        onSubmitCommand(manualInput)
                        manualInput = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue, contentColor = TextPrimary)
            ) {
                Text("চালান")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        recentMessages.takeLast(4).reversed().forEach { msg ->
            GlassCard(
                modifier = Modifier.padding(bottom = 8.dp),
                borderColor = if (msg.isUser) ElectricBlue.copy(alpha = 0.4f) else ImperialGold.copy(alpha = 0.4f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (msg.isUser) "আপনি" else "আবু উবাইদা AI",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (msg.isUser) ElectricBlue else BrightGold
                    )
                    if (!msg.isUser) {
                        IconButton(onClick = { onSpeakText(msg.text) }) {
                            Icon(
                                imageVector = if (voiceState is VoiceState.Speaking) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp,
                                contentDescription = "ভয়েসে শুনুন",
                                tint = BrightGold
                            )
                        }
                    }
                }
                Text(text = msg.text, style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
            }
        }
    }
}
