package com.abuubaida.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.abuubaida.ai.data.model.IslamicCategory
import com.abuubaida.ai.data.model.TrendResearchReport
import com.abuubaida.ai.data.model.VideoFormat
import com.abuubaida.ai.ui.components.GlassCard
import com.abuubaida.ai.ui.theme.AmberGold
import com.abuubaida.ai.ui.theme.BrightGold
import com.abuubaida.ai.ui.theme.DeepNavyBg
import com.abuubaida.ai.ui.theme.ElectricBlue
import com.abuubaida.ai.ui.theme.EmeraldOk
import com.abuubaida.ai.ui.theme.ImperialGold
import com.abuubaida.ai.ui.theme.NavyBorder
import com.abuubaida.ai.ui.theme.RoyalBlue
import com.abuubaida.ai.ui.theme.TextPrimary
import com.abuubaida.ai.ui.theme.TextSecondary

@Composable
fun TrendResearchScreen(
    report: TrendResearchReport?,
    isBusy: Boolean,
    trendResearchEnabled: Boolean,
    onRunResearch: () -> Unit,
    onCreateVideoFromTrend: (String, IslamicCategory, VideoFormat) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("ইসলামিক ট্রেন্ড রিসার্চ", style = MaterialTheme.typography.headlineMedium, color = BrightGold)

        GlassCard(borderColor = ImperialGold.copy(alpha = 0.45f)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.TrendingUp, contentDescription = null, tint = BrightGold)
                Text("বৈধ ও স্বচ্ছ ডেটা বিশ্লেষণ", style = MaterialTheme.typography.titleMedium, color = BrightGold)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "YouTube পাবলিক সার্চ সাজেশন (BD), Google Trends RSS এবং আপনার অনুমোদিত চ্যানেল থেকে আসল ডেটা বিশ্লেষণ করা হয়। কোনো ভুয়া পরিসংখ্যান তৈরি করা হয় না।",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = onRunResearch,
                enabled = !isBusy && trendResearchEnabled,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = ImperialGold, contentColor = DeepNavyBg)
            ) {
                Icon(Icons.Rounded.Refresh, contentDescription = null)
                Text(if (trendResearchEnabled) "  এখনই ট্রেন্ড রিসার্চ করুন" else "  ট্রেন্ড রিসার্চ মাস্টার কন্ট্রোল থেকে বন্ধ")
            }
            if (isBusy) {
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = ImperialGold)
            }
        }

        if (report != null) {
            GlassCard(borderColor = ElectricBlue.copy(alpha = 0.4f)) {
                Text("স্মার্ট ফরম্যাট ও প্রকাশের সময়", style = MaterialTheme.typography.titleMedium, color = ElectricBlue)
                Spacer(modifier = Modifier.height(6.dp))
                Text("প্রস্তাবিত ফরম্যাট: ${report.recommendedFormat.labelBn}", color = BrightGold, style = MaterialTheme.typography.labelLarge)
                Text("সেরা সময়: ${report.recommendedPublishTimeBn}", color = EmeraldOk, style = MaterialTheme.typography.bodyLarge)
                Spacer(modifier = Modifier.height(6.dp))
                report.dataSourcesStatusBn.forEach { src ->
                    Text("• $src", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                }
            }

            report.channelSummary?.let { ch ->
                GlassCard(borderColor = EmeraldOk.copy(alpha = 0.45f)) {
                    Text("আপনার YouTube চ্যানেলের আসল পরিসংখ্যান", style = MaterialTheme.typography.titleMedium, color = EmeraldOk)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("চ্যানেল: ${ch.channelTitle}", color = TextPrimary)
                    if (ch.subscriberCount >= 0) Text("সাবস্ক্রাইবার: ${ch.subscriberCount} | মোট ভিডিও: ${ch.totalVideoCount}", color = TextSecondary)
                    Text("সাম্প্রতিক ${ch.recentVideosAnalyzed}টি ভিডিওতে গড় ভিউ: ${ch.avgRecentViews}", color = BrightGold)
                    Text("সেরা পারফরম্যান্স: ${ch.bestPerformingFormatBn}", color = ElectricBlue)
                }
            }

            if (report.facebookInsightsNoteBn.isNotBlank()) {
                GlassCard(borderColor = NavyBorder) {
                    Text("Meta / Facebook ইনসাইটস অবস্থা", style = MaterialTheme.typography.titleMedium, color = AmberGold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(report.facebookInsightsNoteBn, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                }
            }

            Text("প্রস্তাবিত ইসলামিক কনটেন্ট আইডিয়া (${report.trends.size})", style = MaterialTheme.typography.titleLarge, color = BrightGold)

            report.trends.forEach { item ->
                GlassCard(borderColor = NavyBorder) {
                    Text(item.topic, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("উৎস: ${item.sourceBn} · ${item.suggestedCategory.labelBn}", color = ElectricBlue, style = MaterialTheme.typography.labelLarge)
                    Text("ফরম্যাট: ${item.recommendedFormat.labelBn}", color = BrightGold, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(item.reasonBn, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = {
                            onCreateVideoFromTrend(item.topic, item.suggestedCategory, item.recommendedFormat)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = BrightGold)
                        Text("  এই বিষয়ে ভিডিও তৈরি করুন", color = BrightGold)
                    }
                }
            }
        } else {
            GlassCard(borderColor = NavyBorder) {
                Text(
                    text = "উপরের বাটনে চাপ দিন অথবা ভয়েসে বলুন: \"আমার চ্যানেলের জন্য ভালো কনটেন্ট খুঁজে বের করো\"।",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }
    }
}
