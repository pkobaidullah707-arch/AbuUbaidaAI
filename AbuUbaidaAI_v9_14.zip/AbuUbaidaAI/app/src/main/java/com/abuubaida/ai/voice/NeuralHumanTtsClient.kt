package com.abuubaida.ai.voice

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import com.abuubaida.ai.data.model.IslamicVoicePreset
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

/**
 * মানুষের মতো ১০০% স্বাভাবিক বাংলা নিউরাল কণ্ঠ (bn-BD-PradeepNeural ও bn-IN-BashkarNeural)
 * সরাসরি সুরক্ষিত WSS (TLS) দিয়ে সংশ্লেষণ করে এবং ২৪ kHz মনো ১৬-বিট PCM-এ রূপান্তর করে
 * যাতে অডিও এবং ভিডিও স্লাইড মিলিসেকেন্ড নিখুঁতভাবে সিঙ্ক হয়।
 */
class NeuralHumanTtsClient {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun synthesizeSentenceMp3(
        text: String,
        preset: IslamicVoicePreset,
        userPitchMultiplier: Float = preset.pitch,
        userRateMultiplier: Float = preset.rate
    ): ByteArray? = withContext(Dispatchers.IO) {
        val clean = text.trim()
        if (clean.isBlank()) return@withContext null

        val connectionId = UUID.randomUUID().toString().replace("-", "")
        val secMsGec = generateSecMsGec()
        val url = "wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1" +
            "?TrustedClientToken=$TRUSTED_CLIENT_TOKEN" +
            "&Sec-MS-GEC=$secMsGec" +
            "&Sec-MS-GEC-Version=$CHROMIUM_FULL_VERSION" +
            "&ConnectionId=$connectionId"

        val request = Request.Builder()
            .url(url)
            .header("Pragma", "no-cache")
            .header("Cache-Control", "no-cache")
            .header("Origin", "chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold")
            .header(
                "User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0"
            )
            .build()

        val pitchPctDelta = ((userPitchMultiplier / preset.pitch - 1f) * 30f).roundToInt()
        val basePitchNum = preset.ssmlPitch.removeSuffix("%").toIntOrNull() ?: -4
        val finalPitchStr = "${(basePitchNum + pitchPctDelta).coerceIn(-25, 10)}%"

        val ratePctDelta = ((userRateMultiplier / preset.rate - 1f) * 40f).roundToInt()
        val baseRateNum = preset.ssmlRate.removeSuffix("%").toIntOrNull() ?: -8
        val finalRateStr = "${(baseRateNum + ratePctDelta).coerceIn(-30, 20)}%"

        val timestamp = formatEdgeTimestamp()
        val configMsg =
            "X-Timestamp:$timestamp\r\n" +
                "Content-Type:application/json; charset=utf-8\r\n" +
                "Path:speech.config\r\n\r\n" +
                """{"context":{"synthesis":{"audio":{"metadataoptions":{"sentenceBoundaryEnabled":"false","wordBoundaryEnabled":"false"},"outputFormat":"audio-24khz-48kbitrate-mono-mp3"}}}}"""

        val escapedText = escapeXml(clean)
        val langTag = if (preset.neuralVoiceShortName.startsWith("bn-BD")) "bn-BD" else "bn-IN"
        val ssmlBody =
            "<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='$langTag'>" +
                "<voice name='${preset.neuralVoiceShortName}'>" +
                "<prosody pitch='$finalPitchStr' rate='$finalRateStr' volume='+0%'>$escapedText</prosody>" +
                "</voice></speak>"

        val ssmlMsg =
            "X-RequestId:$connectionId\r\n" +
                "Content-Type:application/ssml+xml\r\n" +
                "X-Timestamp:${timestamp}Z\r\n" +
                "Path:ssml\r\n\r\n" +
                ssmlBody

        val resultDeferred = CompletableDeferred<ByteArray?>()
        val audioStream = ByteArrayOutputStream(24_576)

        val ws = httpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(configMsg)
                webSocket.send(ssmlMsg)
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                val arr = bytes.toByteArray()
                if (arr.size > 2) {
                    val headerLen = ((arr[0].toInt() and 0xFF) shl 8) or (arr[1].toInt() and 0xFF)
                    val payloadOffset = 2 + headerLen
                    if (headerLen > 0 && payloadOffset < arr.size) {
                        val header = String(arr, 2, headerLen, Charsets.UTF_8)
                        if (header.contains("Path:audio")) {
                            audioStream.write(arr, payloadOffset, arr.size - payloadOffset)
                        }
                    }
                }
            }

            override fun onMessage(webSocket: WebSocket, textMsg: String) {
                if (textMsg.contains("Path:turn.end")) {
                    val data = audioStream.toByteArray()
                    if (!resultDeferred.isCompleted) {
                        resultDeferred.complete(if (data.size > 256) data else null)
                    }
                    webSocket.close(1000, "done")
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (!resultDeferred.isCompleted) {
                    resultDeferred.complete(null)
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (!resultDeferred.isCompleted) {
                    val data = audioStream.toByteArray()
                    resultDeferred.complete(if (data.size > 256) data else null)
                }
            }
        })

        val res = withTimeoutOrNull(18_000L) { resultDeferred.await() }
        if (res == null) {
            runCatching { ws.cancel() }
        }
        res
    }

    fun decodeMp3BytesToMono24kPcm(mp3Bytes: ByteArray, scratchDir: File): ByteArray? {
        if (mp3Bytes.size < 128) return null
        val tempMp3 = File(scratchDir, "neural_${UUID.randomUUID()}.mp3")
        var extractor: MediaExtractor? = null
        var decoder: MediaCodec? = null
        return try {
            FileOutputStream(tempMp3).use { it.write(mp3Bytes) }
            val activeExtractor = MediaExtractor().apply { setDataSource(tempMp3.absolutePath) }
            extractor = activeExtractor

            var audioTrack = -1
            var inputFormat: MediaFormat? = null
            for (i in 0 until activeExtractor.trackCount) {
                val fmt = activeExtractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("audio/")) {
                    audioTrack = i
                    inputFormat = fmt
                    break
                }
            }
            val fmt = inputFormat ?: return null
            if (audioTrack < 0) return null
            activeExtractor.selectTrack(audioTrack)

            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: return null
            val activeDecoder = MediaCodec.createDecoderByType(mime)
            decoder = activeDecoder
            activeDecoder.configure(fmt, null, null, 0)
            activeDecoder.start()

            val pcmOut = ByteArrayOutputStream(mp3Bytes.size * 6)
            val info = MediaCodec.BufferInfo()
            var sampleRate = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 24_000
            var channels = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 1
            var inputDone = false
            var outputDone = false

            while (!outputDone) {
                if (!inputDone) {
                    val inIdx = activeDecoder.dequeueInputBuffer(5_000L)
                    if (inIdx >= 0) {
                        val inBuf = activeDecoder.getInputBuffer(inIdx)
                        if (inBuf != null) {
                            inBuf.clear()
                            val sampleSize = activeExtractor.readSampleData(inBuf, 0)
                            if (sampleSize < 0) {
                                activeDecoder.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                activeDecoder.queueInputBuffer(inIdx, 0, sampleSize, activeExtractor.sampleTime, 0)
                                activeExtractor.advance()
                            }
                        }
                    }
                }

                val outIdx = activeDecoder.dequeueOutputBuffer(info, 5_000L)
                when {
                    outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val outFmt = activeDecoder.outputFormat
                        if (outFmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                            sampleRate = outFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        }
                        if (outFmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                            channels = outFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        }
                    }
                    outIdx >= 0 -> {
                        val outBuf = activeDecoder.getOutputBuffer(outIdx)
                        if (outBuf != null && info.size > 0) {
                            outBuf.position(info.offset)
                            outBuf.limit(info.offset + info.size)
                            val chunk = ByteArray(info.size)
                            outBuf.get(chunk)
                            pcmOut.write(chunk)
                        }
                        activeDecoder.releaseOutputBuffer(outIdx, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            outputDone = true
                        }
                    }
                }
            }

            val rawPcm = pcmOut.toByteArray()
            if (rawPcm.size < 256) return null
            resampleToMono24k(rawPcm, sampleRate, channels)
        } catch (_: Exception) {
            null
        } finally {
            runCatching { decoder?.stop(); decoder?.release() }
            runCatching { extractor?.release() }
            runCatching { tempMp3.delete() }
        }
    }

    fun resampleToMono24k(
        pcm16Le: ByteArray,
        srcSampleRate: Int,
        srcChannels: Int,
        dstSampleRate: Int = TARGET_SAMPLE_RATE
    ): ByteArray {
        val ch = srcChannels.coerceIn(1, 2)
        val totalFrames = pcm16Le.size / (ch * 2)
        if (totalFrames <= 0) return ByteArray(0)

        val mono = ShortArray(totalFrames)
        val bb = ByteBuffer.wrap(pcm16Le).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until totalFrames) {
            val s0 = bb.getShort().toInt()
            mono[i] = if (ch == 2) {
                val s1 = bb.getShort().toInt()
                ((s0 + s1) / 2).toShort()
            } else {
                s0.toShort()
            }
        }

        val resampled = if (srcSampleRate == dstSampleRate || srcSampleRate <= 0) {
            mono
        } else {
            val dstFrames = ((totalFrames.toLong() * dstSampleRate.toLong()) / srcSampleRate.toLong())
                .toInt()
                .coerceAtLeast(1)
            val out = ShortArray(dstFrames)
            val ratio = (totalFrames - 1).toDouble() / (dstFrames - 1).coerceAtLeast(1).toDouble()
            for (j in 0 until dstFrames) {
                val pos = j * ratio
                val idx0 = pos.toInt().coerceIn(0, totalFrames - 1)
                val idx1 = (idx0 + 1).coerceIn(0, totalFrames - 1)
                val frac = pos - idx0
                val sample = mono[idx0] * (1.0 - frac) + mono[idx1] * frac
                out[j] = sample.roundToInt().coerceIn(-32767, 32767).toShort()
            }
            out
        }

        val outBytes = ByteArray(resampled.size * 2)
        val outBb = ByteBuffer.wrap(outBytes).order(ByteOrder.LITTLE_ENDIAN)
        for (s in resampled) {
            outBb.putShort(s)
        }
        return outBytes
    }

    private fun generateSecMsGec(): String {
        val unixSec = System.currentTimeMillis() / 1000L
        var ticks = (unixSec + WINDOWS_EPOCH_OFFSET_SEC) * 10_000_000L
        ticks -= ticks % FIVE_MIN_TICKS
        val strToHash = "$ticks$TRUSTED_CLIENT_TOKEN"
        val digest = MessageDigest.getInstance("SHA-256").digest(strToHash.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02X".format(it) }
    }

    private fun formatEdgeTimestamp(): String {
        val sdf = SimpleDateFormat("EEE MMM dd yyyy HH:mm:ss 'GMT+0000 (Coordinated Universal Time)'", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        return sdf.format(Date())
    }

    private fun escapeXml(input: String): String {
        return input
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }

    companion object {
        const val TARGET_SAMPLE_RATE = 24_000
        private const val TRUSTED_CLIENT_TOKEN = "6A5AA1D4EAFF4E9FB37E23D68491D6F4"
        private const val CHROMIUM_FULL_VERSION = "1-130.0.2849.68"
        private const val WINDOWS_EPOCH_OFFSET_SEC = 11_644_473_600L
        private const val FIVE_MIN_TICKS = 3_000_000_000L
    }
}
