package com.abuubaida.ai.trends

import com.abuubaida.ai.data.model.ChannelPerformanceSummary
import com.abuubaida.ai.data.model.IslamicCategory
import com.abuubaida.ai.data.model.TrendItem
import com.abuubaida.ai.data.model.TrendResearchReport
import com.abuubaida.ai.data.model.VideoFormat
import com.abuubaida.ai.data.security.SecurePrefsManager
import com.abuubaida.ai.islamic.ContentSafetyGuard
import com.abuubaida.ai.youtube.YouTubeStudioRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.StringReader
import java.net.URLEncoder
import java.util.Calendar
import java.util.concurrent.TimeUnit

/**
 * কেবল বৈধ পাবলিক ডেটা উৎস (Google Trends BD RSS, YouTube Public Search Suggestions)
 * এবং ব্যবহারকারীর অনুমোদিত YouTube OAuth / Meta Page API থেকে আসল ডেটা বিশ্লেষণ করে।
 * কখনো ভুয়া সংখ্যা বা অপ্রাপ্য প্রাইভেট অ্যানালিটিক্স তৈরি করে না।
 */
class TrendResearchRepository(
    private val securePrefsManager: SecurePrefsManager,
    private val youTubeStudioRepository: YouTubeStudioRepository
) {
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    suspend fun researchIslamicTrends(): Result<TrendResearchReport> = withContext(Dispatchers.IO) {
        val controls = securePrefsManager.loadMasterControls()
        if (!controls.trendResearchEnabled) {
            return@withContext Result.failure(
                IllegalStateException("মাস্টার কন্ট্রোলে 'ট্রেন্ড রিসার্চ' বন্ধ রাখা হয়েছে। গোপনীয়তা ড্যাশবোর্ড থেকে চালু করুন।")
            )
        }

        val sourceStatuses = mutableListOf<String>()
        val discoveredTrends = mutableListOf<TrendItem>()

        // 1. YouTube Public Autocomplete Suggestions (Bangladesh, Bengali Islamic topics)
        val ytQueries = listOf("ইসলামিক ভিডিও", "কোরআন তেলাওয়াত", "নবীদের কাহিনী", "হাদিস শিক্ষা", "ইসলামের ইতিহাস")
        val ytSuggestions = fetchYouTubePublicSuggestions(ytQueries)
        if (ytSuggestions.isNotEmpty()) {
            sourceStatuses.add("YouTube পাবলিক সার্চ সাজেশন (BD): ${ytSuggestions.size}টি প্রচলিত টপিক সংগৃহীত।")
            ytSuggestions.take(6).forEach { suggestion ->
                val cat = classifyTopicCategory(suggestion)
                discoveredTrends.add(
                    TrendItem(
                        topic = suggestion,
                        sourceBn = "YouTube পাবলিক সার্চ (BD)",
                        suggestedCategory = cat,
                        recommendedFormat = cat.defaultFormat,
                        reasonBn = "বর্তমানে বাংলাদেশে ব্যবহারকারীরা এই বিষয়ে নিয়মিত YouTube-এ সার্চ করছেন।"
                    )
                )
            }
        } else {
            sourceStatuses.add("YouTube পাবলিক সার্চ সাজেশন: নেটওয়ার্ক না থাকায় লাইভ সার্চ সাজেশন আনা যায়নি।")
        }

        // 2. Google Trends Daily RSS for Bangladesh (filtering Islamic / religious relevance honestly)
        val googleTrendsTitles = fetchGoogleTrendsBangladeshRss()
        if (googleTrendsTitles.isNotEmpty()) {
            sourceStatuses.add("Google Trends বাংলাদেশ RSS: ${googleTrendsTitles.size}টি সাম্প্রতিক ট্রেন্ড পঠিত।")
            googleTrendsTitles
                .filter { isIslamicRelevant(it) }
                .take(3)
                .forEach { t ->
                    val cat = classifyTopicCategory(t)
                    discoveredTrends.add(
                        TrendItem(
                            topic = t,
                            sourceBn = "Google Trends (BD RSS)",
                            suggestedCategory = cat,
                            recommendedFormat = cat.defaultFormat,
                            reasonBn = "বাংলাদেশের সাম্প্রতিক সার্চ ট্রেন্ডের সাথে সম্পর্কিত ইসলামিক বিষয়।"
                        )
                    )
                }
        } else {
            sourceStatuses.add("Google Trends (BD): অফলাইন বা ফিড অপ্রাপ্য।")
        }

        // 3. User's Authorized YouTube Channel Analytics (Real API when connected)
        val channelSummary = if (controls.youTubeConnectionEnabled && !youTubeStudioRepository.getSavedAccessToken().isNullOrBlank()) {
            youTubeStudioRepository.fetchAuthorizedChannelPerformance().also { summary ->
                if (summary != null) {
                    sourceStatuses.add("আপনার YouTube চ্যানেল (${summary.channelTitle}): ${summary.recentVideosAnalyzed}টি ভিডিওর আসল পরিসংখ্যান বিশ্লেষিত।")
                } else {
                    sourceStatuses.add("YouTube চ্যানেল অ্যানালিটিক্স: OAuth সেশন নবায়ন প্রয়োজন বা চ্যানেল তথ্য পাওয়া যায়নি।")
                }
            }
        } else {
            sourceStatuses.add("YouTube চ্যানেল অ্যানালিটিক্স: সংযুক্ত নয় (কানেক্ট করলে নিজস্ব চ্যানেলের আসল ডেটা দেখাবে)।")
            null
        }

        // 4. User's Authorized Facebook Page Insights Note
        val fbInfo = securePrefsManager.getFacebookAccountInfo()
        val fbNote = if (controls.facebookConnectionEnabled && fbInfo.hasAccessToken && fbInfo.pageId.isNotBlank()) {
            val followersText = if (fbInfo.followersCount >= 0) " (${fbInfo.followersCount} ফলোয়ার)" else ""
            sourceStatuses.add("Facebook পেজ (${fbInfo.pageName.ifBlank { fbInfo.pageId }}): অফিসিয়াল Meta Graph সংযোগ সক্রিয়${followersText}।")
            "আপনার Facebook পেজ '${fbInfo.pageName.ifBlank { fbInfo.pageId }}' সংযুক্ত আছে। Meta নীতিমালা অনুযায়ী কেবল আপনার নিজের পেজের অনুমোদিত ডেটাই পড়া হয়।"
        } else {
            sourceStatuses.add("Facebook / Meta ইনসাইটস: পেজ সংযুক্ত নয় — তাই প্রাইভেট Meta অ্যানালিটিক্স তৈরি বা অনুমান করা হয়নি।")
            "Facebook পেজ সংযুক্ত না থাকায় Meta ইনসাইটস যুক্ত করা হয়নি (ভুয়া ডেটা দেখানো হয় না)।"
        }

        // Evergreen authentic Islamic library suggestions (clearly labeled as curated Islamic syllabus, never fake trends)
        if (discoveredTrends.size < 4) {
            val evergreen = listOf(
                TrendItem(
                    topic = "সূরা আল-ইনশিরাহ (৯৪:৫-৬) — কষ্টের পরেই রয়েছে স্বস্তি",
                    sourceBn = "যাচাইকৃত ইসলামিক বিষয়বস্তু (অফলাইন সিলেবাস)",
                    suggestedCategory = IslamicCategory.SURAH_EXPLANATION,
                    recommendedFormat = VideoFormat.SHORTS_9_16,
                    reasonBn = "অফলাইন নির্ভরযোগ্য কুরআন ভিত্তিক সান্ত্বনা ও আত্মিক প্রেরণাদায়ক বিষয়।"
                ),
                TrendItem(
                    topic = "সহীহ বুখারীর প্রথম হাদিস: নিয়তের বিশুদ্ধতা",
                    sourceBn = "যাচাইকৃত ইসলামিক বিষয়বস্তু (অফলাইন সিলেবাস)",
                    suggestedCategory = IslamicCategory.HADITH_EDUCATION,
                    recommendedFormat = VideoFormat.SHORTS_9_16,
                    reasonBn = "ইসলামিক শিক্ষামূলক সংক্ষিপ্ত Shorts ও Reels হিসেবে দর্শকদের কাছে খুবই উপকারী।"
                ),
                TrendItem(
                    topic = "নবী ইউসুফ (আ.)-এর ধৈর্য ও ক্ষমার শিক্ষণীয় ঘটনা",
                    sourceBn = "যাচাইকৃত ইসলামিক বিষয়বস্তু (অফলাইন সিলেবাস)",
                    suggestedCategory = IslamicCategory.PROPHET_STORIES,
                    recommendedFormat = VideoFormat.LONG_16_9,
                    reasonBn = "লং-ফর্ম YouTube ভিডিও এবং ইসলামিক গল্পের জন্য চিরন্তন চাহিদাসম্পন্ন বিষয়।"
                ),
                TrendItem(
                    topic = "আল্লাহর সুন্দর নামসমূহ (আসমাউল হুসনা) ও দৈনন্দিন আমল",
                    sourceBn = "যাচাইকৃত ইসলামিক বিষয়বস্তু (অফলাইন সিলেবাস)",
                    suggestedCategory = IslamicCategory.NAMES_OF_ALLAH,
                    recommendedFormat = VideoFormat.SHORTS_9_16,
                    reasonBn = "নিয়মিত ধারাবাহিক ইসলামিক Shorts সিরিজের জন্য উপযুক্ত।"
                )
            )
            discoveredTrends.addAll(evergreen.filter { e -> discoveredTrends.none { it.topic == e.topic } })
        }

        val recommendedFormat = if (channelSummary?.bestPerformingFormatBn?.contains("লং") == true) {
            VideoFormat.LONG_16_9
        } else {
            VideoFormat.SHORTS_9_16
        }

        val (bestTimeMillis, bestTimeLabel) = computeBestIslamicPublishSlot(channelSummary?.bestHistoricalHour24)

        Result.success(
            TrendResearchReport(
                trends = discoveredTrends.distinctBy { it.topic },
                channelSummary = channelSummary,
                facebookInsightsNoteBn = fbNote,
                recommendedFormat = recommendedFormat,
                recommendedPublishTimeBn = bestTimeLabel,
                recommendedPublishMillis = bestTimeMillis,
                dataSourcesStatusBn = sourceStatuses
            )
        )
    }

    private fun fetchYouTubePublicSuggestions(seedQueries: List<String>): List<String> {
        val results = mutableListOf<String>()
        for (seed in seedQueries.take(3)) {
            try {
                val encoded = URLEncoder.encode(seed, "UTF-8")
                val url = "https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&hl=bn&gl=BD&q=$encoded"
                val req = Request.Builder()
                    .url(url)
                    .header("User-Agent", "AbuUbaidaAI/2.0 (Android)")
                    .get()
                    .build()
                httpClient.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val raw = resp.body?.string().orEmpty()
                        val arr = JSONArray(raw)
                        val suggestions = arr.optJSONArray(1)
                        if (suggestions != null) {
                            for (i in 0 until suggestions.length().coerceAtMost(4)) {
                                val item = ContentSafetyGuard.sanitizeExternalText(suggestions.optString(i), 90)
                                if (item.length >= 4) results.add(item)
                            }
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }
        return results.distinct()
    }

    private fun fetchGoogleTrendsBangladeshRss(): List<String> {
        return try {
            val req = Request.Builder()
                .url("https://trends.google.com/trending/rss?geo=BD")
                .header("User-Agent", "AbuUbaidaAI/2.0 (Android)")
                .get()
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return emptyList()
                val xml = resp.body?.string().orEmpty()
                if (xml.isBlank()) return emptyList()
                val factory = XmlPullParserFactory.newInstance()
                val parser = factory.newPullParser()
                parser.setInput(StringReader(xml))
                val titles = mutableListOf<String>()
                var insideItem = false
                var event = parser.eventType
                while (event != XmlPullParser.END_DOCUMENT) {
                    val tag = parser.name
                    when (event) {
                        XmlPullParser.START_TAG -> {
                            if (tag == "item") insideItem = true
                            else if (insideItem && tag == "title") {
                                val text = ContentSafetyGuard.sanitizeExternalText(parser.nextText(), 100)
                                if (text.isNotBlank()) titles.add(text)
                            }
                        }
                        XmlPullParser.END_TAG -> {
                            if (tag == "item") insideItem = false
                        }
                    }
                    event = parser.next()
                }
                titles
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun isIslamicRelevant(title: String): Boolean {
        val keywords = listOf(
            "ইসলাম", "কোরআন", "কুরআন", "হাদিস", "নামাজ", "রোজা", "রমজান", "ঈদ",
            "দোয়া", "সূরা", "নবী", "মসজিদ", "ওয়াজ", "গজল", "islam", "quran", "hadith", "dua", "ramadan"
        )
        return keywords.any { title.contains(it, ignoreCase = true) }
    }

    fun classifyTopicCategory(topic: String): IslamicCategory {
        val lower = topic.lowercase()
        return when {
            topic.contains("তেলাওয়াত") || lower.contains("recitation") -> IslamicCategory.QURAN_RECITATION
            topic.contains("সূরা") || topic.contains("তাফসীর") || lower.contains("surah") -> IslamicCategory.SURAH_EXPLANATION
            topic.contains("হাদিস") || lower.contains("hadith") -> IslamicCategory.HADITH_EDUCATION
            topic.contains("নবী") || topic.contains("রাসূল") || lower.contains("prophet") -> IslamicCategory.PROPHET_STORIES
            topic.contains("ইতিহাস") || lower.contains("history") -> IslamicCategory.ISLAMIC_HISTORY
            topic.contains("৯৯ নাম") || topic.contains("আসমাউল") -> IslamicCategory.NAMES_OF_ALLAH
            topic.contains("দোয়া") || topic.contains("জিকির") || topic.contains("সান্ত্বনা") -> IslamicCategory.ISLAMIC_REMINDER
            else -> IslamicCategory.ISLAMIC_EDUCATION
        }
    }

    fun computeBestIslamicPublishSlot(preferredHour24: Int? = null): Pair<Long, String> {
        val now = Calendar.getInstance()
        val candidate = Calendar.getInstance()
        val targetHour = preferredHour24 ?: when {
            now.get(Calendar.HOUR_OF_DAY) < 6 -> 6
            now.get(Calendar.HOUR_OF_DAY) < 13 -> 13
            now.get(Calendar.HOUR_OF_DAY) < 20 -> 20
            else -> {
                candidate.add(Calendar.DAY_OF_YEAR, 1)
                20
            }
        }
        candidate.set(Calendar.HOUR_OF_DAY, targetHour)
        candidate.set(Calendar.MINUTE, 30)
        candidate.set(Calendar.SECOND, 0)
        candidate.set(Calendar.MILLISECOND, 0)
        if (candidate.timeInMillis <= now.timeInMillis + 15 * 60_000L) {
            candidate.add(Calendar.DAY_OF_YEAR, 1)
        }
        val dayLabel = if (candidate.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR)) "আজ" else "আগামীকাল"
        val period = when (targetHour) {
            in 4..11 -> "সকাল"
            in 12..15 -> "দুপুর"
            in 16..18 -> "বিকাল"
            else -> "রাত"
        }
        val hour12 = if (targetHour == 0) 12 else if (targetHour > 12) targetHour - 12 else targetHour
        return candidate.timeInMillis to "$dayLabel $period ${hour12}:৩০ (বাংলাদেশ প্রাইম ইসলামিক সময়)"
    }
}
