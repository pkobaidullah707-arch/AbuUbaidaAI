package com.abuubaida.ai.voice

import android.service.voice.VoiceInteractionService

/**
 * Android Assistant Role এর জন্য VoiceInteractionService আর্কিটেকচার।
 * ব্যবহারকারী ফোনের Default Digital Assistant হিসেবে "আবু উবাইদা AI" নির্বাচন করলে
 * সিস্টেম অ্যাসিস্ট্যান্ট বাটন বা জেসচারের মাধ্যমে এই সার্ভিস ট্রিগার হয়।
 */
class AbuUbaidaVoiceInteractionService : VoiceInteractionService() {
    override fun onReady() {
        super.onReady()
    }
}
