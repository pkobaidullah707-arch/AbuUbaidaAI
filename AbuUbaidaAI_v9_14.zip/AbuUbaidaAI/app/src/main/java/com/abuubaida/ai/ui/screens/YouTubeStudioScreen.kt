package com.abuubaida.ai.ui.screens

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.abuubaida.ai.data.model.PublishingRecommendation
import com.abuubaida.ai.data.model.YouTubeAccountInfo
import com.abuubaida.ai.data.model.YouTubeUploadRequest
import com.abuubaida.ai.data.model.YouTubeVisibility
import com.abuubaida.ai.ui.components.GlassCard
import com.abuubaida.ai.ui.theme.AmberGold
import com.abuubaida.ai.ui.theme.BrightGold
import com.abuubaida.ai.ui.theme.DeepNavyBg
import com.abuubaida.ai.ui.theme.ElectricBlue
import com.abuubaida.ai.ui.theme.EmeraldOk
import com.abuubaida.ai.ui.theme.ImperialGold
import com.abuubaida.ai.ui.theme.NavyBorder
import com.abuubaida.ai.ui.theme.RoyalBlue
import com.abuubaida.ai.ui.theme.TextPrimary
import com.abuubaida.ai.ui.theme.TextSecondary
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity

@Composable
fun YouTubeStudioScreen(
    accountInfo: YouTubeAccountInfo,
    youTubeEnabled: Boolean,
    autoUploadEnabled: Boolean,
    isBusy: Boolean,
    uploadRequest: YouTubeUploadRequest,
    recommendation: PublishingRecommendation?,
    onToggleYouTubeEnabled: (Boolean) -> Unit,
    onToggleAutoUpload: (Boolean) -> Unit,
    onUpdateRequest: ((YouTubeUploadRequest) -> YouTubeUploadRequest) -> Unit,
    onPickVideo: (android.net.Uri) -> Unit,
    onConnectOAuth: (Activity, (android.content.IntentSender) -> Unit) -> Unit,
    onConnectEasy: (String, String) -> Unit,
    onConsentResult: (AuthorizationResult?) -> Unit,
    onDisconnectOAuth: () -> Unit,
    onRequestPublish: (YouTubeUploadRequest) -> Unit,
    onShareToYouTubeApp: (YouTubeUploadRequest) -> Unit,
    onCheckStatus: (String) -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    var channelInput by remember(accountInfo.channelUrl, accountInfo.channelName) {
        mutableStateOf(accountInfo.channelUrl.ifBlank { accountInfo.channelName })
    }
    var accessTokenInput by remember { mutableStateOf("") }
    var tagsText by remember(uploadRequest.tags) {
        mutableStateOf(uploadRequest.tags.joinToString(", "))
    }

    val videoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) onPickVideo(uri)
    }

    val oauthConsentLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && activity != null) {
            val authResult = try {
                Identity.getAuthorizationClient(activity).getAuthorizationResultFromIntent(result.data)
            } catch (_: Exception) {
                null
            }
            onConsentResult(authResult)
        } else {
            onConsentResult(null)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("YouTube স্টুডিও", style = MaterialTheme.typography.headlineMedium, color = BrightGold)

        // Controls + Easy & OAuth Connect + Remove Card
        GlassCard(borderColor = if (accountInfo.isConnected) EmeraldOk.copy(alpha = 0.55f) else ImperialGold.copy(alpha = 0.45f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("YouTube স্টুডিও চালু / বন্ধ", style = MaterialTheme.typography.titleMedium, color = BrightGold)
                    Text("চাইলে এই অপশনটি সম্পূর্ণ বন্ধ রাখতে পারেন", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                }
                Switch(checked = youTubeEnabled, onCheckedChange = onToggleYouTubeEnabled)
            }

            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("অটো-আপলোড চালু / বন্ধ", color = TextPrimary)
                    Text("চালু করলে অনুমতি সাপেক্ষে স্বয়ংক্রিয় আপলোড হবে", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                }
                Switch(checked = autoUploadEnabled, onCheckedChange = onToggleAutoUpload)
            }

            Spacer(modifier = Modifier.height(10.dp))
            if (accountInfo.isConnected) {
                val label = accountInfo.channelName.ifBlank {
                    accountInfo.channelUrl.ifBlank { "Google YouTube অ্যাকাউন্ট" }
                }
                Text("সংযুক্ত চ্যানেল: $label", color = EmeraldOk, style = MaterialTheme.typography.titleMedium)
                if (accountInfo.channelUrl.isNotBlank()) {
                    Text(accountInfo.channelUrl, color = ElectricBlue, style = MaterialTheme.typography.bodyMedium)
                }
                Text(
                    text = if (accountInfo.hasOAuthToken) {
                        "স্ট্যাটাস: Google OAuth Token সক্রিয় (সরাসরি API আপলোড চালু)"
                    } else {
                        "স্ট্যাটাস: সহজ চ্যানেল প্রোফাইল যুক্ত (১-ট্যাপ শেয়ার ও ট্রেন্ড বিশ্লেষণ চালু)"
                    },
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = onDisconnectOAuth,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("YouTube অ্যাকাউন্ট রিমুভ ও বিচ্ছিন্ন করুন", color = AmberGold)
                }
            } else {
                Text(
                    "যেকোনো সহজ উপায়ে যুক্ত করুন — ১-ট্যাপ Google OAuth অথবা আপনার চ্যানেলের নাম/@handle বা লিংক দিন:",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = {
                        if (activity != null) {
                            onConnectOAuth(activity) { sender ->
                                oauthConsentLauncher.launch(IntentSenderRequest.Builder(sender).build())
                            }
                        }
                    },
                    enabled = !isBusy && youTubeEnabled,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue, contentColor = TextPrimary)
                ) {
                    Text("Google দিয়ে অটো-সংযুক্ত করুন (OAuth)")
                }

                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = channelInput,
                    onValueChange = { channelInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("YouTube চ্যানেলের নাম, @handle বা লিংক") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = NavyBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = accessTokenInput,
                    onValueChange = { accessTokenInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("OAuth Access Token (ঐচ্ছিক — ফাঁকা রাখলেও যুক্ত হবে)") },
                    visualTransformation = PasswordVisualTransformation(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = NavyBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = { onConnectEasy(channelInput, accessTokenInput) },
                    enabled = !isBusy && youTubeEnabled && (channelInput.isNotBlank() || accessTokenInput.isNotBlank()),
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldOk, contentColor = DeepNavyBg)
                ) {
                    Text("সহজে YouTube চ্যানেল যুক্ত করুন")
                }
            }
        }

        GlassCard {
            Text("ভিডিও ফাইল, থাম্বনেইল ও প্রকাশনা", style = MaterialTheme.typography.titleMedium, color = ElectricBlue)
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedButton(
                onClick = { videoPicker.launch("video/*") },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = if (uploadRequest.videoDisplayName.isNotBlank()) {
                        "নির্বাচিত ফাইল: ${uploadRequest.videoDisplayName}"
                    } else {
                        "ডিভাইস থেকে ভিডিও (MP4) নির্বাচন করুন"
                    },
                    color = BrightGold
                )
            }

            if (uploadRequest.thumbnailLocalPath.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text("থাম্বনেইল PNG সংযুক্ত আছে (আপলোডের সময় সেট হবে)", color = EmeraldOk, style = MaterialTheme.typography.bodyMedium)
            }

            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = uploadRequest.title,
                onValueChange = { v -> onUpdateRequest { it.copy(title = v) } },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("ভিডিও শিরোনাম (Title)") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = NavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )

            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = uploadRequest.description,
                onValueChange = { v -> onUpdateRequest { it.copy(description = v) } },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp),
                label = { Text("ভিডিও বর্ণনা (Description)") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = NavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )

            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = tagsText,
                onValueChange = { raw ->
                    tagsText = raw
                    val parsed = raw.split(",").map { it.trim() }.filter { it.isNotBlank() }
                    onUpdateRequest { it.copy(tags = parsed) }
                },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("ট্যাগসমূহ (কমা দিয়ে আলাদা করুন)") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = NavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )

            if (recommendation != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("স্মার্ট সময়ে শিডিউল করুন", color = TextPrimary)
                        Text(recommendation.targetTimeLabelBn, color = EmeraldOk, style = MaterialTheme.typography.bodyMedium)
                    }
                    Switch(
                        checked = uploadRequest.scheduledPublishIsoUtc.isNotBlank(),
                        onCheckedChange = { enableSched ->
                            onUpdateRequest {
                                if (enableSched) {
                                    it.copy(
                                        visibility = YouTubeVisibility.PRIVATE,
                                        scheduledPublishIsoUtc = recommendation.targetIsoUtc,
                                        scheduledLabelBn = recommendation.targetTimeLabelBn
                                    )
                                } else {
                                    it.copy(scheduledPublishIsoUtc = "", scheduledLabelBn = "")
                                }
                            }
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text("দৃশ্যমানতা নির্বাচন করুন:", style = MaterialTheme.typography.labelLarge, color = BrightGold)
            YouTubeVisibility.entries.forEach { vis ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    RadioButton(
                        selected = uploadRequest.visibility == vis,
                        onClick = { onUpdateRequest { it.copy(visibility = vis) } }
                    )
                    Text(vis.labelBn, color = TextPrimary)
                }
            }

            if (isBusy) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = ImperialGold)
                Spacer(modifier = Modifier.height(8.dp))
            }

            if (accountInfo.hasOAuthToken) {
                Button(
                    onClick = { onRequestPublish(uploadRequest) },
                    enabled = !isBusy && youTubeEnabled && uploadRequest.videoUriString.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = ImperialGold, contentColor = DeepNavyBg)
                ) {
                    Text("নিশ্চিত করে সরাসরি YouTube-এ আপলোড করুন")
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            OutlinedButton(
                onClick = { onShareToYouTubeApp(uploadRequest) },
                enabled = !isBusy && youTubeEnabled && uploadRequest.videoUriString.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("YouTube অ্যাপে সরাসরি শেয়ার / আপলোড করুন", color = BrightGold)
            }

            if (uploadRequest.lastUploadedVideoId.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = { onCheckStatus(uploadRequest.lastUploadedVideoId) },
                    enabled = !isBusy,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("আপলোড স্ট্যাটাস দেখুন (${uploadRequest.lastUploadedVideoId})", color = ElectricBlue)
                }
            }

            if (uploadRequest.lastStatusReportBn.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(uploadRequest.lastStatusReportBn, color = EmeraldOk, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
