package com.abuubaida.ai.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.abuubaida.ai.data.model.ContactItem
import com.abuubaida.ai.data.model.InstalledAppInfo
import com.abuubaida.ai.ui.components.GlassCard
import com.abuubaida.ai.ui.theme.BrightGold
import com.abuubaida.ai.ui.theme.DeepNavyBg
import com.abuubaida.ai.ui.theme.ElectricBlue
import com.abuubaida.ai.ui.theme.ImperialGold
import com.abuubaida.ai.ui.theme.NavyBorder
import com.abuubaida.ai.ui.theme.RoyalBlue
import com.abuubaida.ai.ui.theme.TextPrimary
import com.abuubaida.ai.ui.theme.TextSecondary

@Composable
fun PhoneControlScreen(
    contacts: List<ContactItem>,
    installedApps: List<InstalledAppInfo>,
    onRefreshContacts: (String) -> Unit,
    onRequestCall: (displayName: String, phoneNumber: String, directCall: Boolean) -> Unit,
    onLaunchApp: (String) -> Unit,
    onOpenSettings: (String) -> Unit,
    onSetAlarm: (hour: Int, minute: Int, label: String) -> Unit
) {
    val context = LocalContext.current
    var contactQuery by remember { mutableStateOf("") }
    var manualNumber by remember { mutableStateOf("") }
    var appQuery by remember { mutableStateOf("") }
    var alarmHour by remember { mutableStateOf("6") }
    var alarmMinute by remember { mutableStateOf("30") }
    var alarmLabel by remember { mutableStateOf("ফজরের পর কাজ") }

    var hasContactsPerm by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    val contactsPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasContactsPerm = granted
        if (granted) onRefreshContacts(contactQuery)
    }

    val callPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        // Call goes through confirmation dialog regardless
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("ফোন কন্ট্রোল (নিরাপদ মোড)", style = MaterialTheme.typography.headlineMedium, color = BrightGold)

        // Direct Dial / Call Card
        GlassCard(borderColor = ImperialGold.copy(alpha = 0.45f)) {
            Text("ফোন কল (নিশ্চিতকরণসহ)", style = MaterialTheme.typography.titleMedium, color = BrightGold)
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = manualNumber,
                    onValueChange = { manualNumber = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("ফোন নম্বর লিখুন", color = TextSecondary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = NavyBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true
                )
                Button(
                    onClick = {
                        val hasCallPerm = ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.CALL_PHONE
                        ) == PackageManager.PERMISSION_GRANTED
                        if (!hasCallPerm) {
                            callPermLauncher.launch(Manifest.permission.CALL_PHONE)
                        }
                        onRequestCall(manualNumber, manualNumber, hasCallPerm)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ImperialGold, contentColor = DeepNavyBg)
                ) {
                    Icon(Icons.Rounded.Call, contentDescription = null)
                }
            }
        }

        // Contacts Card
        GlassCard(borderColor = ElectricBlue.copy(alpha = 0.4f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("কন্টাক্ট তালিকা", style = MaterialTheme.typography.titleMedium, color = ElectricBlue)
                if (!hasContactsPerm) {
                    Button(
                        onClick = { contactsPermLauncher.launch(Manifest.permission.READ_CONTACTS) },
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue, contentColor = TextPrimary)
                    ) {
                        Text("অনুমতি দিন")
                    }
                }
            }
            if (hasContactsPerm) {
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = contactQuery,
                    onValueChange = {
                        contactQuery = it
                        onRefreshContacts(it)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("নাম বা নম্বর খুঁজুন...", color = TextSecondary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = NavyBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))
                contacts.take(6).forEach { contact ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(contact.name, color = TextPrimary, style = MaterialTheme.typography.bodyLarge)
                            Text(contact.phoneNumber, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                        }
                        IconButton(onClick = {
                            val direct = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.CALL_PHONE
                            ) == PackageManager.PERMISSION_GRANTED
                            onRequestCall(contact.name, contact.phoneNumber, direct)
                        }) {
                            Icon(Icons.Rounded.Call, contentDescription = "কল", tint = BrightGold)
                        }
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    "আপনার অনুমতি ছাড়া কন্টাক্ট পড়া হবে না।",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
        }

        // Alarm & Reminder Card
        GlassCard {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.Alarm, contentDescription = null, tint = BrightGold)
                Text("অ্যালার্ম ও রিমাইন্ডার", style = MaterialTheme.typography.titleMedium, color = BrightGold)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = alarmHour,
                    onValueChange = { alarmHour = it.filter(Char::isDigit).take(2) },
                    modifier = Modifier.weight(1f),
                    label = { Text("ঘণ্টা (0-23)") },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )
                OutlinedTextField(
                    value = alarmMinute,
                    onValueChange = { alarmMinute = it.filter(Char::isDigit).take(2) },
                    modifier = Modifier.weight(1f),
                    label = { Text("মিনিট (0-59)") },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = alarmLabel,
                onValueChange = { alarmLabel = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("লেবেল") },
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = {
                    val h = alarmHour.toIntOrNull() ?: 7
                    val m = alarmMinute.toIntOrNull() ?: 0
                    onSetAlarm(h, m, alarmLabel)
                },
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue, contentColor = TextPrimary)
            ) {
                Text("অ্যালার্ম সেট করুন")
            }
        }

        // Installed Apps & Android Settings
        GlassCard {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.Apps, contentDescription = null, tint = ElectricBlue)
                Text("ইনস্টল করা অ্যাপ চালু করুন", style = MaterialTheme.typography.titleMedium, color = ElectricBlue)
            }
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = appQuery,
                onValueChange = { appQuery = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("অ্যাপের নাম লিখুন...", color = TextSecondary) },
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(8.dp))
            installedApps
                .filter { appQuery.isBlank() || it.appName.contains(appQuery, ignoreCase = true) }
                .take(8)
                .forEach { app ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(app.appName, color = TextPrimary, modifier = Modifier.weight(1f))
                        OutlinedButton(onClick = { onLaunchApp(app.packageName) }) {
                            Text("খুলুন", color = BrightGold)
                        }
                    }
                }
        }

        GlassCard {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.Settings, contentDescription = null, tint = BrightGold)
                Text("দ্রুত সিস্টেম সেটিংস", style = MaterialTheme.typography.titleMedium, color = BrightGold)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = { onOpenSettings(Settings.ACTION_WIFI_SETTINGS) },
                    modifier = Modifier.weight(1f)
                ) { Text("Wi-Fi", color = ElectricBlue) }
                OutlinedButton(
                    onClick = { onOpenSettings(Settings.ACTION_BLUETOOTH_SETTINGS) },
                    modifier = Modifier.weight(1f)
                ) { Text("Bluetooth", color = ElectricBlue) }
                OutlinedButton(
                    onClick = { onOpenSettings(Settings.ACTION_SETTINGS) },
                    modifier = Modifier.weight(1f)
                ) { Text("সব সেটিংস", color = BrightGold) }
            }
        }
    }
}
