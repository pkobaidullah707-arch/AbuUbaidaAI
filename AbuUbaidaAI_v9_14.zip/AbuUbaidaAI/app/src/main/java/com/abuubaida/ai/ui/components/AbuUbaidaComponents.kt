package com.abuubaida.ai.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.abuubaida.ai.data.model.PendingSensitiveAction
import com.abuubaida.ai.data.model.VoiceState
import com.abuubaida.ai.ui.theme.AmberGold
import com.abuubaida.ai.ui.theme.BrightGold
import com.abuubaida.ai.ui.theme.DeepBlueGlow
import com.abuubaida.ai.ui.theme.DeepNavyBg
import com.abuubaida.ai.ui.theme.ElectricBlue
import com.abuubaida.ai.ui.theme.EmeraldOk
import com.abuubaida.ai.ui.theme.ImperialGold
import com.abuubaida.ai.ui.theme.NavyBorder
import com.abuubaida.ai.ui.theme.NavyCard
import com.abuubaida.ai.ui.theme.RoyalBlue
import com.abuubaida.ai.ui.theme.TextPrimary
import com.abuubaida.ai.ui.theme.TextSecondary
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun AbuUbaidaLogo(
    modifier: Modifier = Modifier,
    size: Dp = 44.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val cx = w / 2f
        val cy = h / 2f
        val outerR = w * 0.45f
        val innerR = w * 0.34f

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(DeepBlueGlow.copy(alpha = 0.7f), DeepNavyBg),
                center = Offset(cx, cy),
                radius = outerR * 1.2f
            ),
            radius = outerR,
            center = Offset(cx, cy)
        )

        drawCircle(
            brush = Brush.linearGradient(listOf(BrightGold, ImperialGold, AmberGold)),
            radius = outerR,
            center = Offset(cx, cy),
            style = Stroke(width = w * 0.05f)
        )

        drawCircle(
            color = ElectricBlue,
            radius = innerR,
            center = Offset(cx, cy),
            style = Stroke(width = w * 0.03f)
        )

        // 8-point geometric gold star motif
        val starPath = Path()
        val points = 8
        for (i in 0 until points * 2) {
            val r = if (i % 2 == 0) w * 0.28f else w * 0.13f
            val angle = (i * PI / points) - (PI / 2.0)
            val x = cx + (r * cos(angle)).toFloat()
            val y = cy + (r * sin(angle)).toFloat()
            if (i == 0) starPath.moveTo(x, y) else starPath.lineTo(x, y)
        }
        starPath.close()
        drawPath(
            path = starPath,
            brush = Brush.linearGradient(listOf(BrightGold, ImperialGold))
        )

        drawCircle(
            color = RoyalBlue,
            radius = w * 0.09f,
            center = Offset(cx, cy)
        )
        drawCircle(
            color = BrightGold,
            radius = w * 0.04f,
            center = Offset(cx, cy)
        )
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    borderColor: Color = NavyBorder,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = NavyCard.copy(alpha = 0.92f)),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Column(modifier = Modifier.padding(16.dp), content = content)
    }
}

@Composable
fun AnimatedVoiceOrb(
    voiceState: VoiceState,
    rmsLevel: Float,
    onMicClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isListening = voiceState is VoiceState.Listening
    val isSpeaking = voiceState is VoiceState.Speaking
    val isProcessing = voiceState is VoiceState.Processing

    val infiniteTransition = rememberInfiniteTransition(label = "voice_orb")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isListening) 650 else 1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200),
            repeatMode = RepeatMode.Restart
        ),
        label = "wavePhase"
    )

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(196.dp)
        ) {
            val scaleFactor = if (isListening) 1f + (rmsLevel * 0.18f) else pulse
            Canvas(modifier = Modifier.size(190.dp).scale(scaleFactor)) {
                val center = Offset(size.width / 2f, size.height / 2f)
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            if (isListening) BrightGold.copy(alpha = 0.35f)
                            else ElectricBlue.copy(alpha = 0.25f),
                            Color.Transparent
                        )
                    ),
                    radius = size.minDimension / 2f,
                    center = center
                )
                drawCircle(
                    brush = Brush.sweepGradient(
                        colors = listOf(ElectricBlue, ImperialGold, RoyalBlue, BrightGold, ElectricBlue)
                    ),
                    radius = size.minDimension * 0.40f,
                    center = center,
                    style = Stroke(width = 4.dp.toPx())
                )
            }

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(124.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = if (isListening) {
                                listOf(ImperialGold, RoyalBlue)
                            } else {
                                listOf(RoyalBlue, DeepBlueGlow)
                            }
                        )
                    )
                    .clickable(onClick = onMicClick)
            ) {
                Icon(
                    imageVector = when {
                        isListening -> Icons.Rounded.Stop
                        isSpeaking -> Icons.Rounded.GraphicEq
                        else -> Icons.Rounded.Mic
                    },
                    contentDescription = "আবু উবাইদা AI মাইক্রোফোন",
                    tint = if (isListening) DeepNavyBg else BrightGold,
                    modifier = Modifier.size(52.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Live Voice Waveform Bars
        Canvas(
            modifier = Modifier
                .fillMaxWidth(0.75f)
                .height(38.dp)
        ) {
            val barCount = 24
            val gap = size.width / barCount
            val barWidth = gap * 0.48f
            val baseEnergy = when {
                isListening -> 0.25f + (rmsLevel * 0.75f)
                isSpeaking -> 0.55f
                isProcessing -> 0.35f
                else -> 0.12f
            }
            for (i in 0 until barCount) {
                val wave = ((sin(wavePhase + i * 0.45f) + 1f) / 2f)
                val barHeight = (size.height * (0.18f + wave * baseEnergy * 0.82f))
                    .coerceIn(4.dp.toPx(), size.height)
                val x = i * gap + (gap - barWidth) / 2f
                val y = (size.height - barHeight) / 2f
                val barColor = if (i % 3 == 0) BrightGold else ElectricBlue
                drawRoundRect(
                    color = barColor,
                    topLeft = Offset(x, y),
                    size = Size(barWidth, barHeight),
                    cornerRadius = CornerRadius(6f, 6f)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        val statusText = when (voiceState) {
            VoiceState.Idle -> "কথা বলতে মাইক্রোফোনে ট্যাপ করুন"
            VoiceState.Listening -> "শুনছি... বাংলায় বলুন"
            VoiceState.Processing -> "আবু উবাইদা AI চিন্তা করছে..."
            is VoiceState.Speaking -> "উত্তর বলছে..."
            is VoiceState.Error -> voiceState.messageBn
        }
        Text(
            text = statusText,
            style = MaterialTheme.typography.titleMedium,
            color = if (voiceState is VoiceState.Error) AmberGold else TextPrimary
        )
    }
}

@Composable
fun SensitiveActionConfirmationDialog(
    action: PendingSensitiveAction,
    onConfirm: () -> Unit,
    onSelectAlternateContact: (com.abuubaida.ai.data.model.ContactItem) -> Unit = {},
    onDismiss: () -> Unit
) {
    val (title, body, confirmLabel) = when (action) {
        is PendingSensitiveAction.CallPhone -> Triple(
            "ফোন কল নিশ্চিতকরণ",
            "আপনি কি ${action.displayName} (${action.phoneNumber}) নম্বরে কল করতে চান?",
            "কল করুন"
        )
        is PendingSensitiveAction.SendSms -> Triple(
            "SMS পাঠানোর নিশ্চিতকরণ",
            "${action.recipientName} (${action.phoneNumber}) নম্বরে এই বার্তাটি পাঠানো হবে:\n\n\"${action.message}\"",
            "SMS পাঠান"
        )
        is PendingSensitiveAction.PublishYouTube -> Triple(
            "YouTube প্রকাশ নিশ্চিতকরণ",
            "শিরোনাম: ${action.request.title}\nদৃশ্যমানতা: ${action.request.visibility.labelBn}\n" +
                (if (action.request.scheduledLabelBn.isNotBlank()) "শিডিউল: ${action.request.scheduledLabelBn}\n" else "") +
                "\nআপনি কি ভিডিওটি YouTube-এ আপলোড করতে চান?",
            "নিশ্চিত ও আপলোড করুন"
        )
        is PendingSensitiveAction.PublishFacebook -> Triple(
            "Facebook পেজ প্রকাশ নিশ্চিতকরণ",
            "শিরোনাম: ${action.request.title}\nমোড: ${action.request.publishState.labelBn}\n" +
                (if (action.request.scheduledLabelBn.isNotBlank()) "সময়: ${action.request.scheduledLabelBn}\n" else "") +
                "\nআপনি কি ভিডিওটি আপনার Facebook পেজে পাঠাতে চান?",
            "নিশ্চিত ও পাঠান"
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NavyCard,
        titleContentColor = BrightGold,
        textContentColor = TextPrimary,
        title = { Text(text = title, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(text = body)
                if (action is PendingSensitiveAction.CallPhone && action.alternateMatches.isNotEmpty()) {
                    Text(
                        text = "অন্য নাম খুঁজলে নিচে থেকে সঠিকটি বেছে নিন:",
                        style = MaterialTheme.typography.labelMedium,
                        color = ElectricBlue
                    )
                    action.alternateMatches.forEach { alt ->
                        OutlinedButton(
                            onClick = { onSelectAlternateContact(alt) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("${alt.name} (${alt.phoneNumber})", color = BrightGold)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = ImperialGold, contentColor = DeepNavyBg)
            ) {
                Text(confirmLabel, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("বাতিল", color = ElectricBlue)
            }
        }
    )
}

@Composable
fun PermissionStatusRow(
    title: String,
    description: String,
    granted: Boolean,
    onRequestClick: () -> Unit
) {
    GlassCard(borderColor = if (granted) EmeraldOk.copy(alpha = 0.5f) else AmberGold.copy(alpha = 0.5f)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                Text(text = title, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = description, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            }
            if (granted) {
                Text(
                    text = "অনুমোদিত",
                    color = EmeraldOk,
                    style = MaterialTheme.typography.labelLarge
                )
            } else {
                Button(
                    onClick = onRequestClick,
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue, contentColor = TextPrimary)
                ) {
                    Text("অনুমতি দিন")
                }
            }
        }
    }
}
