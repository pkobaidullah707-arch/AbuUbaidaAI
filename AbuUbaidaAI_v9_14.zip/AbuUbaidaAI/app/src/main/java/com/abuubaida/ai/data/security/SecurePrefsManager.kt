package com.abuubaida.ai.data.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.abuubaida.ai.data.model.AssistantSettings
import com.abuubaida.ai.data.model.ChatMessage
import com.abuubaida.ai.data.model.FacebookAccountInfo
import com.abuubaida.ai.data.model.IslamicVoicePreset
import com.abuubaida.ai.data.model.MasterControlSettings
import com.abuubaida.ai.data.model.PublishingMode
import com.abuubaida.ai.data.model.YouTubeAccountInfo
import org.json.JSONArray
import org.json.JSONObject

class SecurePrefsManager(private val context: Context) {

    private var prefs: SharedPreferences = createEncryptedPrefs(context)
    var isKeystoreEncrypted: Boolean = prefs !is FallbackMarkerPrefs
        private set

    private class FallbackMarkerPrefs(private val delegate: SharedPreferences) : SharedPreferences by delegate

    private fun fallbackPrefs(): SharedPreferences =
        FallbackMarkerPrefs(context.getSharedPreferences("abu_ubaida_fallback_prefs", Context.MODE_PRIVATE))

    private fun switchToFallbackPrefs(): SharedPreferences {
        val fb = fallbackPrefs()
        prefs = fb
        isKeystoreEncrypted = false
        return fb
    }

    private fun createEncryptedPrefs(context: Context): SharedPreferences {
        return try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                "abu_ubaida_secure_prefs",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (_: Throwable) {
            fallbackPrefs()
        }
    }

    private fun safeGetString(key: String, defaultValue: String?): String? {
        return try {
            prefs.getString(key, defaultValue)
        } catch (_: Throwable) {
            try {
                switchToFallbackPrefs().getString(key, defaultValue)
            } catch (_: Throwable) {
                defaultValue
            }
        }
    }

    private fun safeGetBoolean(key: String, defaultValue: Boolean): Boolean {
        return try {
            prefs.getBoolean(key, defaultValue)
        } catch (_: Throwable) {
            try {
                switchToFallbackPrefs().getBoolean(key, defaultValue)
            } catch (_: Throwable) {
                defaultValue
            }
        }
    }

    private fun safeGetFloat(key: String, defaultValue: Float): Float {
        return try {
            prefs.getFloat(key, defaultValue)
        } catch (_: Throwable) {
            try {
                switchToFallbackPrefs().getFloat(key, defaultValue)
            } catch (_: Throwable) {
                defaultValue
            }
        }
    }

    private fun safeGetLong(key: String, defaultValue: Long): Long {
        return try {
            prefs.getLong(key, defaultValue)
        } catch (_: Throwable) {
            try {
                switchToFallbackPrefs().getLong(key, defaultValue)
            } catch (_: Throwable) {
                defaultValue
            }
        }
    }

    private fun safeEdit(block: SharedPreferences.Editor.() -> Unit) {
        try {
            prefs.edit().apply(block).apply()
        } catch (_: Throwable) {
            try {
                switchToFallbackPrefs().edit().apply(block).apply()
            } catch (_: Throwable) {
            }
        }
    }

    fun loadSettings(): AssistantSettings {
        val presetName = safeGetString(KEY_VOICE_PRESET, IslamicVoicePreset.MAULANA_UBAIDA.name)
            ?: IslamicVoicePreset.MAULANA_UBAIDA.name
        val preset = when (presetName) {
            "SWEET_WAAZ", "MELODIOUS_SOFT" -> IslamicVoicePreset.MAULANA_UBAIDA
            "DEEP_MAHFEL" -> IslamicVoicePreset.QARI_ABDULLAH
            "ENERGETIC_BAYAN", "DOCUMENTARY_CALM" -> IslamicVoicePreset.HAFIZ_RAYHAN
            else -> try {
                IslamicVoicePreset.valueOf(presetName)
            } catch (_: Exception) {
                IslamicVoicePreset.MAULANA_UBAIDA
            }
        }
        return AssistantSettings(
            wakePhrase = safeGetString(KEY_WAKE_PHRASE, DEFAULT_WAKE_PHRASE) ?: DEFAULT_WAKE_PHRASE,
            ttsEnabled = safeGetBoolean(KEY_TTS_ENABLED, true),
            continuousVoiceMode = safeGetBoolean(KEY_CONTINUOUS_VOICE, false),
            backgroundServiceEnabled = safeGetBoolean(KEY_BG_SERVICE_ENABLED, false),
            proxyEndpointUrl = safeGetString(KEY_PROXY_URL, "") ?: "",
            speechLanguageTag = safeGetString(KEY_SPEECH_LANG, "bn-BD") ?: "bn-BD",
            voicePreset = preset,
            voicePitch = safeGetFloat(KEY_VOICE_PITCH, preset.pitch).coerceIn(0.65f, 1.15f),
            voiceRate = safeGetFloat(KEY_VOICE_RATE, preset.rate).coerceIn(0.65f, 1.15f),
            selectedTtsVoiceName = safeGetString(KEY_TTS_VOICE_NAME, "") ?: "",
            includeVoiceoverInVideo = safeGetBoolean(KEY_VIDEO_VOICEOVER_ON, true),
            autoSaveMp4ToPhone = safeGetBoolean(KEY_AUTO_SAVE_MP4, true),
            motionGraphicsEnabled = safeGetBoolean(KEY_MOTION_GRAPHICS_ON, true)
        )
    }

    fun saveSettings(settings: AssistantSettings) {
        safeEdit {
            putString(KEY_WAKE_PHRASE, settings.wakePhrase.ifBlank { DEFAULT_WAKE_PHRASE })
            putBoolean(KEY_TTS_ENABLED, settings.ttsEnabled)
            putBoolean(KEY_CONTINUOUS_VOICE, settings.continuousVoiceMode)
            putBoolean(KEY_BG_SERVICE_ENABLED, settings.backgroundServiceEnabled)
            putString(KEY_PROXY_URL, settings.proxyEndpointUrl.trim())
            putString(KEY_SPEECH_LANG, settings.speechLanguageTag.ifBlank { "bn-BD" })
            putString(KEY_VOICE_PRESET, settings.voicePreset.name)
            putFloat(KEY_VOICE_PITCH, settings.voicePitch.coerceIn(0.65f, 1.15f))
            putFloat(KEY_VOICE_RATE, settings.voiceRate.coerceIn(0.65f, 1.15f))
            putString(KEY_TTS_VOICE_NAME, settings.selectedTtsVoiceName.trim())
            putBoolean(KEY_VIDEO_VOICEOVER_ON, settings.includeVoiceoverInVideo)
            putBoolean(KEY_AUTO_SAVE_MP4, settings.autoSaveMp4ToPhone)
            putBoolean(KEY_MOTION_GRAPHICS_ON, settings.motionGraphicsEnabled)
        }
    }

    fun loadMasterControls(): MasterControlSettings {
        val modeName = safeGetString(KEY_PUBLISHING_MODE, PublishingMode.ASK_BEFORE_PUBLISHING.name)
            ?: PublishingMode.ASK_BEFORE_PUBLISHING.name
        val mode = try {
            PublishingMode.valueOf(modeName)
        } catch (_: Exception) {
            PublishingMode.ASK_BEFORE_PUBLISHING
        }
        return MasterControlSettings(
            aiAssistantEnabled = safeGetBoolean(KEY_MASTER_AI, true),
            contentCreationEnabled = safeGetBoolean(KEY_MASTER_CREATION, true),
            autoUploadEnabled = safeGetBoolean(KEY_MASTER_AUTO_UPLOAD, false),
            youTubeConnectionEnabled = safeGetBoolean(KEY_MASTER_YOUTUBE, true),
            facebookConnectionEnabled = safeGetBoolean(KEY_MASTER_FACEBOOK, true),
            trendResearchEnabled = safeGetBoolean(KEY_MASTER_TRENDS, true),
            publishingMode = mode
        )
    }

    fun saveMasterControls(controls: MasterControlSettings) {
        safeEdit {
            putBoolean(KEY_MASTER_AI, controls.aiAssistantEnabled)
            putBoolean(KEY_MASTER_CREATION, controls.contentCreationEnabled)
            putBoolean(KEY_MASTER_AUTO_UPLOAD, controls.autoUploadEnabled)
            putBoolean(KEY_MASTER_YOUTUBE, controls.youTubeConnectionEnabled)
            putBoolean(KEY_MASTER_FACEBOOK, controls.facebookConnectionEnabled)
            putBoolean(KEY_MASTER_TRENDS, controls.trendResearchEnabled)
            putString(KEY_PUBLISHING_MODE, controls.publishingMode.name)
        }
    }

    fun saveOAuthAccessToken(token: String?) {
        safeEdit {
            if (token.isNullOrBlank()) remove(KEY_YT_ACCESS_TOKEN) else putString(KEY_YT_ACCESS_TOKEN, token.trim())
        }
    }

    fun getOAuthAccessToken(): String? = safeGetString(KEY_YT_ACCESS_TOKEN, null)

    fun saveYouTubeProfile(channelName: String, channelUrl: String) {
        safeEdit {
            putString(KEY_YT_CHANNEL_NAME, channelName.trim())
            putString(KEY_YT_CHANNEL_URL, channelUrl.trim())
        }
    }

    fun getYouTubeAccountInfo(): YouTubeAccountInfo {
        val token = safeGetString(KEY_YT_ACCESS_TOKEN, null)
        return YouTubeAccountInfo(
            channelName = safeGetString(KEY_YT_CHANNEL_NAME, "") ?: "",
            channelUrl = safeGetString(KEY_YT_CHANNEL_URL, "") ?: "",
            hasOAuthToken = !token.isNullOrBlank()
        )
    }

    fun clearYouTubeCredentials() {
        safeEdit {
            remove(KEY_YT_ACCESS_TOKEN)
            remove(KEY_YT_CHANNEL_NAME)
            remove(KEY_YT_CHANNEL_URL)
        }
    }

    fun saveFacebookCredentials(
        pageId: String,
        pageName: String,
        accessToken: String,
        followersCount: Long = -1L,
        pageUrl: String = ""
    ) {
        safeEdit {
            putString(KEY_FB_PAGE_ID, pageId.trim())
            putString(KEY_FB_PAGE_NAME, pageName.trim())
            putString(KEY_FB_PAGE_URL, pageUrl.trim())
            if (accessToken.isBlank()) remove(KEY_FB_ACCESS_TOKEN) else putString(KEY_FB_ACCESS_TOKEN, accessToken.trim())
            putLong(KEY_FB_FOLLOWERS, followersCount)
        }
    }

    fun getFacebookAccessToken(): String? = safeGetString(KEY_FB_ACCESS_TOKEN, null)

    fun getFacebookAccountInfo(): FacebookAccountInfo {
        val token = safeGetString(KEY_FB_ACCESS_TOKEN, null)
        return FacebookAccountInfo(
            pageId = safeGetString(KEY_FB_PAGE_ID, "") ?: "",
            pageName = safeGetString(KEY_FB_PAGE_NAME, "") ?: "",
            pageUrl = safeGetString(KEY_FB_PAGE_URL, "") ?: "",
            followersCount = safeGetLong(KEY_FB_FOLLOWERS, -1L),
            hasAccessToken = !token.isNullOrBlank()
        )
    }

    fun clearFacebookCredentials() {
        safeEdit {
            remove(KEY_FB_PAGE_ID)
            remove(KEY_FB_PAGE_NAME)
            remove(KEY_FB_PAGE_URL)
            remove(KEY_FB_ACCESS_TOKEN)
            remove(KEY_FB_FOLLOWERS)
        }
    }

    fun saveMetaAppId(appId: String) {
        safeEdit { putString(KEY_META_APP_ID, appId.trim()) }
    }

    fun getMetaAppId(): String = safeGetString(KEY_META_APP_ID, "") ?: ""

    fun saveChatHistory(messages: List<ChatMessage>) {
        val arr = JSONArray()
        messages.takeLast(100).forEach { msg ->
            val obj = JSONObject().apply {
                put("id", msg.id)
                put("text", msg.text)
                put("isUser", msg.isUser)
                put("timestampMillis", msg.timestampMillis)
            }
            arr.put(obj)
        }
        safeEdit { putString(KEY_CHAT_HISTORY, arr.toString()) }
    }

    fun loadChatHistory(): List<ChatMessage> {
        val raw = safeGetString(KEY_CHAT_HISTORY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    add(
                        ChatMessage(
                            id = obj.optString("id"),
                            text = obj.optString("text"),
                            isUser = obj.optBoolean("isUser"),
                            timestampMillis = obj.optLong("timestampMillis", System.currentTimeMillis())
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun clearChatHistory() {
        safeEdit { remove(KEY_CHAT_HISTORY) }
    }

    fun wipeAllLocalData() {
        safeEdit { clear() }
    }

    companion object {
        const val DEFAULT_WAKE_PHRASE = "হ্যালো আবু উবাইদা"
        private const val KEY_WAKE_PHRASE = "wake_phrase"
        private const val KEY_TTS_ENABLED = "tts_enabled"
        private const val KEY_CONTINUOUS_VOICE = "continuous_voice_mode"
        private const val KEY_BG_SERVICE_ENABLED = "bg_service_enabled"
        private const val KEY_PROXY_URL = "proxy_endpoint_url"
        private const val KEY_SPEECH_LANG = "speech_language_tag"
        private const val KEY_VOICE_PRESET = "voice_preset"
        private const val KEY_VOICE_PITCH = "voice_pitch"
        private const val KEY_VOICE_RATE = "voice_rate"
        private const val KEY_TTS_VOICE_NAME = "tts_voice_name"
        private const val KEY_VIDEO_VOICEOVER_ON = "video_voiceover_on"
        private const val KEY_AUTO_SAVE_MP4 = "auto_save_mp4"
        private const val KEY_MOTION_GRAPHICS_ON = "motion_graphics_on"
        private const val KEY_YT_ACCESS_TOKEN = "yt_oauth_access_token"
        private const val KEY_YT_CHANNEL_NAME = "yt_channel_name"
        private const val KEY_YT_CHANNEL_URL = "yt_channel_url"
        private const val KEY_FB_PAGE_ID = "fb_page_id"
        private const val KEY_FB_PAGE_NAME = "fb_page_name"
        private const val KEY_FB_PAGE_URL = "fb_page_url"
        private const val KEY_FB_ACCESS_TOKEN = "fb_page_access_token"
        private const val KEY_FB_FOLLOWERS = "fb_followers_count"
        private const val KEY_META_APP_ID = "fb_meta_app_id"
        private const val KEY_CHAT_HISTORY = "chat_history_json"
        private const val KEY_MASTER_AI = "master_ai_assistant_enabled"
        private const val KEY_MASTER_CREATION = "master_content_creation_enabled"
        private const val KEY_MASTER_AUTO_UPLOAD = "master_auto_upload_enabled"
        private const val KEY_MASTER_YOUTUBE = "master_youtube_connection_enabled"
        private const val KEY_MASTER_FACEBOOK = "master_facebook_connection_enabled"
        private const val KEY_MASTER_TRENDS = "master_trend_research_enabled"
        private const val KEY_PUBLISHING_MODE = "master_publishing_mode"
    }
}
