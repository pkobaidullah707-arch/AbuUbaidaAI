package com.abuubaida.ai.facebook

import android.content.Context
import android.net.Uri
import com.abuubaida.ai.data.model.FacebookAccountInfo
import com.abuubaida.ai.data.model.FacebookPublishState
import com.abuubaida.ai.data.model.FacebookUploadRequest
import com.abuubaida.ai.data.security.SecurePrefsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okio.BufferedSink
import okio.source
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * অফিসিয়াল Meta Graph API v21.0 ব্যবহার করে অনুমোদিত Facebook পেজে ভিডিও / Reels প্রকাশ,
 * ড্রাফট, শিডিউল এবং স্ট্যাটাস পরীক্ষা পরিচালনা করে।
 */
class FacebookStudioRepository(
    private val context: Context,
    private val securePrefsManager: SecurePrefsManager
) {
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(180, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    fun getAccountInfo(): FacebookAccountInfo = securePrefsManager.getFacebookAccountInfo()

    fun disconnectPage() {
        securePrefsManager.clearFacebookCredentials()
    }

    fun getSavedMetaAppId(): String = securePrefsManager.getMetaAppId()

    fun saveMetaAppId(appId: String) {
        securePrefsManager.saveMetaAppId(appId)
    }

    fun buildOfficialMetaOAuthUrl(metaAppId: String): String? {
        val cleanId = metaAppId.trim()
        if (cleanId.isBlank()) return null
        val scopes = URLEncoder.encode("pages_manage_posts,pages_read_engagement,pages_show_list", "UTF-8")
        val redirect = URLEncoder.encode("https://www.facebook.com/connect/login_success.html", "UTF-8")
        return "https://www.facebook.com/v21.0/dialog/oauth?client_id=$cleanId&redirect_uri=$redirect&scope=$scopes&response_type=token"
    }

    suspend fun verifyAndSavePageToken(
        pageIdInput: String,
        pageAccessToken: String
    ): Result<FacebookAccountInfo> = withContext(Dispatchers.IO) {
        val cleanToken = pageAccessToken.trim()
        val rawPageInput = pageIdInput.trim()
        val parsedSlugOrId = extractFacebookSlugOrId(rawPageInput)
        val normalizedUrl = normalizeFacebookUrl(rawPageInput)

        if (cleanToken.isBlank()) {
            if (rawPageInput.isBlank()) {
                return@withContext Result.failure(
                    IllegalArgumentException("আপনার Facebook পেজের নাম/লিংক অথবা Meta Page Access Token দিন।")
                )
            }
            val displayName = parsedSlugOrId.ifBlank { rawPageInput }
            securePrefsManager.saveFacebookCredentials(
                pageId = parsedSlugOrId,
                pageName = displayName,
                accessToken = "",
                followersCount = -1L,
                pageUrl = normalizedUrl
            )
            return@withContext Result.success(securePrefsManager.getFacebookAccountInfo())
        }

        try {
            val resolvedId: String
            val resolvedName: String
            val followers: Long

            if (parsedSlugOrId.isBlank()) {
                val accountsReq = Request.Builder()
                    .url("https://graph.facebook.com/v21.0/me/accounts?fields=id,name,access_token,followers_count")
                    .addHeader("Authorization", "Bearer $cleanToken")
                    .get()
                    .build()
                httpClient.newCall(accountsReq).execute().use { resp ->
                    val body = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        val errMsg = parseGraphError(body, resp.code)
                        return@withContext Result.failure(IllegalStateException("Meta পেজ যাচাই ব্যর্থ: $errMsg"))
                    }
                    val data = JSONObject(body).optJSONArray("data")
                    if (data == null || data.length() == 0) {
                        return@withContext Result.failure(
                            IllegalStateException("এই টোকেনের অধীনে কোনো Facebook পেজ পাওয়া যায়নি। পেজের নাম বা ID দিন।")
                        )
                    }
                    val firstPage = data.getJSONObject(0)
                    resolvedId = firstPage.optString("id")
                    resolvedName = firstPage.optString("name", resolvedId)
                    followers = firstPage.optLong("followers_count", -1L)
                    val pageScopedToken = firstPage.optString("access_token").ifBlank { cleanToken }
                    securePrefsManager.saveFacebookCredentials(
                        resolvedId,
                        resolvedName,
                        pageScopedToken,
                        followers,
                        "https://www.facebook.com/$resolvedId"
                    )
                    return@withContext Result.success(securePrefsManager.getFacebookAccountInfo())
                }
            } else {
                val pageReq = Request.Builder()
                    .url("https://graph.facebook.com/v21.0/${Uri.encode(parsedSlugOrId)}?fields=id,name,followers_count")
                    .addHeader("Authorization", "Bearer $cleanToken")
                    .get()
                    .build()
                httpClient.newCall(pageReq).execute().use { resp ->
                    val body = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        val errMsg = parseGraphError(body, resp.code)
                        return@withContext Result.failure(IllegalStateException("Meta পেজ যাচাই ব্যর্থ: $errMsg"))
                    }
                    val obj = JSONObject(body)
                    resolvedId = obj.optString("id", parsedSlugOrId)
                    resolvedName = obj.optString("name", parsedSlugOrId)
                    followers = obj.optLong("followers_count", -1L)
                    securePrefsManager.saveFacebookCredentials(
                        resolvedId,
                        resolvedName,
                        cleanToken,
                        followers,
                        normalizedUrl.ifBlank { "https://www.facebook.com/$resolvedId" }
                    )
                    return@withContext Result.success(securePrefsManager.getFacebookAccountInfo())
                }
            }
        } catch (e: Exception) {
            Result.failure(IllegalStateException("Facebook সংযোগ ত্রুটি: ${e.localizedMessage ?: "নেটওয়ার্ক সমস্যা"}"))
        }
    }

    private fun extractFacebookSlugOrId(input: String): String {
        val trimmed = input.trim()
        if (trimmed.isBlank()) return ""
        return try {
            if (trimmed.contains("facebook.com", ignoreCase = true) || trimmed.contains("fb.com", ignoreCase = true)) {
                val uri = Uri.parse(if (trimmed.startsWith("http")) trimmed else "https://$trimmed")
                val idQuery = uri.getQueryParameter("id")
                if (!idQuery.isNullOrBlank()) return idQuery
                uri.pathSegments.lastOrNull { it.isNotBlank() && it != "profile.php" && it != "pages" } ?: trimmed
            } else {
                trimmed.removePrefix("@")
            }
        } catch (_: Exception) {
            trimmed
        }
    }

    private fun normalizeFacebookUrl(input: String): String {
        val trimmed = input.trim()
        if (trimmed.isBlank()) return ""
        if (trimmed.startsWith("http://", ignoreCase = true) || trimmed.startsWith("https://", ignoreCase = true)) {
            return trimmed
        }
        return "https://www.facebook.com/${trimmed.removePrefix("@").replace(" ", "")}"
    }

    suspend fun publishVideoToPage(request: FacebookUploadRequest): Result<Pair<String, String>> =
        withContext(Dispatchers.IO) {
            val controls = securePrefsManager.loadMasterControls()
            if (!controls.facebookConnectionEnabled) {
                return@withContext Result.failure(
                    IllegalStateException("মাস্টার কন্ট্রোলে Facebook সংযোগ বন্ধ আছে। গোপনীয়তা ড্যাশবোর্ড থেকে চালু করুন।")
                )
            }

            val token = securePrefsManager.getFacebookAccessToken()
            val info = securePrefsManager.getFacebookAccountInfo()
            if (token.isNullOrBlank() || info.pageId.isBlank()) {
                return@withContext Result.failure(
                    IllegalStateException("আগে Facebook স্টুডিও থেকে আপনার অনুমোদিত পেজ ও Meta Page Access Token সংযুক্ত করুন।")
                )
            }

            if (request.videoUriString.isBlank()) {
                return@withContext Result.failure(
                    IllegalArgumentException("আপলোডের জন্য একটি MP4 ভিডিও নির্বাচন বা তৈরি করুন।")
                )
            }

            val videoUri = Uri.parse(request.videoUriString)
            val fullCaption = buildString {
                append(request.caption.trim())
                if (request.hashtags.isNotEmpty()) {
                    append("\n\n")
                    append(request.hashtags.joinToString(" ") { tag -> if (tag.startsWith("#")) tag else "#$tag" })
                }
            }.trim()

            try {
                val streamingFileBody = object : RequestBody() {
                    override fun contentType() = "video/mp4".toMediaType()
                    override fun writeTo(sink: BufferedSink) {
                        context.contentResolver.openInputStream(videoUri)?.use { input ->
                            sink.writeAll(input.source())
                        } ?: throw IllegalStateException("ভিডিও ফাইল পড়া যাচ্ছে না।")
                    }
                }

                val multipartBuilder = MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("title", request.title.ifBlank { "আবু উবাইদা AI ইসলামিক ভিডিও" })
                    .addFormDataPart("description", fullCaption)
                    .addFormDataPart(
                        "source",
                        request.videoDisplayName.ifBlank { "abu_ubaida_video.mp4" },
                        streamingFileBody
                    )

                when (request.publishState) {
                    FacebookPublishState.PUBLISH_NOW -> {
                        multipartBuilder.addFormDataPart("published", "true")
                    }
                    FacebookPublishState.DRAFT -> {
                        multipartBuilder.addFormDataPart("published", "false")
                    }
                    FacebookPublishState.SCHEDULE -> {
                        val minFutureSec = (System.currentTimeMillis() / 1000L) + 660L // Meta requires >= 10 mins ahead
                        val sched = (request.scheduledUnixSeconds ?: minFutureSec).coerceAtLeast(minFutureSec)
                        multipartBuilder.addFormDataPart("published", "false")
                        multipartBuilder.addFormDataPart("scheduled_publish_time", sched.toString())
                    }
                }

                val uploadReq = Request.Builder()
                    .url("https://graph-video.facebook.com/v21.0/${Uri.encode(info.pageId)}/videos")
                    .addHeader("Authorization", "Bearer $token")
                    .post(multipartBuilder.build())
                    .build()

                httpClient.newCall(uploadReq).execute().use { resp ->
                    val body = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        val errMsg = parseGraphError(body, resp.code)
                        return@withContext Result.failure(IllegalStateException("Facebook আপলোড ব্যর্থ: $errMsg"))
                    }
                    val videoId = JSONObject(body).optString("id")
                    val statusMsg = when (request.publishState) {
                        FacebookPublishState.PUBLISH_NOW ->
                            "Facebook পেজে (${info.pageName}) ভিডিও সফলভাবে প্রকাশিত হয়েছে! আইডি: $videoId"
                        FacebookPublishState.SCHEDULE ->
                            "Facebook পেজে ভিডিও শিডিউল হয়েছে (${request.scheduledLabelBn})। আইডি: $videoId"
                        FacebookPublishState.DRAFT ->
                            "Facebook পেজে ভিডিও ড্রাফট (অপ্রকাশিত) হিসেবে সংরক্ষিত হয়েছে! আইডি: $videoId"
                    }
                    Result.success(videoId to statusMsg)
                }
            } catch (e: Exception) {
                Result.failure(
                    IllegalStateException("Facebook আপলোডে ত্রুটি: ${e.localizedMessage ?: "নেটওয়ার্ক সমস্যা"}")
                )
            }
        }

    suspend fun checkVideoStatus(videoId: String): Result<String> = withContext(Dispatchers.IO) {
        val token = securePrefsManager.getFacebookAccessToken()
        if (token.isNullOrBlank() || videoId.isBlank()) {
            return@withContext Result.failure(IllegalStateException("ভিডিও আইডি বা Facebook টোকেন পাওয়া যায়নি।"))
        }
        try {
            val req = Request.Builder()
                .url("https://graph.facebook.com/v21.0/${Uri.encode(videoId)}?fields=status,permalink_url")
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext Result.failure(IllegalStateException(parseGraphError(body, resp.code)))
                }
                val json = JSONObject(body)
                val statusObj = json.optJSONObject("status")
                val videoStatus = statusObj?.optString("video_status").orEmpty().ifBlank { "processing" }
                val permalink = json.optString("permalink_url").orEmpty()
                Result.success(
                    buildString {
                        append("Facebook ভিডিও স্ট্যাটাস: $videoStatus")
                        if (permalink.isNotBlank()) append("\nলিংক: https://facebook.com$permalink")
                    }
                )
            }
        } catch (e: Exception) {
            Result.failure(IllegalStateException("স্ট্যাটাস পরীক্ষা ব্যর্থ: ${e.localizedMessage}"))
        }
    }

    private fun parseGraphError(body: String, code: Int): String {
        return try {
            val err = JSONObject(body).optJSONObject("error")
            val msg = err?.optString("message").orEmpty()
            if (msg.isNotBlank()) "($code) $msg" else "HTTP $code"
        } catch (_: Exception) {
            "HTTP $code"
        }
    }
}
