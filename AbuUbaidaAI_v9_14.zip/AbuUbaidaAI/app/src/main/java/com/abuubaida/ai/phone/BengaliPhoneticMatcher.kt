package com.abuubaida.ai.phone

import com.abuubaida.ai.data.model.ContactItem
import java.text.Normalizer
import kotlin.math.max
import kotlin.math.min

/**
 * বাংলা ও ইংরেজি কন্টাক্টের সঠিক ও নির্ভুল ফোনেটিক ম্যাচিং ইঞ্জিন।
 * বাংলা ব্যঞ্জনবর্ণের স্বরবর্ণ ('অ'/'আ' ধ্বনি) বিবেচনা করে সঠিক কন্টাক্ট খুঁজে বের করে
 * এবং ভুল/অপ্রাসঙ্গিক নাম ম্যাচ করা থেকে বিরত থাকে।
 */
object BengaliPhoneticMatcher {

    data class ContactMatch(
        val contact: ContactItem,
        val score: Double
    )

    private val kinshipAliases: Map<String, List<String>> = mapOf(
        "আব্বু" to listOf("abbu", "abba", "baba", "dad", "father", "papa"),
        "আব্বা" to listOf("abba", "abbu", "baba", "dad", "father"),
        "বাবা" to listOf("baba", "abbu", "dad", "father", "papa"),
        "আম্মু" to listOf("ammu", "amma", "ma", "mom", "mother", "mama"),
        "আম্মা" to listOf("amma", "ammu", "ma", "mom", "mother"),
        "মা" to listOf("ma", "ammu", "mom", "mother"),
        "ভাই" to listOf("vai", "bhai", "brother", "bro"),
        "ভাইয়া" to listOf("bhaiya", "vaiya", "vai", "bhai", "brother"),
        "আপু" to listOf("apu", "apa", "sister", "sis"),
        "আপা" to listOf("apa", "apu", "sister"),
        "চাচা" to listOf("chacha", "kaka", "uncle"),
        "মামা" to listOf("mama", "uncle"),
        "খালু" to listOf("khalu", "uncle"),
        "ফুফা" to listOf("fufa", "fupha", "uncle"),
        "খালা" to listOf("khala", "aunt", "aunty"),
        "মামী" to listOf("mami", "aunt", "aunty"),
        "ফুফু" to listOf("fupu", "fuphu", "aunt"),
        "দাদা" to listOf("dada", "grandfather"),
        "নানা" to listOf("nana", "grandfather"),
        "ভাবি" to listOf("vabi", "bhabi", "bhabhi"),
        "ভাবী" to listOf("vabi", "bhabi", "bhabhi"),
        "বউ" to listOf("bou", "wife"),
        "অফিস" to listOf("office"),
        "বস" to listOf("boss"),
        "হুজুর" to listOf("hujur", "imam", "maulana")
    )

    private val conjunctMap: List<Pair<String, String>> = listOf(
        "ক্ষ" to "kh",
        "জ্ঞ" to "gg",
        "ত্র" to "tr",
        "শ্র" to "sr",
        "দ্র" to "dr",
        "প্র" to "pr",
        "ব্র" to "br",
        "ক্র" to "kr",
        "গ্র" to "gr",
        "স্ত" to "st",
        "ন্দ" to "nd",
        "ন্ত" to "nt",
        "ম্প" to "mp",
        "ম্ব" to "mb",
        "ল্ল" to "ll",
        "ন্ন" to "nn",
        "ম্ম" to "mm",
        "ব্ব" to "bb"
    )

    private val consonantChars: Map<Char, String> = mapOf(
        'ক' to "k", 'খ' to "kh", 'গ' to "g", 'ঘ' to "gh",
        'ঙ' to "ng",
        'চ' to "ch", 'ছ' to "ch", 'জ' to "j", 'ঝ' to "jh",
        'ঞ' to "n",
        'ট' to "t", 'ঠ' to "th", 'ড' to "d", 'ঢ' to "dh",
        'ণ' to "n",
        'ত' to "t", 'থ' to "th", 'দ' to "d", 'ধ' to "dh",
        'ন' to "n",
        'প' to "p", 'ফ' to "f", 'ব' to "b", 'ভ' to "bh",
        'ম' to "m",
        'য' to "j", '\u09DF' to "y", 'র' to "r", '\u09DC' to "r", '\u09DD' to "r",
        'ল' to "l",
        'শ' to "sh", 'ষ' to "sh", 'স' to "s", 'হ' to "h"
    )

    private val charMap: Map<Char, String> = consonantChars + mapOf(
        'অ' to "o", 'আ' to "a", 'ই' to "i", 'ঈ' to "i",
        'উ' to "u", 'ঊ' to "u", 'ঋ' to "ri", 'এ' to "e",
        'ঐ' to "oi", 'ও' to "o", 'ঔ' to "ou",
        'া' to "a", 'ি' to "i", 'ী' to "i", 'ু' to "u",
        'ূ' to "u", 'ৃ' to "ri", 'ে' to "e", 'ৈ' to "oi",
        'ো' to "o", 'ৌ' to "ou",
        'ং' to "ng", 'ৎ' to "t", 'ঁ' to "", '্' to ""
    )

    private val vowelSignsAndHasant = setOf('া', 'ি', 'ী', 'ু', 'ূ', 'ৃ', 'ে', 'ৈ', 'ো', 'ৌ', '্', 'ং', 'ঃ')
    private val suffixList = listOf("ভাইকে", "আপুকে", "সাহেবকে", "দেরকে", "কে", "রে", "ের", "র")

    fun cleanTargetName(rawTarget: String): String {
        var cleaned = BengaliCommandEngine.normalizeDigits(rawTarget).trim()
            .trim(',', '।', '-', '?', '!')
        // Clean suffix on each word boundary safely if needed (mainly trailing word)
        for (suffix in suffixList) {
            if (cleaned.length > suffix.length + 1 && cleaned.endsWith(suffix)) {
                cleaned = cleaned.removeSuffix(suffix).trim()
                break
            }
        }
        return cleaned
    }

    fun transliterateBengaliToLatin(input: String, inherentVowel: String = "a"): String {
        val nfc = Normalizer.normalize(input.trim(), Normalizer.Form.NFC)
        var text = BengaliCommandEngine.normalizeDigits(nfc)
        for ((bn, en) in conjunctMap) {
            text = text.replace(bn, en)
        }
        val sb = StringBuilder(text.length * 2)
        val len = text.length
        for (i in 0 until len) {
            val ch = text[i]
            val mapped = charMap[ch]
            if (mapped != null) {
                sb.append(mapped)
                if (ch in consonantChars && inherentVowel.isNotEmpty()) {
                    val next = if (i + 1 < len) text[i + 1] else ' '
                    val nextIsBengaliConsonant = next in consonantChars || next == 'ৎ'
                    if (next !in vowelSignsAndHasant && nextIsBengaliConsonant) {
                        sb.append(inherentVowel)
                    }
                }
            } else {
                sb.append(ch.lowercaseChar())
            }
        }
        return sb.toString()
    }

    fun phoneticSkeleton(latinOrBn: String): String {
        var s = transliterateBengaliToLatin(latinOrBn, inherentVowel = "a").lowercase()
        s = s.replace(Regex("[^a-z0-9\\s]"), " ")
            .replace("ph", "f")
            .replace("bh", "b")
            .replace("vh", "b")
            .replace("v", "b")
            .replace("w", "o")
            .replace("z", "j")
            .replace("q", "k")
            .replace("sh", "s")
            .replace("ch", "c")
            .replace("kh", "k")
            .replace("gh", "g")
            .replace("th", "t")
            .replace("dh", "d")
            .replace("jh", "j")
            .replace("c", "k")
            .replace("oo", "u")
            .replace("ee", "i")
            .replace("aa", "a")
            .replace("ai", "i")
            .replace("ay", "i")
            .replace("ey", "i")
            .replace("ou", "o")
            .replace("au", "o")
            .replace("u", "o")
        val collapsed = StringBuilder(s.length)
        var prev = '\u0000'
        for (ch in s) {
            if (ch != prev || ch == ' ') {
                collapsed.append(ch)
                prev = ch
            }
        }
        return collapsed.toString().trim().replace(Regex("\\s+"), " ")
    }

    fun consonantSkeleton(phonetic: String): String {
        val clean = phonetic.replace(" ", "")
        if (clean.isEmpty()) return ""
        val sb = StringBuilder(clean.length)
        clean.forEachIndexed { idx, ch ->
            if (idx == 0 || ch !in charArrayOf('a', 'e', 'i', 'o', 'u', 'y')) {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun expandCandidates(rawTarget: String): List<String> {
        val cleaned = cleanTargetName(rawTarget)
        val lower = cleaned.lowercase()
        val list = mutableListOf(
            lower,
            transliterateBengaliToLatin(cleaned, inherentVowel = "a"),
            transliterateBengaliToLatin(cleaned, inherentVowel = "o"),
            transliterateBengaliToLatin(cleaned, inherentVowel = "")
        )
        kinshipAliases.forEach { (bn, aliases) ->
            if (lower == bn || lower.contains(bn)) {
                list.addAll(aliases)
            }
        }
        return list.map { it.trim() }.filter { it.isNotBlank() }.distinct()
    }

    fun findBestContact(rawTarget: String, contacts: List<ContactItem>): ContactItem? {
        return findTopContacts(rawTarget, contacts, limit = 1).firstOrNull()?.contact
    }

    fun findTopContacts(
        rawTarget: String,
        contacts: List<ContactItem>,
        limit: Int = 4
    ): List<ContactMatch> {
        if (contacts.isEmpty() || rawTarget.isBlank()) return emptyList()

        val cleaned = cleanTargetName(rawTarget)
        if (cleaned.isBlank()) return emptyList()

        val digitsQuery = cleaned.filter { it.isDigit() }
        if (digitsQuery.length >= 3) {
            val digitMatches = contacts.filter { c ->
                c.phoneNumber.filter { it.isDigit() }.contains(digitsQuery)
            }
            if (digitMatches.isNotEmpty()) {
                return digitMatches.take(limit).map { ContactMatch(it, 1.0) }
            }
        }

        // Exact or substring Bengali/Latin text matches first
        val exactText = contacts.filter { c ->
            c.name.equals(cleaned, ignoreCase = true)
        }
        if (exactText.isNotEmpty()) {
            return exactText.take(limit).map { ContactMatch(it, 1.0) }
        }

        val candidates = expandCandidates(cleaned)
        val candidateWords = cleaned.split(" ").filter { it.length >= 2 }
        val scored = mutableListOf<ContactMatch>()

        for (contact in contacts) {
            val nameLower = contact.name.lowercase().trim()
            val namePhonetic = phoneticSkeleton(nameLower)
            val nameConsonants = consonantSkeleton(namePhonetic)
            val nameTokens = namePhonetic.split(" ").filter { it.isNotBlank() }

            var bestForContact = 0.0
            if (nameLower.contains(cleaned.lowercase())) {
                bestForContact = 0.98
            }

            for (cand in candidates) {
                val candPhonetic = phoneticSkeleton(cand)
                val candConsonants = consonantSkeleton(candPhonetic)
                val candTokens = candPhonetic.split(" ").filter { it.isNotBlank() }
                if (candPhonetic.isBlank()) continue

                var score = when {
                    nameLower == cand || namePhonetic == candPhonetic -> 1.0
                    nameTokens.any { it == candPhonetic } -> 0.97
                    candTokens.size > 1 && candTokens.all { ct -> nameTokens.any { nt -> nt == ct || similarity(nt, ct) >= 0.85 } } -> 0.94
                    candPhonetic.length >= 3 && (nameLower.contains(cand) || namePhonetic.contains(candPhonetic)) -> 0.91
                    candConsonants.length >= 3 && nameConsonants == candConsonants -> 0.89
                    candConsonants.length >= 3 && nameTokens.any { consonantSkeleton(it) == candConsonants } -> 0.87
                    else -> {
                        val fullSim = similarity(candPhonetic, namePhonetic)
                        val tokenSim = nameTokens.maxOfOrNull { nt ->
                            if (min(nt.length, candPhonetic.length) < 2) 0.0
                            else similarity(candPhonetic, nt)
                        } ?: 0.0
                        val multiWordSim = if (candTokens.size >= 2) {
                            candTokens.map { ct ->
                                nameTokens.maxOfOrNull { nt -> similarity(ct, nt) } ?: 0.0
                            }.average()
                        } else 0.0
                        val consSim = if (candConsonants.length >= 3 && nameConsonants.length >= 3) {
                            similarity(candConsonants, nameConsonants)
                        } else 0.0
                        val tokenConsSim = if (candConsonants.length >= 3) {
                            nameTokens.maxOfOrNull { nt ->
                                val nc = consonantSkeleton(nt)
                                if (nc.length >= 2) similarity(candConsonants, nc) else 0.0
                            } ?: 0.0
                        } else 0.0

                        // Bonus if first letter matches (strong safeguard against wrong contact names)
                        val firstCharBonus = if (nameTokens.any { it.firstOrNull() == candPhonetic.firstOrNull() }) 0.03 else -0.08
                        (maxOf(fullSim, tokenSim, multiWordSim, consSim * 0.90, tokenConsSim * 0.90) + firstCharBonus)
                            .coerceIn(0.0, 0.99)
                    }
                }

                // Multi-word Bengali name match boost
                if (candidateWords.size > 1 && candidateWords.all { w -> nameLower.contains(w.lowercase()) }) {
                    score = max(score, 0.96)
                }

                if (score > bestForContact) {
                    bestForContact = score
                }
            }

            if (bestForContact >= 0.72) {
                scored.add(ContactMatch(contact, bestForContact))
            }
        }

        return scored
            .sortedByDescending { it.score }
            .distinctBy { it.contact.phoneNumber }
            .take(limit)
    }

    private fun similarity(a: String, b: String): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        if (a == b) return 1.0
        val dist = levenshtein(a, b)
        return 1.0 - (dist.toDouble() / max(a.length, b.length).toDouble())
    }

    private fun levenshtein(a: String, b: String): Int {
        val m = a.length
        val n = b.length
        val dp = IntArray(n + 1) { it }
        for (i in 1..m) {
            var prevDiag = dp[0]
            dp[0] = i
            for (j in 1..n) {
                val temp = dp[j]
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                dp[j] = min(min(dp[j] + 1, dp[j - 1] + 1), prevDiag + cost)
                prevDiag = temp
            }
        }
        return dp[n]
    }
}
