package com.abuubaida.ai.voice

import android.Manifest
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.abuubaida.ai.AbuUbaidaApplication
import com.abuubaida.ai.MainActivity
import com.abuubaida.ai.R
import com.abuubaida.ai.data.security.SecurePrefsManager

/**
 * স্বচ্ছ ব্যাকগ্রাউন্ড ফোরগ্রাউন্ড মাইক্রোফোন সার্ভিস:
 * - সর্বদা দৃশ্যমান নোটিফিকেশন প্রদর্শন করে (কখনো গোপনে অডিও রেকর্ড করে না)।
 * - কনফিগারযোগ্য ওয়েক-ফ্রেজ ("হ্যালো আবু উবাইদা") শনাক্ত হলে অ্যাপটি সামনে আনে।
 * - Android 14+ এর Foreground Microphone Service এবং ব্যাটারি সীমাবদ্ধতা মেনে চলে।
 */
class BackgroundVoiceService : Service() {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var isRunning = false
    private lateinit var securePrefsManager: SecurePrefsManager

    override fun onCreate() {
        super.onCreate()
        securePrefsManager = SecurePrefsManager(applicationContext)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        val hasMicPermission = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasMicPermission) {
            stopSelf()
            return START_NOT_STICKY
        }

        val wakePhrase = securePrefsManager.loadSettings().wakePhrase
        val notification = buildNotification(
            "আবু উবাইদা AI সক্রিয় আছে — ওয়েক-ফ্রেজ: \"$wakePhrase\" (বন্ধ করতে ট্যাপ করুন)"
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        if (!isRunning) {
            isRunning = true
            startWakeListeningLoop()
        }

        return START_STICKY
    }

    private fun startWakeListeningLoop() {
        mainHandler.post {
            if (!isRunning || !SpeechRecognizer.isRecognitionAvailable(this)) return@post
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(applicationContext).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onPartialResults(partialResults: Bundle?) {
                        checkWakePhrase(partialResults)
                    }

                    override fun onResults(results: Bundle?) {
                        val matched = checkWakePhrase(results)
                        if (!matched && isRunning) {
                            scheduleNextCycle(600L)
                        }
                    }

                    override fun onError(error: Int) {
                        if (isRunning) {
                            val delay = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500L else 1000L
                            scheduleNextCycle(delay)
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            }
            recognizer?.startListening(intent)
        }
    }

    private fun checkWakePhrase(bundle: Bundle?): Boolean {
        val matches = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
        val wakePhrase = securePrefsManager.loadSettings().wakePhrase.trim().lowercase()
        val found = matches.any { heard ->
            val h = heard.lowercase()
            h.contains(wakePhrase) ||
                h.contains("আবু উবাইদা") ||
                h.contains("abu ubaida")
        }
        if (found) {
            val openIntent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra(EXTRA_WAKE_TRIGGERED, true)
            }
            startActivity(openIntent)
            scheduleNextCycle(2500L)
        }
        return found
    }

    private fun scheduleNextCycle(delayMs: Long) {
        mainHandler.postDelayed({
            if (isRunning) {
                startWakeListeningLoop()
            }
        }, delayMs)
    }

    private fun buildNotification(contentText: String): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, BackgroundVoiceService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, AbuUbaidaApplication.VOICE_CHANNEL_ID)
            .setContentTitle("আবু উবাইদা AI — ভয়েস অ্যাসিস্ট্যান্ট")
            .setContentText(contentText)
            .setSmallIcon(R.drawable.ic_abu_ubaida_logo)
            .setOngoing(true)
            .setContentIntent(openAppIntent)
            .addAction(0, "বন্ধ করুন", stopIntent)
            .build()
    }

    override fun onDestroy() {
        isRunning = false
        mainHandler.removeCallbacksAndMessages(null)
        mainHandler.post {
            recognizer?.destroy()
            recognizer = null
        }
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(NOTIFICATION_ID)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_STOP = "com.abuubaida.ai.STOP_BG_VOICE"
        const val EXTRA_WAKE_TRIGGERED = "extra_wake_triggered"
        private const val NOTIFICATION_ID = 4041

        fun start(context: Context) {
            val intent = Intent(context, BackgroundVoiceService::class.java)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, BackgroundVoiceService::class.java))
        }
    }
}
