package com.abuubaida.ai.video

import android.content.Context
import android.net.Uri
import com.abuubaida.ai.data.ai.GeminiAssistantRepository
import com.abuubaida.ai.data.model.IslamicCategory
import com.abuubaida.ai.data.model.NarrationCue
import com.abuubaida.ai.data.model.VideoDurationOption
import com.abuubaida.ai.data.model.VideoFormat
import com.abuubaida.ai.data.model.VideoProject
import com.abuubaida.ai.data.security.SecurePrefsManager
import com.abuubaida.ai.islamic.IslamicKnowledgeRepository
import com.abuubaida.ai.voice.BengaliVoiceManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs

interface VideoGenerationProvider {
    val providerNameBn: String
    val isConnected: Boolean
    suspend fun generateMp4(prompt: String, outputFile: File): Result<Uri>
}

class UnconnectedVideoProvider : VideoGenerationProvider {
    override val providerNameBn: String = "ভিডিও জেনারেশন প্রোভাইডার সংযুক্ত নয়"
    override val isConnected: Boolean = false

    override suspend fun generateMp4(prompt: String, outputFile: File): Result<Uri> {
        return Result.failure(IllegalStateException("MP4 প্রোভাইডার সংযুক্ত নয়।"))
    }
}

class VideoStudioRepository(
    private val context: Context,
    private val securePrefsManager: SecurePrefsManager,
    private val geminiRepo: GeminiAssistantRepository,
    private val islamicKnowledgeRepository: IslamicKnowledgeRepository,
    private val voiceManager: BengaliVoiceManager,
    private val videoProvider: VideoGenerationProvider = LocalMp4VideoProvider(context)
) {
    suspend fun createProjectFromTopic(
        topic: String,
        category: IslamicCategory = IslamicCategory.ISLAMIC_EDUCATION,
        format: VideoFormat = category.defaultFormat,
        durationOption: VideoDurationOption = if (format == VideoFormat.SHORTS_9_16) {
            VideoDurationOption.SHORT_1M
        } else {
            VideoDurationOption.LONG_10M
        }
    ): Result<VideoProject> {
        val controls = securePrefsManager.loadMasterControls()
        if (!controls.contentCreationEnabled) {
            return Result.failure(
                IllegalStateException("মাস্টার কন্ট্রোলে 'কন্টেন্ট তৈরি (Content Creation)' বন্ধ আছে। গোপনীয়তা ড্যাশবোর্ড থেকে চালু করুন।")
            )
        }
        val settings = securePrefsManager.loadSettings()

        // Step 1 & 2: Resolve topic and verify authentic Islamic Quran/Hadith sources
        val verifiedBundle = islamicKnowledgeRepository.prepareVerifiedBundle(topic, category)
        val cleanTopic = verifiedBundle.resolvedTopic

        // Step 3: Script + Bilingual SEO + Structured NarrationCues (zero headings/timestamps)
        val rawProject = if (controls.aiAssistantEnabled) {
            geminiRepo.generateIslamicVideoPackage(cleanTopic, category, format, durationOption, verifiedBundle)
                .getOrElse { buildVerifiedOfflineIslamicPackage(cleanTopic, category, format, durationOption, verifiedBundle) }
        } else {
            buildVerifiedOfflineIslamicPackage(cleanTopic, category, format, durationOption, verifiedBundle)
        }.copy(durationOption = durationOption)

        val formattedScript = BengaliVoiceManager.formatIslamicSpeechText(rawProject.script)
        val baseCues = if (rawProject.narrationCues.isNotEmpty()) {
            rawProject.narrationCues
        } else {
            buildOrderedNarrationCuesFromProject(rawProject.copy(script = formattedScript))
        }
        val baseProject = rawProject.copy(
            script = formattedScript,
            narrationCues = baseCues
        )

        // Step 4: Pre-publish Islamic Accuracy Review
        val review = islamicKnowledgeRepository.reviewReligiousContent(
            script = baseProject.script,
            quranRef = baseProject.quranReference,
            hadithRef = baseProject.hadithReference,
            category = category
        )

        // Step 5: Synthesize Human Male Neural Voiceover WAV with millisecond-exact per-cue timing
        var synthesizedWav: File? = null
        var syncedCues: List<NarrationCue> = baseCues
        if (settings.includeVoiceoverInVideo) {
            val voDir = File(context.filesDir, "abu_ubaida_voiceovers").apply { mkdirs() }
            val voFile = File(voDir, "vo_${System.currentTimeMillis()}.wav")
            val timedResult = voiceManager.synthesizeTimedCuesToWav(baseCues, voFile)
            if (timedResult != null) {
                synthesizedWav = timedResult.first
                syncedCues = timedResult.second
            }
        }

        // Step 6 & 7: Render Thumbnail PNG & Cue-Synced Full HD MP4 Video + Auto-Save to Phone
        var projectWithMedia = baseProject.copy(
            accuracyReview = review,
            narrationCues = syncedCues,
            voiceoverWavPath = synthesizedWav?.absolutePath.orEmpty()
        )

        if (videoProvider is LocalMp4VideoProvider) {
            val thumbDir = File(context.filesDir, "abu_ubaida_thumbnails").apply { mkdirs() }
            val thumbFile = File(thumbDir, "thumb_${System.currentTimeMillis()}.png")
            val thumbRes = videoProvider.renderThumbnailPng(projectWithMedia, thumbFile)
            thumbRes.onSuccess { (uri, localPath) ->
                projectWithMedia = projectWithMedia.copy(
                    thumbnailPngUriString = uri.toString(),
                    thumbnailLocalPath = localPath
                )
            }
        }

        if (!settings.autoSaveMp4ToPhone && videoProvider is LocalMp4VideoProvider) {
            return Result.success(
                projectWithMedia.copy(
                    providerStatusBn = "স্ক্রিপ্ট, থাম্বনেইল ও মানুষের মতো ভয়েসওভার প্রস্তুত (নিচে থেকে ফোনে MP4 সেভ করুন)।"
                )
            )
        }

        val mp4Res = exportMp4WithDetails(projectWithMedia)
        val motionLabel = if (settings.motionGraphicsEnabled) "হলিউড HD মোশন গ্রাফিক্স" else "হলিউড HD স্টিল স্লাইড"
        val finalProject = mp4Res.fold(
            onSuccess = { (mp4Uri, displayPath) ->
                val audioNote = if (!settings.includeVoiceoverInVideo) {
                    "ভয়েসওভার সুইচ বন্ধ থাকায় কেবল $motionLabel ও সাবটাইটেলসহ Full HD MP4 তৈরি হয়েছে।"
                } else if (synthesizedWav != null) {
                    "${settings.voicePreset.labelBn} (১০০% স্বাভাবিক কণ্ঠ ও নিখুঁত স্লাইড-সিঙ্ক) এবং $motionLabel-সহ MP4 সেভ হয়েছে।"
                } else {
                    "স্পষ্ট সাবটাইটেল, $motionLabel ও যাচাইকৃত কুরআন-হাদিস কার্ডসহ Full HD MP4 ফোনে সংরক্ষিত হয়েছে।"
                }
                projectWithMedia.copy(
                    renderedMp4UriString = mp4Uri.toString(),
                    savedMp4DisplayPath = displayPath,
                    audioRightsNoteBn = audioNote,
                    providerStatusBn = "সম্পূর্ণ ${durationOption.labelBn} হলিউড Full HD MP4 ($motionLabel · ভয়েস-সিঙ্কড) সেভ হয়েছে ($displayPath)!"
                )
            },
            onFailure = {
                projectWithMedia.copy(
                    providerStatusBn = "স্ক্রিপ্ট, থাম্বনেইল ও SEO প্রস্তুত।"
                )
            }
        )

        return Result.success(finalProject)
    }

    private fun buildVerifiedOfflineIslamicPackage(
        topic: String,
        category: IslamicCategory,
        format: VideoFormat,
        durationOption: VideoDurationOption,
        bundle: IslamicKnowledgeRepository.VerifiedTopicBundle
    ): VideoProject {
        val quran = bundle.quranRef
        val hadith = bundle.hadithRef
        val isShort = format == VideoFormat.SHORTS_9_16 || durationOption == VideoDurationOption.SHORT_1M
        val cues = mutableListOf<NarrationCue>()
        val scriptParts = mutableListOf<String>()

        fun addSegment(
            badge: String,
            spoken: String,
            display: String = spoken,
            arabic: String = "",
            subtitle: String = ""
        ) {
            val cleanSpoken = BengaliVoiceManager.formatIslamicSpeechText(spoken)
            val cleanDisplay = BengaliVoiceManager.formatIslamicSpeechText(display)
            val cleanSub = BengaliVoiceManager.formatIslamicSpeechText(subtitle)
            scriptParts.add(cleanSpoken)
            cues.add(
                NarrationCue(
                    badge = BengaliVoiceManager.formatIslamicSpeechText(badge),
                    spokenText = cleanSpoken,
                    displayBody = cleanDisplay,
                    arabicText = arabic,
                    subtitle = cleanSub
                )
            )
        }

        // 1. Dynamic Opening tailored specifically to topic & category
        val openingHooks = listOf(
            "বিসমিল্লাহির রাহমানির রাহীম। আসসালামু আলাইকুম ওয়া রাহমাতুল্লাহি ওয়া বারাকাতুহ। প্রিয় দ্বীনি ভাই ও বোনেরা, আজ আমরা অত্যন্ত গুরুত্বপূর্ণ ও হৃদয়স্পর্শী একটি বিষয় \"$topic\" নিয়ে কুরআন ও সহীহ সুন্নাহর আলোকে আলোচনা করব।",
            "বিসমিল্লাহির রাহমানির রাহীম। প্রিয় দর্শক ও শ্রোতাবৃন্দ, মহান রাব্বুল আলামীনের দরবারে অসংখ্য শোকরিয়া যে তিনি আমাদেরকে \"$topic\"-এর মতো কল্যাণময় বিষয় নিয়ে চিন্তা করার সুযোগ দিয়েছেন।",
            "বিসমিল্লাহির রাহমানির রাহীম। আসসালামু আলাইকুম ওয়া রাহমাতুল্লাহ। প্রতিটি মুমিনের জীবনে \"$topic\" বিষয়টি জানা ও বাস্তবে আমল করা অত্যন্ত জরুরি।"
        )
        val openingLine = openingHooks[abs(topic.hashCode()) % openingHooks.size]
        addSegment(
            badge = "আবু উবাইদা AI · ${category.labelBn}",
            spoken = openingLine,
            display = openingLine,
            subtitle = "$topic — ${category.labelBn}"
        )

        // 2. Topic-matched Verified Quran Ayah (with natural Bengali Surah-Ayah phrasing, never 'minus')
        if (quran != null) {
            val spokenCitation = quran.spokenCitationBn.ifBlank {
                BengaliVoiceManager.formatIslamicSpeechText(quran.surahNameBn)
            }
            val quranSpeech = "পবিত্র কুরআনের $spokenCitation-এ মহান আল্লাহ রাব্বুল আলামীন অত্যন্ত স্পষ্টভাবে আমাদের উদ্দেশ্যে ইরশাদ করেছেন: \"${quran.bengaliTranslation}\"। এই পবিত্র বাণী \"$topic\" সম্পর্কে আমাদের সামনে সঠিক দিকনির্দেশনা তুলে ধরে।"
            addSegment(
                badge = quran.surahNameBn,
                spoken = quranSpeech,
                display = quran.bengaliTranslation,
                arabic = quran.arabicUthmaniText,
                subtitle = "সূত্র: ${quran.sourceApiBn}"
            )
        }

        // 3. Topic-matched Verified Sahih Hadith (full honorifics)
        if (hadith != null) {
            val narratorFull = BengaliVoiceManager.formatIslamicSpeechText(hadith.narratorBn)
            val hadithBodyFull = BengaliVoiceManager.formatIslamicSpeechText(hadith.bengaliText)
            val hadithSpeech = "আমাদের প্রিয় নবী হযরত মুহাম্মদ সাল্লাল্লাহু আলাইহি ওয়াসাল্লাম বাস্তব জীবনে এই শিক্ষা দেখিয়েছেন। $narratorFull বর্ণনা করেন, রাসূলুল্লাহ সাল্লাল্লাহু আলাইহি ওয়াসাল্লাম বলেছেন: \"$hadithBodyFull\"। ${hadith.collectionBn} গ্রন্থের এই হাদিসটি \"$topic\" বিষয়ে আমাদের পথপ্রদর্শক।"
            addSegment(
                badge = "${hadith.collectionBn} (${hadith.referenceNumber})",
                spoken = hadithSpeech,
                display = hadithBodyFull,
                arabic = hadith.arabicText,
                subtitle = "$narratorFull · ${hadith.gradingNoteBn}"
            )
        }

        // 4. Contextual historical / theological core for this exact topic
        addSegment(
            badge = topic.take(38),
            spoken = bundle.historicalContextBn,
            display = bundle.historicalContextBn,
            subtitle = "কুরআন ও সহীহ সুন্নাহর মৌলিক শিক্ষা"
        )

        // 5. Category & Topic-Specific Rich Paragraphs (scaled cleanly to 1m / 5m / 10m / 20m)
        val deepSegments = buildTopicSpecificDeepSegments(topic, category, durationOption)
        deepSegments.forEachIndexed { idx, segmentPair ->
            addSegment(
                badge = "$topic · অংশ ${toBengaliNum(idx + 1)}",
                spoken = segmentPair.first,
                display = segmentPair.first,
                subtitle = segmentPair.second
            )
        }

        // 6. Topic-personalized Dua & Closing
        val closingLine = "মহান আল্লাহ রাব্বুল আলামীন আমাদের সবাইকে \"$topic\"-এর এই মূল্যবান শিক্ষাগুলো বুঝে আমল করার তাওফীক দান করুন এবং প্রিয় নবী হযরত মুহাম্মদ সাল্লাল্লাহু আলাইহি ওয়াসাল্লামের পবিত্র সুন্নাহর ওপর অটল রাখুন। এই দ্বীনি আলোচনা উপকারী মনে হলে অন্যের কাছে পৌঁছে দিন। আমীন, ইয়া রাব্বাল আলামীন।"
        addSegment(
            badge = "দোয়া ও দাওয়াহ",
            spoken = closingLine,
            display = closingLine,
            subtitle = "জাযাকাল্লাহু খাইরান — আবু উবাইদা AI"
        )

        val script = scriptParts.joinToString("\n\n")
        val subtitles = cues.map { it.subtitle.ifBlank { it.displayBody } }

        val seoTitle = if (isShort) {
            "$topic | ইসলামিক শর্টস #Shorts"
        } else {
            "$topic — কুরআন ও সহীহ হাদিসের আলোকে পূর্ণাঙ্গ বয়ান (${durationOption.labelBn})"
        }
        val englishTitle = "$topic | Authentic Islamic Lecture & Reminder (Bangla)"

        val description = buildString {
            appendLine("বিষয়: $topic")
            appendLine("বিভাগ: ${category.labelBn} · সময়: ${durationOption.labelBn}")
            appendLine()
            if (quran != null) {
                appendLine("কুরআনের সূত্র: ${quran.surahNameBn}")
                appendLine("আরবি: ${quran.arabicUthmaniText}")
                appendLine("অনুবাদ: ${quran.bengaliTranslation}")
                appendLine()
            }
            if (hadith != null) {
                appendLine("হাদিসের সূত্র: ${hadith.collectionBn} (${hadith.referenceNumber}) — ${hadith.gradingNoteBn}")
                if (hadith.arabicText.isNotBlank()) appendLine("আরবি: ${hadith.arabicText}")
                appendLine(BengaliVoiceManager.formatIslamicSpeechText(hadith.bengaliText))
                appendLine()
            }
            appendLine("সতর্কতা: ইসলামিক তথ্যের বিশুদ্ধতা নিশ্চিত করতে নির্ভরযোগ্য আলেম ও মূল গ্রন্থের সাথে মিলিয়ে পড়ার অনুরোধ রইল।")
            appendLine()
            appendLine("#ইসলামিকভিডিও #QuranBangla #HadithBangla #AbuUbaidaAI #BanglaWaz")
        }

        val keywords = listOf(
            topic,
            category.labelBn,
            "বাংলা ইসলামিক বয়ান",
            quran?.surahNameBn ?: "কুরআন ও হাদিস",
            "Bangla Islamic Lecture"
        )
        val tags = listOf(
            topic,
            "ইসলামিক ভিডিও বাংলা",
            category.labelBn,
            "কুরআন তেলাওয়াত ও অর্থ",
            "সহীহ হাদিস বাংলা",
            "আবু উবাইদা AI"
        )
        val hashtags = listOf("#ইসলামিকভিডিও", "#কুরআন", "#সহীহহাদিস", "#BanglaWaz", "#AbuUbaidaAI")
        val thumbText = topic.take(36)

        return VideoProject(
            topic = topic,
            category = category,
            format = format,
            durationOption = durationOption,
            script = script,
            subtitleLines = subtitles,
            narrationCues = cues,
            seoTitle = seoTitle,
            englishTitle = englishTitle,
            seoDescription = description,
            seoKeywords = keywords,
            seoTags = tags,
            hashtags = hashtags,
            thumbnailText = thumbText,
            thumbnailDesignSummary = "হলিউড Full HD ডিপ কসমিক ও গোল্ডেন মসজিদ স্কাইলাইন + ১২-কোনা ইসলামিক ম্যান্ডালা ও ক্যালিগ্রাফি ডিজাইন।",
            thumbnailPrompts = listOf(
                "Cinematic deep royal navy and radiant gold Islamic geometric mandala with mosque silhouette for '$topic', Hollywood HD, 4K",
                "Minimalist dark sapphire background with subtle golden arabesque border and room for Bengali headline '$thumbText'"
            ),
            quranReference = quran,
            hadithReference = hadith,
            providerStatusBn = "বিষয়ভিত্তিক স্বতন্ত্র ইসলামিক সূত্র, মানুষের মতো ওয়াজ কণ্ঠ ও সিঙ্কড স্ক্রিপ্ট প্রস্তুত।"
        )
    }

    /**
     * বিষয় ও বিভাগের ধরন অনুযায়ী প্রতিটি ভিডিওর জন্য আলাদা আলাদা বাস্তবধর্মী বয়ানের অংশ তৈরি করে,
     * যাতে ভিন্ন ভিন্ন বিষয়ে কখনো একই মুখস্থ কথা পুনরাবৃত্তি না হয়।
     */
    private fun buildTopicSpecificDeepSegments(
        topic: String,
        category: IslamicCategory,
        durationOption: VideoDurationOption
    ): List<Pair<String, String>> {
        val targetExtraCount = when (durationOption) {
            VideoDurationOption.SHORT_1M -> 2
            VideoDurationOption.MEDIUM_5M -> 9
            VideoDurationOption.LONG_10M -> 16
            VideoDurationOption.LONG_20M -> 24
        }

        val topicFocusPool: List<Pair<String, String>> = when (category) {
            IslamicCategory.PROPHET_STORIES -> listOf(
                "নবী-রাসূলগণ আলাইহিমুস সালামের জীবন আমাদের শেখায়—সত্যের পথে চলতে গিয়ে যত বাধাই আসুক, আল্লাহর সাহায্য অবশ্যই ধৈর্যশীলদের সাথেই থাকে।" to "নবী-রাসূলগণ আলাইহিমুস সালামের অটল ধৈর্য",
                "\"$topic\"-এর ঘটনার ভেতরে সবচেয়ে বড় শিক্ষা হলো: সংকটের মুহূর্তেও তাওহীদ ও চরিত্রের পবিত্রতা বিসর্জন না দেওয়া।" to "$topic — চরিত্র ও তাওহীদের শিক্ষা",
                "যখন মানুষ ক্ষমতায় বা সচ্ছলতায় পৌঁছায়, তখন প্রতিশোধ না নিয়ে ক্ষমা করে দেওয়া নবীদের আলাইহিমুস সালামের অন্যতম মহৎ গুণ।" to "ক্ষমতা পেয়েও ক্ষমাশীলতার আদর্শ",
                "হযরত মুহাম্মদ সাল্লাল্লাহু আলাইহি ওয়াসাল্লাম মক্কা থেকে মদিনার কঠিন সময়ে পূর্ববর্তী নবীদের আলাইহিমুস সালামের ঘটনা থেকে সান্ত্বনা লাভ করতেন।" to "সিরাত ও পূর্ববর্তী নবীদের সান্ত্বনা",
                "পরিবার ও সন্তানদের সামনে কুরআনের এই সত্য কাহিনীগুলো তুলে ধরলে তাদের অন্তরে ঈমানী দৃঢ়তা ও নৈতিক সাহস তৈরি হয়।" to "নতুন প্রজন্মের জন্য নবী-রাসূলদের আদর্শ"
            )
            IslamicCategory.ISLAMIC_HISTORY -> listOf(
                "ইসলামের প্রাথমিক যুগে সাহাবায়ে কেরাম রাদিআল্লাহু তাআলা আনহুম সংখ্যা ও সম্পদে কম ছিলেন, কিন্তু তাঁদের ঈমান ও ভ্রাতৃত্ব ছিল পর্বতের মতো অটল।" to "সাহাবায়ে কেরাম রাদিআল্লাহু তাআলা আনহুমের ত্যাগ",
                "\"$topic\" অধ্যয়ন করলে স্পষ্ট হয়—মুসলিম উম্মাহ যখন ন্যায়বিচার, আমানতদারিতা ও ইলম চর্চায় এগিয়ে ছিল, তখন বিশ্বজুড়ে শান্তি প্রতিষ্ঠিত হয়েছিল।" to "$topic — ইতিহাস থেকে শিক্ষা",
                "হযরত আবু বকর রাদিআল্লাহু তাআলা আনহু ও হযরত উমর রাদিআল্লাহু তাআলা আনহু রাষ্ট্র পরিচালনায় আল্লাহর ভয় ও সাধারণ মানুষের অধিকারকে সর্বোচ্চ অগ্রাধিকার দিতেন।" to "খোলাফায়ে রাশেদীনের ন্যায়বিচার",
                "মদিনার সনদ বিশ্বের ইতিহাসে প্রথম লিখিত কল্যাণরাষ্ট্রের দলিল, যেখানে সকল নাগরিকের জান-মাল ও ধর্মীয় নিরাপত্তা নিশ্চিত করা হয়েছিল।" to "মদিনা সনদ ও মানবিক সমাজ",
                "অতীতের গৌরব কেবল গল্প করে নয়, বরং সাহাবায়ে কেরাম রাদিআল্লাহু তাআলা আনহুমের কর্মনিষ্ঠা ও তাকওয়া নিজেদের জীবনে ফিরিয়ে আনলেই সাফল্য আসবে।" to "ব্যক্তিজীবনে সোনালি যুগের অনুসরণ"
            )
            IslamicCategory.QURAN_RECITATION, IslamicCategory.SURAH_EXPLANATION -> listOf(
                "কুরআনুল কারীমের প্রতিটি শব্দ আল্লাহর কালাম; \"$topic\" নিয়ে গভীরভাবে তাদাব্বুর বা চিন্তা করলে হৃদয়ের সমস্ত মরিচা দূর হয়ে যায়।" to "$topic — কুরআনের তাদাব্বুর ও মর্ম",
                "আমরা অনেকেই কুরআন শুধু তাড়াহুড়ো করে পড়ে যাই, অথচ প্রতিদিন অল্প কয়েকটি আয়াতের বাংলা অর্থ ও তাফসীর বুঝে পড়লে জীবন আমূল বদলে যায়।" to "অর্থ বুঝে কুরআন অধ্যয়নের গুরুত্ব",
                "হযরত উসমান রাদিআল্লাহু তাআলা আনহু ও অন্যান্য সাহাবিগণ রাতের নির্জনতায় তেলাওয়াত করে কেঁদে বুক ভাসাতেন।" to "সাহাবায়ে কেরামের কুরআনপ্রেম",
                "\"$topic\" আমাদের স্মরণ করিয়ে দেয় যে দুনিয়ার প্রতিটি সমস্যার মূল সমাধান মহান আল্লাহর কিতাবের ভেতরেই সংরক্ষিত রয়েছে।" to "সমস্যার সমাধানে আল-কুরআন",
                "ঘরে নিয়মিত কুরআন তেলাওয়াত চালু থাকলে সেখানে রহমত ও প্রশান্তি নেমে আসে এবং পরিবারের সদস্যদের সম্পর্ক সুন্দর হয়।" to "কুরআনের আলোয় আলোকিত পরিবার"
            )
            IslamicCategory.NAMES_OF_ALLAH -> listOf(
                "আল্লাহ তাআলার প্রতিটি গুণবাচক নাম আমাদের রবের সাথে সরাসরি হৃদয়ের সম্পর্ক তৈরি করে; \"$topic\"-এর ভেতর রয়েছে অন্তরের গভীর প্রশান্তি।" to "$topic — আসমাউল হুসনার রহস্য",
                "তিনি আর-রাহমান ও আর-রাহীম; বান্দা যখন ব্যর্থতায় ভেঙে পড়ে, তখন তাঁর এই দয়াময় নাম স্মরণ করলেই নতুন আশা জেগে ওঠে।" to "আর-রাহমান ও আর-রাহীমের অসীম দয়া",
                "তিনি আল-রাযযাক ও আল-মুগনী; হালাল উপার্জনের পাশাপাশি কেবল আল্লাহর কাছেই রিজিকের জন্য হাত পাতাই প্রকৃত তাওহীদ।" to "আল-রাযযাক — রিজিকের একচ্ছত্র মালিক",
                "দোয়ার সময় আল্লাহর পবিত্র নামগুলো ধরে ডাকলে দোয়া কবুলের সম্ভাবনা বেড়ে যায় এবং মনে বিনয় সৃষ্টি হয়।" to "আসমাউল হুসনার মাধ্যমে দোয়া",
                "আল্লাহর নামগুলোর অর্থ কেবল মুখস্থ করলেই নয়, বরং দয়া, ক্ষমা ও ন্যায়ের মতো গুণগুলো আমাদের আচরণেও ফুটিয়ে তুলতে হবে।" to "ব্যক্তিজীবনে আল্লাহর নামের প্রতিফলন"
            )
            IslamicCategory.HADITH_EDUCATION -> listOf(
                "হযরত মুহাম্মদ সাল্লাল্লাহু আলাইহি ওয়াসাল্লামের প্রতিটি হাদিস ওহীর আলোকে উচ্চারিত; \"$topic\" বিষয়ক এই হাদিস আমাদের জীবনের দিশারী।" to "$topic — সহীহ সুন্নাহর দিকনির্দেশনা",
                "ইসলামে শুধু আমলের পরিমাণ নয়, বরং আমলের পেছনে নিয়তের বিশুদ্ধতা ও সুন্নাহর অনুসরণই সবচেয়ে বেশি মূল্যবান।" to "নিয়ত ও সুন্নাহর সমন্বয়",
                "সাহাবায়ে কেরাম রাদিআল্লাহু তাআলা আনহুম একটি হাদিস শোনার সাথে সাথে প্রশ্ন না করেই আমলে বাস্তবায়ন করতেন; আজ আমাদেরও সেই আন্তরিকতা প্রয়োজন।" to "সাহাবিদের দ্রুত আমল করার উদাহরণ",
                "হাদিসের বাণী শুধু বইয়ের পাতায় নয়, আমাদের ব্যবসা-বাণিজ্য, পারিবারিক আচরণ ও প্রতিবেশীর সাথে লেনদেনে প্রতিফলিত হওয়া উচিত।" to "বাস্তব লেনদেনে হাদিসের প্রয়োগ",
                "নবীজির সাল্লাল্লাহু আলাইহি ওয়াসাল্লামের সুন্নাহ আঁকড়ে ধরা ফিতনার যুগে ঈমান রক্ষার সবচেয়ে শক্তিশালী ঢাল।" to "ফিতনার যুগে সুন্নাহর আশ্রয়"
            )
            else -> listOf(
                "\"$topic\" নিয়ে ভাবলে আমরা বুঝতে পারি—মানুষের আসল সফলতা দুনিয়ার ক্ষণস্থায়ী চাকচিক্যে নয়, বরং আল্লাহর সন্তুষ্টি অর্জনেই নিহিত।" to "$topic — সফলতার প্রকৃত মাপকাঠি",
                "দৈনন্দিন ব্যস্ততার মাঝে পাঁচ ওয়াক্ত নামাজকে জীবনের কেন্দ্রবিন্দু বানালে সময়, রিজিক ও মনে অকল্পনীয় বরকত নেমে আসে।" to "সালাত ও জীবনের শৃঙ্খলা",
                "হযরত মুহাম্মদ সাল্লাল্লাহু আলাইহি ওয়াসাল্লাম আমাদের শিখিয়েছেন—দুর্বলের প্রতি দয়া, সত্য কথা বলা এবং পিতামাতার খিদমতই জান্নাতের নিকটবর্তী করে।" to "মানবিকতা ও পিতামাতার খিদমত",
                "আমাদের কোনো গুনাহ বা ভুল হয়ে গেলে হতাশ না হয়ে সাথে সাথে তাওবা করা উচিত; কারণ আল্লাহ তাআলার রহমত সবকিছুর চেয়ে বিশাল।" to "হতাশা ছেড়ে তাওবার পথে ফেরা",
                "হারাম উপার্জন, গীবত ও হিংসা বর্জন না করলে ইবাদতের স্বাদ পাওয়া যায় না; তাই \"$topic\" আমাদের আত্মসমালোচনার সুযোগ করে দেয়।" to "হালাল উপার্জন ও অন্তরের পবিত্রতা"
            )
        }

        // Dynamic rotating reflection segments explicitly anchored to `topic` so every topic produces fresh combinations
        val universalContextualPool = listOf(
            "আজ আমরা নিজেরাই নিজেকে একটু প্রশ্ন করি—\"$topic\" সম্পর্কে জানার পর আজকের দিন থেকেই আমার জীবনে কী একটি ভালো পরিবর্তন আনতে পারি? একটি ছোট সৎ সংকল্পই আমাদের আখিরাতের পাথেয় বদলে দিতে পারে।" to "$topic — আত্মসমালোচনা ও সংকল্প",
            "আমাদের উপার্জনে হালাল বজায় রাখা, কারও হক নষ্ট না করা এবং প্রতিবেশী ও আত্মীয়দের সাথে সুসম্পর্ক রাখা \"$topic\"-এর বাস্তব রূপ।" to "লেনদেন ও সামাজিক দায়িত্ববোধ",
            "সকাল ও সন্ধ্যার যিকির, বেশি বেশি দুরুদ শরীফ পাঠ এবং ইস্তিগফার মানুষের দুশ্চিন্তা দূর করে এবং হৃদয়ে দৃঢ় প্রশান্তি এনে দেয়।" to "যিকির, দুরুদ ও অন্তরের প্রশান্তি",
            "কবর ও আখিরাতের চিরস্থায়ী জীবনের কথা মনে রাখলে দুনিয়ার অহংকার, রাগ ও লোভ সহজেই নিয়ন্ত্রণে চলে আসে।" to "আখিরাতমুখী জীবনের প্রস্তুতি",
            "সৎ বন্ধুর সান্নিধ্য, দ্বীনি মজলিস এবং নির্ভরযোগ্য আলেমদের পরামর্শ আমাদের \"$topic\"-এর পথে অটল থাকতে সাহায্য করে।" to "নেক সান্নিধ্য ও সঠিক দিকনির্দেশনা",
            "পরিবারের সবাইকে নিয়ে প্রতিদিন অন্তত দশ মিনিট কুরআন ও হাদিসের কথা আলোচনা করলে ঘরে শয়তানের প্রভাব কমে এবং শান্তি ফিরে আসে।" to "পরিবারে দ্বীনি পরিবেশ গঠন",
            "অর্থের সদকার পাশাপাশি একটি সুন্দর হাসি, সত্য পরামর্শ এবং বিপদগ্রস্ত মানুষের পাশে দাঁড়ানোও মহান আল্লাহর কাছে অতি প্রিয় ইবাদত।" to "বিনা খরচের উত্তম সদকা",
            "রাতে ঘুমানোর আগে সারাদিনের কাজগুলোর হিসাব নেওয়া—কোন কাজে আল্লাহ খুশি হলেন আর কোথায় ভুল হলো—এটিই প্রকৃত বুদ্ধিমান মুমিনের অভ্যাস।" to "রাতে শোয়ার আগে আত্মহিসাব",
            "দুনিয়ার পরীক্ষা যত দীর্ঘই মনে হোক না কেন, আল্লাহর প্রতি অটল বিশ্বাস ও ধৈর্য রাখলে শেষে নিশ্চয়ই স্বস্তি ও সম্মান অপেক্ষা করে।" to "পরীক্ষায় ধৈর্য ও আল্লাহর সাহায্য",
            "দক্ষতা, সময়ানুবর্তিতা ও আমানতদারিতার সাথে নিজের দায়িত্ব পালন করা ইসলামের দৃষ্টিতে অত্যন্ত মর্যাদাপূর্ণ আমল।" to "কর্মে আমানতদারিতা ও নিষ্ঠা"
        )

        val combined = mutableListOf<Pair<String, String>>()
        val offset = abs(topic.hashCode())
        // Interleave topic-focus segments with rotated contextual segments
        val maxLoop = targetExtraCount.coerceAtLeast(1)
        for (i in 0 until maxLoop) {
            val item = if (i < topicFocusPool.size) {
                topicFocusPool[(i + offset) % topicFocusPool.size]
            } else {
                universalContextualPool[(i - topicFocusPool.size + offset) % universalContextualPool.size]
            }
            combined.add(item)
        }
        return combined
    }

    /**
     * AI থেকে পাওয়া স্ক্রিপ্টের জন্যও প্রতিটি বাক্যকে NarrationCue-তে রূপান্তর করে, যাতে ভয়েস ও স্লাইড ১০০% সিঙ্ক থাকে।
     */
    private fun buildOrderedNarrationCuesFromProject(project: VideoProject): List<NarrationCue> {
        val cues = mutableListOf<NarrationCue>()
        val cleanScript = BengaliVoiceManager.cleanNarrationForSpeech(project.script)
        val rawParagraphs = cleanScript
            .split(Regex("\\n{2,}"))
            .map { it.trim() }
            .filter { it.length >= 6 }

        val expandedChunks = mutableListOf<String>()
        if (rawParagraphs.size >= 4) {
            rawParagraphs.forEach { p ->
                if (p.length <= 360) {
                    expandedChunks.add(p)
                } else {
                    val sents = p.split(Regex("[।!?]+")).map { it.trim() }.filter { it.length >= 4 }
                    sents.chunked(2).forEach { grp -> expandedChunks.add(grp.joinToString("। ") + "।") }
                }
            }
        } else {
            val sents = cleanScript.split(Regex("[।!?\\n]+")).map { it.trim() }.filter { it.length >= 6 }
            sents.chunked(2).forEach { grp -> expandedChunks.add(grp.joinToString("। ") + "।") }
        }

        val opener = expandedChunks.firstOrNull() ?: "বিসমিল্লাহির রাহমানির রাহীম। আজ আমরা ${project.topic} নিয়ে আলোচনা করব।"
        cues.add(
            NarrationCue(
                badge = "আবু উবাইদা AI · ${project.category.labelBn}",
                spokenText = opener,
                displayBody = opener,
                subtitle = project.seoTitle.ifBlank { project.topic }
            )
        )

        var cursor = 1
        project.quranReference?.let { q ->
            val citation = q.spokenCitationBn.ifBlank { BengaliVoiceManager.formatIslamicSpeechText(q.surahNameBn) }
            val spokenQ = "পবিত্র কুরআনের $citation-এ আল্লাহ তাআলা বলেছেন: \"${q.bengaliTranslation}\"।"
            cues.add(
                NarrationCue(
                    badge = q.surahNameBn,
                    spokenText = spokenQ,
                    displayBody = q.bengaliTranslation,
                    arabicText = q.arabicUthmaniText,
                    subtitle = "সূত্র: ${q.sourceApiBn}"
                )
            )
        }

        project.hadithReference?.let { h ->
            val narratorFull = BengaliVoiceManager.formatIslamicSpeechText(h.narratorBn)
            val bodyFull = BengaliVoiceManager.formatIslamicSpeechText(h.bengaliText)
            val spokenH = "$narratorFull বর্ণনা করেন, রাসূলুল্লাহ সাল্লাল্লাহু আলাইহি ওয়াসাল্লাম বলেছেন: \"$bodyFull\"।"
            cues.add(
                NarrationCue(
                    badge = "${h.collectionBn} (${h.referenceNumber})",
                    spokenText = spokenH,
                    displayBody = bodyFull,
                    arabicText = h.arabicText,
                    subtitle = "$narratorFull · ${h.gradingNoteBn}"
                )
            )
        }

        val subs = project.subtitleLines
        val maxBodyCues = 30
        val bodyList = if (cursor < expandedChunks.size) expandedChunks.subList(cursor, expandedChunks.size) else emptyList()
        bodyList.take(maxBodyCues).forEachIndexed { idx, bodyText ->
            cues.add(
                NarrationCue(
                    badge = project.topic.ifBlank { project.category.labelBn }.take(40),
                    spokenText = bodyText,
                    displayBody = bodyText,
                    subtitle = subs.getOrElse(idx % subs.size.coerceAtLeast(1)) { bodyText.take(90) }
                )
            )
        }

        return cues
    }

    private fun toBengaliNum(number: Int): String {
        val bnDigits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
        return number.toString().map { ch ->
            if (ch in '0'..'9') bnDigits[ch - '0'] else ch
        }.joinToString("")
    }

    fun isMp4ProviderConnected(): Boolean = videoProvider.isConnected

    suspend fun exportMp4IfConnected(project: VideoProject): Result<Uri> =
        exportMp4WithDetails(project).map { it.first }

    suspend fun exportMp4WithDetails(project: VideoProject): Result<Pair<Uri, String>> = withContext(Dispatchers.IO) {
        if (!videoProvider.isConnected) {
            return@withContext videoProvider.generateMp4(project.topic, File(context.cacheDir, "placeholder.mp4"))
                .map { it to "cache" }
        }
        val settings = securePrefsManager.loadSettings()
        val outDir = File(context.filesDir, "abu_ubaida_videos").apply { mkdirs() }
        val durationTag = "${project.durationOption.durationSeconds / 60}m"
        val file = File(outDir, "AbuUbaida_${durationTag}_${System.currentTimeMillis()}.mp4")
        if (videoProvider is LocalMp4VideoProvider) {
            videoProvider.renderProjectSlidesMp4WithPath(
                project = project,
                internalOutputFile = file,
                motionGraphicsEnabled = settings.motionGraphicsEnabled
            )
        } else {
            videoProvider.generateMp4(
                prompt = project.thumbnailPrompts.firstOrNull() ?: project.topic,
                outputFile = file
            ).map { it to file.absolutePath }
        }
    }

    suspend fun exportScriptTextPackage(project: VideoProject): Result<File> = withContext(Dispatchers.IO) {
        return@withContext try {
            val outDir = File(context.filesDir, "abu_ubaida_scripts").apply { mkdirs() }
            val file = File(outDir, "script_${System.currentTimeMillis()}.txt")
            val content = buildString {
                appendLine("=== আবু উবাইদা AI ইসলামিক ভিডিও স্টুডিও প্যাকেজ ===")
                appendLine("বিষয়: ${project.topic} | বিভাগ: ${project.category.labelBn} | সময়: ${project.durationOption.labelBn}")
                appendLine("ধর্মীয় সূত্র যাচাই: ${project.accuracyReview.sourceCitationBn}")
                appendLine()
                appendLine("বাংলা SEO শিরোনাম: ${project.seoTitle}")
                appendLine("English Title: ${project.englishTitle}")
                appendLine("SEO বর্ণনা:\n${project.seoDescription}")
                appendLine("ট্যাগসমূহ: ${project.seoTags.joinToString(", ")}")
                appendLine("হ্যাশট্যাগ: ${project.hashtags.joinToString(" ")}")
                appendLine()
                appendLine("--- বাংলা চিত্রনাট্য (Script) ---")
                appendLine(project.script)
            }
            file.writeText(content)
            Result.success(file)
        } catch (e: Exception) {
            Result.failure(IllegalStateException("স্ক্রিপ্ট সংরক্ষণ করা যায়নি: ${e.localizedMessage}"))
        }
    }

    fun wipeGeneratedLocalFiles() {
        listOf("abu_ubaida_videos", "abu_ubaida_scripts", "abu_ubaida_thumbnails", "abu_ubaida_voiceovers")
            .forEach { folder ->
                File(context.filesDir, folder).deleteRecursively()
            }
    }
}
