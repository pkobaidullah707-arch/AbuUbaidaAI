package com.abuubaida.ai.publishing

import com.abuubaida.ai.data.model.PublishingRecommendation
import com.abuubaida.ai.data.model.TrendResearchReport
import com.abuubaida.ai.data.model.VideoFormat
import com.abuubaida.ai.data.model.VideoProject
import com.abuubaida.ai.trends.TrendResearchRepository
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * বর্তমান ট্রেন্ড, অডিয়েন্সের সক্রিয় সময়, পূর্ববর্তী চ্যানেল পারফরম্যান্স,
 * কন্টেন্ট যাচাইকরণ স্কোর ও ভিডিও ফরম্যাট বিচার করে সেরা প্রকাশের সময় নির্ধারণ করে।
 */
class SmartPublishingManager(
    private val trendResearchRepository: TrendResearchRepository
) {
    fun evaluateBestPublishingPlan(
        project: VideoProject?,
        trendReport: TrendResearchReport?,
        forceTomorrow: Boolean = false
    ): PublishingRecommendation {
        val preferredHour = trendReport?.channelSummary?.bestHistoricalHour24
        val baseSlot = if (forceTomorrow) {
            computeTomorrowPrimeSlot(preferredHour)
        } else {
            trendResearchRepository.computeBestIslamicPublishSlot(preferredHour)
        }

        val targetMillis = baseSlot.first
        val targetLabel = baseSlot.second
        val isoUtc = formatIso8601Utc(targetMillis)
        val unixSec = targetMillis / 1000L

        val format = project?.format ?: trendReport?.recommendedFormat ?: VideoFormat.SHORTS_9_16
        var score = 70
        if (project?.accuracyReview?.passed == true) score += 15
        if (project?.quranReference?.verified == true || project?.hadithReference?.verifiedAuthentic == true) score += 10
        if (trendReport != null && trendReport.trends.isNotEmpty()) score += 5
        score = score.coerceAtMost(100)

        val reason = buildString {
            append("মান স্কোর: ${score}/১০০। ")
            if (format == VideoFormat.SHORTS_9_16) {
                append("সংক্ষিপ্ত ভার্টিক্যাল Shorts/Reels ফরম্যাট দ্রুত রিচ পেতে সহায়ক। ")
            } else {
                append("বিস্তারিত লং-ফর্ম (১৬:৯) শিক্ষামূলক দর্শক ধরে রাখতে উপযোগী। ")
            }
            if (trendReport?.channelSummary != null) {
                append("আপনার চ্যানেলের পূর্ববর্তী পারফরম্যান্স ও প্রাইম ইসলামিক সময় অনুযায়ী নির্ধারিত।")
            } else {
                append("বাংলাদেশের ইসলামিক দর্শকদের সর্বাধিক সক্রিয় সময় অনুযায়ী নির্বাচিত।")
            }
        }

        return PublishingRecommendation(
            targetTimeMillis = targetMillis,
            targetTimeLabelBn = targetLabel,
            targetIsoUtc = isoUtc,
            targetUnixSeconds = unixSec,
            recommendedFormat = format,
            qualityScore = score,
            reasonBn = reason
        )
    }

    private fun computeTomorrowPrimeSlot(preferredHour24: Int?): Pair<Long, String> {
        val cal = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, 1)
            set(Calendar.HOUR_OF_DAY, preferredHour24 ?: 20)
            set(Calendar.MINUTE, 30)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        val period = when (hour) {
            in 4..11 -> "সকাল"
            in 12..15 -> "দুপুর"
            in 16..18 -> "বিকাল"
            else -> "রাত"
        }
        val hour12 = if (hour == 0) 12 else if (hour > 12) hour - 12 else hour
        return cal.timeInMillis to "আগামীকাল $period ${hour12}:৩০ (নির্ধারিত ইসলামিক প্রাইম সময়)"
    }

    fun formatIso8601Utc(epochMillis: Long): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")
        return fmt.format(Date(epochMillis))
    }
}
