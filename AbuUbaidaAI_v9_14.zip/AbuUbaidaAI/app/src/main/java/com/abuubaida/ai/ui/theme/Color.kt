package com.abuubaida.ai.ui.theme

import androidx.compose.ui.graphics.Color

val DeepNavyBg = Color(0xFF060B18)
val NavySurface = Color(0xFF0B132B)
val NavyCard = Color(0xFF121E3D)
val NavyBorder = Color(0xFF1E325C)

val RoyalBlue = Color(0xFF2563EB)
val ElectricBlue = Color(0xFF38BDF8)
val DeepBlueGlow = Color(0xFF1D4ED8)

val ImperialGold = Color(0xFFD4AF37)
val BrightGold = Color(0xFFFCD34D)
val AmberGold = Color(0xFFF59E0B)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)

val EmeraldOk = Color(0xFF10B981)
val CrimsonWarn = Color(0xFFEF4444)
