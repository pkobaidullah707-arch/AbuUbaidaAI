package com.abuubaida.ai.voice

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.abuubaida.ai.data.model.AssistantSettings
import com.abuubaida.ai.data.model.IslamicVoicePreset
import com.abuubaida.ai.data.model.NarrationCue
import com.abuubaida.ai.data.model.TtsVoiceOption
import com.abuubaida.ai.data.model.VoiceState
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.min
import kotlin.math.tanh

class BengaliVoiceManager(private val context: Context) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val voiceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val neuralTtsClient = NeuralHumanTtsClient()

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var liveNeuralPlayer: MediaPlayer? = null
    private var liveNeuralJob: Job? = null
    private var isTtsReady = false
    private var speechFinishedCallback: (() -> Unit)? = null
    private var activeFinalUtteranceId: String? = null
    private val pendingSynthesis = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()

    private var activeSettings: AssistantSettings = AssistantSettings()
    private val rawVoicesMap = ConcurrentHashMap<String, Voice>()
    private var rankedMaleVoices: List<Voice> = emptyList()
    private var deviceHasOnlyFemaleBnVoice: Boolean = false

    private val _voiceState = MutableStateFlow<VoiceState>(VoiceState.Idle)
    val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

    private val _rmsLevel = MutableStateFlow(0f)
    val rmsLevel: StateFlow<Float> = _rmsLevel.asStateFlow()

    private val _partialTranscript = MutableStateFlow("")
    val partialTranscript: StateFlow<String> = _partialTranscript.asStateFlow()

    private val _ttsSupportedBn = MutableStateFlow(true)
    val ttsSupportedBn: StateFlow<Boolean> = _ttsSupportedBn.asStateFlow()

    private val _availableVoices = MutableStateFlow<List<TtsVoiceOption>>(emptyList())
    val availableVoices: StateFlow<List<TtsVoiceOption>> = _availableVoices.asStateFlow()

    init {
        initTextToSpeech()
    }

    private fun initTextToSpeech() {
        try {
            textToSpeech = TextToSpeech(context.applicationContext) { status ->
                try {
                    if (status == TextToSpeech.SUCCESS) {
                        val bdLocale = Locale("bn", "BD")
                        val result = textToSpeech?.setLanguage(bdLocale)
                        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                            val fallbackResult = textToSpeech?.setLanguage(Locale("bn"))
                            _ttsSupportedBn.value =
                                fallbackResult != TextToSpeech.LANG_MISSING_DATA &&
                                fallbackResult != TextToSpeech.LANG_NOT_SUPPORTED
                        } else {
                            _ttsSupportedBn.value = true
                        }

                        refreshAvailableVoicesLocked()
                        applyVoiceSettingsInternal(activeSettings)

                        textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                            override fun onStart(utteranceId: String?) {}
                            override fun onDone(utteranceId: String?) {
                                val syn = utteranceId?.let { pendingSynthesis.remove(it) }
                                if (syn != null) {
                                    syn.complete(true)
                                    return
                                }
                                if (utteranceId == activeFinalUtteranceId || activeFinalUtteranceId == null) {
                                    mainHandler.post {
                                        activeFinalUtteranceId = null
                                        _voiceState.value = VoiceState.Idle
                                        val cb = speechFinishedCallback
                                        speechFinishedCallback = null
                                        cb?.invoke()
                                    }
                                }
                            }

                            @Deprecated("Deprecated in Java")
                            override fun onError(utteranceId: String?) {
                                val syn = utteranceId?.let { pendingSynthesis.remove(it) }
                                if (syn != null) {
                                    syn.complete(false)
                                    return
                                }
                                if (utteranceId == activeFinalUtteranceId || activeFinalUtteranceId == null) {
                                    mainHandler.post {
                                        activeFinalUtteranceId = null
                                        _voiceState.value = VoiceState.Idle
                                        speechFinishedCallback = null
                                    }
                                }
                            }

                            override fun onError(utteranceId: String?, errorCode: Int) {
                                val syn = utteranceId?.let { pendingSynthesis.remove(it) }
                                if (syn != null) {
                                    syn.complete(false)
                                    return
                                }
                                if (utteranceId == activeFinalUtteranceId || activeFinalUtteranceId == null) {
                                    mainHandler.post {
                                        activeFinalUtteranceId = null
                                        _voiceState.value = VoiceState.Idle
                                        speechFinishedCallback = null
                                    }
                                }
                            }
                        })
                        isTtsReady = true
                    } else {
                        isTtsReady = false
                        _ttsSupportedBn.value = false
                    }
                } catch (_: Throwable) {
                    isTtsReady = false
                    _ttsSupportedBn.value = false
                }
            }
        } catch (_: Throwable) {
            isTtsReady = false
            _ttsSupportedBn.value = false
        }
    }

    private fun isLikelyFemaleVoice(voice: Voice): Boolean {
        val tokens = voice.name.lowercase(Locale.US)
            .split('-', '_', '.', ' ', '#')
            .filter { it.isNotBlank() }
            .toSet()
        if (tokens.any { it in setOf("female", "woman", "girl", "bnf", "ban", "bng", "sfg", "f") }) {
            return true
        }
        val featuresStr = runCatching { voice.features?.joinToString(" ")?.lowercase(Locale.US) }.getOrNull().orEmpty()
        return featuresStr.contains("female")
    }

    private fun isExplicitMaleVoice(voice: Voice): Boolean {
        val tokens = voice.name.lowercase(Locale.US)
            .split('-', '_', '.', ' ', '#')
            .filter { it.isNotBlank() }
            .toSet()
        if (tokens.any { it in setOf("bnm", "bam", "bgm", "male", "man", "m") }) {
            return true
        }
        val featuresStr = runCatching { voice.features?.joinToString(" ")?.lowercase(Locale.US) }.getOrNull().orEmpty()
        return featuresStr.contains("male") && !featuresStr.contains("female")
    }

    private fun refreshAvailableVoicesLocked() {
        try {
            val allVoices = textToSpeech?.voices ?: return
            rawVoicesMap.clear()

            val allBnVoices = allVoices.filter { v ->
                val lang = v.locale?.language?.lowercase(Locale.US).orEmpty()
                lang == "bn" ||
                    v.name.contains("bn-", ignoreCase = true) ||
                    v.name.contains("bn_", ignoreCase = true) ||
                    v.name.contains("bengali", ignoreCase = true)
            }

            val maleOnly = allBnVoices
                .filterNot { isLikelyFemaleVoice(it) }
                .sortedWith(
                    compareByDescending<Voice> { isExplicitMaleVoice(it) }
                        .thenByDescending { it.quality >= Voice.QUALITY_HIGH }
                        .thenByDescending { it.isNetworkConnectionRequired }
                        .thenByDescending { it.locale?.country.equals("BD", ignoreCase = true) }
                        .thenBy { it.name }
                )

            rankedMaleVoices = maleOnly
            deviceHasOnlyFemaleBnVoice = allBnVoices.isNotEmpty() && maleOnly.isEmpty()

            val options = maleOnly.mapIndexed { idx, voice ->
                rawVoicesMap[voice.name] = voice
                val countryLabel = when {
                    voice.locale?.country.equals("BD", ignoreCase = true) -> "বাংলাদেশি পুরুষ কণ্ঠ"
                    voice.locale?.country.equals("IN", ignoreCase = true) -> "বাংলা পুরুষ কণ্ঠ"
                    else -> "ইসলামিক পুরুষ কণ্ঠ"
                }
                val qualityLabel = if (voice.isNetworkConnectionRequired || voice.quality >= Voice.QUALITY_HIGH) {
                    "HD স্বাভাবিক"
                } else {
                    "অফলাইন"
                }
                val codeSuffix = voice.name.substringAfterLast("-").take(8)
                TtsVoiceOption(
                    name = voice.name,
                    labelBn = "$countryLabel ${idx + 1} ($qualityLabel · $codeSuffix)",
                    localeTag = voice.locale?.toLanguageTag().orEmpty()
                )
            }
            _availableVoices.value = options
        } catch (_: Throwable) {
        }
    }

    fun applyVoiceSettings(settings: AssistantSettings) {
        activeSettings = settings
        mainHandler.post {
            applyVoiceSettingsInternal(settings)
        }
    }

    private fun applyVoiceSettingsInternal(settings: AssistantSettings) {
        val tts = textToSpeech ?: return
        try {
            if (rankedMaleVoices.isEmpty() && rawVoicesMap.isEmpty()) {
                refreshAvailableVoicesLocked()
            }

            var chosenVoice: Voice? = null
            if (settings.selectedTtsVoiceName.isNotBlank()) {
                val explicit = rawVoicesMap[settings.selectedTtsVoiceName]
                    ?: tts.voices?.firstOrNull { it.name == settings.selectedTtsVoiceName }
                if (explicit != null && !isLikelyFemaleVoice(explicit)) {
                    chosenVoice = explicit
                }
            }

            if (chosenVoice == null && rankedMaleVoices.isNotEmpty()) {
                val slotIdx = settings.voicePreset.voiceSlot % rankedMaleVoices.size
                chosenVoice = rankedMaleVoices[slotIdx]
            }

            if (chosenVoice != null) {
                tts.voice = chosenVoice
            }

            val basePitch = settings.voicePitch.coerceIn(0.68f, 1.08f)
            val finalPitch = if (chosenVoice == null && deviceHasOnlyFemaleBnVoice) {
                (basePitch * 0.77f).coerceIn(0.55f, 0.82f)
            } else {
                basePitch
            }
            val finalRate = settings.voiceRate.coerceIn(0.72f, 1.15f)
            tts.setPitch(finalPitch)
            tts.setSpeechRate(finalRate)
        } catch (_: Throwable) {
        }
    }

    fun openInstallTtsVoiceData(): Result<String> {
        return try {
            val intent = Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success("ফোনের TTS ভয়েস প্যাক ইনস্টলার খোলা হয়েছে — এখান থেকে পুরুষ বাংলা (bn-BD / HD) কণ্ঠ ডাউনলোড করতে পারবেন।")
        } catch (_: Exception) {
            Result.failure(IllegalStateException("এই ডিভাইসে সরাসরি ভয়েস ডাউনলোড পর্দা খোলা যায়নি; ফোনের Settings -> Language -> Text-to-Speech থেকে Google ভয়েস আপডেট করুন।"))
        }
    }

    fun isSpeechRecognitionAvailable(): Boolean {
        return SpeechRecognizer.isRecognitionAvailable(context)
    }

    fun buildBengaliSpeechIntent(
        languageTag: String = "bn-BD",
        promptBn: String = "আবু উবাইদা AI-কে বলুন..."
    ): Intent {
        val cleanLang = languageTag.ifBlank { "bn-BD" }
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, cleanLang)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, cleanLang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PROMPT, promptBn)
        }
    }

    fun startListening(
        languageTag: String = "bn-BD",
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        mainHandler.post {
            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                val msg = "সরাসরি মাইক্রোফোন সেবা পাওয়া যায়নি—নিচের 'গুগল ভয়েস ডায়ালগ' বাটনটি ব্যবহার করুন।"
                _voiceState.value = VoiceState.Error(msg)
                onError(msg)
                return@post
            }

            stopSpeaking()
            try {
                speechRecognizer?.cancel()
                speechRecognizer?.destroy()
            } catch (_: Exception) {
            }
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context.applicationContext).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _partialTranscript.value = ""
                        _voiceState.value = VoiceState.Listening
                    }

                    override fun onBeginningOfSpeech() {}

                    override fun onRmsChanged(rmsdB: Float) {
                        val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                        _rmsLevel.value = normalized
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        _rmsLevel.value = 0f
                        _voiceState.value = VoiceState.Processing
                    }

                    override fun onError(error: Int) {
                        _rmsLevel.value = 0f
                        val message = when (error) {
                            SpeechRecognizer.ERROR_AUDIO -> "অডিও রেকর্ডিংয়ে সমস্যা হয়েছে।"
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "মাইক্রোফোন অনুমতি দেওয়া হয়নি।"
                            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                                "ভয়েস চিনতে ইন্টারনেট সংযোগ প্রয়োজন।"
                            SpeechRecognizer.ERROR_NO_MATCH -> "আপনার কথা স্পষ্ট বোঝা যায়নি। আবার বলুন বা 'গুগল ভয়েস' বাটন চাপুন।"
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "কোনো কথা শোনা যায়নি।"
                            else -> "ভয়েস রিকগনিশনে সমস্যা হয়েছে—'গুগল ভয়েস ডায়ালগ' ব্যবহার করে দেখুন।"
                        }
                        _voiceState.value = VoiceState.Error(message)
                        onError(message)
                    }

                    override fun onResults(results: Bundle?) {
                        _rmsLevel.value = 0f
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull()?.trim().orEmpty()
                        if (text.isNotBlank()) {
                            _partialTranscript.value = text
                            onResult(text)
                        } else {
                            val msg = "কোনো বাংলা কথা শনাক্ত করা যায়নি।"
                            _voiceState.value = VoiceState.Error(msg)
                            onError(msg)
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val partial = partialResults
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            .orEmpty()
                        if (partial.isNotBlank()) {
                            _partialTranscript.value = partial
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }

            speechRecognizer?.startListening(buildBengaliSpeechIntent(languageTag = languageTag))
        }
    }

    fun stopListening() {
        mainHandler.post {
            speechRecognizer?.stopListening()
            _rmsLevel.value = 0f
            if (_voiceState.value is VoiceState.Listening) {
                _voiceState.value = VoiceState.Idle
            }
        }
    }

    /**
     * প্রতিটি NarrationCue-কে আলাদা আলাদা মানুষের মতো নিউরাল ভয়েসে (অথবা অফলাইন পুরুষ TTS-এ)
     * ২৪ kHz মনো PCM-এ রূপান্তর করে মিলিসেকেন্ড নিখুঁত startUs ও durationUs হিসাব করে দেয়,
     * যাতে ভিডিও স্লাইডের লেখা কথার সাথে ভগ্নাংশ সেকেন্ডেও ১০০% মিলে থাকে!
     */
    suspend fun synthesizeTimedCuesToWav(
        cues: List<NarrationCue>,
        outputWavFile: File
    ): Pair<File, List<NarrationCue>>? = withContext(Dispatchers.IO) {
        if (cues.isEmpty()) return@withContext null

        outputWavFile.parentFile?.mkdirs()
        if (outputWavFile.exists()) outputWavFile.delete()

        val settings = activeSettings
        val preset = settings.voicePreset
        val pauseMs = preset.sentencePauseMs.coerceIn(240L, 580L)
        val targetRate = NeuralHumanTtsClient.TARGET_SAMPLE_RATE
        val pauseSamples = ((targetRate * pauseMs) / 1000L).toInt().coerceAtLeast(1)
        val pausePcm = ByteArray(pauseSamples * 2)

        val delayRingSamples = when (preset) {
            IslamicVoicePreset.MAULANA_UBAIDA -> (targetRate * 0.022f).toInt().coerceAtLeast(1)
            IslamicVoicePreset.QARI_ABDULLAH -> (targetRate * 0.036f).toInt().coerceAtLeast(1)
            IslamicVoicePreset.HAFIZ_RAYHAN -> 1
        }
        val reverbMix = when (preset) {
            IslamicVoicePreset.MAULANA_UBAIDA -> 0.09f
            IslamicVoicePreset.QARI_ABDULLAH -> 0.16f
            IslamicVoicePreset.HAFIZ_RAYHAN -> 0.0f
        }
        val delayRing = FloatArray(delayRingSamples)
        var ringIdx = 0
        var prevBass = 0f

        val timedCues = mutableListOf<NarrationCue>()
        var cumulativeSamples = 0L
        var anyAudioWritten = false
        val tempTtsWavs = mutableListOf<File>()

        try {
            BufferedOutputStream(FileOutputStream(outputWavFile), 32_768).use { out ->
                out.write(buildWavHeader(targetRate, 1, 0))

                for ((idx, cue) in cues.withIndex()) {
                    val spoken = cleanNarrationForSpeech(cue.spokenText)
                    if (spoken.length < 3) continue

                    // Split overly long cues internally only for synthesis if > 1100 chars while keeping whole cue unified
                    val subChunks = splitCleanTextSafely(spoken, maxLen = 1000)
                    val cueStartUs = (cumulativeSamples * 1_000_000L) / targetRate.toLong()
                    var cueSamples = 0L

                    for (sub in subChunks) {
                        var pcm24k: ByteArray? = null

                        // 1. Primary Studio Path: Authentic Human Neural Voice (PradeepNeural / BashkarNeural)
                        val neuralMp3 = neuralTtsClient.synthesizeSentenceMp3(
                            text = sub,
                            preset = preset,
                            userPitchMultiplier = settings.voicePitch,
                            userRateMultiplier = settings.voiceRate
                        )
                        if (neuralMp3 != null) {
                            pcm24k = neuralTtsClient.decodeMp3BytesToMono24kPcm(neuralMp3, context.cacheDir)
                        }

                        // 2. Fallback Path (if offline): Android Device Male TTS -> resampled 24kHz mono PCM
                        if (pcm24k == null && isTtsReady && _ttsSupportedBn.value) {
                            val wavPart = File(context.cacheDir, "tts_cue_${idx}_${UUID.randomUUID()}.wav")
                            tempTtsWavs.add(wavPart)
                            val synthOk = synthesizeSingleChunkToTtsWav(sub, wavPart, settings)
                            if (synthOk) {
                                pcm24k = readWavAsMono24kPcm(wavPart)
                            }
                            runCatching { wavPart.delete() }
                        }

                        if (pcm24k != null && pcm24k.size >= 32) {
                            val alignedLen = pcm24k.size - (pcm24k.size % 2)
                            if (alignedLen > 0) {
                                ringIdx = masterMono24kPcmInPlace(
                                    bytes = pcm24k,
                                    length = alignedLen,
                                    preset = preset,
                                    reverbMix = reverbMix,
                                    delayRing = delayRing,
                                    ringIdxInitial = ringIdx,
                                    prevBassHolder = floatArrayOf(prevBass).also { prevBass = it[0] }
                                )
                                out.write(pcm24k, 0, alignedLen)
                                val writtenSamples = (alignedLen / 2).toLong()
                                cueSamples += writtenSamples
                                cumulativeSamples += writtenSamples
                                anyAudioWritten = true
                            }
                        }
                    }

                    // Natural breath pause at cue end (except after very last cue)
                    if (cueSamples > 0L) {
                        if (idx < cues.lastIndex) {
                            out.write(pausePcm)
                            cueSamples += pauseSamples.toLong()
                            cumulativeSamples += pauseSamples.toLong()
                        }
                        val cueDurationUs = (cueSamples * 1_000_000L) / targetRate.toLong()
                        timedCues.add(
                            cue.copy(
                                spokenText = spoken,
                                startUs = cueStartUs,
                                durationUs = cueDurationUs
                            )
                        )
                    }
                }
            }

            if (!anyAudioWritten || timedCues.isEmpty()) {
                outputWavFile.delete()
                return@withContext null
            }

            val totalPcmBytes = (cumulativeSamples * 2L).coerceAtMost(Int.MAX_VALUE.toLong() - 64L).toInt()
            RandomAccessFile(outputWavFile, "rw").use { raf ->
                raf.seek(0L)
                raf.write(buildWavHeader(targetRate, 1, totalPcmBytes))
            }
            outputWavFile to timedCues
        } catch (_: Exception) {
            runCatching { outputWavFile.delete() }
            null
        } finally {
            tempTtsWavs.forEach { runCatching { it.delete() } }
        }
    }

    suspend fun synthesizeBengaliVoiceoverToFile(spokenScript: String, outputWavFile: File): File? {
        val sentences = splitIntoNaturalSentences(cleanNarrationForSpeech(spokenScript))
        if (sentences.isEmpty()) return null
        val cues = sentences.chunked(2).map { group ->
            val line = group.joinToString("। ") + "।"
            NarrationCue(
                badge = "আবু উবাইদা AI",
                spokenText = line,
                displayBody = line
            )
        }
        return synthesizeTimedCuesToWav(cues, outputWavFile)?.first
    }

    private suspend fun synthesizeSingleChunkToTtsWav(
        chunkText: String,
        targetWav: File,
        settings: AssistantSettings
    ): Boolean {
        val uid = "cue_${UUID.randomUUID()}"
        val deferred = CompletableDeferred<Boolean>()
        pendingSynthesis[uid] = deferred
        val queued = withContext(Dispatchers.Main) {
            applyVoiceSettingsInternal(settings)
            textToSpeech?.synthesizeToFile(chunkText, Bundle(), targetWav, uid) ?: TextToSpeech.ERROR
        }
        if (queued != TextToSpeech.SUCCESS) {
            pendingSynthesis.remove(uid)
            return false
        }
        val ok = withTimeoutOrNull(30_000L) { deferred.await() } ?: false
        pendingSynthesis.remove(uid)
        return ok && targetWav.exists() && targetWav.length() > 128L
    }

    private fun readWavAsMono24kPcm(file: File): ByteArray? {
        return try {
            val all = file.readBytes()
            if (all.size < 44) return null
            val riff = String(all, 0, 4, Charsets.US_ASCII)
            val wave = String(all, 8, 4, Charsets.US_ASCII)
            if (riff != "RIFF" || wave != "WAVE") return null
            val bb = ByteBuffer.wrap(all).order(ByteOrder.LITTLE_ENDIAN)
            var pos = 12
            var channels = 1
            var sampleRate = 22050
            var bitsPerSample = 16
            while (pos + 8 <= all.size) {
                val id = String(all, pos, 4, Charsets.US_ASCII)
                val size = bb.getInt(pos + 4)
                if (size < 0) return null
                if (id == "fmt " && pos + 24 <= all.size) {
                    channels = bb.getShort(pos + 10).toInt()
                    sampleRate = bb.getInt(pos + 12)
                    bitsPerSample = bb.getShort(pos + 22).toInt()
                } else if (id == "data") {
                    if (bitsPerSample != 16 || sampleRate <= 0) return null
                    val dataStart = pos + 8
                    val dataEnd = min(all.size, dataStart + size)
                    if (dataEnd <= dataStart) return null
                    val slice = all.copyOfRange(dataStart, dataEnd)
                    return neuralTtsClient.resampleToMono24k(slice, sampleRate, channels)
                }
                pos += 8 + size + (size and 1)
            }
            null
        } catch (_: Exception) {
            null
        }
    }

    private fun masterMono24kPcmInPlace(
        bytes: ByteArray,
        length: Int,
        preset: IslamicVoicePreset,
        reverbMix: Float,
        delayRing: FloatArray,
        ringIdxInitial: Int,
        prevBassHolder: FloatArray
    ): Int {
        var ringIdx = ringIdxInitial
        val ringLen = delayRing.size
        var prevBass = prevBassHolder[0]
        val bassBoost = when (preset) {
            IslamicVoicePreset.MAULANA_UBAIDA -> 0.08f
            IslamicVoicePreset.QARI_ABDULLAH -> 0.16f
            IslamicVoicePreset.HAFIZ_RAYHAN -> 0.04f
        }
        var i = 0
        while (i + 1 < length) {
            val lo = bytes[i].toInt() and 0xFF
            val hi = bytes[i + 1].toInt()
            val sampleInt = (hi shl 8) or lo
            val x = sampleInt / 32768.0f

            prevBass += 0.04f * (x - prevBass)
            val warm = x + prevBass * bassBoost
            val shaped = if (reverbMix > 0.001f && ringLen > 1) {
                val delayed = delayRing[ringIdx]
                val wet = warm + delayed * reverbMix
                delayRing[ringIdx] = (warm + delayed * 0.22f).coerceIn(-0.98f, 0.98f)
                ringIdx = (ringIdx + 1) % ringLen
                wet
            } else {
                warm
            }

            val soft = tanh((shaped * 1.06f).toDouble()).toFloat()
            val outSample = (soft * 32760.0f).toInt().coerceIn(-32767, 32767)
            bytes[i] = (outSample and 0xFF).toByte()
            bytes[i + 1] = ((outSample ushr 8) and 0xFF).toByte()
            i += 2
        }
        prevBassHolder[0] = prevBass
        return ringIdx
    }

    private fun buildWavHeader(sampleRate: Int, channels: Int, dataSize: Int): ByteArray {
        val byteRate = sampleRate * channels * 2
        val blockAlign = (channels * 2).toShort()
        val chunkSize = 36 + dataSize
        return ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray(Charsets.US_ASCII))
            putInt(chunkSize)
            put("WAVE".toByteArray(Charsets.US_ASCII))
            put("fmt ".toByteArray(Charsets.US_ASCII))
            putInt(16)
            putShort(1.toShort())
            putShort(channels.toShort())
            putInt(sampleRate)
            putInt(byteRate)
            putShort(blockAlign)
            putShort(16.toShort())
            put("data".toByteArray(Charsets.US_ASCII))
            putInt(dataSize)
        }.array()
    }

    /**
     * লাইভ স্পিক: প্রথমে মানুষের মতো নিউরাল কণ্ঠ (bn-BD-PradeepNeural / bn-IN-BashkarNeural) দিয়ে বাজায়,
     * আর ইন্টারনেট না থাকলে অফলাইন পুরুষ TTS দিয়ে পড়ে শোনায়।
     */
    fun speak(text: String, onFinished: (() -> Unit)? = null) {
        val cleaned = cleanNarrationForSpeech(text)
        if (cleaned.isBlank()) {
            onFinished?.invoke()
            return
        }

        stopSpeakingInternal(resetState = false)
        speechFinishedCallback = onFinished
        _voiceState.value = VoiceState.Speaking(cleaned)

        val currentSettings = activeSettings
        liveNeuralJob = voiceScope.launch {
            val previewText = cleaned.take(900)
            val mp3Bytes = neuralTtsClient.synthesizeSentenceMp3(
                text = previewText,
                preset = currentSettings.voicePreset,
                userPitchMultiplier = currentSettings.voicePitch,
                userRateMultiplier = currentSettings.voiceRate
            )
            if (mp3Bytes != null && isActive) {
                val tempMp3 = File(context.cacheDir, "live_voice_${System.currentTimeMillis()}.mp3")
                val playedOk = runCatching {
                    FileOutputStream(tempMp3).use { it.write(mp3Bytes) }
                    withContext(Dispatchers.Main) {
                        val mp = MediaPlayer().apply {
                            setAudioAttributes(
                                AudioAttributes.Builder()
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                    .setUsage(AudioAttributes.USAGE_MEDIA)
                                    .build()
                            )
                            setDataSource(tempMp3.absolutePath)
                            setOnCompletionListener { player ->
                                runCatching { player.release() }
                                liveNeuralPlayer = null
                                runCatching { tempMp3.delete() }
                                _voiceState.value = VoiceState.Idle
                                val cb = speechFinishedCallback
                                speechFinishedCallback = null
                                cb?.invoke()
                            }
                            setOnErrorListener { player, _, _ ->
                                runCatching { player.release() }
                                liveNeuralPlayer = null
                                runCatching { tempMp3.delete() }
                                _voiceState.value = VoiceState.Idle
                                speechFinishedCallback = null
                                true
                            }
                        }
                        liveNeuralPlayer = mp
                        mp.prepare()
                        mp.start()
                    }
                    true
                }.getOrDefault(false)

                if (playedOk) return@launch
                runCatching { tempMp3.delete() }
            }

            // Offline fallback to device male-filtered TTS
            if (isActive) {
                speakViaDeviceTts(cleaned, currentSettings)
            }
        }
    }

    private fun speakViaDeviceTts(cleaned: String, settings: AssistantSettings) {
        if (!isTtsReady) {
            mainHandler.post {
                _voiceState.value = VoiceState.Idle
                val cb = speechFinishedCallback
                speechFinishedCallback = null
                cb?.invoke()
            }
            return
        }
        mainHandler.post {
            applyVoiceSettingsInternal(settings)
            val sentences = splitIntoNaturalSentences(cleaned)
            if (sentences.isEmpty()) {
                _voiceState.value = VoiceState.Idle
                val cb = speechFinishedCallback
                speechFinishedCallback = null
                cb?.invoke()
                return@post
            }

            val pauseMs = settings.voicePreset.sentencePauseMs.coerceIn(220L, 650L)
            val finalId = "spk_end_${UUID.randomUUID()}"
            activeFinalUtteranceId = finalId

            sentences.forEachIndexed { idx, sentence ->
                val isFirst = idx == 0
                val isLast = idx == sentences.lastIndex
                val queueMode = if (isFirst) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
                val uid = if (isLast) finalId else "spk_${idx}_${UUID.randomUUID()}"
                textToSpeech?.speak(sentence, queueMode, null, uid)
                if (!isLast) {
                    textToSpeech?.playSilentUtterance(pauseMs, TextToSpeech.QUEUE_ADD, "pause_${idx}_${UUID.randomUUID()}")
                }
            }
        }
    }

    private fun splitCleanTextSafely(text: String, maxLen: Int): List<String> {
        if (text.length <= maxLen) return listOf(text)
        val sentences = splitIntoNaturalSentences(text)
        if (sentences.isEmpty()) return text.chunked(maxLen)
        val out = mutableListOf<String>()
        val cur = StringBuilder()
        for (s in sentences) {
            val formatted = if (s.endsWith("।") || s.endsWith("?") || s.endsWith("!")) s else "$s।"
            if (cur.length > 0 && cur.length + formatted.length + 1 > maxLen) {
                out.add(cur.toString().trim())
                cur.setLength(0)
            }
            if (cur.length > 0) cur.append(" ")
            cur.append(formatted)
        }
        if (cur.length > 0) out.add(cur.toString().trim())
        return out
    }

    private fun splitIntoNaturalSentences(cleaned: String): List<String> {
        return cleaned
            .split(Regex("[।!?\\n]+"))
            .map { it.trim() }
            .filter { it.length >= 2 }
    }

    private fun stopSpeakingInternal(resetState: Boolean) {
        liveNeuralJob?.cancel()
        liveNeuralJob = null
        mainHandler.post {
            activeFinalUtteranceId = null
            speechFinishedCallback = null
            runCatching { liveNeuralPlayer?.stop() }
            runCatching { liveNeuralPlayer?.release() }
            liveNeuralPlayer = null
            textToSpeech?.stop()
            if (resetState && _voiceState.value is VoiceState.Speaking) {
                _voiceState.value = VoiceState.Idle
            }
        }
    }

    fun stopSpeaking() {
        stopSpeakingInternal(resetState = true)
    }

    fun setProcessing() {
        _voiceState.value = VoiceState.Processing
    }

    fun setIdle() {
        _voiceState.value = VoiceState.Idle
    }

    fun release() {
        pendingSynthesis.values.forEach { it.complete(false) }
        pendingSynthesis.clear()
        liveNeuralJob?.cancel()
        voiceScope.cancel()
        mainHandler.post {
            activeFinalUtteranceId = null
            speechFinishedCallback = null
            runCatching { liveNeuralPlayer?.stop() }
            runCatching { liveNeuralPlayer?.release() }
            liveNeuralPlayer = null
            speechRecognizer?.destroy()
            speechRecognizer = null
            textToSpeech?.stop()
            textToSpeech?.shutdown()
            textToSpeech = null
        }
    }

    companion object {
        private val STRUCTURAL_LABELS = listOf(
            "বিসমিল্লাহ ও সূচনা",
            "কুরআনের বাণী",
            "সহীহ হাদিসের শিক্ষা",
            "বাস্তব শিক্ষা ও আমল",
            "মূল আলোচনা",
            "উপসংহার",
            "সমাপ্তি",
            "ভূমিকা",
            "সূচনা",
            "ইনট্রো",
            "আউট্রো",
            "Intro",
            "Outro",
            "Conclusion",
            "Introduction"
        )

        private val FEMALE_SAHABA_KEYWORDS = listOf(
            "আয়েশা", "আয়েশা", "খাদীজা", "খাদিজা", "ফাতিমা", "হাফসা",
            "জয়নব", "উম্মে", "সুমাইয়া", "আসমা", "হালিমা", "মরিয়ম"
        )

        /**
         * সম্মানসূচক ইসলামি উপাধি সম্পূর্ণ উচ্চারণ (সাল্লাল্লাহু আলাইহি ওয়াসাল্লাম,
         * আলাইহিস সালাম, রাদিআল্লাহু তাআলা আনহু) এবং সূরা-আয়াত রেফারেন্সকে
         * 'মাইনাস' ছাড়া সঠিক বাংলা '১ থেকে ৩ নম্বর আয়াত'-এ রূপান্তর করে।
         */
        fun formatIslamicSpeechText(input: String): String {
            if (input.isBlank()) return ""
            var text = input

            // 1. Expand Surah:Ayah ranges cleanly BEFORE touching hyphens: e.g., ১০৩:১-৩ -> ১০৩ নম্বর সূরার ১ থেকে ৩ নম্বর আয়াত
            text = text.replace(
                Regex("([0-9০-৯]{1,3})\\s*[:：]\\s*([0-9০-৯]{1,3})\\s*[-–—]\\s*([0-9০-৯]{1,3})")
            ) { mr ->
                "${mr.groupValues[1]} নম্বর সূরার ${mr.groupValues[2]} থেকে ${mr.groupValues[3]} নম্বর আয়াত"
            }
            // Single Surah:Ayah citation: e.g., ১০৩:১ -> ১০৩ নম্বর সূরার ১ নম্বর আয়াত
            text = text.replace(
                Regex("([0-9০-৯]{1,3})\\s*[:：]\\s*([0-9০-৯]{1,3})")
            ) { mr ->
                "${mr.groupValues[1]} নম্বর সূরার ${mr.groupValues[2]} নম্বর আয়াত"
            }
            // Numeric ranges like ১-৩, 1-3 -> ১ থেকে ৩ (never read "-" as minus!)
            text = text.replace(
                Regex("([0-9০-৯]+)\\s*[-–—]\\s*([0-9০-৯]+)")
            ) { mr ->
                "${mr.groupValues[1]} থেকে ${mr.groupValues[2]}"
            }

            // 2. Prophet Muhammad (Peace Be Upon Him) honorific expansion
            text = text
                .replace(Regex("\\(\\s*(?:সা\\.?|সাঃ|সাল্লাল্লাহু আলাইহি ওয়া?সাল্লাম)\\s*\\)"), " সাল্লাল্লাহু আলাইহি ওয়াসাল্লাম")
                .replace(Regex("(নবী\\s*করীম|হযরত\\s*মুহাম্মদ|হযরত\\s*মুহাম্মাদ|রাসূলুল্লাহ|রাসূল|নবীজি|নবী)(?:\\s*সাঃ|\\s*সা\\.)(?=\\s|$|[,।\\-–—])"), "$1 সাল্লাল্লাহু আলাইহি ওয়াসাল্লাম")
                .replace(Regex("\\s+সাঃ(?=\\s|$|[,।\\-–—])"), " সাল্লাল্লাহু আলাইহি ওয়াসাল্লাম")
                .replace(Regex("\\s+সা\\.(?=\\s|$|[,।\\-–—])"), " সাল্লাল্লাহু আলাইহি ওয়াসাল্লাম")

            // 3. Other Prophets / Angels honorific expansion -> আলাইহিস সালাম
            text = text
                .replace(Regex("\\(\\s*(?:আ\\.?|আঃ)\\s*\\)"), " আলাইহিস সালাম")
                .replace(Regex("\\s+(?:আঃ|আ\\.)(?=\\s|$|[,।\\-–—])"), " আলাইহিস সালাম")

            // 4. Companions (Sahaba) honorific expansion -> রাদিআল্লাহু তা'আলা আনহু / আনহা
            val raRegex = Regex("([^\\n।]{0,40})\\(\\s*(?:রা\\.?|রাঃ|রাদি\\.?)\\s*\\)")
            text = raRegex.replace(text) { mr ->
                val prefix = mr.groupValues[1]
                val isFemaleCompanion = FEMALE_SAHABA_KEYWORDS.any { prefix.contains(it) }
                val phrase = if (isFemaleCompanion) "রাদিআল্লাহু তাআলা আনহা" else "রাদিআল্লাহু তাআলা আনহু"
                "$prefix $phrase"
            }
            text = text.replace(Regex("\\s+(?:রাঃ|রা\\.)(?=\\s|$|[,।\\-–—])"), " রাদিআল্লাহু তাআলা আনহু")

            // 5. Scholars -> রহমাতুল্লাহি আলাইহি
            text = text
                .replace(Regex("\\(\\s*(?:রহ\\.?|রহঃ)\\s*\\)"), " রহমাতুল্লাহি আলাইহি")
                .replace(Regex("\\s+রহঃ(?=\\s|$|[,।\\-–—])"), " রহমাতুল্লাহি আলাইহি")

            return text
                .replace(Regex("সাল্লাল্লাহু আলাইহি ওয়াসাল্লাম\\s*[-–—]?\\s*কে"), "সাল্লাল্লাহু আলাইহি ওয়াসাল্লামকে")
                .replace(Regex("আলাইহিস সালাম\\s*[-–—]?\\s*এর"), "আলাইহিস সালামের")
                .replace(Regex("রাদিআল্লাহু তাআলা আনহু\\s*[-–—]?\\s*এর"), "রাদিআল্লাহু তাআলা আনহুর")
                .replace(Regex("[ ]{2,}"), " ")
                .trim()
        }

        /**
         * ভয়েসওভার থেকে টাইমকোড, ব্র্যাকেট, হেডিং বাদ দেয় এবং ইসলামি সম্মানসূচক উপাধি ও
         * সূরা-আয়াত নম্বর সম্পূর্ণ ও সঠিকভাবে উচ্চারণ উপযোগী করে।
         */
        fun cleanNarrationForSpeech(rawText: String): String {
            if (rawText.isBlank()) return ""
            var cleaned = rawText
                // Remove [ ... ] blocks
                .replace(Regex("\\[[\\s\\S]*?\\]"), "\n")
                // Remove Arabic Unicode blocks so Bengali voice reads smoothly
                .replace(Regex("[\\u0600-\\u06FF\\u0750-\\u077F\\uFB50-\\uFDFF\\uFE70-\\uFEFF]+"), " ")
                // Remove timecodes (00:10 - 00:30) ONLY when starting with 0/00 hours/mins or >= 2 digits colon 2 digits like 00:10, ০০:৩০
                .replace(
                    Regex("[0০]{1,2}\\s*[:：.]\\s*[0-9০-৯]{2}(?:\\s*[:：.]\\s*[0-9০-৯]{2})?(?:\\s*(?:-|–|—|থেকে|to)\\s*[0০]{1,2}\\s*[:：.]\\s*[0-9০-৯]{2})?"),
                    " "
                )
                .replace(Regex("(?:^|\\s)[0০]{2}[0-9০-৯]{2}(?:\\s*(?:-|–|—|থেকে|to)\\s*[0০]{2}[0-9০-৯]{2})?(?=\\s|$|[.,।|])"), " ")
                .replace(Regex("[*_#`~|]+"), " ")
                .replace(Regex("[📖📜📚🎬✅⚠️•👉🔊۝]+"), " ")

            cleaned = formatIslamicSpeechText(cleaned)

            val processedLines = cleaned.lines().mapNotNull { rawLine ->
                var line = rawLine.trim()
                if (line.isBlank()) return@mapNotNull null

                line = line.replace(
                    Regex("^(?:স্লাইড|দৃশ্য|অংশ|ধাপ|পর্ব|Scene|Slide|Part)\\s*[0-9০-৯]+\\s*[:：\\-|—]*\\s*", RegexOption.IGNORE_CASE),
                    ""
                ).trim()

                for (label in STRUCTURAL_LABELS) {
                    if (line.equals(label, ignoreCase = true)) {
                        line = ""
                        break
                    }
                    val prefixRegex = Regex("^${Regex.escape(label)}\\s*[:：\\-|—।]*\\s*", RegexOption.IGNORE_CASE)
                    line = line.replace(prefixRegex, "").trim()
                }

                line.takeIf { it.isNotBlank() }
            }

            return processedLines
                .joinToString("\n")
                .replace(Regex("[ \\t]+"), " ")
                .replace(Regex("\\n{2,}"), "\n")
                .trim()
        }
    }
}
